"""The shape of a control record, on disk and on the wire (vicaria-docs RFC 0065 §3.7).

``sg.control.v1`` lines are what a turn decided and what ran, never a word of
text: the recipe *id*, the prompt's *length*, the model and effort, and the
contract's own typed records. Every kind carries the ids the others join on
(``session_id``, ``prompt_id``, ``decision_id``), and the records door
(``POST /v1/records``, ``vicaria_server/records.py``) takes each kind in a
closed shape, two hundred lines a batch and 64 KiB a line, with any key that
could hold text refused at any depth.

This module is that shape and nothing else. Where a record is kept is the
packaging's: the plugins append it to a shard under the data directory
(``smart_gateway.control.records``), the SDK to its journal (``vicaria_sdk``).
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

CONTROL_RECORD_SCHEMA = "sg.control.v1"

#: The kinds the records door takes (``vicaria_server/records.py`` ``KINDS``).
WIRE_KINDS = ("stage", "dispatch", "request", "assignment", "usage", "error", "signal", "feedback")

#: The door's bounds: lines per batch, and bytes of one line's JSON.
RECORDS_BATCH = 200
MAX_LINE_BYTES = 64 * 1024

#: Keys the envelope owns. A payload carrying one of them would overwrite it ---
#: and a record whose ``schema`` was overwritten by an inner one is not dropped
#: loudly, it is skipped silently by every reader, which is how an entire record
#: kind can go missing without a single failure. Refused instead.
ENVELOPE_KEYS = ("schema", "recorded_at", "recorder", "kind", "launch")

#: Keys that hold text a person typed or a model produced; the door refuses a
#: line carrying one at any depth (``vicaria_server/records.py`` ``TEXT_KEYS``).
TEXT_KEYS = frozenset(
    {
        "prompt",
        "prompt_text",
        "text",
        "content",
        "messages",
        "recipe_text",
        "system",
        "transcript",
        "body",
        "comment",
        "last_assistant_message",
    }
)
#: How deep the door looks for one.
TEXT_KEY_DEPTH = 16


def envelope(
    kind: str, *, version: str, recorded_at: str, component: str | None = None
) -> dict[str, Any]:
    """What every control record opens with. ``component`` names the recorder;
    the plugins have always named it by the record's kind."""
    return {
        "schema": CONTROL_RECORD_SCHEMA,
        "recorded_at": recorded_at,
        "recorder": {"component": component or kind, "version": version},
        "kind": kind,
    }


def refuse_envelope_clash(kind: str, fields: Mapping[str, Any]) -> None:
    """A payload may not carry a key the envelope owns (:data:`ENVELOPE_KEYS`)."""
    clashing = sorted(set(fields) & set(ENVELOPE_KEYS))
    if clashing:
        raise ValueError(
            f"a {kind} record's payload may not carry the envelope key(s) {clashing}: "
            "nest the inner record under its own key instead"
        )


def text_key(value: Any, depth: int = 0) -> str | None:
    """The first text-holding key with a value anywhere in ``value``, the way the
    door finds it; ``None`` when there is none."""
    if depth > TEXT_KEY_DEPTH:
        return "too_deep"
    if isinstance(value, Mapping):
        for key, child in value.items():
            if isinstance(key, str) and key in TEXT_KEYS and child not in (None, "", 0, False):
                return key
            found = text_key(child, depth + 1)
            if found is not None:
                return found
    elif isinstance(value, list | tuple):
        for item in value:
            found = text_key(item, depth + 1)
            if found is not None:
                return found
    return None


__all__ = [
    "CONTROL_RECORD_SCHEMA",
    "ENVELOPE_KEYS",
    "MAX_LINE_BYTES",
    "RECORDS_BATCH",
    "TEXT_KEYS",
    "TEXT_KEY_DEPTH",
    "WIRE_KINDS",
    "envelope",
    "refuse_envelope_clash",
    "text_key",
]
