"""vicaria-client: the client core every Vicaria client runs (vicaria-docs RFC 0065 §3.7).

RFC 0009's rule is one client core and a thin adapter per harness. This
package is that core as a distribution of its own: the Claude Code and Codex
hooks, the commit point and the OpenCode bridge import it from inside
``smart_gateway``, and the SDK (``vicaria_sdk``) imports it in a vendor's
process. It depends on ``vicaria_contracts`` and the standard library, and on
nothing of a developer machine's or a server's.

What it holds, and where it came from (see README.md beside this file):

- :mod:`vicaria_client.adapter`: the harness-neutral middle as a sequence ---
  the plan request's body, the answer taken as this decision's or refused, the
  reference re-admitted against the delivered client configuration --- carved
  from ``smart_gateway.control.adapter``;
- :mod:`vicaria_client.plans`: the plan wire and its reference server, moved
  whole from ``smart_gateway.control.plans``;
- :mod:`vicaria_client.records`: the shape of a control record, carved from
  ``smart_gateway.control.records``;
- :mod:`vicaria_client.events`: the ``cb.session_event.v8`` builder and its
  content digest, moved whole from ``smart_gateway.capture.events``;
- :mod:`vicaria_client.transport`: the origin-bound delivery connection, moved
  whole from ``smart_gateway.capture.transport``;
- :mod:`vicaria_client.scenarios`: the scripted plan source's answers RFC 0009
  §6 needs, moved whole from ``smart_gateway.conformance.scenarios``, which the
  plugins' drivers and the SDK's kit both run.
"""

__version__ = "0.1.0"
