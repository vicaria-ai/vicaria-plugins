# vicaria-client

The client core (vicaria-docs RFC 0065 §3.7, D2): RFC 0009's one client core
as an actual package, so *one core, three packagings* is a dependency graph
rather than a sentence. The Claude Code and Codex hooks, the commit point and
the OpenCode bridge import it from inside `smart_gateway`; `vicaria-sdk`
imports it in a vendor's process. It depends on `vicaria-contracts` and the
standard library only, and imports neither `smart_gateway` nor a server.

## What moved, and why

The rule was to move the *sequence* and leave the laptop's *shape*: a module
that is wholly sequence moved whole and left a `sys.modules` alias behind (the
pattern of `smart_gateway.billing`); a module that mixes the two gave up its
neutral part, and the `smart_gateway` module now imports it.

| Was | Now | How | What stayed, and why |
| --- | --- | --- | --- |
| `smart_gateway.control.plans` | `vicaria_client.plans` | moved whole; the old name is an alias | nothing: the plan client, its typed outcomes and the reference plan server are the wire, which every client and the conformance drivers speak |
| `smart_gateway.capture.events` | `vicaria_client.events` | moved whole; alias | nothing: the v7 builder and the digest are the contract's, for the collector and the SDK alike |
| `smart_gateway.capture.transport` | `vicaria_client.transport` | moved whole; alias | nothing: an origin-bound delivery connection with one replay of a deduplicated capture batch |
| `smart_gateway.conformance.scenarios` | `vicaria_client.scenarios` | moved whole; alias | nothing: the scripted plan source's answers (retain, apply, suggest, a moved baseline, a superseded revision, `cannot_execute`, a server error), which the drivers and the SDK's kit both script |
| `smart_gateway.control.records` | `vicaria_client.records` | the shape carved out: the schema, the envelope and its keys, the door's batch and line bounds, the text keys | the shard under the data directory (`write_record`, `iter_records`) and the benchmark launch a record is stamped with: a developer machine's |
| `smart_gateway.control.adapter` | `vicaria_client.adapter` | the sequence carved out: the plan request's body, the answer taken as this decision's or refused, the reference re-admitted against the client configuration's admission block, `ident`, `advisor_sentence` | `AdapterCore`: state in a file per session, records to disk, `control.json`, the benchmark's assignment, induced faults; a laptop's one-session process |

What did not move at all is a developer machine's whole: the collector's four
gates for a person (`smart_gateway.capture.collector`), the on-disk queue
(`capture.store`), the device link and the capture API client. The SDK reuses
the builder, the digest and the bounds, and none of the gates (RFC 0065 §3.5).

## Packaging

The code lives once, at `src/vicaria_client/`, so a checkout runs it with
`PYTHONPATH=src` and nothing installed, as the plugin smoke job does. Three
wheels carry it:

- `packages/vicaria-client/` builds `vicaria_client-*.whl`, this package alone,
  depending on `vicaria-contracts`;
- the repository root builds `smart_gateway-*.whl`, which carries
  `vicaria_client` beside `smart_gateway`, because the plugin runtime installs
  the root wheel and the contracts wheel and nothing else, and CI installs each
  pinned repository root as one project (`prepare_test_workspace.py`);
- `packages/vicaria-sdk/` builds `vicaria_sdk-*.whl`, the SDK alone, depending
  on `vicaria-client`; the smart-gateway wheel no longer carries it, so a vendor
  that installs `vicaria-sdk` gets no plugin, no `sg` command and no proxy.

    pip wheel --no-deps packages/vicaria-client packages/vicaria-sdk
