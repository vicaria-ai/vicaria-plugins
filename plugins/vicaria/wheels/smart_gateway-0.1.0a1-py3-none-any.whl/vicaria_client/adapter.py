"""The harness-neutral middle of every adapter, as a sequence (vicaria-docs RFC 0065 §3.1, §3.7).

RFC 0009's rule is one client core and a thin adapter per harness. The
contracts hold the decide-then-resolve sequence that cannot be run out of
order (``vicaria_contracts.client``); between the harness's event and that
sequence, every adapter does the same three things, and this module is them:

1. **ask**: the plan request's body, built from the episode, the decision id and
   the context the adapter read off its harness (:func:`plan_request`);
2. **take the answer**: a plan that answers another decision is not this
   decision's plan, and is a refusal rather than adopted under either id
   (:func:`decided_from`); no answer is :func:`vicaria_contracts.client.no_decision`;
3. **re-admit**: a configuration that runs without a served plan --- the
   reference --- is admitted against the organization's rules the client
   configuration delivered (:func:`admit_against`), as the OpenCode plugin and
   the SDK both do.

What is a harness's or a machine's stays with it. The Claude Code hook and the
OpenCode bridge keep their state in files under the data directory and read
``control.json`` (``smart_gateway.control.adapter.AdapterCore``); the SDK keeps
its sessions in memory behind a store and reads the client configuration
(``vicaria_sdk``). Both call this.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from vicaria_contracts.capability import Dimension
from vicaria_contracts.client import Decided, Episode, decide, no_decision
from vicaria_contracts.decision import UnavailableReason
from vicaria_contracts.plan import Configuration, Plan
from vicaria_contracts.staging import Admission

from vicaria_client.plans import PLAN_REQUEST_SCHEMA

#: The order a configured effort bound is read in.
EFFORT_RANK = {"low": 0, "medium": 1, "high": 2}


def ident(value: Any) -> str | None:
    """A printable identifier, or ``None`` — never a coerced one."""
    return (
        value if isinstance(value, str) and 0 < len(value) <= 256 and value.isprintable() else None
    )


def advisor_sentence(reason: Any) -> str | None:
    """The advisor's sentence a plan's reason carries, if any.

    The service appends it once, to the answer that first carries it:
    ``advisor(<code>): <sentence>``. Each translator shows it beside the
    recommendation it explains, so a developer reads what a suggestion rests on.
    """
    head, sep, sentence = str(reason or "").partition("): ")
    sentence = sentence.strip()
    return sentence if sep and head.startswith("advisor(") and sentence else None


def plan_request(
    episode: Episode,
    decision_id: str,
    context: Mapping[str, Any],
    *,
    assignment: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """The body of ``POST /v1/plan`` (``vicaria.plan-request.v1``): the
    descriptor and the active configuration the episode was opened with, the
    decision id, and the context the adapter read. ``assignment`` is the
    benchmark's arm where a launch has one."""
    body: dict[str, Any] = {
        "schema": PLAN_REQUEST_SCHEMA,
        "decision_id": decision_id,
        "episode_id": episode.episode_id,
        "request_revision": episode.request_revision,
        "descriptor": episode.descriptor.to_dict(),
        "active_config": {d.value: episode.active_config.value(d) for d in Dimension},
    }
    if assignment is not None:
        body["assignment"] = dict(assignment)
    body["context"] = dict(context)
    return body


def decided_from(episode: Episode, decision_id: str, plan: Plan) -> Decided:
    """The plan source's answer, validated: a plan answering a different
    decision is treated as a refusal rather than adopted under either id."""
    if plan.decision_id != decision_id:
        return no_decision(episode, UnavailableReason.REFUSED, decision_id=decision_id)
    return decide(episode, plan)


def admit_against(config: Configuration, admission: Mapping[str, Any] | None) -> Admission:
    """The organization's answer for ``config`` from the client configuration's
    ``admission`` block (``allowed_models``; ``effort`` with ``min`` and
    ``max``), as RFC 0009 §4.3 re-admits the reference. No block admits."""
    rules = admission or {}
    allowed = rules.get("allowed_models") or []
    if allowed and config.model not in allowed:
        return Admission(
            admitted=False, reason=f"model {config.model} is not allowed for this organization"
        )
    bounds = rules.get("effort") or {}
    if isinstance(bounds, Mapping) and (bounds.get("min") or bounds.get("max")):
        rank = EFFORT_RANK.get(config.effort)
        if rank is None:
            return Admission(
                admitted=False,
                reason=f"effort {config.effort} cannot be shown to be within the "
                "organization's bounds",
            )
        low = EFFORT_RANK.get(str(bounds.get("min")), 0)
        high = EFFORT_RANK.get(str(bounds.get("max")), 2)
        if rank < low or rank > high:
            return Admission(
                admitted=False,
                reason=f"effort {config.effort} is outside the organization's bounds",
            )
    return Admission(admitted=True)


__all__ = [
    "EFFORT_RANK",
    "admit_against",
    "advisor_sentence",
    "decided_from",
    "ident",
    "plan_request",
]
