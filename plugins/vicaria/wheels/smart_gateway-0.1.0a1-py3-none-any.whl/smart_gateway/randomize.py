"""Assigning a configuration to an episode, and recording the probability it was.

`assignment.py` writes the record `gate.py` reads and says of itself: *"It does
not decide. Something upstream chooses the configuration and the arm."* Nothing
was that something. This module is one — the randomizing one — and it exists
separately so that the record stays usable by any other assigner while this
stays replaceable.

THE DRAW IS A FUNCTION, NOT A GENERATOR

Every assignment here is derived from ``sha256(salt, experiment, episode_id)``.
No RNG state, no clock, no counter. That is not a performance choice; it is the
only way the two defects below stay impossible rather than unlikely.

*Re-randomizing on retry.* An episode that is retried — a timeout, a dropped
connection, a resumed session — must land in the arm it was already in. Draw
again and the same unit appears in both arms, each record well-formed, each
recorded propensity describing a draw that is not the one the design made. The
gate cannot see it: both attempts are `randomized`, both name the experiment,
both record the same propensity, and the unit is silently counted twice under
two treatments. With the draw a pure function of the episode id, a retry is not
a new draw and there is nothing to get wrong.

*One uniform for two decisions.* Enrollment and arm are separate draws with
separate salts. Sharing one uniform correlates them, and the failure is total
rather than subtle: with 5% enrollment and two labels, every enrolled unit has
``u < 0.05``, so every one of them lands in the first arm while its record says
the probability was 0.5. Every field is well-formed, the gate finds one
propensity and no mixed experiments, and the comparison it then runs is between
an arm and nothing. ``test_randomize.py`` builds that implementation to show
what it produces.

WHY ALLOCATION IS EQUAL, AND WHY THAT IS NOT A SIMPLIFICATION

:class:`Experiment` cannot express a 70/30 split, because this repository has
one analysis path and that path refuses one. ``gate.decide`` collects the
distinct propensities across the comparison and refuses on
``unequal_propensity`` unless there is exactly one — it has no weighting
estimator, so unequal allocation is not something it analyses imprecisely, it is
something it declines to analyse at all.

Unequal allocation is a legitimate design. It is not a legitimate design *here*
yet, and a type that could express it would let an operator configure a study
that runs for weeks and is then refused at the only gate that could read it —
discovered after the fact, which is the class of failure this repository keeps
moving earlier. The restriction lifts when an estimator that can weight arrives,
together with it and not before.

WHAT IT DOES NOT DO

It does not choose *which* configurations compete; the labels are the caller's.
It does not decide when an experiment starts or stops. And it proves nothing
about authenticity — the episode id is a string a caller supplies, so an
assigner fed the same id for two different episodes will put them in the same
arm and be right to.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from math import isfinite

from smart_gateway.assignment import Assignment, AssignmentKind

__all__ = [
    "Experiment",
    "Unenrolled",
    "assign",
]

#: Distinct per decision, so enrollment and arm are independent draws over the
#: same episode id. Versioned because changing either string re-randomizes every
#: episode that has not yet run — which is a design change, not a refactor.
_ENROLLMENT_SALT = "sg.randomize.enrollment.v1"
_ARM_SALT = "sg.randomize.arm.v1"

#: 2**64, the range of the digest prefix below.
_SCALE = float(1 << 64)


def _uniform(salt: str, experiment_id: str, episode_id: str) -> float:
    """A uniform in [0, 1), stable across processes, hosts and releases.

    The parts are joined on NUL rather than concatenated, because ``("ab", "c")``
    and ``("a", "bc")`` otherwise hash identically — two different episodes in
    two different experiments drawing the same number, which is the kind of
    collision that produces a real imbalance and no evidence of one.
    """
    material = "\x00".join((salt, experiment_id, episode_id)).encode("utf-8")
    return int.from_bytes(hashlib.sha256(material).digest()[:8], "big") / _SCALE


@dataclass(frozen=True, slots=True)
class Experiment:
    """A running experiment: which labels compete, and over how much traffic.

    ``enrollment`` is the share of episodes randomized at all. The rest get the
    caller's :class:`Unenrolled` answer and carry **no** experiment identifier,
    because they were not in one — naming it would put a unit the design never
    randomized into the population the gate reads.
    """

    experiment_id: str
    config_labels: tuple[str, ...]
    enrollment: float = 1.0

    def __post_init__(self) -> None:
        if not isinstance(self.experiment_id, str) or not self.experiment_id:
            raise ValueError(f"experiment_id must be a nonempty string, got {self.experiment_id!r}")

        labels = tuple(self.config_labels)
        object.__setattr__(self, "config_labels", labels)
        for label in labels:
            if not isinstance(label, str) or not label:
                raise ValueError(f"every config_label must be a nonempty string, got {label!r}")
        if len(labels) < 2:
            raise ValueError(
                f"an experiment needs at least two labels, got {len(labels)} — one arm is "
                "not a draw, and a record asserting propensity 1.0 is the coin that always "
                "landed the same way that `propensity` being absent-not-1.0 exists to refuse"
            )
        if len(set(labels)) != len(labels):
            raise ValueError(
                "config_labels must be distinct: `gate._arm_of` resolves an arm by comparing "
                "the label, so two arms sharing one are a single arm to every reader, and "
                "each unit would record half the probability it actually had"
            )

        if isinstance(self.enrollment, bool) or not isinstance(self.enrollment, int | float):
            raise ValueError(f"enrollment must be a number, got {self.enrollment!r}")
        if not isfinite(self.enrollment) or not 0.0 < float(self.enrollment) <= 1.0:
            raise ValueError(
                f"enrollment must be in (0, 1], got {self.enrollment!r} — an experiment "
                "nobody can enter is not running, and it should be removed rather than "
                "configured to enrol no one"
            )
        object.__setattr__(self, "enrollment", float(self.enrollment))

    @property
    def propensity(self) -> float:
        """The probability of any one arm, given that the episode was enrolled.

        Conditional on enrollment, and deliberately not multiplied by it. The
        gate's comparison contains only enrolled units — everything else fails
        `_arm_of` — so the probability that weights it is the one within that
        population. Folding enrollment in would scale both arms by the same
        factor, leave the design looking balanced, and make every recorded
        probability wrong by exactly the amount nobody would notice.
        """
        return 1.0 / len(self.config_labels)

    def enrolls(self, episode_id: str) -> bool:
        return _uniform(_ENROLLMENT_SALT, self.experiment_id, episode_id) < self.enrollment

    def arm_for(self, episode_id: str) -> str:
        """Which label this episode draws. A pure function of the two ids."""
        draw = _uniform(_ARM_SALT, self.experiment_id, episode_id)
        index = int(draw * len(self.config_labels))
        # `draw` is in [0, 1), so `index` is in range; the clamp costs nothing and
        # removes any dependence on that argument holding for every float.
        return self.config_labels[min(index, len(self.config_labels) - 1)]


@dataclass(frozen=True, slots=True)
class Unenrolled:
    """What runs when this episode is not randomized.

    Required rather than defaulted: an episode outside the experiment still ran
    *something*, and the two honest answers — a policy chose it, or it is the
    reference — are different facts about the system. Defaulting to either would
    put a claim in the record that the caller never made.
    """

    kind: AssignmentKind
    config_label: str
    policy_bundle_id: str | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.kind, AssignmentKind):
            raise ValueError(f"kind must be an AssignmentKind, got {type(self.kind).__name__}")
        if self.kind is AssignmentKind.RANDOMIZED:
            raise ValueError(
                "an unenrolled episode was not randomized — recording it as `randomized` "
                "admits a unit to an arm comparison the design never drew it into"
            )
        if not isinstance(self.config_label, str) or not self.config_label:
            raise ValueError(f"config_label must be a nonempty string, got {self.config_label!r}")


def assign(
    *,
    decision_id: str,
    episode_id: str,
    experiment: Experiment | None,
    unenrolled: Unenrolled,
) -> Assignment:
    """The assignment for one episode. Same inputs, same answer, always.

    ``experiment`` is ``None`` when none is running, which is the ordinary case
    and not an error: the caller still gets a record, because an episode that was
    never randomized is a fact the evidence needs rather than a gap in it.

    The recorded propensity is read from the same experiment that made the draw,
    so the number in the record is the number the design used. A caller passing
    the probability alongside the arm would be maintaining it in two places, and
    the copy that drifts is the one the analysis trusts.
    """
    if experiment is not None and not isinstance(experiment, Experiment):
        raise ValueError(
            f"experiment must be an Experiment or None, got {type(experiment).__name__}"
        )
    if not isinstance(unenrolled, Unenrolled):
        raise ValueError(f"unenrolled must be an Unenrolled, got {type(unenrolled).__name__}")

    if experiment is None or not experiment.enrolls(episode_id):
        return Assignment(
            decision_id=decision_id,
            episode_id=episode_id,
            kind=unenrolled.kind,
            config_label=unenrolled.config_label,
            policy_bundle_id=unenrolled.policy_bundle_id,
        )

    return Assignment(
        decision_id=decision_id,
        episode_id=episode_id,
        kind=AssignmentKind.RANDOMIZED,
        config_label=experiment.arm_for(episode_id),
        experiment=experiment.experiment_id,
        propensity=experiment.propensity,
    )
