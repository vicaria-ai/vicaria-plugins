"""Data directory and config.json (spec section 8.1).

One resolution rule for hooks, the receiver and every `sg` command, so they can never
disagree about where the data lives. Unknown keys are refused (exit 2) because a
misspelled gate parameter silently falling back to a default would corrupt a
pre-registered decision.
"""

from __future__ import annotations

import copy
import hashlib
import json
import os
import re
from collections.abc import Mapping
from pathlib import Path

from smart_gateway.rawlog import atomic_write, encode_line

__all__ = [
    "CONFIG_FILE",
    "CONFIG_SCHEMA",
    "DATA_DIR_ENV",
    "DEFAULT_CONFIG",
    "DEFAULT_DATA_DIR_NAME",
    "ConfigError",
    "config_digest",
    "ensure_data_dir",
    "load_config",
    "resolve_data_dir",
    "validate_config",
    "write_config",
]

DATA_DIR_ENV = "SG_DATA_DIR"
DEFAULT_DATA_DIR_NAME = ".smart-gateway"
CONFIG_FILE = "config.json"
CONFIG_SCHEMA = "sg.config.v1"
_SUBDIRS = ("raw", "state", "derived", "reports")

DEFAULT_CONFIG: dict = {
    "schema": CONFIG_SCHEMA,
    "team": "payments",
    "week_start": "monday",
    # {0,9} rather than the spec's {1,9}: the spec's own vector `feature/T-123-fixture -> T-123`
    # needs a one-letter project key to match.
    "task_id_branch_regex": r"(?i)\b([A-Z][A-Z0-9]{0,9}-\d+)\b",
    "protected_branches": ["main", "master", "develop", "HEAD"],
    "engineer_usd_per_hour": 150,
    "ci_usd_per_minute": None,
    "delay_usd_per_hour": None,
    "repair_minutes_team_estimate": 15,
    "otel": {"mode": "local", "port": 4318},
    "billing": {"scope": {"kind": "auto", "ids": []}, "workspace_id": None, "model_aliases": {}},
    "gate": {
        "current_config_label": "fable-high",
        "candidate_config_labels": ["sonnet-medium"],
        "delta": 0.03,
        "primary_outcome": "reviewer_accepted",
        "quality_floor": None,
        "alpha": 0.05,
        "power": 0.8,
        "min_n_feasibility": 10,
        "max_unknown_rate": 0.2,
        "cost_terms": ["inference_billed", "repair", "overhead"],
        "bootstrap_b": 2000,
        "bootstrap_seed": 20260904,
    },
}

_WEEK_STARTS = ("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")
_OTEL_MODES = ("local", "external")
_SCOPE_KINDS = ("auto", "account_id", "api_key_id", "workspace_id", "org")
_OUTCOME_COLUMNS = ("tests_passed", "reviewer_accepted", "task_reopened", "classifier_flagged")
_COST_TERMS = (
    "inference_estimate",
    "inference_billed",
    "verification",
    "repair",
    "delay",
    "overhead",
)


class ConfigError(Exception):
    """Invalid or unknown configuration; the CLI maps it to exit code 2 (refused)."""

    exit_code = 2


def resolve_data_dir(environ: Mapping[str, str] | None = None) -> Path:
    """`$SG_DATA_DIR` if set, else `~/.smart-gateway`; pure, creates nothing."""
    env = os.environ if environ is None else environ
    value = env.get(DATA_DIR_ENV, "")
    if value:
        return Path(value).expanduser()
    return Path.home() / DEFAULT_DATA_DIR_NAME


def ensure_data_dir(data_dir: Path) -> Path:
    """Create the data dir (mode 0700) and its standard subdirectories; idempotent."""
    for path in (data_dir, *(data_dir / d for d in _SUBDIRS)):
        if not path.is_dir():
            path.mkdir(parents=True, exist_ok=True)
            path.chmod(0o700)
    return data_dir


def _fail(where: str, what: str) -> ConfigError:
    return ConfigError(f"config.json: {where} {what}")


def _is_number(v: object) -> bool:
    return isinstance(v, int | float) and not isinstance(v, bool)


def _check_keys(obj: object, allowed: Mapping, where: str) -> dict:
    if not isinstance(obj, dict):
        raise _fail(where, "must be a JSON object")
    unknown = sorted(set(obj) - set(allowed))
    if unknown:
        raise _fail(where, f"has unknown keys: {', '.join(unknown)}")
    merged = copy.deepcopy(dict(allowed))
    merged.update(obj)
    return merged


def _check_str(v: object, where: str, nullable: bool = False) -> None:
    if v is None and nullable:
        return
    if not isinstance(v, str):
        raise _fail(where, "must be a string")


def _check_str_list(v: object, where: str, choices: tuple[str, ...] | None = None) -> None:
    if not isinstance(v, list) or not all(isinstance(x, str) for x in v):
        raise _fail(where, "must be a list of strings")
    if choices is not None and any(x not in choices for x in v):
        raise _fail(where, f"entries must be one of {', '.join(choices)}")


def _check_number(v: object, where: str, lo: float, hi: float, nullable: bool = False) -> None:
    if v is None and nullable:
        return
    if not _is_number(v) or not lo <= v <= hi:
        raise _fail(where, f"must be a number in [{lo}, {hi}]")


def _check_int(v: object, where: str, lo: int, nullable: bool = False) -> None:
    if v is None and nullable:
        return
    if isinstance(v, bool) or not isinstance(v, int) or v < lo:
        raise _fail(where, f"must be an integer >= {lo}")


def _check_choice(v: object, where: str, choices: tuple[str, ...], nullable: bool = False) -> None:
    if v is None and nullable:
        return
    if v not in choices:
        raise _fail(where, f"must be one of {', '.join(choices)}")


def validate_config(obj: object) -> dict:
    """Return the config with defaults filled in, or raise ConfigError.

    Unknown keys at any level are refused; every value is type- and range-checked.
    """
    cfg = _check_keys(obj, DEFAULT_CONFIG, "top level")
    if cfg["schema"] != CONFIG_SCHEMA:
        raise _fail("schema", f"must be {CONFIG_SCHEMA}")
    _check_str(cfg["team"], "team")
    _check_choice(cfg["week_start"], "week_start", _WEEK_STARTS)
    _check_str(cfg["task_id_branch_regex"], "task_id_branch_regex")
    try:
        pattern = re.compile(cfg["task_id_branch_regex"])
    except re.error as e:
        raise _fail("task_id_branch_regex", "must compile") from e
    if pattern.groups < 1:
        raise _fail("task_id_branch_regex", "needs a capture group for the task id")
    _check_str_list(cfg["protected_branches"], "protected_branches")
    _check_number(cfg["engineer_usd_per_hour"], "engineer_usd_per_hour", 0, 1e6)
    _check_number(cfg["ci_usd_per_minute"], "ci_usd_per_minute", 0, 1e6, nullable=True)
    _check_number(cfg["delay_usd_per_hour"], "delay_usd_per_hour", 0, 1e6, nullable=True)
    _check_int(cfg["repair_minutes_team_estimate"], "repair_minutes_team_estimate", 0, True)

    otel = cfg["otel"] = _check_keys(cfg["otel"], DEFAULT_CONFIG["otel"], "otel")
    _check_choice(otel["mode"], "otel.mode", _OTEL_MODES)
    _check_int(otel["port"], "otel.port", 1)
    if otel["port"] > 65535:
        raise _fail("otel.port", "must be <= 65535")

    billing = cfg["billing"] = _check_keys(cfg["billing"], DEFAULT_CONFIG["billing"], "billing")
    scope = billing["scope"] = _check_keys(
        billing["scope"], DEFAULT_CONFIG["billing"]["scope"], "billing.scope"
    )
    _check_choice(scope["kind"], "billing.scope.kind", _SCOPE_KINDS)
    _check_str_list(scope["ids"], "billing.scope.ids")
    _check_str(billing["workspace_id"], "billing.workspace_id", nullable=True)
    aliases = billing["model_aliases"]
    if not isinstance(aliases, dict) or not all(
        isinstance(k, str) and isinstance(v, str) for k, v in aliases.items()
    ):
        raise _fail("billing.model_aliases", "must map model strings to model strings")

    gate = cfg["gate"] = _check_keys(cfg["gate"], DEFAULT_CONFIG["gate"], "gate")
    _check_str(gate["current_config_label"], "gate.current_config_label", nullable=True)
    _check_str_list(gate["candidate_config_labels"], "gate.candidate_config_labels")
    _check_number(gate["delta"], "gate.delta", 0, 1)
    _check_choice(gate["primary_outcome"], "gate.primary_outcome", _OUTCOME_COLUMNS)
    _check_number(gate["quality_floor"], "gate.quality_floor", 0, 1, nullable=True)
    _check_number(gate["alpha"], "gate.alpha", 0, 1)
    _check_number(gate["power"], "gate.power", 0, 1)
    _check_int(gate["min_n_feasibility"], "gate.min_n_feasibility", 1)
    _check_number(gate["max_unknown_rate"], "gate.max_unknown_rate", 0, 1)
    _check_str_list(gate["cost_terms"], "gate.cost_terms", _COST_TERMS)
    _check_int(gate["bootstrap_b"], "gate.bootstrap_b", 1)
    _check_int(gate["bootstrap_seed"], "gate.bootstrap_seed", 0)
    for key in ("delta", "alpha", "power"):
        if gate[key] in (0, 1):
            raise _fail(f"gate.{key}", "must be strictly between 0 and 1")
    return cfg


def load_config(data_dir: Path, *, missing_ok: bool = False) -> dict:
    """Read and validate `<data_dir>/config.json`.

    Hooks pass missing_ok=True so a machine that has not run `sg init` still records;
    every CLI command that derives or reports requires the file.
    """
    path = data_dir / CONFIG_FILE
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError:
        if missing_ok:
            return copy.deepcopy(DEFAULT_CONFIG)
        raise ConfigError("config.json is missing; run `sg init`") from None
    try:
        obj = json.loads(text)
    except ValueError as e:
        raise ConfigError("config.json is not valid JSON") from e
    return validate_config(obj)


def write_config(data_dir: Path, config: dict) -> dict:
    """Validate, then atomically write `<data_dir>/config.json`; returns the stored config."""
    cfg = validate_config(config)
    atomic_write(data_dir / CONFIG_FILE, json.dumps(cfg, indent=2, sort_keys=True) + "\n")
    return cfg


def config_digest(config: dict) -> str:
    """sha256 of the canonical encoding of the validated config; part of build_id.

    Canonical (not file bytes) so two machines with the same settings build identically.
    """
    return hashlib.sha256(encode_line(validate_config(config))).hexdigest()
