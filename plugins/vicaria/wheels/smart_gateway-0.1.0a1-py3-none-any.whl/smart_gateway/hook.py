"""Hook entry point: `python3 -m smart_gateway.hook <Event> [<matcher>]` (spec section 6.1).

Invisible by construction: fd 1 is pointed at /dev/null before anything else runs, every
failure ends in `os._exit(0)`, and nothing is ever printed — a recorder that could block,
inject context or fail closed would change the very work it is measuring.

Free text on stdin (prompt, messages, tool input/output, errors, paths) is read only for
its length, its salted hash, or deletable state; the raw record never carries it.
Imports are kept minimal on purpose: the sync hooks run inside a 5 s budget on every
prompt, so the heavy modules (subprocess, socket) are imported only on the paths that
need them.
"""

from __future__ import annotations

import time

_T0 = time.perf_counter()  # module import is the start of the in-process overhead clock

import copy  # noqa: E402
import json  # noqa: E402
import os  # noqa: E402
import re  # noqa: E402
import sys  # noqa: E402
from pathlib import Path  # noqa: E402

from smart_gateway import __version__  # noqa: E402
from smart_gateway.config import (  # noqa: E402
    DEFAULT_CONFIG,
    ConfigError,
    ensure_data_dir,
    load_config,
    resolve_data_dir,
)
from smart_gateway.ids import (  # noqa: E402
    extract_task_ref,
    load_or_create_salt,
    salted_hash,
    sanitize_task_id,
    utc_now_iso,
)
from smart_gateway.rawlog import append_line, atomic_write, shard_path  # noqa: E402

__all__ = ["main"]

HOOK_SCHEMA = "sg.hook.v1"
STDIN_LIMIT = 1 << 20  # 1 MiB; a larger payload is recorded as malformed, never parsed
ERROR_LOG = "hook_errors.log"
TRANSCRIPTS_STATE = "transcripts.json"
CURSORS_LOCK = "cursors.lock"

# Spec section 6.1 table: which events Claude Code runs in the background.
HOOK_ASYNC = {
    "SessionStart": False,
    "UserPromptSubmit": False,
    "SubagentStart": True,
    "SubagentStop": True,
    "Stop": True,
    "StopFailure": True,
    "PostModelSwitch": True,
    "PreCompact": True,
    "PostCompact": True,
    "SessionEnd": False,
}

# Allowlists (spec section 5.1): stdin keys the hook may look at, per event. Any other key
# is reported by name only in `extra_keys`. Text-bearing keys are listed so they are not
# flagged as unexpected, but they are only ever measured or hashed, never copied.
_COMMON_KEYS = frozenset(
    {
        "session_id",
        "prompt_id",
        "agent_id",
        "agent_type",
        "permission_mode",
        "cwd",
        "transcript_path",
        "hook_event_name",
    }
)
_EVENT_KEYS: dict[str, frozenset[str]] = {
    "SessionStart": frozenset({"source", "model"}),
    "UserPromptSubmit": frozenset({"prompt"}),
    "SubagentStart": frozenset(),
    "SubagentStop": frozenset({"last_assistant_message", "stop_hook_active"}),
    "Stop": frozenset({"effort", "stop_hook_active", "last_assistant_message"}),
    "StopFailure": frozenset({"error", "error_type"}),
    "PostModelSwitch": frozenset({"from_model", "to_model"}),
    "PreCompact": frozenset({"trigger", "custom_instructions"}),
    "PostCompact": frozenset({"trigger"}),
    "SessionEnd": frozenset({"reason"}),
}
_INGEST_DEADLINE_S = {"Stop": 20, "SubagentStop": 20, "SessionEnd": 5}
_BINDING_EVENTS = frozenset({"SessionStart", "UserPromptSubmit"})

# An identifier is stored verbatim only if it looks structural: no whitespace or control
# characters and a bounded length. Anything else could be free text and is dropped.
_IDENT_RE = re.compile(r"[^\s\x00-\x1f\x7f]{1,256}")
_ERROR_TYPE_RE = re.compile(r"[a-z_]{3,40}")
_PATH_TOKEN_RE = re.compile(r"\S*/\S*")
_TRUE_VALUES = frozenset({"1", "true"})


def _ident(value: object) -> str | None:
    return value if isinstance(value, str) and _IDENT_RE.fullmatch(value) else None


def _path_value(value: object) -> str | None:
    """A filesystem path used in-process only (hashed before it is written).

    Paths legitimately contain spaces and unicode, so the identifier alphabet does not
    apply; only control characters and absurd lengths are rejected.
    """
    if not isinstance(value, str) or not value or len(value) > 4096:
        return None
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in value):
        return None
    return value


def _bool(value: object) -> bool | None:
    return value if isinstance(value, bool) else None


def _length(value: object) -> int | None:
    return len(value) if isinstance(value, str) else None


def _truthy(value: str | None) -> bool:
    return value is not None and value.strip().lower() in _TRUE_VALUES


def _scrub(message: str) -> str:
    """Error text for hook_errors.log: path-shaped tokens replaced, one line, bounded."""
    text = _PATH_TOKEN_RE.sub("<path>", message)
    return " ".join(text.split())[:200]


def _log_error(data_dir: Path | None, event: str, exc: BaseException) -> None:
    """Best effort: one plain-text line in raw/hook_errors.log; any failure here is final."""
    if data_dir is None:
        return
    line = f"{utc_now_iso()} {event} {type(exc).__name__}: {_scrub(str(exc))}\n"
    try:
        fd = os.open(data_dir / "raw" / ERROR_LOG, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    except OSError:
        return
    try:
        os.write(fd, line.encode("utf-8", "replace"))
    except OSError:
        pass
    finally:
        os.close(fd)


def _read_stdin(limit: int) -> bytes | None:
    """Up to `limit` bytes from fd 0; None when stdin is unreadable or exceeds the bound."""
    chunks: list[bytes] = []
    total = 0
    while total <= limit:
        try:
            chunk = os.read(0, 1 << 16)
        except OSError:
            return None
        if not chunk:
            return b"".join(chunks)
        chunks.append(chunk)
        total += len(chunk)
    return None


def _parse_stdin(data: bytes | None) -> tuple[dict, bool]:
    """(payload, malformed): a non-object or undecodable payload becomes {} + True."""
    if data is None:
        return {}, True
    try:
        obj = json.loads(data)
    except ValueError:
        return {}, True
    return (obj, False) if isinstance(obj, dict) else ({}, True)


def _git_branch(cwd: str, environ: dict[str, str]) -> str | None:
    """Current branch via git with a 1 s budget; any failure (no git, no repo, timeout)
    simply means the branch is unknown — never an error worth a log line."""
    if not os.path.isdir(cwd):
        return None
    import subprocess

    try:
        proc = subprocess.run(
            ["git", "-C", cwd, "rev-parse", "--abbrev-ref", "HEAD"],
            stdin=subprocess.DEVNULL,
            capture_output=True,
            timeout=1,
            check=False,
            env={**environ, "GIT_TERMINAL_PROMPT": "0"},
        )
    except (OSError, subprocess.SubprocessError):
        return None
    if proc.returncode != 0:
        return None
    branch = proc.stdout.decode("utf-8", "replace").strip()
    return branch or None


def _marker_task_id(cwd: str) -> str | None:
    """First line of <cwd>/.sg/task, accepted only if it is a well-formed task id."""
    try:
        with open(os.path.join(cwd, ".sg", "task"), "rb") as f:
            head = f.read(512)
    except OSError:
        return None
    first = head.split(b"\n", 1)[0].decode("utf-8", "replace")
    try:
        return sanitize_task_id(first)
    except ValueError:
        return None


def _env_task_id(value: str | None) -> str | None:
    if value is None:
        return None
    try:
        return sanitize_task_id(value)
    except ValueError:
        return None


def _propensity(value: str | None) -> float | None:
    if value is None:
        return None
    try:
        p = float(value.strip())
    except ValueError:
        return None
    return p if 0.0 <= p <= 1.0 else None


def _binding_hints(
    payload: dict, salt: bytes | None, config: dict, environ: dict[str, str]
) -> dict:
    """Everything binding.py needs, evaluated now so the branch name never reaches disk."""
    # cwd is a filesystem path, not an identifier: a directory with a space in it is
    # ordinary, and rejecting it silently lost the .sg/task marker and the branch hint.
    cwd = _path_value(payload.get("cwd"))
    branch = _git_branch(cwd, environ) if cwd else None
    assignment = environ.get("SG_ASSIGNMENT")
    return {
        "sg_task_id": _env_task_id(environ.get("SG_TASK_ID")),
        "sg_config_label": _ident(environ.get("SG_CONFIG_LABEL")),
        "sg_assignment": assignment if assignment in ("randomized", "observational") else None,
        "sg_propensity": _propensity(environ.get("SG_PROPENSITY")),
        "sg_experiment": _ident(environ.get("SG_EXPERIMENT")),
        "marker_task_id": _marker_task_id(cwd) if cwd else None,
        "branch_task_ref": extract_task_ref(
            branch, config["task_id_branch_regex"], config["protected_branches"]
        ),
        "branch_hash": salted_hash(salt, branch) if branch and salt else None,
    }


def _env_hints(salt: bytes | None, environ: dict[str, str]) -> dict:
    """The configured-side receipt: what the environment asked Claude Code to use."""
    base_url = environ.get("ANTHROPIC_BASE_URL")
    host_hash = None
    if base_url and salt:
        from urllib.parse import urlsplit

        try:
            host = urlsplit(base_url).hostname
        except ValueError:
            host = None
        host_hash = salted_hash(salt, host or base_url)
    return {
        "anthropic_model": _ident(environ.get("ANTHROPIC_MODEL")),
        "effort_level": _ident(environ.get("CLAUDE_CODE_EFFORT_LEVEL")),
        "subagent_model": _ident(environ.get("CLAUDE_CODE_SUBAGENT_MODEL")),
        "base_url_host_hash": host_hash,
        "use_bedrock": _truthy(environ.get("CLAUDE_CODE_USE_BEDROCK")),
        "use_vertex": _truthy(environ.get("CLAUDE_CODE_USE_VERTEX")),
        "cloud_region": _ident(environ.get("AWS_REGION") or environ.get("CLOUD_ML_REGION")),
        "otel_enabled": _truthy(environ.get("CLAUDE_CODE_ENABLE_TELEMETRY")),
    }


def _remember_transcript(data_dir: Path, session_id: str, transcript_path: str) -> None:
    """state/transcripts.json[session_id] = transcript_path, under the shared cursors lock.

    Deletable state, not raw: this is the one place a path is stored, and only so the
    extractor can find the file without scanning ~/.claude.
    """
    import fcntl

    state = data_dir / "state"
    lock_fd = os.open(state / CURSORS_LOCK, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        # Non-blocking: an ingest on another process holds this same lock for the whole of
        # its extraction pass, and a synchronous hook that waited for it would spend its
        # entire timeout here and lose the event line it had not written yet. The path is
        # deletable state that ingest rediscovers, so skipping this update costs nothing.
        try:
            fcntl.flock(lock_fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            return
        path = state / TRANSCRIPTS_STATE
        try:
            current = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            current = {}
        if not isinstance(current, dict):
            current = {}
        if current.get(session_id) == transcript_path:
            return
        current[session_id] = transcript_path
        atomic_write(path, json.dumps(current, sort_keys=True, indent=1) + "\n")
    finally:
        os.close(lock_fd)


def _ensure_receiver(data_dir: Path, config: dict, environ: dict[str, str]) -> None:
    """Spawn a detached local OTEL receiver when nothing answers on the configured port.

    The child is never waited for: if `sg otel serve` is missing or fails, its traceback
    lands in state/otel.log and this hook is unaffected.
    """
    otel = config["otel"]
    if otel["mode"] != "local":
        return
    import socket

    try:
        socket.create_connection(("127.0.0.1", otel["port"]), timeout=0.1).close()
        return
    except TimeoutError:
        return  # something is there but slow; never race a second receiver against it
    except OSError:
        pass
    import subprocess

    log_fd = os.open(data_dir / "state" / "otel.log", os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    try:
        subprocess.Popen(
            [sys.executable, "-m", "smart_gateway.cli", "otel", "serve"],
            start_new_session=True,
            stdin=subprocess.DEVNULL,
            stdout=log_fd,
            stderr=subprocess.STDOUT,
            close_fds=True,
            env=environ,
        )
    finally:
        os.close(log_fd)


def _ingest_transcript(session_id: str, deadline_s: int, only_agent: str | None) -> None:
    """Usage-only transcript extraction; imported late so a missing or broken extractor
    costs one error line, never the hook record."""
    from smart_gateway import transcript

    transcript.ingest(session_id, deadline_s, only_agent=only_agent, trigger="hook")


def build_record(payload: dict, malformed: bool, argv: list[str], salt: bytes | None) -> dict:
    """The sg.hook.v1 record minus the parts that need side effects (hints, overhead).

    Every field is present (null when the event does not carry it) so consumers never
    need `.get` defaults; per-event gating keeps a stray key from another event out.
    """
    argv_event = argv[0] if argv else ""
    event = _ident(payload.get("hook_event_name")) or argv_event or "unknown"
    matcher_argv = _ident(argv[1]) if len(argv) > 1 else None
    allowed = _EVENT_KEYS.get(event, frozenset())

    def take(key: str, reader=_ident):
        return reader(payload.get(key)) if key in allowed else None

    error_type = None
    error_type_source = None
    if event == "StopFailure":
        stdin_type = payload.get("error_type")
        if isinstance(stdin_type, str) and _ERROR_TYPE_RE.fullmatch(stdin_type):
            error_type, error_type_source = stdin_type, "stdin"
        elif matcher_argv is not None:
            error_type, error_type_source = matcher_argv, "argv"

    # cwd is a filesystem path, not an identifier: a directory with a space in it is
    # ordinary, and rejecting it silently lost the .sg/task marker and the branch hint.
    cwd = _path_value(payload.get("cwd"))
    extra = sorted(str(k)[:64] for k in payload if k not in _COMMON_KEYS and k not in allowed)[:50]
    return {
        "schema": HOOK_SCHEMA,
        "recorded_at": utc_now_iso(),
        "recorder": {"component": "hook", "version": __version__},
        "event": event,
        "argv_event": argv_event,
        "matcher_argv": matcher_argv,
        "session_id": _ident(payload.get("session_id")),
        "prompt_id": _ident(payload.get("prompt_id")),
        "agent_id": _ident(payload.get("agent_id")),
        "agent_type": _ident(payload.get("agent_type")),
        "permission_mode": _ident(payload.get("permission_mode")),
        "cwd_hash": salted_hash(salt, cwd) if cwd and salt else None,
        "source": take("source"),
        "reason": take("reason"),
        "trigger": take("trigger"),
        "model": take("model"),
        "from_model": take("from_model"),
        "to_model": take("to_model"),
        "effort": take("effort"),
        "stop_hook_active": take("stop_hook_active", _bool),
        "error_type": error_type,
        "error_type_source": error_type_source,
        "prompt_length": take("prompt", _length),
        "last_message_length": take("last_assistant_message", _length),
        "binding_hints": None,
        "env_hints": None,
        "hook_overhead_ms": 0,
        "hook_async": HOOK_ASYNC.get(event, False),
        "malformed_stdin": malformed,
        "extra_keys": extra,
    }


def _run(argv: list[str], data_dir: Path) -> None:
    environ = dict(os.environ)
    payload, malformed = _parse_stdin(_read_stdin(STDIN_LIMIT))
    ensure_data_dir(data_dir)
    event = _ident(payload.get("hook_event_name")) or (argv[0] if argv else "unknown")

    def attempt(step, *args):
        # Each side effect fails on its own: the hook record is written regardless.
        try:
            return step(*args)
        except Exception as exc:  # logged, never fatal
            _log_error(data_dir, event, exc)
            return None

    salt = attempt(load_or_create_salt, data_dir)
    try:
        config = load_config(data_dir, missing_ok=True)
    except ConfigError as exc:
        _log_error(data_dir, event, exc)
        config = copy.deepcopy(DEFAULT_CONFIG)

    record = build_record(payload, malformed, argv, salt)
    session_id = record["session_id"]
    transcript_path = payload.get("transcript_path")
    if session_id and isinstance(transcript_path, str) and transcript_path:
        attempt(_remember_transcript, data_dir, session_id, transcript_path)

    if event in _BINDING_EVENTS:
        record["binding_hints"] = attempt(_binding_hints, payload, salt, config, environ)
        if event == "SessionStart":
            record["env_hints"] = attempt(_env_hints, salt, environ)
        attempt(_ensure_receiver, data_dir, config, environ)
    elif event in _INGEST_DEADLINE_S and session_id:
        only_agent = record["agent_id"] if event == "SubagentStop" else None
        attempt(_ingest_transcript, session_id, _INGEST_DEADLINE_S[event], only_agent)

    record["hook_overhead_ms"] = int((time.perf_counter() - _T0) * 1000)
    append_line(shard_path(data_dir / "raw", "hooks"), record)


def main(argv: list[str] | None = None) -> None:
    """Record one hook invocation; always exits 0 with nothing on stdout."""
    os.dup2(os.open(os.devnull, os.O_WRONLY), 1)  # inner stdout guard; the shim is the outer
    argv = sys.argv[1:] if argv is None else argv
    data_dir: Path | None = None
    try:
        data_dir = resolve_data_dir()
        _run(argv, data_dir)
    except BaseException as exc:  # a hook must never surface an error
        _log_error(data_dir, argv[0] if argv else "unknown", exc)
    finally:
        os._exit(0)


if __name__ == "__main__":
    main()
