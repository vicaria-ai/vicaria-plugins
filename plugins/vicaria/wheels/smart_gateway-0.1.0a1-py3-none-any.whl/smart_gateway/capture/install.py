"""Install the capture plugin into Claude Code, pinned to this interpreter.

The plugin used to be a directory in a checkout, loaded with ``--plugin-dir``
on every launch, whose shim ran whatever ``python3`` came first on the path.
On a stock Mac that is 3.9, which cannot import this package, and the shim
then exited 0 in silence: the website said *Linked*, the person agreed, and no
session ever arrived.

Here the plugin is written into the client home as a one-plugin marketplace
(``<home>/claude-plugin``), with two files beside its shim: ``runtime``, the
interpreter running this code (the one ``uv tool install`` or ``pip`` put this
package and its contracts into), and ``home``, the client home the link is
stored in.  Then:

1. **The self-check.**  The plugin's own shim answers ``/vicaria:status``
   exactly as Claude Code would call it.  A runtime that cannot load fails
   here, in the terminal, before anything is claimed.
2. **Registration.**  ``claude plugin marketplace add`` and ``claude plugin
   install vicaria@vicaria-local --scope user``.  A local marketplace's plugin
   loads in place, so a later install rewrites the files and the next session
   runs them; both commands are safe to repeat.

``sg capture link`` runs this before it exchanges the code, so a machine that
cannot run the plugin keeps its code and is told why.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path

#: The plugin's name, which Claude Code prefixes to its commands:
#: ``/vicaria:off``.
PLUGIN = "vicaria"
MARKETPLACE = "vicaria-local"
PLUGIN_ID = f"{PLUGIN}@{MARKETPLACE}"

#: Where the files come from: the wheel carries the repository's
#: ``plugin-capture`` here (``[tool.hatch.build.targets.wheel.force-include]``);
#: an editable install or a checkout reads the repository's own directory.
PACKAGED = Path(__file__).resolve().parent / "_plugin"
CHECKOUT = Path(__file__).resolve().parents[3] / "plugin-capture"

#: The ``claude`` to register with.  ``VICARIA_CLAUDE_BIN`` names another, which
#: is how the tests keep this away from a real Claude Code configuration.
CLAUDE_BIN_ENV = "VICARIA_CLAUDE_BIN"

SELF_CHECK_SESSION = "vicaria-install-self-check"


class InstallFailed(Exception):
    """The plugin could not be made to work on this machine; the message says why."""


@dataclass
class Installed:
    plugin_dir: Path
    marketplace_dir: Path
    runtime: str
    answer: str
    registered: bool
    notes: list[str] = field(default_factory=list)


def plugin_source() -> Path:
    for candidate in (PACKAGED, CHECKOUT):
        if (candidate / ".claude-plugin" / "plugin.json").is_file():
            return candidate
    raise InstallFailed(
        "the plugin's files are not in this installation (looked in "
        f"{PACKAGED} and {CHECKOUT}); reinstall smart-gateway"
    )


def write_plugin(home: Path, runtime: str | None = None) -> tuple[Path, Path]:
    """Write the marketplace and the plugin under ``home``; return both paths.

    The plugin directory is replaced whole, so a file the new version dropped
    does not linger in the directory Claude Code loads.
    """
    source = plugin_source()
    marketplace = home / "claude-plugin"
    plugin_dir = marketplace / "plugins" / PLUGIN
    staging = marketplace / "plugins" / f".{PLUGIN}.new"
    if staging.exists():
        shutil.rmtree(staging)
    shutil.copytree(source, staging, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
    (staging / "runtime").write_text((runtime or sys.executable) + "\n", encoding="utf-8")
    (staging / "home").write_text(str(home) + "\n", encoding="utf-8")
    if plugin_dir.exists():
        shutil.rmtree(plugin_dir)
    staging.rename(plugin_dir)
    manifest = json.loads((plugin_dir / ".claude-plugin" / "plugin.json").read_text("utf-8"))
    (marketplace / ".claude-plugin").mkdir(parents=True, exist_ok=True)
    (marketplace / ".claude-plugin" / "marketplace.json").write_text(
        json.dumps(
            {
                "name": MARKETPLACE,
                "owner": {"name": "Vicaria"},
                "description": (
                    "Vicaria's capture plugin, installed by `sg capture link` on this machine."
                ),
                "plugins": [
                    {
                        "name": PLUGIN,
                        "source": f"./plugins/{PLUGIN}",
                        "version": manifest.get("version"),
                        "description": manifest.get("description"),
                    }
                ],
            },
            indent=2,
        )
        + "\n",
        encoding="utf-8",
    )
    return marketplace, plugin_dir


def self_check(plugin_dir: Path, home: Path) -> str:
    """Run the plugin's shim on ``/vicaria:status`` as Claude Code would.

    Returns the line it answered.  The shim's own fallback answers too when
    the runtime cannot load, so the answer is checked for the fallback's
    words, not just for being an answer.
    """
    payload = {
        "hook_event_name": "UserPromptExpansion",
        "session_id": SELF_CHECK_SESSION,
        "expansion_type": "slash_command",
        "command_name": f"{PLUGIN}:status",
        "command_args": "",
        "command_source": "plugin",
        "prompt": f"/{PLUGIN}:status",
    }
    env = {key: value for key, value in os.environ.items() if key != "PYTHONPATH"}
    env["VICARIA_HOME"] = str(home)
    try:
        done = subprocess.run(
            ["/bin/sh", str(plugin_dir / "bin" / "vc-capture"), "UserPromptExpansion"],
            input=json.dumps(payload),
            capture_output=True,
            text=True,
            env=env,
            timeout=30,
            check=False,
        )
    except (OSError, subprocess.TimeoutExpired) as failure:
        raise InstallFailed(f"the plugin's hook could not be run ({failure})") from failure
    try:
        answer = json.loads(done.stdout)["stopReason"]
    except (ValueError, KeyError, TypeError):
        detail = (done.stderr or done.stdout or "no output").strip().splitlines()[-1:]
        raise InstallFailed(
            f"the plugin's hook gave no answer (exit {done.returncode}: {' '.join(detail)})"
        ) from None
    # The shim's own fallback answers too when the runtime cannot load: it
    # says so in the person's words, and those words are what this looks for.
    if (
        not isinstance(answer, str)
        or "not running on this computer" in answer
        or "setting itself up" in answer
    ):
        raise InstallFailed(f"the plugin's hook could not start its runtime: {answer}")
    return answer


def claude_bin() -> str | None:
    named = os.environ.get(CLAUDE_BIN_ENV)
    if named is not None:
        return named if named and Path(named).exists() else None
    return shutil.which("claude")


def register(marketplace: Path) -> tuple[bool, list[str]]:
    """Add the marketplace and install the plugin in Claude Code, user scope.

    Returns whether both succeeded and what was said along the way.  Never
    raises: without ``claude`` on the path the person is told the two
    commands to run instead.
    """
    binary = claude_bin()
    manual = [
        f"claude plugin marketplace add {marketplace}",
        f"claude plugin install {PLUGIN_ID} --scope user",
    ]
    if binary is None:
        return False, ["Claude Code (`claude`) was not found on the path; run:", *manual]
    notes: list[str] = []
    for args in (
        ["plugin", "marketplace", "add", str(marketplace), "--scope", "user"],
        ["plugin", "install", PLUGIN_ID, "--scope", "user"],
    ):
        try:
            done = subprocess.run(
                [binary, *args], capture_output=True, text=True, timeout=120, check=False
            )
        except (OSError, subprocess.TimeoutExpired) as failure:
            return False, [f"`claude {' '.join(args)}` could not run ({failure}); run:", *manual]
        if done.returncode != 0:
            said = (done.stderr or done.stdout or "").strip().splitlines()[-1:]
            return False, [
                f"`claude {' '.join(args)}` failed ({' '.join(said) or done.returncode}); run:",
                *manual,
            ]
    notes.append(f"installed in Claude Code as {PLUGIN_ID}; it loads in every new session")
    return True, notes


def install(home: Path, *, register_with_claude: bool = True) -> Installed:
    marketplace, plugin_dir = write_plugin(home)
    answer = self_check(plugin_dir, home)
    registered, notes = register(marketplace) if register_with_claude else (False, [])
    return Installed(
        plugin_dir=plugin_dir,
        marketplace_dir=marketplace,
        runtime=sys.executable,
        answer=answer,
        registered=registered,
        notes=notes,
    )


def claude_version() -> str | None:
    """``2.1.280`` from ``claude --version``, or None."""
    binary = claude_bin()
    if binary is None:
        return None
    try:
        done = subprocess.run(
            [binary, "--version"], capture_output=True, text=True, timeout=20, check=False
        )
    except (OSError, subprocess.TimeoutExpired):
        return None
    first = (done.stdout or "").strip().split(" ", 1)[0]
    parts = first.split(".")
    return first if len(parts) >= 2 and all(part.isdigit() for part in parts) else None
