"""What each capture adapter can and cannot observe, as a publishable document.

``cb.adapter_coverage.v1`` exists so that an omission is *recorded* rather than
inferred.  Without it, a session with no tool inputs looks like a session that
used no tools, and a workbench renders an empty column instead of "not captured
by the adapter".  The contract requires an entry for every observable kind,
including the ones an adapter cannot see, for exactly that reason.

Every row here is a claim, not a result
---------------------------------------
The contract is explicit: a row becomes *support* only when the control
conformance suite passes against a named version, and it reverts to a claim when
that run fails.  No capture conformance run exists for either adapter below — the
existing reports are for the 0.1.0a1 *control* adapter, which has no uploader —
so both documents carry ``conformance.state: "claimed"`` with the gap named.
Publishing them anyway is deliberate: a session whose coverage document is
missing is shown as ``coverage_document_missing``, which tells a reviewer
nothing about what the adapter could see, while a claimed document tells them
what to expect and what has not been verified.

Two rows are worth reading closely
----------------------------------
``tool_call_input`` and ``tool_call_output`` are ``observed`` on Claude Code and
``observed``/``partial`` on Codex (vicaria-docs RFC 0039): the bodies go as the
harness exposes them, and nothing is redacted.  The one limit is size --- a body
over 1 MiB is cut at 1 MiB and the cut is counted on the event --- and the
reason field says so, so a consumer never reads a cut body as a whole one.
"""

from __future__ import annotations

from typing import Any

from smart_gateway.capture import notice as notice_module
from smart_gateway.capture.events import coverage_id
from smart_gateway.capture.notice import notice_for
from smart_gateway.control.signals import SIGNAL_NAMES

#: The closed set the contract requires one entry for. Listed here so a missing
#: row is a test failure in this repository rather than a schema failure at the
#: service.
OBSERVABLES = (
    "user_message_text",
    "assistant_message_text",
    "assistant_reasoning",
    "tool_call_input",
    "tool_call_output",
    "tool_completion_status",
    "tool_exit_status",
    "attachments",
    "feedback_direction",
    "feedback_comment_text",
    "workspace_checkpoint",
    "working_tree_diff_at_turn_start",
    "working_tree_diff_at_turn_end",
    "token_usage",
    "turn_termination",
    "subagent_boundary",
    "session_end_instant",
    "task_latency",
)

#: The one limit on a tool body, said once (vicaria-docs RFC 0039).
_CUT_NOT_HIDDEN = (
    " A body over 1 MiB is cut at 1 MiB and the cut is counted on the event; "
    "nothing else is removed from it."
)

_CLAUDE_CODE_OBSERVABLES: dict[str, dict[str, Any]] = {
    "user_message_text": {
        "state": "observed",
        "citation": "smart-gateway/src/smart_gateway/capture/claude_code.py:UserPromptSubmit",
    },
    "assistant_message_text": {
        "state": "partial",
        "reason": (
            "The Stop hook carries last_assistant_message, which is the final "
            "assistant message of a turn. Intermediate assistant messages within a "
            "turn are not delivered to a hook and are not captured."
        ),
        "downstream_effect": "measurement_shown_as_not_measured",
    },
    "assistant_reasoning": {
        "state": "not_observed",
        "reason": "No hook carries provider-side reasoning.",
        "downstream_effect": "none",
    },
    "tool_call_input": {
        "state": "observed",
        "reason": (
            "PreToolUse's tool_input, the structure as Claude Code hands it." + _CUT_NOT_HIDDEN
        ),
        "citation": "smart-gateway/src/smart_gateway/capture/claude_code.py:PreToolUse",
    },
    "tool_call_output": {
        "state": "observed",
        "reason": (
            "PostToolUse's tool_response as Claude Code gives it to the model (a string "
            "as it is, a structure as canonical text), or PostToolUseFailure's error in "
            "its place." + _CUT_NOT_HIDDEN
        ),
        "citation": "smart-gateway/src/smart_gateway/capture/claude_code.py:PostToolUse",
    },
    "tool_completion_status": {
        "state": "observed",
        "citation": "smart-gateway/src/smart_gateway/capture/claude_code.py:PostToolUse",
    },
    "tool_exit_status": {
        "state": "not_observed",
        "reason": (
            "A hook reports that a tool succeeded or failed, not a numeric process "
            "exit code; exit_status is left unknown rather than invented."
        ),
        "downstream_effect": "measurement_shown_as_not_measured",
    },
    "attachments": {
        "state": "not_observed",
        "reason": "No hook carries an attachment list, so an attachment is invisible "
        "rather than absent.",
        "downstream_effect": "none",
    },
    "feedback_direction": {
        "state": "observed",
        "reason": None,
        "citation": "smart-gateway/plugin-capture/commands/feedback.md",
    },
    "feedback_comment_text": {
        "state": "observed",
        "reason": "The comment as the person typed it, with its length beside it (RFC 0039).",
        "citation": "smart-gateway/src/smart_gateway/capture/claude_code.py:_feedback",
    },
    "workspace_checkpoint": {
        "state": "not_observed",
        "reason": "No checkpoint hook; the workspace at the cut would have to be "
        "reconstructed from the repository and a recorded diff.",
        "downstream_effect": "starting_state_cannot_be_reconstructed",
    },
    "working_tree_diff_at_turn_start": {
        "state": "not_observed",
        "reason": "The adapter records no repository diff at the mark; "
        "working_directory_checked_at_mark is false.",
        "downstream_effect": "starting_state_cannot_be_reconstructed",
    },
    "working_tree_diff_at_turn_end": {
        "state": "not_observed",
        "reason": "The Stop hook runs at the end of a turn but the adapter records no "
        "working-tree state there.",
        "downstream_effect": "reference_fix_check_cannot_run",
    },
    "token_usage": {
        "state": "not_observed",
        "reason": (
            "No Claude Code hook carries token counts. This repository's observer "
            "plugin reads them from OTLP and the transcript, and this capture "
            "adapter deliberately does not read either: doing so would collect from "
            "a second source that the notice does not describe. Missing counts are "
            "recorded as omissions, never as zero."
        ),
        "downstream_effect": "measurement_shown_as_not_measured",
    },
    "turn_termination": {
        "state": "observed",
        "reason": None,
        "citation": "smart-gateway/src/smart_gateway/capture/claude_code.py:Stop",
    },
    "subagent_boundary": {
        "state": "observed",
        "reason": None,
        "citation": "smart-gateway/src/smart_gateway/capture/claude_code.py:SubagentStart",
    },
    "session_end_instant": {
        "state": "observed",
        "reason": None,
        "citation": "smart-gateway/src/smart_gateway/capture/claude_code.py:SessionEnd",
    },
    "task_latency": {
        "state": "not_observed",
        "reason": "No record carries a task's duration. A surface shows the heading and "
        "says not measured rather than showing a column it has no instrument "
        "for.",
        "downstream_effect": "measurement_shown_as_not_measured",
    },
}

_CODEX_OBSERVABLES: dict[str, dict[str, Any]] = {
    "user_message_text": {
        "state": "observed",
        "reason": None,
        "citation": "smart-gateway/src/smart_gateway/capture/codex.py:run",
    },
    "assistant_message_text": {
        "state": "observed",
        "reason": None,
        "citation": "smart-gateway/src/smart_gateway/capture/codex.py:agent_message",
    },
    "assistant_reasoning": {
        "state": "partial",
        "reason": (
            "codex exec --json emits reasoning items only when reasoning summaries are "
            "enabled, and the full chain of thought stays encrypted in "
            "encrypted_content. The adapter records that a summary was available, not "
            "the reasoning itself."
        ),
        "downstream_effect": "none",
    },
    "tool_call_input": {
        "state": "observed",
        "reason": (
            "Each item's own input fields as the stream carries them: a command's "
            "command, a patch's changes, an MCP call's server, tool and arguments, a "
            "web search's query." + _CUT_NOT_HIDDEN
        ),
        "citation": "smart-gateway/src/smart_gateway/capture/codex.py:_tool_input",
    },
    "tool_call_output": {
        "state": "partial",
        "reason": (
            "A command item's aggregated output, as Codex cut it, and an MCP call's "
            "result or error as canonical text. A file change and a web search carry "
            "no output in the stream, and their finishes record that." + _CUT_NOT_HIDDEN
        ),
        "citation": "smart-gateway/src/smart_gateway/capture/codex.py:_tool_output",
        "downstream_effect": "measurement_shown_as_not_measured",
    },
    "tool_completion_status": {
        "state": "partial",
        "reason": (
            "Command, patch and MCP items carry a status: failed or declined is "
            "recorded as error, anything else as completed. A web search item "
            "carries none and is recorded completed because the item completed, "
            "not because the search found anything. An item that never terminated "
            "records nothing."
        ),
        "citation": "smart-gateway/src/smart_gateway/capture/codex.py:_completion",
        "downstream_effect": "measurement_shown_as_not_measured",
    },
    "tool_exit_status": {
        "state": "partial",
        "reason": (
            "A command item carries its exit code in its own exit_code field, which "
            "is recorded. Patches, MCP calls and web searches have no exit code. "
            "Nothing is parsed out of the aggregated output, which this adapter "
            "does not capture."
        ),
        "citation": "smart-gateway/src/smart_gateway/capture/codex.py:_exit_code",
        "downstream_effect": "measurement_shown_as_not_measured",
    },
    "attachments": {
        "state": "not_observed",
        "reason": "The exec JSON stream carries no attachment list.",
        "downstream_effect": "none",
    },
    "feedback_direction": {
        "state": "not_observed",
        "reason": (
            "codex exec is non-interactive and offers no feedback gesture. This is an "
            "affordance difference, not a quieter user base: a feedback rate from this "
            "adapter is not comparable with one from a harness that offers a keystroke."
        ),
        "downstream_effect": "feedback_rate_not_comparable_across_harnesses",
    },
    "feedback_comment_text": {
        "state": "not_observed",
        "reason": "There is no feedback gesture, so there is no comment.",
        "downstream_effect": "feedback_rate_not_comparable_across_harnesses",
    },
    "workspace_checkpoint": {
        "state": "not_observed",
        "reason": "No checkpoint event.",
        "downstream_effect": "starting_state_cannot_be_reconstructed",
    },
    "working_tree_diff_at_turn_start": {
        "state": "not_observed",
        "reason": "The adapter records no repository diff at the mark.",
        "downstream_effect": "starting_state_cannot_be_reconstructed",
    },
    "working_tree_diff_at_turn_end": {
        "state": "not_observed",
        "reason": (
            "file_change items name the paths a patch touched, which is not a diff and "
            "not a working-tree state; the adapter does not record either."
        ),
        "downstream_effect": "reference_fix_check_cannot_run",
    },
    "token_usage": {
        "state": "partial",
        "reason": (
            "turn.completed carries authoritative per-turn usage, and the adapter "
            "records the input and output counts. Codex also reports "
            "cached_input_tokens; cb.session_event.v2's usage block defines only the "
            "two, so the cached breakdown is dropped rather than folded into the input "
            "count, which would overstate it."
        ),
        "citation": "smart-gateway/src/smart_gateway/capture/codex.py:_usage",
        "downstream_effect": "measurement_shown_as_not_measured",
    },
    "turn_termination": {
        "state": "observed",
        "reason": None,
        "citation": "smart-gateway/src/smart_gateway/capture/codex.py:turn.completed",
    },
    "subagent_boundary": {
        "state": "not_observed",
        "reason": (
            "The exec JSON stream carries no sub-agent boundary; the persisted rollout "
            "does, and this adapter reads only the stream it was given."
        ),
        "downstream_effect": "measurement_shown_as_not_measured",
    },
    "session_end_instant": {
        "state": "partial",
        "reason": (
            "A wrapped run ends when codex exec exits, and no event records that. "
            "The capture session spans every run under its id and ends when the "
            "developer runs sg capture off, which the stop event records."
        ),
        "citation": "smart-gateway/src/smart_gateway/capture/cli.py:_cmd_off",
        "downstream_effect": "measurement_shown_as_not_measured",
    },
    "task_latency": {
        "state": "not_observed",
        "reason": (
            "The wrapper knows how long the process ran, and no event carries it. "
            "Stating the omission is better than publishing a duration no consumer "
            "was told the meaning of."
        ),
        "downstream_effect": "measurement_shown_as_not_measured",
    },
}

_RECORDING_INDICATOR = {
    "claude-code": {
        "state": "at_mark_only",
        "compensation": (
            "Claude Code offers no persistent recording indicator. The mark is visible "
            "when it is made: the command's reply; for a connected person, the "
            "session's first line, or, when that start could not reach the service, "
            "a line at the prompt that turns the session on (the hook's systemMessage "
            "at UserPromptSubmit, which has not been checked on a live Claude Code). "
            "/vicaria:status says it at any time. A per-turn marker was published "
            "here before: it went to stderr, which Claude Code does not show, so it "
            "indicated nothing, and it is dropped."
        ),
    },
    "codex": {
        "state": "at_mark_only",
        "compensation": (
            "codex exec is non-interactive and shows nothing while it runs. The mark is "
            "visible at confirmation and in sg capture status, which is weaker than a "
            "per-turn marker and is stated rather than glossed."
        ),
    },
}

_NOT_VERIFIED = [
    "No capture conformance run exists for this adapter.",
    "The available conformance reports are for the 0.1.0a1 control adapter, which has "
    "no uploader; they do not verify capture, consent receipts or replay.",
]


def _observables(table: dict[str, dict[str, Any]]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for what in OBSERVABLES:
        entry = table[what]
        row: dict[str, Any] = {"what": what, "state": entry["state"]}
        if entry.get("reason"):
            row["reason"] = entry["reason"]
        if entry.get("citation"):
            row["citation"] = entry["citation"]
        if entry.get("downstream_effect"):
            row["downstream_effect"] = entry["downstream_effect"]
        rows.append(row)
    return rows


#: The instant every coverage document these adapters publish carries.
#:
#: A coverage id names one IMMUTABLE document: repeating the bytes is a retry,
#: and the same id with different bytes is a conflict the service refuses. A
#: wall-clock value would make every publication a conflict with the last.
#:
#: It is the DEFAULT here rather than something the publisher passes in, because
#: while it was only the publisher's, `sg capture coverage` built its own
#: document with `published_at` set to now --- so the document a developer
#: inspected differed, byte for byte, from the one the service held, under the
#: same id. One identity, one document, one place that decides.
#:
#: The date moves when the claims below do. 2026-09-20: the notice each document
#: quotes was corrected, and the notice version is inside the document.
#: 2026-09-22: the Claude Code notice's stop sentence names `/vicaria off`, the
#: command that now exists, and the adapter learned the second authority ---
#: an interval minted from the account's standing consent. The schema pins the
#: four gate names as constants, so the fourth gate is still spelled
#: `developer_marked_this_session` here; on a linked device the person marked
#: every session once, on the website, and the gate reads the state that mint
#: wrote exactly as it reads a per-session mark.
#: 2026-09-24: adapter 0.1.5. Codex records a command's exit_code field and an
#: item's failed status, and says its session end is the developer's `off`;
#: Claude Code mints a prompt's event id from the harness prompt id.
#: 2026-09-27: each notice names TypeSafe AI, the decision-model provider
#: (RFC 0034 §2.1), and its version moved with it. Later the same day: the
#: notices name the stand-in too and say the decision record records the text
#: being sent; adapter 0.1.7, so no identity names two documents. Later
#: again: the notices say no other provider reads the text (Claude Code v6,
#: Codex v5); the version and this date moved, the adapter did not.
#: 2026-09-27, after 0.1.7 reached main: adapter 0.1.8. Claude Code's per-turn
#: marker is dropped (RFC 0032 § 9.1): it went to stderr, which Claude Code
#: does not show, so its recording indicator is `at_mark_only`, and its notice
#: (v7) says so. The notice and this document name the plugin's commands,
#: `/vicaria:off` and `/vicaria:status`: typed as `/vicaria off`, Claude Code
#: answers "Unknown command" before any hook runs. Later, still 0.1.8 (never
#: on main): the notice's confirm line names `--session`, without which
#: `sg capture confirm` refuses to run. Later again, still 0.1.8: the
#: indicator's compensation names the prompt-time line, and says it has not
#: been checked live.
#: 2026-09-27, after 0.1.8 reached main: adapter 0.1.9. The Codex notice (v6)
#: names `--harness codex` in its confirm, stop and status commands, and
#: `--session` in the two that need it; without them none ran as Codex.
#: 0.1.9 has never been on main, so these combined bytes keep it.
#: 2026-09-27, after 0.1.9 reached main: adapter 0.1.10. Tool inputs and
#: outputs are sent as the harness exposes them (vicaria-docs RFC 0039); the
#: notices (Claude Code v8, Codex v7) say so, and say no redaction will be
#: built.
COVERAGE_PUBLISHED_AT = "2026-09-27T23:30:00Z"


def document(
    harness: str,
    *,
    harness_version: str,
    adapter_version: str = "0.1.10",
    published_at: str | None = None,
) -> dict[str, Any]:
    """The publishable coverage document for one harness at one version."""
    tables = {"claude-code": _CLAUDE_CODE_OBSERVABLES, "codex": _CODEX_OBSERVABLES}
    if harness not in tables:
        raise ValueError(f"no coverage document for harness {harness!r}")
    notice = notice_for(harness)
    missing = notice.scope_not_named
    if missing:
        raise ValueError(
            f"the {harness} notice no longer names {', '.join(missing)}, so this "
            "coverage document would assert a scope the developer was not shown; "
            "fix the notice text or the claim, not this check"
        )
    if not notice.states_redaction_is_incomplete:
        raise ValueError(
            f"the {harness} notice no longer admits that redaction is incomplete, so "
            "this coverage document would assert an admission the developer was not "
            "shown; fix the notice text or the claim, not this check"
        )
    if not (notice.names_the_decision_model_provider and notice.names_the_stand_in):
        # Not a published claim (the contract's notice block admits no other key):
        # a check that the notice the document quotes still says what RFC 0034 §2.1
        # adopted, so a dropped sentence is a refusal here and not a digest to update.
        raise ValueError(
            f"the {harness} notice no longer names the decision-model provider and the "
            "stand-in (RFC 0034 §2.1); fix the notice text, not this check"
        )
    return {
        "schema_version": "cb.adapter_coverage.v1",
        "coverage_id": coverage_id(harness, harness_version, adapter_version),
        "adapter_id": f"adapter_{harness.replace('-', '_')}",
        "adapter_version": adapter_version,
        "harness": harness,
        "harness_version": harness_version,
        # Both adapters apply at one point: the Python collector. Claude Code's
        # *control* adapter is two-component (a hook stages, a commit point
        # applies) and this is not that adapter.
        "component_shape": "one_component",
        "published_at": published_at or COVERAGE_PUBLISHED_AT,
        "observables": _observables(tables[harness]),
        "conformance": {
            "state": "claimed",
            "report_path": None,
            "checks_passed": None,
            "checks_total": 10,
            "verified_at": None,
            "not_verified_by_this_suite": list(_NOT_VERIFIED),
        },
        "capture_gates": {
            "order": [
                "organization_permits_sampling",
                "developer_has_not_opted_out_on_this_machine",
                "repository_and_paths_not_excluded",
                "developer_marked_this_session",
            ],
            "all_four_required": True,
            "absence_means_off": True,
            "machine_opt_out_beats_every_setting_above_it": True,
        },
        "exclusion_enforcement": {
            # False, and said so.  No caller ever computes the `excluded` flag
            # `capture_allowed` takes, so its branch is dead, and the event
            # builder already refuses to set `paths_checked_against_exclusions`
            # because "claiming it were true would claim an exclusion
            # enforcement that is not built".  The coverage document claimed it
            # anyway, because the schema made `true` the only valid value.
            "enforced_before_upload": False,
            "limbs": [],
            "turn_text_match_is_wider": True,
            "drops_whole_never_redacts": True,
            "residual_limit_stated": True,
            # No service in this system re-checks on arrival either.
            "server_rechecks_same_three_limbs": False,
        },
        "notice": {
            "notice_version": notice.version,
            "notice_digest": notice.digest,
            "shown_in_full": True,
            "confirmed": True,
            "cancelling_leaves_session_unmarked": True,
            # Read off the notice, not retyped beside it. Both are contract
            # constants, so a document for a notice that stopped naming the
            # scope or stopped admitting redaction is incomplete cannot be
            # published at all -- which is the point of publishing one.
            "names_the_authorized_scope": list(notice_module.AUTHORIZED_SCOPE),
            "states_redaction_is_incomplete": notice.states_redaction_is_incomplete,
            # The service has an erasure route; no adapter here has wired a
            # client-side erasure request, so the notice does not promise
            # deletion and this field must agree with it.
            "erasure_path_built": False,
            "promises_deletion_of_sent_material": notice.promises_deletion,
        },
        "recording_indicator": _RECORDING_INDICATOR[harness],
        "local_send_log": {
            "path": "~/.vicaria/records/uploads.jsonl",
            "fields": ["capture_id", "session_id", "byte_count", "outcome"],
            "one_line_per_upload": True,
            "drop_log_path": "~/.vicaria/records/drops.jsonl",
        },
        "shape_only_record_stream": {
            "refuses_text_keys_at_any_depth": True,
            "refuses_before_the_wire": True,
            "conditional_on_any_flag": False,
            "separate_token_from_the_capture_endpoint": True,
            "signal_names": list(SIGNAL_NAMES),
        },
        "build_edge_to_the_advice_service": "none",
    }
