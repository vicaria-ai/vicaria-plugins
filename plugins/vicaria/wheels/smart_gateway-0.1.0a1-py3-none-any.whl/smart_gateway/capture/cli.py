"""``sg capture``: the developer's side of consent-bound capture.

    sg capture notice   --session <id>     show the notice; store only that it was shown
    sg capture confirm  --session <id>     the gesture; opens one interval
    sg capture status                      what this machine holds
    sg capture off      --session <id>     close the interval; flush what is queued
    sg capture flush                       offer the queue again after an outage
    sg capture opt-out [--undo]            this machine, beating every setting above it
    sg capture coverage --harness <h>      print the adapter's coverage document
    sg capture link <code> --server <url>  install the Claude Code plugin, then exchange a
                                           website link code for this device's token
    sg capture install-plugin              install (or repair) the Claude Code plugin
    sg capture unlink                      forget this device's token

Two authorities can open a session's interval.  The commands above the rule
are the per-session one: notice, confirm, off.  ``link`` is the other: a
person signed in on the website, agreed once to its notice, and minted a
code; exchanging it stores a device token under the client home, and from
then on the Claude Code hook mints every session's interval from that
standing consent at session start.  ``/vicaria:off`` and ``/vicaria:on``, the
plugin's commands, are the switch for one session.  ``link`` installs that
plugin first (:mod:`smart_gateway.capture.install`), so *linked* on the website
means the plugin's own hook ran on this machine.

Two commands do something a reader should expect to be able to check.
``sg capture notice`` makes **no network request** and writes no session content
— only a local receipt that the text was displayed.  ``sg capture status`` reads
files and prints counts; it asks the service nothing, because the point of the
local send log is that a developer can count what left their machine without
trusting a server to tell them.
"""

from __future__ import annotations

import argparse
import json
import os
import platform
import sys
import urllib.parse
from pathlib import Path
from typing import Any

from smart_gateway.capture import coverage as coverage_module
from smart_gateway.capture.api import CaptureApi
from smart_gateway.capture.collector import STANDING_CONSENT, CaptureRefused, collector_for
from smart_gateway.capture.notice import SUPPORTED
from smart_gateway.capture.store import CaptureStore, utc_now

ENV = {
    "server": "VICARIA_CAPTURE_SERVER",
    "org": "VICARIA_CAPTURE_ORG_ID",
    "token": "VICARIA_CAPTURE_TOKEN",
    "sample": "VICARIA_CAPTURE_SAMPLE",
    "home": "VICARIA_HOME",
}


def resolve_credentials(
    *,
    server: str | None = None,
    org: str | None = None,
    token: str | None = None,
    home: str | os.PathLike[str] | None = None,
    environ: Any = None,
) -> dict[str, Any] | None:
    """Where the capture credentials come from, in order: flags, environment, device link.

    The three environment variables are the organization path: an operator's
    token and org id, exported into the shell that launches the harness.  The
    device link is the individual path: ``sg capture link`` stored the token
    the website minted for this machine.  A complete environment wins over a
    link, because the person who exported it meant it; an incomplete one is
    not a credential and falls through.  ``None`` means capture is not
    configured at all --- the ordinary case, and a silent one.
    """
    environ = os.environ if environ is None else environ
    server = server or environ.get(ENV["server"])
    org = org or environ.get(ENV["org"])
    token = token or environ.get(ENV["token"])
    if server and org and token:
        return {"server": server, "org": org, "token": token, "source": "environment"}
    device = CaptureStore(home or environ.get(ENV["home"])).device()
    if device is not None:
        return {
            "server": device["server"],
            "org": device["org_id"],
            "token": device["token"],
            "source": "device",
        }
    return None


def _collector(args: argparse.Namespace, *, needs_service: bool = True) -> Any:
    credentials = resolve_credentials(
        server=args.server,
        org=args.org,
        token=args.token,
        home=args.home or os.environ.get(ENV["home"]),
    )
    if needs_service and credentials is None:
        raise SystemExit(
            f"capture needs {ENV['server']}, {ENV['org']} and {ENV['token']} "
            "(or --server/--org/--token), or a device link from `sg capture link <code>`"
        )
    args._credential_source = credentials["source"] if credentials else None
    return collector_for(
        args.harness,
        org_id=credentials["org"] if credentials else "org_unset",
        server=credentials["server"] if credentials else "http://127.0.0.1:0",
        token=credentials["token"] if credentials else "",
        home=args.home or os.environ.get(ENV["home"]),
        harness_version=args.harness_version,
        surface=lambda line: print(line),
    )


def _sampled_from_env() -> bool:
    """Gate 1 from the environment alone, for callers with no argparse namespace."""
    return (os.environ.get(ENV["sample"]) or "").strip().lower() in ("1", "on", "true", "yes")


def _sampled(args: argparse.Namespace) -> bool:
    """Gate 1 as this client can see it.

    On the organization path it is an environment flag, nothing more: a local
    flag is not an organization sampling policy and not a durable eligibility
    receipt.  It makes the offer available and authorizes nothing.  On the
    individual path the device link is that receipt --- the service minted it
    for this machine and can revoke it --- so a linked device is eligible
    without the flag.  Neither authorizes a session; the grant does.
    """
    return (
        bool(getattr(args, "sampled", False))
        or _sampled_from_env()
        or getattr(args, "_credential_source", None) == "device"
    )


def _cmd_notice(args: argparse.Namespace) -> int:
    # Needs the service identity even though it contacts nothing. The receipt
    # this writes is keyed to the session, the organization, the endpoint and
    # the notice digest, because that is what makes "the grant binds what was
    # shown" true. Run without them it wrote a receipt under `org_unset` at
    # `http://127.0.0.1:0` --- one no real `confirm` can ever match. The
    # developer read the whole notice, was told to run `sg capture confirm`,
    # and got "show the notice first".
    collector = _collector(args)
    receipt = collector.show_notice(args.session)
    print(
        json.dumps(
            {
                "status": "notice_only",
                "session_id": args.session,
                "sent": False,
                "stored_session_content": False,
                "notice_version": receipt.notice_version,
                "client_home": str(collector.store.home),
                "next": (
                    f"after reading the notice: sg capture confirm --harness {args.harness} "
                    f"--session {args.session}"
                ),
            },
            indent=2,
        )
    )
    return 0


def _cmd_confirm(args: argparse.Namespace) -> int:
    collector = _collector(args)
    if collector.store.opted_out():
        print(f"not marked: {OPTED_OUT_NOTE}", file=sys.stderr)
        return 1
    if not _sampled(args):
        print(
            f"capture is not offered for this session: set {ENV['sample']}=on or run "
            "`sg capture --sampled confirm ...`. Eligibility authorizes nothing by itself.",
            file=sys.stderr,
        )
        return 1
    # A session stopped at the end of a harness run (Claude Code's SessionEnd)
    # can only be marked again from the turn it stopped at; turn 0 is refused.
    turn = collector.next_turn(args.session) if args.turn is None else args.turn
    try:
        authorization = collector.confirm(args.session, turn_index=turn, repository=args.repository)
    except CaptureRefused as refusal:
        print(f"refused [{refusal.reason}]: {refusal.detail}", file=sys.stderr)
        return 1
    # Off stands: a switch-off from another terminal landed while the mark
    # was in flight, the collector said so, and the interval it opened is
    # closed by the next flush.  Not "capturing".
    status = "capturing" if collector.active(args.session) else "off"
    print(
        json.dumps(
            {
                "status": status,
                "session_id": args.session,
                "authorized_interval_id": authorization["authorized_interval_id"],
                "first_consented_turn": authorization["first_consented_turn"],
            },
            indent=2,
        )
    )
    return 0 if status == "capturing" else 1


def _cmd_status(args: argparse.Namespace) -> int:
    collector = _collector(args, needs_service=False)
    print(json.dumps(collector.status(args.session), indent=2))
    return 0


def _cmd_install_plugin(args: argparse.Namespace) -> int:
    """Install the Claude Code plugin under the client home and register it.

    The repair for a plugin whose runtime moved (a reinstalled Python, a new
    virtual environment): the files are rewritten pinned to this interpreter,
    the plugin's own hook answers once, and Claude Code is told about it.
    """
    from smart_gateway.capture import install as installer

    home = CaptureStore(args.home or os.environ.get(ENV["home"])).home
    try:
        installed = installer.install(home)
    except (installer.InstallFailed, OSError) as failure:
        print(f"vicaria capture: the plugin cannot run on this machine: {failure}", file=sys.stderr)
        return 1
    print(f"vicaria capture: the plugin answers: {installed.answer}")
    stream = sys.stdout if installed.registered else sys.stderr
    for line in installed.notes:
        print(line, file=stream)
    return 0 if installed.registered else 1


def _cmd_link(args: argparse.Namespace) -> int:
    """Exchange the website's code for this device's token, then say so once.

    The one request this client makes with no credential: the code is the
    credential, minted by a signed-in person and good for one exchange.  The
    token comes back once and goes into ``capture/device.json`` under the
    client home, readable by this user only.  Then one heartbeat, because
    *linked* on the website means a heartbeat arrived, never that a file
    exists; a link that could not send one says so and exits 1 with the file
    kept, so the next ``sg capture status`` can still show what happened.
    """
    server = args.server or os.environ.get(ENV["server"])
    if not server:
        raise SystemExit("sg capture link needs --server <url>: the address shown beside the code")
    parsed = urllib.parse.urlsplit(server)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise SystemExit(
            "sg capture link: --server must be an http:// or https:// address, "
            "as shown beside the code"
        )
    if parsed.scheme == "http" and parsed.hostname not in ("127.0.0.1", "localhost", "::1"):
        # Not refused: a lab server on a private network is a real case. Said
        # once, because a token that travels in clear is worth a sentence.
        print(
            "vicaria capture: the address is plain http, so the token will travel in clear; "
            "use https unless this server is local",
            file=sys.stderr,
        )
    home = args.home or os.environ.get(ENV["home"])
    harness_version = args.harness_version
    if args.harness == "claude-code" and not args.no_plugin:
        # Before the code is spent: a machine that cannot run the plugin keeps
        # its code, and is told why.  A heartbeat from a machine whose plugin
        # cannot start would put *Linked* on the website over a device that
        # captures nothing.
        from smart_gateway.capture import install as installer

        try:
            installed = installer.install(CaptureStore(home).home)
        except (installer.InstallFailed, OSError) as failure:
            print(
                f"not linked: the Claude Code plugin cannot run on this machine: {failure}. "
                "The code is unused: fix that and run the same command again.",
                file=sys.stderr,
            )
            return 1
        if not installed.registered:
            for line in installed.notes:
                print(line, file=sys.stderr)
            print(
                "not linked: the plugin is ready but not installed in Claude Code. The code is "
                "unused: run the lines above, then the same command again.",
                file=sys.stderr,
            )
            return 1
        print(f"vicaria capture: plugin {installed.notes[0]}", file=sys.stderr)
        if harness_version == "unknown":
            harness_version = installer.claude_version() or "unknown"
    name = args.name or platform.node() or "this device"
    body: dict[str, Any] = {
        "code": args.code,
        "name": name,
        "harness": args.harness,
        "platform": platform.system().lower() or None,
    }
    if harness_version != "unknown":
        body["harness_version"] = harness_version
    outcome = CaptureApi(server, "").link_device(body)
    if not outcome.ok or not isinstance(outcome.value, dict):
        print(f"not linked [{outcome.reason}]: {outcome.detail}", file=sys.stderr)
        return 1
    value = outcome.value
    for key in ("token", "org_id", "device_id"):
        if not isinstance(value.get(key), str) or not value[key]:
            print(f"not linked: the service answered without a {key}", file=sys.stderr)
            return 1
    store = CaptureStore(home)
    previous = store.device()
    if previous is None and store.device_path.is_file():
        # The file there does not read as a link: it held no token to settle
        # the sessions it minted with, so they stay as they are.
        print(
            "vicaria capture: the previous link file could not be read as a link; it is "
            "replaced, and nothing it minted could be settled (close its sessions on the "
            "website)",
            file=sys.stderr,
        )
    relink = previous is not None and (
        previous.get("org_id") != value["org_id"] or previous.get("server") != server.rstrip("/")
    )
    if relink and previous is not None:
        # A re-link to another workspace is an unlink, then a link: the
        # previous link's sessions are stopped and flushed under its own
        # credential, what cannot be sent leaves the queue as `unlinked`,
        # and its unacknowledged stops are named.  Left in place they would
        # wait for a credential this machine no longer holds.
        settled: dict[str, Any] = {"stopped": [], "flush": None, "dropped": 0}
        old = collector_for(
            args.harness,
            org_id=previous["org_id"],
            server=previous["server"],
            token=previous["token"],
            home=home,
            harness_version=args.harness_version,
            surface=lambda line: print(line, file=sys.stderr),
        )
        old_standing = _standing_sessions(old) | _stop_naming_sessions(old)
        try:
            _settle_before_unlink(old, old_standing, settled)
        except Exception as failure:
            settled["settle_failed"] = f"{type(failure).__name__}: {failure}"
    try:
        store.save_device(
            {
                "server": server.rstrip("/"),
                "org_id": value["org_id"],
                "device_id": value["device_id"],
                "token": value["token"],
                "name": name,
                "scopes": value.get("scopes") or [],
                "linked_at": utc_now(),
            }
        )
    except OSError as failure:
        # The code is spent and the token is not on disk: said plainly, so
        # the person links again with a new code rather than finding a
        # traceback and a machine that still believes the old link.  The
        # old link's sessions are off and flushed, nothing of theirs is
        # discarded, and the old token can still deliver what is pending.
        if relink and previous is not None:
            # What the settle did stands (its sessions are off until
            # `/vicaria on`, and linking again settles nothing): said
            # before the failure, not lost to it.
            print(_settled_line(previous["org_id"], settled), file=sys.stderr)
        print(f"not linked: the token could not be stored ({failure}); link again", file=sys.stderr)
        return 1
    if relink and previous is not None:
        # The old token is gone from this machine: what it alone could have
        # delivered leaves with it.
        raised = _discard(old, old_standing, settled)
        notice = settled.pop("notice", "")
        print(_settled_line(previous["org_id"], settled), file=sys.stderr)
        if notice:
            print(notice, file=sys.stderr)
        if raised:
            print(raised, file=sys.stderr)
    if store.opted_out():
        # The link is the website's record of this device, not capture: the
        # code exchange and the heartbeat go, and nothing else will.  Said
        # before the heartbeat, whose failure ends the command.
        print(
            "vicaria capture: this machine is opted out: the device is linked, and no "
            "session is captured or sent until `sg capture opt-out --undo`",
            file=sys.stderr,
        )
    beat = CaptureApi(server, value["token"]).heartbeat(
        {"harness_version": harness_version} if harness_version != "unknown" else {}
    )
    if not beat.ok:
        print(
            f"vicaria capture: token stored for {name}, but the heartbeat failed "
            f"[{beat.reason}]: {beat.detail}. The website will not say linked until one arrives.",
            file=sys.stderr,
        )
        return 1
    print(f"vicaria capture: linked · {name} · heartbeat sent")
    return 0


def _cmd_unlink(args: argparse.Namespace) -> int:
    """Forget the token, after settling what was queued under it.

    An unlink used to remove the credential and nothing else: intervals this
    link had opened stayed active, and events queued from a deferred upload
    sat in the queue with no token that could ever send them and no line in
    either log.  So, with the token it is about to forget: close the
    intervals it opened (gesture ``switch_off``), offer each of its sessions'
    queues once, and drop what the service did not take with reason
    ``unlinked``.  Sessions and events under an organization's credentials
    are not this link's: they are neither offered to the device's server nor
    dropped, whatever happens.  The token is forgotten whatever the settling
    did: a settle that fails is reported in the summary, never a reason to
    keep a credential the person asked to be rid of.
    """
    home = args.home or os.environ.get(ENV["home"])
    store = CaptureStore(home)
    device = store.device()
    summary: dict[str, Any] = {"unlinked": False, "stopped": [], "flush": None, "dropped": 0}
    if device is None and store.device_path.is_file():
        # A file that does not read as a link holds no token to settle
        # with: forgotten all the same, and said, so a session it minted is
        # not left looking settled.
        summary["link_unreadable"] = True
        print(
            "vicaria capture: the link file could not be read as a link; it is forgotten, "
            "and nothing it minted could be settled (close its sessions on the website)",
            file=sys.stderr,
        )
    if device is not None:
        collector = collector_for(
            args.harness,
            org_id=device["org_id"],
            server=device["server"],
            token=device["token"],
            home=home,
            harness_version=args.harness_version,
            surface=lambda line: print(line, file=sys.stderr),
        )
        standing = _standing_sessions(collector) | _stop_naming_sessions(collector)
        try:
            _settle_before_unlink(collector, standing, summary)
        except Exception as failure:
            summary["settle_failed"] = f"{type(failure).__name__}: {failure}"
    try:
        summary["unlinked"] = store.forget_device()
    except OSError as failure:
        # The token is still on disk, and so is everything it can still
        # deliver: nothing is discarded, and the person is told.
        print(f"not unlinked: the token could not be forgotten ({failure})", file=sys.stderr)
        return 1
    if device is not None:
        raised = _discard(collector, standing, summary)
        notice = summary.pop("notice", "")
        if notice:
            print(notice, file=sys.stderr)
        if raised:
            print(raised, file=sys.stderr)
    summary["home"] = str(store.home)
    summary["note"] = (
        "the token is forgotten on this machine; revoke the device on the website "
        "to refuse it everywhere. Nothing already sent is erased by this."
    )
    print(json.dumps(summary, indent=2))
    return 0


def _settled_line(org_id: str, settled: dict[str, Any]) -> str:
    """The one line a re-link prints for the previous link, whatever came after."""
    return (
        f"vicaria capture: the previous link ({org_id}) was settled first: "
        f"stopped {len(settled['stopped'])} (off until /vicaria:on), "
        f"dropped {settled['dropped']}"
        + (f", settle failed: {settled['settle_failed']}" if "settle_failed" in settled else "")
        + (
            ", the service was told nothing of it (this machine is opted out)"
            if (settled.get("flush") or {}).get("opted_out")
            else ""
        )
    )


def _standing_sessions(collector: Any) -> set[str]:
    """The sessions this link minted, its workspace and server: the ones a settle may touch.

    A session another link left on (a mint whose save landed after that
    link's discard listed the sessions) is not this link's to stop: stopped
    here, its stop would be kept for a flush under a credential the machine
    may never hold again, and every later mint of it refused for that.
    """
    return {
        str(state.get("session_id"))
        for state in collector.store.sessions()
        if state.get("authority") == STANDING_CONSENT
        and state.get("org_id") == collector.org_id
        and state.get("server") == collector.api.server
    }


def _stop_naming_sessions(collector: Any) -> set[str]:
    """Another workspace's sessions holding a stop that names this one.

    A switch-off under another link rewrites a state's workspace and keeps
    the stop, which names the workspace its interval was minted in: the
    stop is this credential's to deliver (the settle offers it, token in
    hand) and, once the token is gone, this discard's to pop.  A state of
    this workspace on another server is not here: the stop names no
    server, and that link's it is.
    """
    return {
        str(state.get("session_id"))
        for state in collector.store.sessions()
        if isinstance(state.get("pending_revoke"), dict)
        and state["pending_revoke"].get("org_id") == collector.org_id
        and state.get("org_id") != collector.org_id
    }


def _settle_before_unlink(collector: Any, standing: set[str], summary: dict[str, Any]) -> None:
    """Stop and flush this link's sessions, and deliver the stops that name
    its workspace on another workspace's state, under its own credential.

    On an opted-out machine nothing is sent: the opt-out beats every setting
    above it, the unlink included, so no stop reaches the service and no
    queued text is uploaded; the discard then switches the sessions off on
    disk (named, the service not told) and drops what the token alone could
    have delivered.  Otherwise nothing here is discarded: the intervals are
    closed on the service and the queues offered, but a stop the service did
    not hear stays pending
    and the queue stays queued, so a caller whose save or forget then fails
    leaves a machine that can still deliver both.  What cannot
    be delivered once the token is gone is discarded by
    :func:`_discard_after_unlink`, after the token is.
    """
    refused: dict[str, str] = {}
    summary["refused_stops"] = refused
    if collector.store.opted_out():
        summary["flush"] = {
            "sessions": len(standing),
            "offered": 0,
            "stored": 0,
            "opted_out": True,
        }
        return
    for state in list(collector.store.sessions()):
        session_id = str(state.get("session_id"))
        if session_id in standing and state.get("active"):
            stopped = collector.stop(session_id, reason="developer_unmarked", gesture="switch_off")
            if not stopped.get("stopped"):
                # Off since the listing (a `SessionEnd` or `/vicaria off`
                # landed meanwhile): not this settle's stop, and nothing to
                # report for it.
                continue
            summary["stopped"].append(session_id)
            if not stopped.get("service_acknowledged") and not isinstance(
                (collector.store.session(session_id) or {}).get("pending_revoke"), dict
            ):
                # Answered and refused (a token already revoked on the
                # website): not pending, not acknowledged either.
                refused[session_id] = str(stopped.get("detail") or "refused")
    offered = stored = 0
    for session_id in sorted(standing):
        flushed = collector.flush(session_id)
        offered += flushed["offered"]
        stored += flushed["stored"]
        # A stop pending before the settle, sent by this flush and refused
        # (a token already revoked on the website): cleared by the refusal,
        # so named here, as a stop the settle made and saw refused is.
        answer = collector._revoked.get(session_id)
        if (
            answer is not None
            and not answer.ok
            and session_id not in refused
            and not isinstance(
                (collector.store.session(session_id) or {}).get("pending_revoke"), dict
            )
        ):
            refused[session_id] = str(answer.detail or "refused")
    summary["flush"] = {"sessions": len(standing), "offered": offered, "stored": stored}


def _discard(collector: Any, standing: set[str], summary: dict[str, Any]) -> str:
    """Run the discard; a raise that escapes it is recorded in the summary
    and returned as the line to print after the discard's own, so that what
    the discard did before the raise and the raise itself are both said."""
    try:
        _discard_after_unlink(collector, standing, summary)
    except Exception as failure:
        what = f"{type(failure).__name__}: {failure}"
        summary.setdefault("discard_failed", []).append(what)
        return f"vicaria capture: the discard raised before it could finish: {what}"
    return ""


def _name_what_stays(
    session_id: str,
    failure: OSError,
    pending: Any,
    still_on: bool,
    interval: str | None,
    read: bool,
    failed: list[str],
    foreign: set[str],
) -> None:
    """A discard step that failed before its save: the record stays as it
    was, and the entry says what that is (the pop and the switch-off were in
    memory until the save)."""
    stays = []
    if isinstance(pending, dict):
        stays.append(
            "its stop is still pending on disk, and a mint of this session under a link to "
            "another workspace is refused until that stop is delivered under "
            f"{pending.get('org_id')} or the state file is removed"
        )
    if still_on:
        stays.append(f"it is still on (interval {interval})")
    if not read:
        # The lock (or the read) raised before the record was seen: whose
        # it is could not be told, and a drop is for good, so its queue
        # stays with it.
        foreign.add(session_id)
        stays.append(
            "the lock could not be taken; its record was not touched and its queue is kept"
        )
    failed.append(
        f"{session_id}: {type(failure).__name__}: {failure}"
        + (f" ({'; '.join(stays)})" if stays else "")
    )


def _discard_after_unlink(collector: Any, standing: set[str], summary: dict[str, Any]) -> None:
    """What the forgotten token could have delivered leaves with it.

    Run only once the token is gone from this machine.  A session the
    settle left on (it raised before reaching it) is switched off on disk,
    with no service to tell; a stop the service never acknowledged is
    popped and named in the drop log (with the token gone no hook can
    deliver it, and a mark under the next link must not wait for one), on
    this link's own sessions and on a state another workspace's switch-off
    rewrote alike, since a stop names the workspace its interval was minted
    in; a stop naming another workspace is kept for that workspace's
    credential (``kept_stops``); a stop on a state of this workspace on
    another server is that link's and is left as it is, unnamed; and
    what is still queued under the old credential leaves the queue with its
    reason, except the queue of a session of this workspace on another server
    or whose record could not be read, which stays (a drop is for good, and
    events name no server); this workspace's events of a session another
    workspace now holds leave with the token, since no credential left on the
    machine can deliver them.  The sessions are listed again here, after the token went: a
    session a hook minted while the settle ran is the old link's too, and
    left alone it would stay on under a credential no hook can settle with.
    Every step is guarded on its own and named when it fails
    (``discard_failed``), so one unwritable record does not skip the rest;
    what such a record holds stays as it was (a stop of it still pending on
    disk, a session of it still on) and its entry says so.  The line for
    stderr is left in ``summary["notice"]`` for the caller to print in
    order.
    """
    failed: list[str] = []
    left_open: dict[str, str] = {}
    unacknowledged: list[str] = []
    # A stop naming another workspace, found on a state a switch-off under
    # this link rewrote: kept for that workspace's credential, never popped.
    kept: dict[str, str] = {}
    # Named as soon as it is done, so a raise later in the discard still
    # leaves the summary saying what was popped and switched off.
    summary["unacknowledged_stops"] = unacknowledged
    summary["left_open"] = left_open
    summary["discard_failed"] = failed
    summary["kept_stops"] = kept
    # Sessions of this workspace on another server, or whose record could
    # not be read: the state check below protects their state, and this set
    # keeps their queue, which the events' workspace alone cannot tell apart
    # on a re-link that changed only the server.  Another workspace's state
    # needs no entry: the queue drops this workspace's events alone.
    foreign: set[str] = set()
    try:
        # Listed again now that the old token is gone (or the new one
        # saved): a session whose mint saved during the settle joins the
        # set; one whose mint is still in flight is not seen and stays on.
        # The listing is this link's workspace and server; the check below
        # matters for a session listed before the settle and minted again
        # under the new link meanwhile, which is left alone.
        standing = set(standing) | _standing_sessions(collector)
        # And the sessions holding a stop that names this workspace on a
        # state another workspace's switch-off rewrote: the stop is this
        # workspace's to deliver, and with the token gone nobody can.  (A
        # state of this workspace on another server keeps its stop: the
        # stop names no server, and that link's it is.)
        standing |= _stop_naming_sessions(collector)
        for session_id in sorted(standing):
            pending: Any = None
            still_on = False
            read = False
            saved = False
            interval = None
            try:
                with collector.store.session_lock():
                    state = collector.store.session(session_id)
                    if state is None:
                        if collector.store.session_path(session_id).is_file():
                            # On disk but not readable as a record (the
                            # store reads such a file as absence): whose it
                            # is cannot be told, and a drop is for good, so
                            # its queue stays with it.
                            foreign.add(session_id)
                            failed.append(
                                f"{session_id}: its record could not be read; its queue is kept"
                            )
                        continue
                    read = True
                    # Only what is the old credential's: a session already
                    # minted again under the new link (another workspace,
                    # or the same one on another server), or stopped under
                    # it, is its.  The events carry no server, so the queue
                    # below is scoped by workspace alone.
                    mine = (
                        state.get("org_id") == collector.org_id
                        and state.get("server") == collector.api.server
                    )
                    if not mine and state.get("org_id") == collector.org_id:
                        # This workspace on another server: its queued
                        # events name the workspace and not the server, so
                        # the ones there may be that link's.  A state of
                        # another workspace needs no such guard: the queue
                        # below drops this workspace's events alone, which
                        # no credential left on the machine can deliver.
                        foreign.add(session_id)
                    pending = state.get("pending_revoke")
                    if not isinstance(pending, dict):
                        pending = None
                    elif pending.get("org_id") == collector.org_id and (
                        mine or state.get("org_id") != collector.org_id
                    ):
                        # This workspace's stop, on its own state or on one
                        # another workspace's switch-off rewrote: popped,
                        # since nobody can deliver it once the token is
                        # gone.  (On a state of this workspace on another
                        # server it is that link's, and stays.)
                        state.pop("pending_revoke", None)
                    elif mine:
                        # The stop names the workspace its interval was
                        # minted in, and a switch-off under this link
                        # rewrote the state's; the stop is that workspace's
                        # to deliver and is never written over
                        # (`_revoke_pending` asks the stop, not the state,
                        # for the same reason).
                        kept[session_id] = str(pending.get("org_id"))
                        pending = None
                    else:
                        pending = None
                    still_on = bool(state.get("active")) and mine
                    if still_on:
                        interval = str(
                            (state.get("authorization") or {}).get("authorized_interval_id")
                        )
                        state.update(
                            active=False, stopped_at=utc_now(), stop_reason="developer_unmarked"
                        )
                    if isinstance(pending, dict) or still_on:
                        collector.store.save_session(state)
                        saved = True
                        if still_on:
                            # Named as switched off only once the save
                            # landed; a save that failed leaves it on, and
                            # the entry below says so.
                            left_open[session_id] = str(interval)
            except OSError as failure:
                if saved:
                    # The lock's release failed after the save landed: the
                    # pop and the switch-off are on disk, and named below
                    # like any other.
                    failed.append(
                        f"{session_id}: {type(failure).__name__}: {failure} "
                        "(after its record was saved)"
                    )
                else:
                    _name_what_stays(
                        session_id, failure, pending, still_on, interval, read, failed, foreign
                    )
                    continue
            if isinstance(pending, dict):
                unacknowledged.append(session_id)
                detail = (
                    "the device link was forgotten before the service acknowledged the stop "
                    f"of interval {pending.get('authorized_interval_id')} at turn "
                    f"{pending.get('turn_index')}"
                )
            elif still_on:
                detail = (
                    "the device link was forgotten while this session was still open "
                    f"(interval {left_open[session_id]}); switched off here, the service not told"
                )
            else:
                continue
            try:
                collector.store.append_drop_log(
                    {
                        "at": utc_now(),
                        "event_id": None,
                        "session_id": session_id,
                        "reason": "unlinked",
                        "detail": detail,
                    }
                )
            except OSError as failure:
                failed.append(f"{session_id} (log): {type(failure).__name__}: {failure}")
        try:
            queued_before = [
                event
                for event in collector.store.pending()
                if str(event.get("session_id")) in standing - foreign
                and event.get("org_id") == collector.org_id
            ]
        except OSError as failure:
            failed.append(f"the queue could not be listed: {type(failure).__name__}: {failure}")
            queued_before = []
        for event in queued_before:
            try:
                # Counted by the drop's own answer: an event another process
                # stored meanwhile was not there to drop, and one whose line
                # could not be written left the queue all the same.
                removed = collector.store.drop(
                    str(event["event_id"]),
                    reason="unlinked",
                    session_id=str(event.get("session_id")),
                    detail="the device link was forgotten before this event could be sent",
                    only_if_queued=True,
                )
            except OSError as failure:
                failed.append(f"{event['event_id']}: {type(failure).__name__}: {failure}")
                removed = not (
                    collector.store.capture / "queue" / f"{event['event_id']}.json"
                ).exists()
            if removed:
                summary["dropped"] += 1
    finally:
        if not failed:
            summary.pop("discard_failed", None)
        if not kept:
            summary.pop("kept_stops", None)
        refused = summary.get("refused_stops") or {}
        named = sorted(set(unacknowledged) | set(refused) | set(left_open))
        notice = ""
        if named:
            notice = (
                (
                    "vicaria capture: this machine is opted out, so the service was not "
                    "told of the stop of "
                    if (summary.get("flush") or {}).get("opted_out")
                    else "vicaria capture: the service did not acknowledge the stop of "
                )
                + f"{', '.join(named)}"
                + (
                    " (" + "; ".join(f"{sid}: {why}" for sid, why in sorted(refused.items())) + ")"
                    if refused
                    else ""
                )
                + (
                    " (still open when the link went: "
                    + ", ".join(f"{sid} interval {iv}" for sid, iv in sorted(left_open.items()))
                    + ")"
                    if left_open
                    else ""
                )
                + "; the interval stays open on the service until it is closed there "
                "(stop the session on its page, or withdraw)"
            )
        if kept:
            notice = (notice + "; " if notice else "vicaria capture: ") + "; ".join(
                f"a stop under {org} stays pending on {sid}, for "
                f"`sg capture flush --session {sid}` under that credential"
                for sid, org in sorted(kept.items())
            )
        if failed:
            notice = (notice + "; " if notice else "vicaria capture: ") + (
                "the discard could not finish for " + "; ".join(failed)
            )
        if notice:
            summary["notice"] = notice


OPTED_OUT_NOTE = (
    "this machine is opted out: nothing is sent, and what is queued waits for "
    "`sg capture opt-out --undo`"
)


def _cmd_off(args: argparse.Namespace) -> int:
    collector = _collector(args)
    if collector.store.opted_out():
        # Gate 2 beats this command as it beats the hook's `/vicaria off`:
        # the session is switched off on disk and the service is not told.
        state = collector.store.session(args.session)
        was_on = bool(state and state.get("active"))
        if was_on:
            collector.switch_off_before_mint(args.session, rescope=False)
        print(
            json.dumps({"stopped": was_on, "service_told": False, "note": OPTED_OUT_NOTE}, indent=2)
        )
        return 0
    print(json.dumps(collector.stop(args.session), indent=2))
    return 0


def _cmd_flush(args: argparse.Namespace) -> int:
    collector = _collector(args)
    result = collector.flush(args.session)
    if result.get("opted_out"):
        result["note"] = OPTED_OUT_NOTE
    print(json.dumps(result, indent=2))
    return 0


def _cmd_opt_out(args: argparse.Namespace) -> int:
    collector = _collector(args, needs_service=False)
    collector.store.set_opt_out(not args.undo)
    print(
        json.dumps(
            {
                "opted_out": collector.store.opted_out(),
                "home": str(collector.store.home),
                "note": (
                    "this machine's opt-out beats every setting above it, including an "
                    "organization's sampling policy"
                ),
            },
            indent=2,
        )
    )
    return 0


def _cmd_coverage(args: argparse.Namespace) -> int:
    print(
        json.dumps(
            coverage_module.document(args.harness, harness_version=args.harness_version),
            indent=2,
            sort_keys=True,
        )
    )
    return 0


def _cmd_feedback(args: argparse.Namespace) -> int:
    collector = _collector(args)
    open_gate, refusal = collector.gates(sampled=_sampled(args), session_id=args.session)
    if not open_gate:
        print(f"not recording feedback: {refusal}", file=sys.stderr)
        return 1
    state = collector.store.session(args.session) or {}
    # The comment goes as typed (RFC 0039); its length is kept for the line below.
    comment_length = len(args.comment or "")
    try:
        collector.record_feedback(
            args.session,
            turn_index=int(state.get("turn_index") or 0),
            direction=args.direction,
            comment=args.comment or None,
        )
    except CaptureRefused as refusal:
        # Switched off between the gate and the write.
        print(f"refused [{refusal.reason}]: {refusal.detail}", file=sys.stderr)
        return 1
    result = collector.flush(args.session)
    print(
        json.dumps(
            {
                "recorded": args.direction,
                "comment_length": comment_length,
                "comment_text_sent": bool(args.comment),
                "flush": result,
            },
            indent=2,
        )
    )
    return 0


def _cmd_terminal_connect(args):
    from .terminal import connect_command

    return connect_command(args)


def _cmd_terminal_disconnect(args):
    from .terminal import home_for

    args.home = str(home_for(args))
    return _cmd_unlink(args)


def _cmd_terminal_run(args):
    from .terminal import run_command

    return run_command(args)


def add_parser(sub: Any) -> None:
    """Register ``sg capture`` on the main CLI's subparsers."""
    parser = sub.add_parser(
        "capture", help="consent-bound session capture for continuous benchmarking"
    )
    parser.add_argument(
        "--harness", choices=SUPPORTED, help="default: claude-code; `codex` implies codex"
    )
    parser.add_argument("--harness-version", default="unknown")
    parser.add_argument("--server", help=f"default: ${ENV['server']}")
    parser.add_argument("--org", help=f"default: ${ENV['org']}")
    parser.add_argument("--token", help=f"default: ${ENV['token']}")
    parser.add_argument("--home", help=f"client home; default: ${ENV['home']} or ~/.vicaria")
    parser.add_argument(
        "--sampled",
        action="store_true",
        help="make the offer available for this session; authorizes nothing",
    )
    # The host CLI dispatches on `func`; each operation below sets its own
    # `capture_handler`, and this is the one bridge between the two.
    parser.set_defaults(func=dispatch)
    csub = parser.add_subparsers(dest="capture_command", required=True, metavar="<op>")

    q = csub.add_parser("notice", help="show the notice; no network request, no content stored")
    q.add_argument("--session", required=True)
    q.set_defaults(capture_handler=_cmd_notice)

    q = csub.add_parser("confirm", help="the confirmation gesture; opens one interval")
    q.add_argument("--session", required=True)
    q.add_argument(
        "--turn", type=int, help="first covered turn; default: the session's next turn on disk"
    )
    q.add_argument("--repository")
    q.set_defaults(capture_handler=_cmd_confirm)

    q = csub.add_parser("status", help="what this machine holds; reads files only")
    q.add_argument("--session")
    q.set_defaults(capture_handler=_cmd_status)

    q = csub.add_parser("off", help="close the interval; stopping is not erasing")
    q.add_argument("--session", required=True)
    q.set_defaults(capture_handler=_cmd_off)

    q = csub.add_parser("flush", help="offer the queue again after an outage")
    q.add_argument("--session")
    q.set_defaults(capture_handler=_cmd_flush)

    q = csub.add_parser("opt-out", help="this machine; beats every setting above it")
    q.add_argument("--undo", action="store_true")
    q.set_defaults(capture_handler=_cmd_opt_out)

    q = csub.add_parser("coverage", help="print this adapter's coverage document")
    q.set_defaults(capture_handler=_cmd_coverage)

    q = csub.add_parser(
        "feedback", help="a thumbs up or down on the last turn, with the comment as typed"
    )
    q.add_argument("--session", required=True)
    q.add_argument("direction", choices=("up", "down"))
    q.add_argument("--comment", default="", help="sent as typed, with the session (RFC 0039)")
    q.set_defaults(capture_handler=_cmd_feedback)

    q = csub.add_parser("connect", help="connect a terminal harness to your personal account")
    q.add_argument("--server", default=argparse.SUPPRESS)
    q.set_defaults(capture_handler=_cmd_terminal_connect)

    q = csub.add_parser(
        "disconnect", help="disconnect one personal terminal harness on this computer"
    )
    q.set_defaults(capture_handler=_cmd_terminal_disconnect)

    q = csub.add_parser("run", help="record one terminal harness run to your personal account")
    q.add_argument("--prompt", required=True)
    q.set_defaults(capture_handler=_cmd_terminal_run)

    q = csub.add_parser("link", help="exchange a website link code for this device's token")
    q.add_argument("code", help="the single-use code the website shows")
    q.add_argument("--name", help="how the website names this device; default: the hostname")
    # Accepted here as well as before the subcommand, because the website
    # prints `sg capture link <code> --server <url>`. SUPPRESS keeps a value
    # given before the subcommand from being overwritten with None.
    q.add_argument("--server", default=argparse.SUPPRESS, help="the address shown beside the code")
    q.add_argument(
        "--no-plugin",
        action="store_true",
        help="link without installing the Claude Code plugin (a checkout loaded with --plugin-dir)",
    )
    q.set_defaults(capture_handler=_cmd_link)

    q = csub.add_parser(
        "install-plugin", help="install (or repair) the Claude Code plugin, pinned to this Python"
    )
    q.set_defaults(capture_handler=_cmd_install_plugin)

    q = csub.add_parser("unlink", help="forget this device's token on this machine")
    q.set_defaults(capture_handler=_cmd_unlink)

    # `--harness` is also accepted after the operation, where the runbook puts
    # it: `sg capture confirm --harness codex ...`. SUPPRESS keeps a value given
    # before the operation from being overwritten with None.
    for op in csub.choices.values():
        op.add_argument("--harness", choices=SUPPORTED, default=argparse.SUPPRESS)


def _resolve_harness(args: argparse.Namespace) -> None:
    """The terminal launcher's commands name their harness; everything else
    defaults to Claude Code.  (``sg capture codex``, the wrapper around
    ``codex exec``, is retired: Codex is captured by its plugin, RFC 0048.)
    """
    if args.capture_handler in (_cmd_terminal_connect, _cmd_terminal_run, _cmd_terminal_disconnect):
        if args.harness not in ("codex", "opencode"):
            raise SystemExit("Choose --harness codex or opencode; Claude Code uses its plugin")
        return
    if args.harness is None:
        args.harness = "claude-code"
    if args.harness == "codex":
        # Codex's state lives where its plugin keeps it (the shim sets
        # <home>/harnesses/codex), so a confirmation or a stop made here is one
        # the plugin sees. The launcher's commands add the harness themselves.
        base = Path(args.home or os.environ.get(ENV["home"]) or Path.home() / ".vicaria")
        # Idempotent: the launcher's commands take the base home and append the
        # same two parts themselves, and the runbook says to pass the base, so a
        # home already naming this harness is that home, not its parent. Without
        # this, `--home <...>/harnesses/codex` confirmed into a directory nested
        # one level below the one the plugin reads, silently.
        suffix = ("harnesses", "codex")
        if base.parts[-2:] != suffix:
            base = base.joinpath(*suffix)
        args.home = str(base)


def dispatch(args: argparse.Namespace) -> int:
    _resolve_harness(args)
    return int(args.capture_handler(args))


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="sg capture")
    sub = parser.add_subparsers(dest="command", required=True)
    add_parser(sub)
    args = parser.parse_args(argv)
    return dispatch(args)


if __name__ == "__main__":
    raise SystemExit(main())
