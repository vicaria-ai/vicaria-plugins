"""Consent-bound session capture, for harnesses other than OpenCode.

``plugin-opencode/src/capture*.ts`` is the capture adapter that shipped first:
TypeScript, inside the OpenCode plugin, because that is where OpenCode lets a
plugin live.  Claude Code and Codex are reached from Python — Claude Code
through the hook shims this repository already installs, Codex by wrapping
``codex exec --json`` — so this package is the same behaviour on that side of
the line.

It is a second implementation of the *collector*, and deliberately not a second
implementation of the *contract*.  Every event it emits is
``cb.session_event.v4`` as ``vicaria-contracts`` defines it, with
the content digest taken by that package's own RFC 8785 canonicalizer, so the
two collectors' events are interchangeable to the service and to the audit
surface.  Where the harnesses differ, they differ in the published
adapter-coverage document, which is exactly the place the design put that
difference.

The four gates, unchanged per harness
-------------------------------------
Capture is off unless all four hold, in order, and absence of any of them means
off:

1. the organization permits sampling;
2. the developer has not opted out on this machine;
3. the repository and paths are not excluded;
4. **the developer marked this session**, after being shown the notice in full.

Nothing in a harness integration may turn capture on by itself.  The fourth
gate has a second authority on a linked device (``sg capture link``): a person
who agreed once on the website, whose standing consent the service answers with
an interval per session at ``SessionStart`` (:meth:`CaptureCollector.
mint_from_standing_consent`), until ``/vicaria off``; the first three gates are
read as before, the machine opt-out first.  An unmarked
session writes nothing to the queue and creates no file or directory --- not
even the client home, and not the producer id, which is minted on the first
event rather than when a collector is constructed.  The only work it adds to a
hook is reading two paths that do not exist.

Where the harnesses genuinely differ
------------------------------------
Two differences are real and are recorded rather than smoothed over:

* **Claude Code observes more than OpenCode.**  ``SessionStart`` carries the
  model, ``SessionEnd`` gives a terminal instant, ``SubagentStart``/``SubagentStop``
  give a subagent boundary, and ``PreToolUse``/``PostToolUse`` carry tool inputs
  and outputs.  All four are captured (vicaria-docs RFC 0039): tool inputs and
  outputs go as Claude Code hands them, cut only over 1 MiB with the cut
  counted on the event, and nothing is redacted; the OpenCode adapter sends
  them too.  The coverage document records each as ``observed``.

* **Codex ``exec`` is not interactive, so the notice cannot be shown mid-run.**
  A headless run has nowhere to put a notice and no gesture to read back.  The
  answer is not to weaken the gate: capture for Codex is refused unless a
  confirmation receipt for that working directory already exists, recorded by
  ``sg capture confirm`` in a terminal where a person read the notice. The
  coverage document says the recording indicator is ``at_mark_only`` and names
  that as the compensation, rather than claiming parity with a TUI.
"""

from __future__ import annotations

from smart_gateway.capture.collector import CaptureCollector, CaptureRefused
from smart_gateway.capture.notice import Notice, notice_for

__all__ = ["CaptureCollector", "CaptureRefused", "Notice", "notice_for"]
