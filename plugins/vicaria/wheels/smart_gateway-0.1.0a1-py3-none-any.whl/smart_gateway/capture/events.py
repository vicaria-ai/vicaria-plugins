"""Compatibility import: moved to ``vicaria_client.events`` (vicaria-docs RFC 0065 §3.7)."""

import importlib
import sys

sys.modules[__name__] = importlib.import_module("vicaria_client.events")
