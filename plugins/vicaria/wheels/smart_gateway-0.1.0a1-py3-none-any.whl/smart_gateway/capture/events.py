"""Build ``cb.session_event.v4`` documents, and take their content digest.

The canonicalizer is **not** written here.  ``intelligent-tools`` ships
``contracts/cb/primitives.py`` precisely because a second implementation of
"what is the canonical form of this document" is how two producers end up
disagreeing about whether a retry is a retry, and this package is already a
second *collector*.  So the digest is taken by that module, located the way the
rest of this repository locates the contracts.

What the digest covers
----------------------
Everything except ``content_digest`` itself and ``observed_at``.  The exclusion
of ``observed_at`` is the one that matters: a replacement collector picking a
queued event up after a restart records a new observation instant, and if that
instant were inside the digest the replayed event would be a different document
from the one that was queued.  The OpenCode collector excludes the same two
fields, which is what makes the two collectors' events interchangeable.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from types import ModuleType
from typing import Any

from vicaria_contracts.resources import CB, load_cb

#: v4 (vicaria-docs RFC 0039): feedback.added carries the comment as typed.
EMITTED_EVENT_VERSION = "cb.session_event.v4"

EVENT_TYPES = (
    "session.started",
    "user_message.recorded",
    "tool.started",
    "tool.finished",
    "assistant_message.recorded",
    "feedback.added",
    "consent.changed",
    "collection.stopped",
)

#: Fields outside the content digest, and why. Kept as a constant so the reason
#: travels with the rule.
DIGEST_EXCLUDES = ("content_digest", "observed_at")

#: The contract's closed vocabularies, repeated here so a builder refuses a
#: value at the call site instead of handing the service a document it will
#: reject after the event is already queued.
TURN_TERMINATIONS = ("continuing", "not_observed", "completed", "stopped", "error")
STOP_REASONS = (
    "developer_unmarked",
    "excluded_path",
    "session_ended",
    "client_shutdown",
    "organization_disabled",
)

#: ``turn_termination: not_observed`` is the one payload value the contract
#: binds to an envelope field: the event must carry a ``turn_termination``
#: omission beside it, so an ending nobody saw is a labelled hole rather than a
#: blank (session-event.schema.json, ``bind_unobserved_termination``). The
#: Codex adapter reaches this value whenever a stream ends with text and no
#: terminal event -- an interrupted run -- and the events it built were refused
#: by the service as a contract violation with the turn already queued.
UNOBSERVED_TERMINATION = "not_observed"

_primitives: ModuleType | None = None


def _contracts_location() -> Path:
    override = os.environ.get("VICARIA_CONTRACTS")
    if override:
        return Path(override).expanduser().resolve()
    return CB


def primitives() -> ModuleType:
    """The contracts' canonicalizer, loaded once, or a clear failure."""
    global _primitives
    if _primitives is not None:
        return _primitives
    path = _contracts_location() / "primitives.py"
    if not path.is_file():
        raise RuntimeError(
            f"the cb contracts are not at {path}; set VICARIA_CONTRACTS to the "
            "CB directory from vicaria-contracts"
        )
    _primitives = load_cb("primitives", _contracts_location())
    return _primitives


def content_digest(event: dict[str, Any]) -> str:
    """The event's digest over its canonical form, minus the excluded fields."""
    immutable = {key: value for key, value in event.items() if key not in DIGEST_EXCLUDES}
    return primitives().digest_over(immutable)


def stable_id(prefix: str, *parts: str) -> str:
    """A routable id derived from its parts, matching the OpenCode collector's.

    Derived rather than random so that the *same* observation re-offered after
    a restart carries the same id: the service can then recognize a retry
    instead of storing a second copy of one turn.
    """
    digest = hashlib.sha256("\u0000".join(parts).encode("utf-8")).hexdigest()
    return f"{prefix}_{digest[:28]}"


def coverage_id(harness: str, harness_version: str, adapter_version: str) -> str:
    """``cov_<harness>_<harness_version>_adapter_<adapter_version>``.

    An event has to name the *published* coverage record, not a private hash of
    the same facts, or the service can never join a session to the document that
    says what its adapter could and could not see.
    """

    def routable(value: str) -> str:
        return "".join(
            character if character.isalnum() or character in "_.:@+,=~-" else "_"
            for character in value
        )

    return (
        f"cov_{routable(harness)}_{routable(harness_version)}_adapter_{routable(adapter_version)}"
    )


def build(
    *,
    event_type: str,
    event_id: str,
    org_id: str,
    session_id: str,
    producer_id: str,
    producer_seq: int,
    event_time: str,
    observed_at: str,
    consent: dict[str, Any],
    adapter: dict[str, Any],
    payload: dict[str, Any],
    turn_index: int | None = None,
    parent_event_id: str | None = None,
    correlation_id: str | None = None,
    subagent_id: str | None = None,
    recorded_omissions: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """One sealed event document."""
    if event_type not in EVENT_TYPES:
        raise ValueError(f"event_type must be one of {list(EVENT_TYPES)}, got {event_type!r}")
    document: dict[str, Any] = {
        "schema_version": EMITTED_EVENT_VERSION,
        "event_id": event_id,
        "org_id": org_id,
        "session_id": session_id,
        "producer_id": producer_id,
        "producer_seq": producer_seq,
        "event_type": event_type,
        "event_time": event_time,
        "observed_at": observed_at,
        "turn_index": turn_index,
        "parent_event_id": parent_event_id,
        "correlation_id": correlation_id,
        "subagent_id": subagent_id,
        "consent": consent,
        "adapter": adapter,
        "content_digest": "",
        "payload": payload,
    }
    if recorded_omissions:
        document["recorded_omissions"] = recorded_omissions
    _refuse_unlabelled_hole(document)
    document["content_digest"] = content_digest(document)
    return document


def _refuse_unlabelled_hole(document: dict[str, Any]) -> None:
    """An ending nobody observed must arrive with the omission that names it.

    The contract binds the two (``bind_unobserved_termination``), and the
    binding is the project's own rule in schema form: a missing measurement is
    recorded with a reason, never left as a blank for a reader to fill in. It
    is checked here rather than trusted to each caller because the cost of
    getting it wrong is paid late -- the event is built, queued on disk, and
    refused by the service one at a time, with the turn already gone.
    """
    payload = document.get("payload") or {}
    if payload.get("turn_termination") != UNOBSERVED_TERMINATION:
        return
    named = any(
        entry.get("what") == "turn_termination"
        for entry in document.get("recorded_omissions") or []
    )
    if not named:
        raise ValueError(
            "an assistant_message with turn_termination 'not_observed' must carry a "
            "recorded_omissions entry with what='turn_termination'; without it the "
            "service refuses the event and the unobserved ending reads as a blank"
        )


# --- payloads ---------------------------------------------------------------
#
# Each builder writes exactly the fields the contract's payload definition
# allows. A field the adapter cannot observe is written as null *and* named in
# the event's recorded_omissions, because a null alone reads as "there was
# none" and the whole point of the omission list is to distinguish that from
# "nobody looked".


def session_started(
    *,
    harness: str,
    harness_version: str,
    started_at: str,
    repository: str | None = None,
    working_directory_checked_at_mark: bool = False,
) -> dict[str, Any]:
    return {
        "kind": "session.started",
        "harness": harness,
        "harness_version": harness_version,
        "repository": repository,
        # False until the exclusion check runs at the mark. Claiming it were
        # true would claim an exclusion enforcement that is not built.
        "working_directory_checked_at_mark": working_directory_checked_at_mark,
        "started_at": started_at,
    }


def user_message(*, turn_index: int, text: str | None) -> dict[str, Any]:
    return {
        "kind": "user_message.recorded",
        "turn_index": turn_index,
        "role": "user",
        "text": text,
        "text_ref": None,
        "redaction": no_redaction(),
    }


def assistant_message(
    *,
    turn_index: int,
    text: str | None,
    turn_termination: str,
    usage: dict[str, Any] | None = None,
    reasoning_available: bool = False,
) -> dict[str, Any]:
    if turn_termination not in TURN_TERMINATIONS:
        raise ValueError(
            f"turn_termination must be one of {list(TURN_TERMINATIONS)}, got {turn_termination!r}"
        )
    payload: dict[str, Any] = {
        "kind": "assistant_message.recorded",
        "turn_index": turn_index,
        "role": "assistant",
        "text": text,
        "text_ref": None,
        "turn_termination": turn_termination,
        "reasoning_available": reasoning_available,
        "redaction": no_redaction(),
    }
    if usage is not None:
        payload["usage"] = usage
    return payload


#: The one limit on a tool body (vicaria-docs RFC 0039): bytes of UTF-8 an
#: ``input`` or ``output`` travels inline up to.  Over it the body is cut and
#: the cut is counted, never silent; nothing else is ever removed from it.
INLINE_BODY_LIMIT = 1024 * 1024


def canonical_text(value: Any) -> str:
    """A body as text: a string as it is, anything else as canonical JSON.

    Sorted keys and no whitespace, so the same structured response gives the
    same bytes and the same digest on every producer.
    """
    if isinstance(value, str):
        return value
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def cut_body(text: str, limit: int = INLINE_BODY_LIMIT) -> tuple[str, int]:
    """``text`` cut to at most ``limit`` UTF-8 bytes on a character boundary,
    and how many bytes were dropped (zero when nothing was)."""
    encoded = text.encode("utf-8")
    if len(encoded) <= limit:
        return text, 0
    kept = encoded[:limit].decode("utf-8", errors="ignore")
    return kept, len(encoded) - len(kept.encode("utf-8"))


def tool_started(
    *,
    tool_call_id: str,
    tool_name: str,
    turn_index: int,
    input: Any = None,
    input_ref: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "kind": "tool.started",
        "tool_call_id": tool_call_id,
        "tool_name": tool_name,
        "turn_index": turn_index,
        # The input as the harness exposed it (RFC 0039); None only when it
        # exposed none, and then the omission travels with the event.
        "input": input,
        "input_ref": input_ref,
        # No exclusion check runs at a tool call; the field says so.
        "paths_checked_against_exclusions": False,
        "redaction": no_redaction(),
    }


def tool_finished(
    *,
    tool_call_id: str,
    turn_index: int,
    completion_status: str | None = None,
    exit_status: int | None = None,
    output: str | None = None,
    output_ref: dict[str, Any] | None = None,
    output_truncated_bytes: int | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "kind": "tool.finished",
        "tool_call_id": tool_call_id,
        "turn_index": turn_index,
        "output": output,
        "output_ref": output_ref,
        "output_truncated_bytes": output_truncated_bytes,
        "redaction": no_redaction(),
    }
    if completion_status is not None:
        payload["completion_status"] = completion_status
    if exit_status is not None:
        payload["exit_status"] = exit_status
    return payload


def feedback(
    *,
    anchor: dict[str, Any],
    direction: str,
    comment_text: str | None = None,
    arrived_late: bool = False,
) -> dict[str, Any]:
    if direction not in ("up", "down"):
        raise ValueError(f"feedback direction must be 'up' or 'down', got {direction!r}")
    return {
        "kind": "feedback.added",
        "anchor": anchor,
        "direction": direction,
        # The comment as typed, and its length beside it (RFC 0039): nothing
        # is redacted.  None when the person gave no comment.
        "comment_length": len(comment_text or ""),
        "comment_text": comment_text,
        "comment_text_ref": None,
        "arrived_late": arrived_late,
    }


def consent_changed(
    *,
    change: str,
    effective_turn_index: int,
    authorization_id: str,
    notice_version: str,
    notice_digest: str,
    scope: str = "session",
    gesture: str | None = None,
) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "kind": "consent.changed",
        "change": change,
        "effective_turn_index": effective_turn_index,
        "authorization_id": authorization_id,
        "notice_version": notice_version,
        "notice_digest": notice_digest,
        "scope": scope,
    }
    if gesture is not None:
        payload["gesture"] = gesture
    return payload


def collection_stopped(
    *, reason: str, erasure_invoked: bool = False, queue_purge: dict[str, Any] | None = None
) -> dict[str, Any]:
    if reason not in STOP_REASONS:
        raise ValueError(f"stop reason must be one of {list(STOP_REASONS)}, got {reason!r}")
    if reason == "excluded_path":
        # The contract's excluded-path branch obliges four more fields --
        # erasure_invoked true, a matched_pattern, a queue_purge and an
        # erasure_request_id -- because an exclusion match erases what was
        # already sent. This builder can produce none of them, and an adapter
        # here has wired no client-side erasure. Emitting the reason anyway
        # would put a tombstone on the wire for an erasure that never ran.
        raise ValueError(
            "collection.stopped with reason 'excluded_path' asserts an erasure this "
            "adapter has not built; the contract requires matched_pattern, queue_purge "
            "and erasure_request_id alongside it"
        )
    payload: dict[str, Any] = {
        "kind": "collection.stopped",
        "reason": reason,
        # Stopping is not erasing, and the two are different requests. An
        # adapter that has not built erasure says so here rather than leaving
        # the field to be read either way.
        "erasure_invoked": erasure_invoked,
    }
    if queue_purge is not None:
        payload["queue_purge"] = queue_purge
    return payload


def no_redaction() -> dict[str, Any]:
    """The redaction block for an adapter that does not redact.

    Not an empty object and not an omission: the contract wants a structured
    statement, and the honest one is a ruleset that removed nothing. A reader
    sees "no rule ran", which is the truth, rather than "rules ran and found
    nothing".
    """
    return {
        "ruleset_version": "none",
        "ruleset_digest": "sha256:" + hashlib.sha256(b"none").hexdigest(),
        "structure_preserved": True,
        "entries": [],
        "unparsed_count": 0,
        "low_confidence_count": 0,
        "review_flagged": False,
    }


def omission(what: str, note: str, *, reason: str = "adapter_cannot_observe") -> dict[str, Any]:
    return {"what": what, "reason": reason, "note": note}
