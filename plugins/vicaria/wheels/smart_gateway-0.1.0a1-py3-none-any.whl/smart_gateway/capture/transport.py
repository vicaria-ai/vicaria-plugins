"""Origin-bound, run-scoped delivery connections; never used for device linking.

The worker's signal deadline bounds the entire request, including one replay
after a connection reset. Only capture POSTs (identity/digest deduplicated by
the service) are replayed. Stops share the connection but are never replayed.
Configured proxies retain urllib's existing behavior.
"""

from __future__ import annotations

import contextlib
import http.client
import io
import time
import urllib.error
import urllib.parse
import urllib.request
from collections.abc import Callable
from typing import Any

RESET_ERRORS = (ConnectionResetError, BrokenPipeError, http.client.RemoteDisconnected)


class _Answer(io.BytesIO):
    def __init__(self, status: int, body: bytes) -> None:
        super().__init__(body)
        self.status = status


class DeliveryConnection:
    def __init__(
        self,
        server: str,
        log: Callable[[dict[str, Any]], None],
        can_replay: Callable[[], bool] = lambda: True,
    ) -> None:
        self.origin = urllib.parse.urlsplit(server)
        self.connection: http.client.HTTPConnection | None = None
        self.log = log
        self.can_replay = can_replay
        self.connections = 0

    def close(self) -> None:
        if self.connection is not None:
            self.connection.close()
            self.connection = None

    def _log(self, **row: Any) -> None:
        # Diagnostics must not turn a valid receipt into a lost acknowledgement.
        with contextlib.suppress(OSError):
            self.log({"transport": "delivery_connection", **row})

    def _connect(self, timeout: float) -> http.client.HTTPConnection:
        constructor = (
            http.client.HTTPSConnection
            if self.origin.scheme == "https"
            else http.client.HTTPConnection
        )
        connection = constructor(self.origin.hostname, self.origin.port, timeout=timeout)
        self.connection = connection
        started = time.monotonic()
        connected = False
        try:
            connection.connect()
            connected = True
        finally:
            self._log(
                connection=self.connections + 1,
                handshake_ms=round((time.monotonic() - started) * 1000, 3),
                connected=connected,
            )
        self.connections += 1
        return connection

    def __call__(self, request: urllib.request.Request, *, timeout: float) -> _Answer:
        target = urllib.parse.urlsplit(request.full_url)
        if (
            (target.scheme, target.hostname, target.port)
            != (self.origin.scheme, self.origin.hostname, self.origin.port)
            or target.scheme not in {"http", "https"}
            or target.username is not None
            or target.password is not None
        ):
            raise urllib.error.URLError("delivery connection origin changed")
        # One replay is allowed only for identical, deduplicated capture bytes.
        replayable = request.method == "POST" and target.path == (
            self.origin.path.rstrip("/") + "/v1/captures"
        )
        deadline = time.monotonic() + 10.0
        for attempt in range(2 if replayable else 1):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError("delivery request budget exhausted")
            try:
                connection = self.connection or self._connect(min(timeout, remaining))
                if time.monotonic() >= deadline:
                    raise TimeoutError("delivery request budget exhausted")
                if connection.sock is not None:
                    connection.sock.settimeout(
                        min(timeout, max(0.001, deadline - time.monotonic()))
                    )
                connection.request(
                    request.method,
                    urllib.parse.urlunsplit(("", "", target.path or "/", target.query, "")),
                    body=request.data,
                    headers=dict(request.header_items()),
                )
                response = connection.getresponse()
                body = response.read()
                status = response.status
                # Never carry a credential to a redirect target. A refused
                # redirect is returned through the same HTTPError path as 4xx.
                if response.will_close:
                    self.close()
                if 300 <= status < 400:
                    raise urllib.error.URLError("capture delivery redirect refused")
                if status >= 400:
                    raise urllib.error.HTTPError(
                        request.full_url, status, "HTTP response", {}, io.BytesIO(body)
                    )
                return _Answer(status, body)
            except RESET_ERRORS:
                self.close()
                retry = bool(replayable and attempt == 0 and self.can_replay())
                self._log(outcome="connection_reset", replay=retry)
                if not retry:
                    raise
            except urllib.error.HTTPError:
                raise
            except BaseException:
                # Includes the worker's hard wall-time alarm. Never reuse an
                # interrupted stream, and never replay timeout/refusal responses.
                self.close()
                raise
        raise AssertionError("unreachable")


def direct_connection_allowed(server: str) -> bool:
    target = urllib.parse.urlsplit(server)
    return bool(
        target.scheme in {"http", "https"}
        and target.hostname
        and not target.username
        and not target.password
        and (
            not urllib.request.getproxies().get(target.scheme)
            or urllib.request.proxy_bypass(target.hostname)
        )
    )
