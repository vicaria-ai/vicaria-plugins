---
description: Consent-bound capture for continuous benchmarking — link this device, or show the notice, confirm, stop, or report status.
argument-hint: link|notice|confirm|off|status
---
Two ways to open a session's capture interval, and one switch.

**Linked device (consent given once on the website).** Run `sg capture link <code> --server <url>`
once on this machine, with the code and address the website shows. From then on every session
here is captured from its start under the consent you gave there, and the switch is this
plugin's commands:

- `/vicaria:off` pauses this session; nothing further from it is sent, and what was sent stays
  until you delete it on the website. `/vicaria:on` resumes from the next prompt.
- `/vicaria:status` prints one line: whether this session is collecting, the computer it is
  connected as, a question waiting for your answer if there is one, and where your tasks are.
  It asks the service nothing.

**Per session (no device link).** Run the matching `sg capture` command in your shell, with
`--session` set to this session's id:

- `sg capture notice --session <id>` prints the notice in full. It makes no network request
  and stores no session content — only a local receipt that the text was displayed.
- `sg capture confirm --session <id>` is the confirmation gesture. It is refused before any
  request leaves the machine unless that receipt exists for this session, organization and
  endpoint, and for the exact notice text the adapter currently shows.
- `sg capture off --session <id>` closes the interval. Stopping is not erasing: material
  already sent stays, and erasure is a separate typed request.
- `sg capture status` prints what this machine holds — marked sessions, queued events, and the
  counts in your own upload and drop logs. It asks the service nothing.

Capture is off unless four things hold, in order: your organization permits sampling (or this
device is linked), you have not opted out on this machine (`sg capture opt-out`), the
repository and paths are not excluded, and this session's interval is open — marked by you, or
minted from the consent you gave once. Absence of any of them means off.
