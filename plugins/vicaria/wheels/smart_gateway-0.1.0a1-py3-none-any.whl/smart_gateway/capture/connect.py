"""``/vicaria:connect``: one command in the app, one approval in the browser.

RFC 0032 §2 and §6.  The person types the command; this module asks the
service for a code (``POST /device/connect``), keeps the request on disk,
opens the browser on the approval page and tells the person the code.  Then
nothing waits: a hook runs only when the harness fires one, so the poll that
turns the approval into a device token runs at the *next* hook event, once
per event, until the request is approved, expired or gone.  The person
approves, comes back and types their next prompt, and that prompt's hook
says *Connected*.

The request on disk (``capture/connect.json``, this user only) holds the
poll token, which is the whole credential for finishing the link: whoever
holds it gets the device token, so the file has the mode ``device.json``
has.  It is removed when the link is stored, when the request expired, and
when the service no longer knows it.

The command needs a server address.  The first ``/vicaria:connect`` on a
machine takes it as its argument (``/vicaria:connect https://…``), or the
plugin's ``server`` file gives it, or ``VICARIA_SERVER``; after that the
address the link was made against is in ``device.json``.
"""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import urllib.parse
from typing import Any

from smart_gateway.capture import question
from smart_gateway.capture.api import CaptureApi
from smart_gateway.capture.store import CaptureStore, utc_now

#: The environment name a deployment sets for its address.
SERVER_ENV = "VICARIA_SERVER"

#: What the person reads.  One line each, no term of ours.
NO_SERVER_LINE = (
    "vicaria: which server? Type /vicaria:connect followed by the address, "
    "for example /vicaria:connect https://app.vicaria.ai"
)
ALREADY_CONNECTED_LINE = (
    "vicaria: this computer is already connected. /vicaria:status says what is on."
)
UNREACHABLE_LINE = (
    "vicaria: could not reach {server}. Check the address and your connection, then try again."
)
REFUSED_LINE = (
    "vicaria: {server} would not start a connection just now. Try again in a moment; if it "
    "keeps saying this, check the address."
)
#: A refusal a person can meet, by the service's name for it.  The service's
#: own detail is written for developers, and goes to the debug log.
REFUSED_LINES = {
    "app_not_linkable": "vicaria: this app can't connect to Vicaria yet.",
}
CODE_LINE = (
    "vicaria: your code is {code}. Type it in the browser{opened}, then just keep working: "
    "your next prompt here will say Connected. The code is good for ten minutes."
)
#: Connected is not on.  This line is said when the link completes, before any
#: session has been minted, and the mint that follows can be refused (no
#: standing consent) or fail to reach the service; so it says only that the
#: computer is connected.  What is on is said by the session's own line after a
#: mint that worked (``claude_code.START_ON_LINE``), once, at a start or at the
#: prompt that minted.
CONNECTED_LINE = "vicaria: connected as {name}."
EXPIRED_LINE = (
    "vicaria: the code expired before it was approved. Type /vicaria:connect to get another."
)
HEARTBEAT_FAILED_LINE = (
    "vicaria: connected. The website will say so once this computer first checks in."
)
#: The command itself failed (the hook caught it): what went wrong is in
#: the developer's drop log, and the person is told what to do.
CONNECT_FAILED_LINE = (
    "vicaria: connecting didn't finish this time. Type /vicaria:connect again in a moment."
)


def default_server(store: CaptureStore, environ: Any = None) -> str | None:
    """The address to connect to when the command names none."""
    environ = os.environ if environ is None else environ
    named = str(environ.get(SERVER_ENV) or "").strip()
    if named:
        return named
    plugin_file = str(environ.get("VICARIA_PLUGIN_SERVER") or "").strip()
    if plugin_file:
        return plugin_file
    return None


def valid_server(address: str) -> str | None:
    """An http(s) service base, preserving an ASGI mount path."""
    try:
        parsed = urllib.parse.urlsplit(address.strip())
        _ = parsed.port  # Access validates malformed and out-of-range ports.
    except ValueError:
        return None
    if (
        parsed.scheme not in ("http", "https")
        or not parsed.hostname
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
        or any(c.isspace() for c in address)
        or "\\" in address
    ):
        return None
    if any(part in (".", "..") for part in urllib.parse.unquote(parsed.path).split("/")):
        return None
    return urllib.parse.urlunsplit((parsed.scheme, parsed.netloc, parsed.path.rstrip("/"), "", ""))


def machine_name() -> str:
    """The name the person knows this computer by: on macOS the one in
    System Settings ("Renjie's MacBook Air"), elsewhere the hostname without
    a `.local` suffix; `this computer` when neither is known."""
    if platform.system() == "Darwin":
        try:
            done = subprocess.run(
                ["scutil", "--get", "ComputerName"],
                capture_output=True,
                text=True,
                timeout=5,
                check=False,
            )
            if done.returncode == 0 and done.stdout.strip():
                return done.stdout.strip()
        except (OSError, subprocess.TimeoutExpired):
            pass
    node = (platform.node() or "").strip()
    return node[:-6] if node.endswith(".local") else (node or "this computer")


def approve_url(server: str) -> str:
    """Where the code is typed.  The code is never in the address: the site
    ignores one there, because a link carrying a code can come from anyone and
    one click on it connected the sender's computer to the account."""
    return f"{server}/app#connect"


#: Set to anything but ``0`` where no browser may open: the test suite sets it
#: for every test and every process a test starts (``tests/conftest.py``), and
#: the plugin's shim reads it too.  Nothing opened, the line reads the address out.
NO_BROWSER_ENV = "VICARIA_NO_BROWSER"


def open_browser(url: str) -> bool:
    """Open the approval page for the person; say whether anything opened."""
    if os.environ.get(NO_BROWSER_ENV, "") not in ("", "0"):
        return False
    if platform.system() == "Darwin":
        opener = ["open", url]
    elif platform.system() == "Windows":
        opener = ["cmd", "/c", "start", "", url]
    else:
        binary = shutil.which("xdg-open")
        if binary is None:
            return False
        opener = [binary, url]
    try:
        done = subprocess.run(opener, capture_output=True, timeout=10, check=False)
    except (OSError, subprocess.TimeoutExpired):
        return False
    return done.returncode == 0


def _debug(line: str) -> None:
    """What went wrong, for whoever reads the hook's debug log: stderr on a
    hook that exits 0, which Claude Code does not show the person."""
    print(f"vicaria connect: {line}", file=sys.stderr)


def start(
    store: CaptureStore,
    server: str,
    *,
    name: str | None = None,
    harness_version: str | None = None,
    harness: str = "claude-code",
    api: CaptureApi | None = None,
    opener: Any = None,
) -> str:
    """Ask for a code, keep the request, open the browser; return the line.

    The opener is looked up when this runs, not when the module loaded, so a
    caller that replaces ``open_browser`` replaces it here too (found
    2026-09-30: a test that stubbed it opened the person's browser on every run).
    """
    api = api or CaptureApi(server, "", timeout_s=CHECK_TIMEOUT_S)
    body: dict[str, Any] = {
        "harness": harness,
        "name": name or machine_name(),
        "platform": platform.system().lower() or None,
    }
    if harness_version and harness_version != "unknown":
        body["harness_version"] = harness_version
    outcome = api.open_connect(body)
    if not outcome.ok or not isinstance(outcome.value, dict):
        _debug(f"connect to {server} failed: {outcome.reason}: {outcome.detail}")
        if outcome.status is None:
            return UNREACHABLE_LINE.format(server=server)
        error = outcome.value.get("error") if isinstance(outcome.value, dict) else None
        return REFUSED_LINES.get(error or "", REFUSED_LINE.format(server=server))
    value = outcome.value
    code, poll_token = value.get("user_code"), value.get("poll_token")
    if not isinstance(code, str) or not isinstance(poll_token, str):
        _debug(f"connect to {server}: the answer carried no code")
        return REFUSED_LINE.format(server=server)
    store.save_connect(
        {
            "server": server,
            "poll_token": poll_token,
            "user_code": code,
            "name": body["name"],
            "harness": harness,
            "expires_at": value.get("expires_at"),
            "opened_at": utc_now(),
        }
    )
    # Looked up when it runs, not bound as a default: bound, a test that
    # replaced `open_browser` still opened the developer's own browser, on
    # every run of the suite (reported by another session, 2026-09-30).
    opened = (opener or open_browser)(approve_url(server))
    return CODE_LINE.format(
        code=code,
        opened="" if opened else f" at {approve_url(server)}",
    )


def finish(
    store: CaptureStore,
    *,
    session_id: str | None = None,
    harness_version: str | None = None,
    api_for: Any = None,
) -> str | None:
    """One poll of the pending request, if any.  The line to show, or None.

    Called from any hook event.  Silent while the request is still pending;
    says *Connected* once, when the token is stored; says *expired* once,
    and forgets the request, when it is too late.  ``session_id`` is the
    session of the event this runs at: the link is announced there, at its
    next event that mints (:meth:`CaptureStore.mark_announce_next_mint`).
    """
    pending = store.connect()
    if pending is None:
        return None
    if store.device() is not None:
        # Linked meanwhile, by another command or another harness: the
        # request is moot.
        store.forget_connect()
        return None
    server, token = pending["server"], pending["poll_token"]
    api = (api_for or (lambda s, t: CaptureApi(s, t, timeout_s=FINISH_TIMEOUT_S)))(server, token)
    outcome = api.poll_connect()
    if not outcome.ok:
        if outcome.status in (404, 409, 410):
            # Unknown, already spent, or expired: nothing more will come of
            # this request.  Expired is said; the others stay quiet, since
            # the device is linked or the request is not this machine's.
            store.forget_connect()
            return EXPIRED_LINE if outcome.status == 410 else None
        return None  # unreachable or a passing failure: the next event tries again
    value = outcome.value if isinstance(outcome.value, dict) else {}
    if value.get("state") != "connected":
        return None
    for key in ("token", "org_id", "device_id"):
        if not isinstance(value.get(key), str) or not value[key]:
            return None
    store.save_device(
        {
            "server": server,
            "org_id": value["org_id"],
            "device_id": value["device_id"],
            "token": value["token"],
            "harness": pending.get("harness", "claude-code"),
            "name": pending.get("name") or value.get("name") or "this computer",
            "scopes": value.get("scopes") or [],
            "linked_at": utc_now(),
        }
    )
    store.forget_connect()
    # Whichever event this is, the next one of this session that mints says
    # what came of it: a tool or stop event mints nothing, and "connected"
    # reads as on.  This session's alone: the person read "connected" in this
    # terminal, and another terminal's prompt says nothing of it.
    if isinstance(session_id, str) and session_id:
        store.mark_announce_next_mint(session_id)
    body = (
        {"harness_version": harness_version}
        if harness_version and harness_version != "unknown"
        else {}
    )
    make = api_for or (lambda s, t: CaptureApi(s, t, timeout_s=FINISH_TIMEOUT_S))
    beat = make(server, value["token"]).heartbeat(body)
    name = pending.get("name") or "this computer"
    if not beat.ok:
        _debug(f"first check-in to {server} failed: {beat.reason}: {beat.detail}")
        return HEARTBEAT_FAILED_LINE
    return CONNECTED_LINE.format(name=name)


#: The service's names for a token that no longer opens anything: the
#: computer removed on the website, or the account behind it deleted.  The
#: one list, :data:`question.DISCONNECTED_ERRORS`, that the session start and
#: the answer commands read too.
GONE_ERRORS = question.DISCONNECTED_ERRORS

#: How long any request this module makes may wait: the code, the poll,
#: the first check-in, and the check-in that asks whether the website still
#: knows a connected computer.  Each runs inside a hook (the finish at
#: whatever event comes next, two requests there).  The command
#: arrives at ``UserPromptExpansion``, whose hook Claude Code kills at 10 s
#: (``hooks.json``; ``hook.HOOK_LIMIT_S``).  At :class:`CaptureApi`'s default
#: of 10 s a service that never answers took the whole limit: the hook was
#: killed, and the model read the command's fallback text where the person
#: should have read "already connected".  3 s, the event's per-request
#: budget (``hook.BUDGET_S``), leaves the interpreter's start, the store's
#: reads and the answer well inside the limit; a check-in that has not
#: answered by then is not an answer, and the link stands.
CHECK_TIMEOUT_S = 3.0

#: The finish's two requests (the poll, the first check-in) run at whatever
#: event comes next, and at a prompt the capture's mint and coverage publish
#: follow in the same hook, at 3 s each: 1.5 + 1.5 + 3 + 3 = 9 s, inside the
#: prompt hook's 10 s.  At 3 s each the four could take 12 (found in review).
FINISH_TIMEOUT_S = 1.5


def disconnected(device: dict[str, Any], *, api_for: Any = None) -> bool:
    """Whether the service no longer knows this computer.

    A check-in answered with one of :data:`GONE_ERRORS` says so; anything
    else, an unreachable or slow service included, is not an answer, and the
    link this machine holds stands.  The check-in waits
    :data:`CHECK_TIMEOUT_S` at most.
    """
    make = api_for or (lambda s, t: CaptureApi(s, t, timeout_s=CHECK_TIMEOUT_S))
    api = make(device["server"], device["token"])
    beat = api.heartbeat({})
    error = beat.value.get("error") if isinstance(beat.value, dict) else None
    return error in GONE_ERRORS


def command(
    store: CaptureStore,
    args: str | None,
    *,
    session_id: str | None = None,
    harness_version: str | None = None,
    harness: str = "claude-code",
    environ: Any = None,
    api_for: Any = None,
) -> str:
    """The ``/vicaria:connect [server]`` command, answered in one line.

    ``harness`` is the app the link is for (Codex's plugin connects as
    ``codex``, into its own home), which the website shows the computer as.

    A computer removed on the website still holds its link on disk, and the
    line that says so tells the person to connect again; the link is
    checked here, and one the service no longer knows is forgotten (with
    every session's question it kept) so connecting starts over.  A command
    typed again while a request stands can finish the link: ``session_id``,
    the command's session, is where it is announced (:func:`finish`).
    """
    device = store.device()
    if device is not None:
        if not disconnected(device, api_for=api_for):
            return ALREADY_CONNECTED_LINE
        store.forget_device()
        store.forget_questions()
    pending = store.connect()
    named = (args or "").strip()
    server = valid_server(named) if named else None
    if named and server is None:
        return NO_SERVER_LINE
    if server is None:
        given = (pending or {}).get("server") or default_server(store, environ)
        server = valid_server(given) if given else None
    if server is None:
        return NO_SERVER_LINE
    if pending is not None and pending["server"] == server:
        # Asked again while a request stands: poll it now rather than mint a
        # second code, so a person who typed the command twice sees one code.
        finished = finish(store, session_id=session_id, harness_version=harness_version)
        if finished is not None:
            return finished
        return CODE_LINE.format(code=pending["user_code"], opened=f" at {approve_url(server)}")
    return start(
        store,
        server,
        harness_version=harness_version,
        harness=harness,
        api=api_for(server, "") if api_for is not None else None,
    )


def _unused() -> None:  # pragma: no cover
    sys.exit(0)
