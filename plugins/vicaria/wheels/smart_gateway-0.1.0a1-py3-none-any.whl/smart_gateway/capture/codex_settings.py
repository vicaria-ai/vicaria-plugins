"""Conservative native Codex edits with a private, recoverable undo journal.

Only three top-level string keys are edited. The complete parsed TOML must match
exactly the requested change before a file is replaced. No provider/auth field
is rewritten. A durable pending operation precedes every settings write.
"""

from __future__ import annotations

import base64
import contextlib
import copy
import fcntl
import hashlib
import json
import os
import re
import tempfile
import tomllib
from pathlib import Path

MAX_CONFIG_BYTES = 1 << 20
MAX_STATE_BYTES = 16 << 20
SCHEMA = "sg.codex-apply-state.v1"
KEYS = {"model", "model_reasoning_effort", "developer_instructions"}


class Refused(Exception):
    """A refusal before changing the configuration."""


class RecoveryRequired(Exception):
    """A change may be committed; never append a 'nothing changed' claim."""


def digest(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def encoded(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode()


def document(raw: bytes) -> dict:
    try:
        result = tomllib.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeError):
        raise Refused("config.toml is not readable TOML; it was left alone.") from None
    for key in KEYS:
        if key in result and not isinstance(result[key], str):
            raise Refused(f"config.toml's {key} is not a string; it was left alone.")
    return result


def patch_fields(raw: bytes, changes: dict[str, str | None]) -> bytes:
    """Edit exact top-level assignments, proving unrelated TOML stays identical.

    A value of None removes the key. The semantic check identifies the real root
    assignment even when a multiline string or a nested table contains lookalikes.
    Unsupported layouts fail closed instead of being rewritten wholesale.
    """
    if set(changes) - KEYS:
        raise Refused("this command only edits Codex model, effort and lesson settings.")
    original = document(raw)
    desired = copy.deepcopy(original)
    text = raw.decode("utf-8")
    for key, value in changes.items():
        if value is not None and not isinstance(value, str):
            raise Refused("the requested setting is not a string.")
        current = document(text.encode())
        if value is None:
            desired.pop(key, None)
        else:
            desired[key] = value
        replacement = "" if value is None else f"{key} = {json.dumps(value, ensure_ascii=False)}\n"
        if key not in current:
            if value is not None:
                text = replacement + text
            continue
        if current[key] == value:
            continue
        pattern = re.compile(
            r"(?m)^[ \t]*(?:"
            + re.escape(key)
            + '|"'
            + re.escape(key)
            + "\"|'"
            + re.escape(key)
            + "')[ \t]*="
        )
        candidates = list(pattern.finditer(text))
        if len(candidates) > 32:
            raise Refused("the settings layout is too complex to edit safely.")
        without = {k: v for k, v in current.items() if k != key}
        found = False
        for candidate in candidates:
            start = candidate.start()
            end = start
            for line in text[start:].splitlines(keepends=True)[:2048]:
                end += len(line)
                try:
                    assignment = tomllib.loads(text[start:end])
                except ValueError:
                    continue
                if assignment != {key: current[key]}:
                    break
                removed = text[:start] + text[end:]
                try:
                    same = tomllib.loads(removed) == without
                except ValueError:
                    same = False
                if same:
                    text = text[:start] + replacement + text[end:]
                    found = True
                break
            if found:
                break
        if not found:
            raise Refused(
                f"couldn't identify the top-level {key} safely; config.toml was left alone."
            )
    result = text.encode("utf-8")
    if document(result) != desired:
        raise Refused("the edit would change unrelated settings; config.toml was left alone.")
    return result


def _atomic(path: Path, raw: bytes, mode: int) -> None:
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".vicaria-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            os.fchmod(stream.fileno(), mode)
            stream.write(raw)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    except BaseException:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(temporary)
        raise


class Journal:
    """Serialize this plugin's edits; detect external drift; recover interrupted edits."""

    def __init__(self, data_dir: Path, requested: Path, *, reconcile: bool = True):
        self.requested = requested.absolute()
        self.target = requested.resolve()
        self.folder = data_dir / "state" / "codex-apply" / digest(str(self.target).encode())
        self.path = self.folder / "state.json"
        self.state = {"schema": SCHEMA, "stack": [], "preview": None, "pending": None}
        self.fd = None
        self.reconcile = reconcile

    def __enter__(self):
        self.folder.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.fd = os.open(self.folder / "lock", os.O_CREAT | os.O_RDWR, 0o600)
        fcntl.flock(self.fd, fcntl.LOCK_EX)
        try:
            if self.path.exists():
                if self.path.stat().st_size > MAX_STATE_BYTES:
                    raise Refused("the undo journal is too large to read safely.")
                try:
                    self.state = json.loads(self.path.read_bytes())
                except (OSError, ValueError):
                    raise Refused(
                        "the undo journal is unreadable; config.toml was left alone."
                    ) from None
                if (
                    not isinstance(self.state, dict)
                    or self.state.get("schema") != SCHEMA
                    or not isinstance(self.state.get("stack"), list)
                    or any(not isinstance(e, dict) for e in self.state["stack"])
                ):
                    raise Refused("the undo journal is invalid; config.toml was left alone.")
            self.checked_pending()
            if self.reconcile:
                self.recover()
            return self
        except BaseException:
            self.__exit__(None, None, None)
            raise

    def __exit__(self, *_):
        if self.fd is not None:
            fcntl.flock(self.fd, fcntl.LOCK_UN)
            os.close(self.fd)
            self.fd = None

    def snapshot(self) -> dict:
        if self.requested.resolve() != self.target:
            raise Refused("the settings link changed; preview again before applying.")
        try:
            if self.target.exists():
                if not self.target.is_file() or self.target.stat().st_size > MAX_CONFIG_BYTES:
                    raise Refused("config.toml is not a bounded regular file.")
                with self.target.open("rb") as stream:
                    raw = stream.read(MAX_CONFIG_BYTES + 1)
                if len(raw) > MAX_CONFIG_BYTES:
                    raise Refused("config.toml grew beyond the safe edit limit.")
                mode = self.target.stat().st_mode & 0o777
                exists = True
            else:
                raw, mode, exists = b"", 0o600, False
        except OSError:
            raise Refused("couldn't read config.toml; it was left alone.") from None
        return {
            "raw": base64.b64encode(raw).decode(),
            "digest": digest(raw),
            "mode": mode,
            "exists": exists,
            "target": str(self.target),
        }

    @staticmethod
    def bytes(snapshot: dict) -> bytes:
        return base64.b64decode(snapshot["raw"], validate=True)

    def save(self) -> None:
        raw = encoded(self.state)
        if len(raw) > MAX_STATE_BYTES:
            raise Refused("the undo journal is full; undo an earlier application first.")
        _atomic(self.path, raw, 0o600)

    def _valid_snapshot(self, value) -> bool:
        try:
            return (
                isinstance(value, dict)
                and value.get("target") == str(self.target)
                and isinstance(value.get("mode"), int)
                and 0 <= value["mode"] <= 0o777
                and isinstance(value.get("exists"), bool)
                and len(self.bytes(value)) <= MAX_CONFIG_BYTES
                and digest(self.bytes(value)) == value.get("digest")
            )
        except (KeyError, TypeError, ValueError):
            return False

    def _valid_stack(self, value) -> bool:
        if not isinstance(value, list):
            return False
        return all(
            isinstance(entry, dict)
            and self._valid_snapshot(entry.get("before"))
            and isinstance(entry.get("after_digest"), str)
            and isinstance(entry.get("writes"), dict)
            and not (set(entry["writes"]) - KEYS)
            and all(
                isinstance(write, dict)
                and set(write) == {"before", "after"}
                and all(v is None or isinstance(v, str) for v in write.values())
                for write in entry["writes"].values()
            )
            for entry in value
        )

    def checked_pending(self) -> dict | None:
        if not self._valid_stack(self.state.get("stack")):
            raise Refused("the undo journal is invalid; config.toml was left alone.")
        pending = self.state.get("pending")
        if pending is None:
            return None
        if (
            not isinstance(pending, dict)
            or not self._valid_snapshot(pending.get("before"))
            or not self._valid_snapshot(pending.get("after"))
            or not self._valid_stack(pending.get("stack"))
        ):
            raise RecoveryRequired(f"the pending undo journal needs review: {self.path}")
        return pending

    def recover(self) -> None:
        pending = self.checked_pending()
        if pending is None:
            return
        current = self.snapshot()
        before, after = pending["before"], pending["after"]
        landed = current["digest"] == after["digest"] and current["exists"] == after["exists"]
        unchanged = current["digest"] == before["digest"] and current["exists"] == before["exists"]
        if not landed and not unchanged:
            # Codex can record a trusted project, or an editor can change a
            # comment, after either side of an interrupted settings write.
            # Reconcile only our managed keys; never overwrite unrelated edits.
            try:
                actual = document(self.bytes(current))
                old = document(self.bytes(before))
                new = document(self.bytes(after))
                landed = all(actual.get(k) == new.get(k) for k in KEYS)
                unchanged = all(actual.get(k) == old.get(k) for k in KEYS)
            except Refused:
                pass
        if landed:
            self.state["stack"] = pending["stack"]
        elif not unchanged:
            raise RecoveryRequired(
                "an interrupted change has mixed or unreadable managed settings. "
                "Type vicaria apply recover to review a local discard option. "
                f"Recovery copies are retained in {self.path}"
            )
        self.state["pending"] = None
        self.state["preview"] = None
        try:
            self.save()
        except OSError:
            raise RecoveryRequired(
                "the settings change is recoverable, but the undo journal "
                "couldn't be finalized. Free disk space and run vicaria apply undo."
            ) from None

    def transact(self, before: dict, raw: bytes, stack: list[dict], *, exists: bool = True) -> None:
        if self.snapshot() != before:
            raise Refused("config.toml changed since preview; preview again.")
        after = {
            **before,
            "raw": base64.b64encode(raw).decode(),
            "digest": digest(raw),
            "exists": exists,
        }
        self.state["pending"] = {"before": before, "after": after, "stack": stack}
        try:
            self.save()  # Durable recovery information BEFORE the settings change.
        except (OSError, Refused):
            raise Refused(
                "couldn't preserve undo information; config.toml was not changed."
            ) from None
        try:
            if self.bytes(before) != raw or before["exists"] != exists:
                # Detect an editor's change after the journal was persisted.
                if self.snapshot() != before:
                    raise Refused("config.toml changed during apply; preview again.")
                if exists:
                    _atomic(self.target, raw, before["mode"])
                else:
                    self.target.unlink()
                    directory = os.open(self.target.parent, os.O_RDONLY)
                    try:
                        os.fsync(directory)
                    finally:
                        os.close(directory)
        except BaseException:
            # Keep the durable pending entry. The next command checks whether
            # the before or after version landed; never assert nothing changed.
            raise RecoveryRequired(
                "the change did not finish cleanly. Recovery information "
                "is retained; run vicaria apply undo to reconcile it."
            ) from None
        self.state["stack"] = stack
        self.state["pending"] = None
        self.state["preview"] = None
        try:
            self.save()
        except (OSError, Refused):
            raise RecoveryRequired(
                "config.toml was saved and its undo information is retained. "
                "Run vicaria apply undo after the journal can be written."
            ) from None
