"""Explicit terminal capture for personal OpenCode runs.

Codex is captured by its own plugin now (vicaria-docs RFC 0048), which sees
every session rather than the runs started here; ``run --harness codex``
says to install it.  ``connect`` still accepts Codex, whose link this home
has always kept in ``harnesses/codex``, where the plugin reads it.

Only commands started through this launcher are recorded. Each harness keeps a
separate link, so connecting one never silently replaces another's credentials.
No permission-approval flags are added to the harness invocation.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import uuid
from pathlib import Path

from . import connect
from .api import CaptureApi
from .collector import CaptureRefused, collector_for
from .store import CaptureStore

#: The launcher's own harness, and Codex, whose link it keeps (its plugin
#: reads it there) though its runs are the plugin's.
HARNESSES = ("codex", "opencode")


def home_for(args):
    return (
        Path(args.home or os.environ.get("VICARIA_HOME") or Path.home() / ".vicaria")
        / "harnesses"
        / args.harness
    )


def connect_command(args):
    store = CaptureStore(home_for(args))
    server = connect.valid_server(args.server or os.environ.get("VICARIA_SERVER") or "")
    if not server:
        raise SystemExit("Provide --server with the website's full address")
    device = store.device()
    if device:
        if device["server"] != server:
            raise SystemExit(
                "This harness is connected to another server. Disconnect it before "
                "switching servers"
            )
        beat = CaptureApi(server, device["token"]).heartbeat({})
        if not beat.ok:
            raise SystemExit(
                f"The saved connection could not check in. Check Settings. If revoked, "
                f"run disconnect --harness {args.harness}, then connect again"
            )
        print(f"Connected: {args.harness}. Start a task with the run command.")
        return 0
    if store.connect():
        pending = store.connect()
        if pending["server"] != server:
            raise SystemExit(
                "A connection is pending for another server. Finish or let it expire first"
            )
        line = connect.finish(store, harness_version=args.harness_version)
        print(
            line or "Waiting for browser approval. Approve the code, then run this command again."
        )
        return 0
    line = connect.start(store, server, harness=args.harness, harness_version=args.harness_version)
    print(
        line.replace(
            "then just keep working: your next prompt here will say Connected",
            "then run this terminal command again to finish connecting",
        )
    )
    return 0 if store.connect() else 1


class StreamCapture:
    """Map the official JSON stream fields, retaining every emitted text chunk."""

    def __init__(self, collector, session_id):
        self.collector, self.session_id = collector, session_id
        self.turn = collector.next_turn(session_id)
        self.calls = set()
        self.ended = False
        self.seen = 0

    def message(self, text, termination="continuing"):
        self.collector.record_assistant_message(
            self.session_id, turn_index=self.turn, text=text, turn_termination=termination
        )

    def tool(self, call_id, name, arguments):
        if call_id in self.calls:
            return
        self.calls.add(call_id)
        self.collector.record_tool_started(
            self.session_id,
            turn_index=self.turn,
            tool_call_id=call_id,
            tool_name=name,
            input=arguments,
        )

    def result(self, call_id, status, output):
        if call_id not in self.calls:
            return
        if output is not None and not isinstance(output, str):
            output = json.dumps(output, ensure_ascii=False)
        self.collector.record_tool_finished(
            self.session_id,
            turn_index=self.turn,
            tool_call_id=call_id,
            completion_status=status,
            output=output,
        )

    def consume(self, event):
        if not isinstance(event, dict):
            return
        self.seen += 1
        kind = event.get("type")
        part = event.get("part") or {}
        if kind == "text" and isinstance(part.get("text"), str):
            self.message(part["text"])
        elif kind == "tool_use" and part.get("callID") and part.get("tool"):
            state = part.get("state") or {}
            self.tool(str(part["callID"]), str(part["tool"]), state.get("input"))
            if state.get("status") in ("completed", "error"):
                self.result(
                    str(part["callID"]),
                    state["status"],
                    state.get("output", state.get("error")),
                )
        elif kind == "step_finish" and part.get("reason") in ("stop", "length", "error"):
            self.message(
                None,
                "error"
                if part["reason"] == "error"
                else "completed"
                if part["reason"] == "stop"
                else "stopped",
            )
            self.ended = True
        elif kind == "error":
            self.message(json.dumps(event.get("error"), ensure_ascii=False), "error")
            self.ended = True


def run_command(args):
    if args.harness == "codex":
        raise SystemExit(
            "Codex is captured by the Vicaria plugin for Codex: run "
            "`codex plugin marketplace add vicaria-ai/vicaria-plugins` and "
            "`codex plugin add vicaria@vicaria`, then type vicaria connect in Codex"
        )
    if args.harness not in HARNESSES:
        raise SystemExit("Use the Claude Code or Codex plugin, or choose opencode")
    if not shutil.which(args.harness):
        raise SystemExit(f"Install and sign in to {args.harness} first; it was not found in PATH")
    store = CaptureStore(home_for(args))
    device = store.device()
    if not device:
        raise SystemExit("Connect this harness first using the connect command")
    session_id = "ses_" + uuid.uuid4().hex
    collector = collector_for(
        args.harness,
        org_id=device["org_id"],
        server=device["server"],
        token=device["token"],
        home=store.home,
        harness_version=args.harness_version,
        surface=lambda line: print(line, file=sys.stderr),
    )
    try:
        collector.mint_from_standing_consent(session_id)
    except CaptureRefused as error:
        raise SystemExit(
            f"Capture could not start: {error.detail}. Check sharing in Settings"
        ) from error
    print(f"Recording this {args.harness} run to {device['server']}/app#tasks", file=sys.stderr)
    try:
        capture = StreamCapture(collector, session_id)
        collector.record_user_message(session_id, turn_index=capture.turn, text=args.prompt)
        argv = ["opencode", "run", "--format", "json", "--", args.prompt]
        with subprocess.Popen(
            argv, stdout=subprocess.PIPE, stdin=subprocess.DEVNULL, text=True
        ) as process:
            try:
                for line in process.stdout:
                    print(line, end="", flush=True)
                    try:
                        item = json.loads(line)
                    except ValueError:
                        continue
                    capture.consume(item)
                code = process.wait()
            except BaseException:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                raise
        if not capture.ended:
            capture.message(None, "error" if code else "not_observed")
        if not capture.seen:
            print(
                "No structured events received. Check the installed harness version "
                "and stream format.",
                file=sys.stderr,
            )
        return code
    finally:
        collector.stop(session_id, reason="session_ended", gesture="switch_off")
        print(json.dumps(collector.flush(session_id)), file=sys.stderr)
