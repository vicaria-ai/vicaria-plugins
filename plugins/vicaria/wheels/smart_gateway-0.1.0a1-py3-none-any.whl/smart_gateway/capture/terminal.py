"""Explicit terminal capture for personal OpenCode runs.

Codex is captured by its own plugin now (vicaria-docs RFC 0048), which sees
every session rather than the runs started here; ``run --harness codex``
says to install it.  ``connect`` still accepts Codex, whose link this home
has always kept in ``harnesses/codex``, where the plugin reads it.

Only commands started through this launcher are recorded. Each harness keeps a
separate link, so connecting one never silently replaces another's credentials.
No permission-approval flags are added to the harness invocation.
"""

from __future__ import annotations

import base64
import json
import os
import secrets
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from . import connect
from .api import CaptureApi
from .collector import CaptureRefused, collector_for
from .store import CaptureStore

#: The launcher's own harness, and Codex, whose link it keeps (its plugin
#: reads it there) though its runs are the plugin's.
HARNESSES = ("codex", "opencode")


def home_for(args):
    return (
        Path(args.home or os.environ.get("VICARIA_HOME") or Path.home() / ".vicaria")
        / "harnesses"
        / args.harness
    )


def connect_command(args):
    store = CaptureStore(home_for(args))
    server = connect.valid_server(args.server or os.environ.get("VICARIA_SERVER") or "")
    if not server:
        raise SystemExit("Provide --server with the website's full address")
    device = store.device()
    if device:
        if device["server"] != server:
            raise SystemExit(
                "This harness is connected to another server. Disconnect it before "
                "switching servers"
            )
        beat = CaptureApi(server, device["token"]).heartbeat({})
        if not beat.ok:
            raise SystemExit(
                f"The saved connection could not check in. Check Settings. If revoked, "
                f"run disconnect --harness {args.harness}, then connect again"
            )
        print(f"Connected: {args.harness}. Start a task with the run command.")
        return 0
    if store.connect():
        pending = store.connect()
        if pending["server"] != server:
            raise SystemExit(
                "A connection is pending for another server. Finish or let it expire first"
            )
        line = connect.finish(store, harness_version=args.harness_version)
        print(
            line or "Waiting for browser approval. Approve the code, then run this command again."
        )
        return 0
    line = connect.start(store, server, harness=args.harness, harness_version=args.harness_version)
    print(
        line.replace(
            "then just keep working: your next prompt here will say Connected",
            "then run this terminal command again to finish connecting",
        )
    )
    return 0 if store.connect() else 1


class StreamCapture:
    """Map the official JSON stream fields, retaining every emitted text chunk."""

    def __init__(self, collector, session_id):
        self.collector, self.session_id = collector, session_id
        self.turn = collector.next_turn(session_id)
        self.calls = set()
        self.ended = False
        self.seen = 0

    def message(self, text, termination="continuing"):
        self.collector.record_assistant_message(
            self.session_id, turn_index=self.turn, text=text, turn_termination=termination
        )

    def tool(self, call_id, name, arguments):
        if call_id in self.calls:
            return
        self.calls.add(call_id)
        self.collector.record_tool_started(
            self.session_id,
            turn_index=self.turn,
            tool_call_id=call_id,
            tool_name=name,
            input=arguments,
        )

    def result(self, call_id, status, output):
        if call_id not in self.calls:
            return
        if output is not None and not isinstance(output, str):
            output = json.dumps(output, ensure_ascii=False)
        self.collector.record_tool_finished(
            self.session_id,
            turn_index=self.turn,
            tool_call_id=call_id,
            completion_status=status,
            output=output,
        )

    def consume(self, event):
        if not isinstance(event, dict):
            return
        self.seen += 1
        kind = event.get("type")
        part = event.get("part") or {}
        if kind == "text" and isinstance(part.get("text"), str):
            self.message(part["text"])
        elif kind == "tool_use" and part.get("callID") and part.get("tool"):
            state = part.get("state") or {}
            self.tool(str(part["callID"]), str(part["tool"]), state.get("input"))
            if state.get("status") in ("completed", "error"):
                self.result(
                    str(part["callID"]),
                    state["status"],
                    state.get("output", state.get("error")),
                )
        elif kind == "step_finish" and part.get("reason") in ("stop", "length", "error"):
            self.message(
                None,
                "error"
                if part["reason"] == "error"
                else "completed"
                if part["reason"] == "stop"
                else "stopped",
            )
            self.ended = True
        elif kind == "error":
            self.message(json.dumps(event.get("error"), ensure_ascii=False), "error")
            self.ended = True


#: How long OpenCode's own server has to say where it listens, and to make a
#: session (its first start installs the plugins it loads).
SERVER_START_S = 30
SESSION_CREATE_S = 60


class _Server:
    """``opencode serve`` for as long as it takes to make a session, on
    loopback, under a password made for it.

    ``opencode run`` makes a new session only as it sends the prompt, and the
    plugin that asks the plan service sees the prompt first --- so a capture
    minted at the run's first event came after the plan was journaled (found in
    review of #92). Made here, the session has its id before any prompt does:
    capture is minted under it, and only then is the prompt sent into it by a
    run of its own (``run --session``). Not ``run --attach``: on 1.18.35 an
    attached run's JSON stream ends at the turn's first step, though the turn
    goes on to finish on the server."""

    def __init__(self):
        self.password = secrets.token_urlsafe(24)
        self.env = {
            **os.environ,
            "OPENCODE_SERVER_USERNAME": "opencode",
            "OPENCODE_SERVER_PASSWORD": self.password,
        }
        self.url = None
        self._process = None
        self._log = None

    def __enter__(self):
        self._log = tempfile.TemporaryFile(mode="w+")
        self._process = subprocess.Popen(
            ["opencode", "serve", "--hostname", "127.0.0.1", "--port", "0"],
            stdout=self._log,
            stderr=subprocess.STDOUT,
            stdin=subprocess.DEVNULL,
            text=True,
            env=self.env,
        )
        deadline = time.monotonic() + SERVER_START_S
        while self.url is None:
            self._log.seek(0)
            for line in self._log.read().splitlines():
                if "http://" in line:
                    self.url = line[line.index("http://") :].split()[0]
                    break
            else:
                if self._process.poll() is not None or time.monotonic() > deadline:
                    self.__exit__(None, None, None)
                    raise SystemExit(
                        "OpenCode's server did not start; run `opencode serve` to see why"
                    )
                time.sleep(0.05)
        return self

    def new_session(self):
        token = base64.b64encode(f"opencode:{self.password}".encode()).decode()
        request = urllib.request.Request(
            f"{self.url}/session",
            data=b"{}",
            method="POST",
            headers={"content-type": "application/json", "authorization": f"Basic {token}"},
        )
        # Loopback, so never through a proxy the environment names.
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        try:
            with opener.open(request, timeout=SESSION_CREATE_S) as answer:
                made = json.load(answer)
        except (OSError, ValueError) as error:
            raise SystemExit(f"OpenCode did not make a session: {error}") from error
        session_id = made.get("id") if isinstance(made, dict) else None
        if not isinstance(session_id, str) or not session_id:
            raise SystemExit("OpenCode made a session without an id")
        return session_id

    def __exit__(self, *_exc):
        if self._process is not None and self._process.poll() is None:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait()
        if self._log is not None:
            self._log.close()
        return False


def _names_only(event, session_id):
    """Whether an event names this session and no other: its own ``sessionID``
    is the session's, and so is its part's wherever the part names one."""
    if not isinstance(event, dict) or event.get("sessionID") != session_id:
        return False
    part = event.get("part")
    return not isinstance(part, dict) or part.get("sessionID", session_id) == session_id


class _Run:
    """One launcher run, captured under the harness's own session id.

    OpenCode's plugin asks the plan service under OpenCode's own session id,
    so the person's decision page can join a plan to this run only when capture
    uses that id (``cb_server/individual/decisions.py``, ``_own_decision``).
    It is minted before the prompt is sent (:class:`_Server`). An event is
    captured only when it names this session and no other; anything else ---
    no id, another session's, or an outer and a nested id that disagree --- is
    left out and counted."""

    def __init__(self, collector, harness, server, prompt):
        self.collector, self.harness, self.server, self.prompt = collector, harness, server, prompt
        self.capture = None
        self.events = 0
        self.left_out = 0

    def bind(self, session_id):
        try:
            self.collector.mint_from_standing_consent(session_id)
        except CaptureRefused as error:
            raise SystemExit(
                f"Capture could not start: {error.detail}. Check sharing in Settings"
            ) from error
        print(f"Recording this {self.harness} run to {self.server}/app#tasks", file=sys.stderr)
        self.capture = StreamCapture(self.collector, session_id)
        self.collector.record_user_message(
            session_id, turn_index=self.capture.turn, text=self.prompt
        )

    def consume(self, event):
        self.events += 1
        if _names_only(event, self.capture.session_id):
            self.capture.consume(event)
        else:
            # Never joined: a plan made under another id would then open
            # beside a session it does not name.
            self.left_out += 1

    def finish(self, code):
        session_id = self.capture.session_id
        if not self.events:
            print(
                "No structured events received. Check the installed harness version "
                "and stream format.",
                file=sys.stderr,
            )
        if not self.capture.ended:
            self.capture.message(None, "error" if code else "not_observed")
        self.collector.stop(session_id, reason="session_ended", gesture="switch_off")
        print(json.dumps(self.collector.flush(session_id)), file=sys.stderr)
        if self.left_out:
            print(
                f"Left out {self.left_out} event(s) that did not name {session_id} alone.",
                file=sys.stderr,
            )
        print(
            f"Continue this session with: run --harness {self.harness} --session {session_id}",
            file=sys.stderr,
        )


def run_command(args):
    if args.harness == "codex":
        raise SystemExit(
            "Codex is captured by the Vicaria plugin for Codex: run "
            "`codex plugin marketplace add vicaria-ai/vicaria-plugins` and "
            "`codex plugin add vicaria@vicaria`, then type vicaria connect in Codex"
        )
    if args.harness not in HARNESSES:
        raise SystemExit("Use the Claude Code or Codex plugin, or choose opencode")
    if not shutil.which(args.harness):
        raise SystemExit(f"Install and sign in to {args.harness} first; it was not found in PATH")
    store = CaptureStore(home_for(args))
    device = store.device()
    if not device:
        raise SystemExit("Connect this harness first using the connect command")
    collector = collector_for(
        args.harness,
        org_id=device["org_id"],
        server=device["server"],
        token=device["token"],
        home=store.home,
        harness_version=args.harness_version,
        surface=lambda line: print(line, file=sys.stderr),
    )
    run = _Run(collector, args.harness, device["server"], args.prompt)
    session_id = getattr(args, "session", None)
    if not session_id:
        with _Server() as server:
            session_id = server.new_session()
    # Minted before the prompt is sent: the plan the prompt asks for then
    # follows a capture under the same id, or no prompt is sent at all.
    run.bind(session_id)
    argv = ["opencode", "run", "--session", session_id, "--format", "json", "--", args.prompt]
    code = None
    try:
        with subprocess.Popen(
            argv, stdout=subprocess.PIPE, stdin=subprocess.DEVNULL, text=True
        ) as process:
            try:
                for line in process.stdout:
                    print(line, end="", flush=True)
                    try:
                        item = json.loads(line)
                    except ValueError:
                        continue
                    run.consume(item)
                code = process.wait()
            except BaseException:
                process.terminate()
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                raise
        return code
    finally:
        run.finish(code)
