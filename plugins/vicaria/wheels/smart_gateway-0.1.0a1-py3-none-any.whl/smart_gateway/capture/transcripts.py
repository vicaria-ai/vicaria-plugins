"""Reasoning and token counts, read from the harness's own session file.

No hook of either harness carries the model's reasoning or a token count.
Both harnesses write them, response by response, to the session file every
hook payload names in ``transcript_path``:

- **Claude Code** appends one record per content block of a model response,
  each carrying the response's ``message.id`` and its final ``usage``.  A
  ``thinking`` block carries its text only when Claude Code asked the API for
  it: Claude Code sends ``thinking.display = "omitted"`` unless its
  ``showThinkingSummaries`` setting (or ``--thinking-display summarized``) is
  on, and then the block holds a signature and an empty string.  The usage's
  ``output_tokens_details.thinking_tokens`` is there either way.
- **Codex** appends ``response_item`` records (``reasoning`` with its
  summaries, ``message``, the calls) and, after each model response, an
  ``event_msg`` of type ``token_count`` whose ``total_token_usage`` is the
  session's running total.

Checked against Claude Code 2.1.285 and codex-cli 0.144.1 (2026-09-29): by
the time ``PreToolUse`` runs, the response that asked for the tool is on
disk, thinking included; by ``Stop``, so is the final one.  Codex writes a
response's ``token_count`` only after the call's result, so its counts are
read per turn, at ``Stop``.

What is read is what a person agreed to share (the notice names the model's
reasoning and the token counts).  Nothing is removed from it on the way: a
thinking block without text is counted as such, and the adapter says so in
the event's omission rather than sending an empty string.
"""

from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
import re
import time
from collections.abc import Callable, Iterator
from dataclasses import dataclass
from pathlib import Path
from typing import Any

#: How much of a file one hook reads at most.  A transcript grows by the
#: turn, and a hook that fell behind reads the rest at the next event.
READ_LIMIT = 64 * 1024 * 1024

#: How long a read waits for the harness to finish writing what the hook that
#: called it says is there, and how often it looks.  Claude Code writes a
#: response to the transcript a moment *after* the hook that follows it runs
#: --- 60 to 80 ms on 2.1.285, measured over five runs --- so without this the
#: turn's thinking and counts were missed on a short turn, two runs in three.
#: The wait ends the moment the record lands, so the ordinary case pays
#: nothing, and a budget this far above the measurement still leaves a hook
#: its own time limit many times over.
CATCH_UP_S = 1.0
CATCH_UP_STEP_S = 0.02

#: An agent id as Claude Code names a subagent's file: a path component,
#: never a path.
_AGENT_ID = re.compile(r"[A-Za-z0-9_-]{1,64}")


@dataclass
class Response:
    """One model response, or for Codex one turn, as the session file has it."""

    message_id: str | None
    text: str | None
    #: The reasoning text the harness received, blocks joined by a blank line;
    #: None when it received none.
    reasoning: str | None
    #: Reasoning blocks seen, and how many of them came without text.
    reasoning_blocks: int
    reasoning_without_text: int
    #: cb.session_event.v6 usage, RFC 0024 § 6's convention; None when the
    #: file reported none.
    usage: dict[str, int] | None
    #: The instant of the response's first record.
    at: str | None = None
    has_tool_use: bool = False
    #: The ids of the tool calls this response asked for, so a hook can wait
    #: for the response that asked for the call it is running.
    tool_use_ids: tuple[str, ...] = ()
    #: The instant on the record that carries each call in ``tool_use_ids``
    #: (a response's blocks can arrive on several records), in the same order.
    tool_use_at: tuple[str | None, ...] = ()
    #: Set when the counts were still being written when the read gave up on
    #: them: the turn's own are not known, and none are sent.
    usage_incomplete: bool = False
    #: Codex: whether the message the hook says closed the turn is among the
    #: turn's own messages here, so the hook's copy would say it twice.
    has_closing_message: bool = False
    #: The harness's id for the turn this response belongs to, as the session
    #: file shows it: Claude Code's ``promptId`` on the user record before it
    #: (assistant records carry none), Codex's ``turn_id`` on the turn's
    #: records.  None when the records read show none, or Codex's show two.
    turn_id: str | None = None


def read_new(path: Path | str, offset: int) -> tuple[list[dict[str, Any]], int]:
    """The complete JSON-object lines after ``offset``, and the offset after them.

    A line not yet ended by a newline is left for the next read: the harness
    may be writing it.  A line that is not a JSON object is skipped.  An
    offset past the end of the file (the harness rewrote it) reads from the
    start, since reading from there would skip everything written since.
    """
    path = Path(path)
    try:
        size = path.stat().st_size
    except OSError:
        return [], offset
    if offset > size:
        offset = 0
    with path.open("rb") as handle:
        handle.seek(offset)
        data = handle.read(min(size - offset, READ_LIMIT))
    end = data.rfind(b"\n")
    if end < 0:
        return [], offset
    records = []
    for line in data[: end + 1].splitlines():
        try:
            record = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        if isinstance(record, dict):
            records.append(record)
    return records, offset + end + 1


def read_new_until(
    path: Path | str,
    offset: int,
    ready: Callable[[list[dict[str, Any]]], bool] | None,
    *,
    budget_s: float | None = None,
    sleep: Callable[[float], None] | None = None,
    clock: Callable[[], float] | None = None,
) -> tuple[list[dict[str, Any]], int]:
    """:func:`read_new`, waiting for ``ready`` to hold of what was read.

    ``ready`` is what the caller knows is there --- the hook's own final
    message, the id of the call it is about to run --- so the wait ends as
    soon as that arrives, and a caller with nothing to wait for (``None``)
    never waits at all.  When the budget runs out the read is returned as it
    stands: the omission it leaves is recorded, as any other is.
    """
    records, end = read_new(path, offset)
    if ready is None:
        return records, end
    # Read at the call, not bound as a default, so a test can shorten the wait
    # it means to lose --- or watch it --- without holding the suite for a
    # second at a time.
    sleep = sleep or time.sleep
    clock = clock or time.monotonic
    deadline = clock() + (CATCH_UP_S if budget_s is None else budget_s)
    while not ready(records) and clock() < deadline:
        sleep(CATCH_UP_STEP_S)
        later, end = read_new(path, offset)
        records = later
    return records, end


def _codex_last_message(rows: list[dict[str, Any]], said: str | None = None) -> int:
    """Where the last assistant message of ``rows`` is, or the last one that
    *is* ``said``; -1 when there is none.

    Whole message against whole message.  A substring match let a reply that
    merely quotes the closing words --- "When the check succeeds, I will
    reply: ..." --- stand in for the closing reply itself, which ended the
    wait early and published the counts written so far (found in review,
    2026-09-30).  Every one of the 11,796 assistant messages in this
    machine's rollouts carries exactly one text item, and all 739 of the
    replies written with an ``agent_message`` event equal it once stripped,
    so nothing is lost by asking for the whole of it.
    """
    spoken = -1
    for index, row in enumerate(rows):
        payload = row.get("payload")
        if row.get("type") != "response_item" or not isinstance(payload, dict):
            continue
        if payload.get("type") != "message" or payload.get("role") != "assistant":
            continue
        whole = "".join(
            item["text"]
            for item in payload.get("content") or []
            if isinstance(item, dict) and isinstance(item.get("text"), str)
        )
        if said is None or said.strip() == whole.strip():
            spoken = index
    return spoken


def codex_said_the_close(rows: list[dict[str, Any]], said: str | None) -> bool:
    """Whether the turn's own messages include the one the hook says closed it.

    What the joined text turns on: when the rollout has not caught up with
    the closing reply, the hook's copy is the only one there is, and it is
    added.  Asked of whole messages for the same reason as above --- a reply
    quoting the closing words was read as already holding it, and the closing
    reply was dropped as a repetition.
    """
    return said is not None and _codex_last_message(rows, said) >= 0


def codex_counts_complete(rows: list[dict[str, Any]], said: str | None = None) -> bool:
    """Whether the counts of the turn's closing message have been written.

    ``said`` is the message the hook says ended the turn, and the count has
    to follow *that* one.  A rollout writes a ``token_count`` after every
    response, so there is nearly always some count after the last message on
    disk; accepting that one published an earlier response's counts as the
    turn's --- 70 input and 20 output for a turn of 140 and 40, with no
    omission beside it to say so (found in review, 2026-09-30).

    This is what the wait waits for as well: the omission is exactly the hole
    the wait gave up on filling, so the two ask one question.  With no
    message named --- a turn that ended without one --- there is nothing for
    the counts to be behind, and what the rollout holds is the turn's.

    The text is all there is to go on, so a turn that said the same thing
    twice --- the whole message identical, not merely quoted --- could match
    the earlier one while the closing message is still being written.
    Nothing better is available: the rollout marks a turn's end only in
    ``task_complete``, which it writes *after* the Stop hook returns
    (measured on 0.144.1: never on disk in five of five turns, while the
    message and its count were there within 0.2 ms).
    """
    spoken = _codex_last_message(rows, said)
    if spoken < 0:
        return said is None
    return any(_codex_totals(row) is not None for row in rows[spoken + 1 :])


def _int(value: Any) -> int | None:
    return value if isinstance(value, int) and not isinstance(value, bool) and value >= 0 else None


def _joined(parts: list[str]) -> str | None:
    kept = [part for part in parts if part]
    return "\n\n".join(kept) if kept else None


# --- Claude Code -----------------------------------------------------------------


def claude_code_usage(usage: Any) -> dict[str, int] | None:
    """A response's usage in v6's names.  Anthropic counts input apart from the
    cache reads and writes, which is RFC 0024 § 6's convention already, and
    thinking as part of output.  A count the record lacks is left out."""
    if not isinstance(usage, dict):
        return None
    details = usage.get("output_tokens_details")
    details = details if isinstance(details, dict) else {}
    counts = {
        "input_tokens": _int(usage.get("input_tokens")),
        "output_tokens": _int(usage.get("output_tokens")),
        "reasoning_tokens": _int(details.get("thinking_tokens")),
        "cache_read_tokens": _int(usage.get("cache_read_input_tokens")),
        "cache_write_tokens": _int(usage.get("cache_creation_input_tokens")),
    }
    kept = {key: value for key, value in counts.items() if value is not None}
    return kept or None


def claude_code_prompt(
    record: dict[str, Any], prompt_id: str | None, *, sidechain: bool = False
) -> str | None:
    """The prompt in effect after ``record``: a user record's ``promptId``
    (Claude Code writes one on every user record, a tool's result included),
    else ``prompt_id`` unchanged."""
    if record.get("type") == "user" and bool(record.get("isSidechain")) == sidechain:
        named = record.get("promptId")
        if isinstance(named, str) and named:
            return named
    return prompt_id


def claude_code_responses(
    records: list[dict[str, Any]], *, sidechain: bool = False, prompt_id: str | None = None
) -> list[Response]:
    """The model responses in ``records``, in order, one per ``message.id``.

    ``sidechain`` reads a subagent's own transcript, every record of which is
    marked a sidechain; in the session's transcript those records are not its
    responses.  ``prompt_id`` is the prompt in effect before ``records``; each
    response's ``turn_id`` is the one in effect at its first record.
    """
    order: list[str] = []
    groups: dict[str, list[dict[str, Any]]] = {}
    turns: dict[str, str | None] = {}
    for index, record in enumerate(records):
        prompt_id = claude_code_prompt(record, prompt_id, sidechain=sidechain)
        if record.get("type") != "assistant" or bool(record.get("isSidechain")) != sidechain:
            continue
        message = record.get("message")
        if not isinstance(message, dict):
            continue
        key = message.get("id") or record.get("requestId") or f"#{index}"
        if key not in groups:
            order.append(key)
            groups[key] = []
            turns[key] = prompt_id
        groups[key].append(record)
    responses = []
    for key in order:
        texts: list[str] = []
        thoughts: list[str] = []
        calls: list[str] = []
        called_at: list[str | None] = []
        blocks = without = 0
        tool = False
        usage = None
        for record in groups[key]:
            message = record["message"]
            if message.get("usage") is not None:
                # Every block's record repeats the response's usage; the last is final.
                usage = message.get("usage")
            for block in message.get("content") or []:
                if not isinstance(block, dict):
                    continue
                kind = block.get("type")
                if kind == "text" and isinstance(block.get("text"), str):
                    texts.append(block["text"])
                elif kind in ("thinking", "redacted_thinking"):
                    blocks += 1
                    thought = block.get("thinking") if kind == "thinking" else None
                    if isinstance(thought, str) and thought.strip():
                        thoughts.append(thought)
                    else:
                        without += 1
                elif kind == "tool_use":
                    tool = True
                    if isinstance(block.get("id"), str):
                        calls.append(block["id"])
                        stamp = record.get("timestamp")
                        called_at.append(stamp if isinstance(stamp, str) else None)
        first = groups[key][0]
        responses.append(
            Response(
                message_id=first["message"].get("id"),
                text=_joined(texts),
                reasoning=_joined(thoughts),
                reasoning_blocks=blocks,
                reasoning_without_text=without,
                usage=claude_code_usage(usage),
                at=first.get("timestamp") if isinstance(first.get("timestamp"), str) else None,
                has_tool_use=tool,
                tool_use_ids=tuple(calls),
                tool_use_at=tuple(called_at),
                turn_id=turns[key],
            )
        )
    return responses


def claude_code_subagent_path(
    transcript: Path | str, session_id: str, agent_id: str
) -> Path | None:
    """Where Claude Code writes a subagent's transcript: beside the session's,
    ``<session>/subagents/agent-<id>.jsonl``.  None for an id that is not a
    plain name."""
    if not _AGENT_ID.fullmatch(agent_id) or not _AGENT_ID.fullmatch(session_id):
        return None
    return Path(transcript).parent / session_id / "subagents" / f"agent-{agent_id}.jsonl"


# --- Codex -----------------------------------------------------------------------

#: The running totals a rollout writes. codex-cli 0.158 (the ChatGPT desktop
#: app's) adds cache_write_input_tokens; 0.144 has no such count.
_CODEX_TOTALS = (
    "input_tokens",
    "cached_input_tokens",
    "cache_write_input_tokens",
    "output_tokens",
    "reasoning_output_tokens",
)


def _codex_totals(record: dict[str, Any]) -> dict[str, int] | None:
    payload = record.get("payload")
    if record.get("type") != "event_msg" or not isinstance(payload, dict):
        return None
    if payload.get("type") != "token_count" or not isinstance(payload.get("info"), dict):
        return None
    total = payload["info"].get("total_token_usage")
    if not isinstance(total, dict):
        return None
    counts = {key: _int(total.get(key)) for key in _CODEX_TOTALS}
    return {key: value for key, value in counts.items() if value is not None} or None


def codex_turn_named(record: dict[str, Any]) -> str | None:
    """The ``turn_id`` a Codex rollout record carries (``task_started``,
    ``turn_context``, ``item_completed``, ``token_usage_record``,
    ``task_complete``), or None."""
    payload = record.get("payload")
    named = payload.get("turn_id") if isinstance(payload, dict) else None
    return named if isinstance(named, str) and named else None


def codex_turn_after(records: list[dict[str, Any]], turn_id: str | None) -> str | None:
    """The turn in effect after ``records``: the last one they name, else ``turn_id``."""
    for record in records:
        turn_id = codex_turn_named(record) or turn_id
    return turn_id


def codex_turn(
    records: list[dict[str, Any]],
    *,
    previous_totals: dict[str, int] | None,
    turn_id: str | None = None,
) -> tuple[Response, dict[str, int] | None]:
    """The turn in ``records``: every reasoning summary and assistant message
    in order, and its token counts, with the running totals after it.

    ``turn_id`` is the turn in effect before ``records`` (where the prompt
    hook left the cursor).  The response names a turn only when one owns all
    it read: the turns the records name, and ``turn_id`` too when content
    comes before the first record that names one.  Content is a reasoning
    item, a message, a call, or counts that changed: counts written before
    the turn changed are the earlier turn's work, and the turn's usage
    includes them (found in re-review, 2026-10-07).  Content before any
    named turn with no ``turn_id`` has no owner, so the response names none.

    The counts are the change in Codex's cumulative ``total_token_usage``
    across the turn, so a ``token_count`` repeated for a rate-limit update is
    not counted twice.  OpenAI counts cached input inside ``input_tokens``;
    RFC 0024 § 6 counts it apart, so it is subtracted and sent as
    ``cache_read_tokens``; so are the cache writes a Codex that reports them
    (0.158) counts inside ``input_tokens``, sent as ``cache_write_tokens``.
    """
    texts: list[str] = []
    thoughts: list[str] = []
    blocks = without = 0
    tool = False
    totals = None
    first_at = None
    turns: set[str] = set()
    before_any = False
    running = previous_totals
    for record in records:
        named = codex_turn_named(record)
        if named:
            turns.add(named)
        latest = _codex_totals(record)
        if latest is not None:
            if latest != running:
                before_any = before_any or not turns
                running = latest
            totals = latest
            continue
        payload = record.get("payload")
        if record.get("type") != "response_item" or not isinstance(payload, dict):
            continue
        kind = payload.get("type")
        if kind == "reasoning":
            blocks += 1
            parts = [
                item.get("text")
                for item in [*(payload.get("summary") or []), *(payload.get("content") or [])]
                if isinstance(item, dict) and isinstance(item.get("text"), str) and item["text"]
            ]
            if parts:
                thoughts.extend(parts)
            else:
                without += 1
        elif kind == "message" and payload.get("role") == "assistant":
            texts.extend(
                item["text"]
                for item in payload.get("content") or []
                if isinstance(item, dict) and isinstance(item.get("text"), str)
            )
        elif kind in ("function_call", "custom_tool_call", "local_shell_call"):
            tool = True
        else:
            continue
        before_any = before_any or not turns
        if first_at is None and isinstance(record.get("timestamp"), str):
            first_at = record["timestamp"]
    owners: set[str | None] = set(turns)
    if before_any or not turns:
        owners.add(turn_id)
    usage = None
    if totals is not None:
        before = previous_totals or {}
        delta = {key: totals[key] - before.get(key, 0) for key in totals}
        if all(value >= 0 for value in delta.values()):
            cached = delta.get("cached_input_tokens")
            written = delta.get("cache_write_input_tokens")
            usage = {
                key: value
                for key, value in {
                    "input_tokens": None
                    if delta.get("input_tokens") is None
                    else delta["input_tokens"] - (cached or 0) - (written or 0),
                    "output_tokens": delta.get("output_tokens"),
                    "reasoning_tokens": delta.get("reasoning_output_tokens"),
                    "cache_read_tokens": cached,
                    "cache_write_tokens": written,
                }.items()
                if value is not None
            } or None
    return (
        Response(
            message_id=None,
            text=_joined(texts),
            reasoning=_joined(thoughts),
            reasoning_blocks=blocks,
            reasoning_without_text=without,
            usage=usage,
            at=first_at,
            has_tool_use=tool,
            turn_id=next(iter(owners)) if len(owners) == 1 else None,
        ),
        totals if totals is not None else previous_totals,
    )


def codex_totals_before(path: Path | str, offset: int) -> dict[str, int] | None:
    """The last running totals written before ``offset``: where a cursor that
    starts late (capture turned on mid-session) takes its first turn's counts
    from."""
    path = Path(path)
    try:
        with path.open("rb") as handle:
            data = handle.read(offset)
    except OSError:
        return None
    totals = None
    for line in data.splitlines():
        if b"token_count" not in line:
            continue
        try:
            record = json.loads(line)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        if isinstance(record, dict):
            totals = _codex_totals(record) or totals
    return totals


def codex_version(path: Path | str) -> str | None:
    """The ``cli_version`` of the rollout's ``session_meta``: Codex names its
    version to no hook, and the rollout's first record carries it."""
    try:
        with Path(path).open("rb") as handle:
            first = handle.readline(1024 * 1024)
        record = json.loads(first)
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    payload = record.get("payload") if isinstance(record, dict) else None
    version = payload.get("cli_version") if isinstance(payload, dict) else None
    return version if isinstance(version, str) and version else None


#: Why a setting a Codex turn ran on is not known (smart-gateway#95). The same
#: closed vocabulary the service takes as ``effort_unrecorded``.
ABSENT, DISAGREE, NOT_FOUND = "absent", "disagree", "not_found"

#: How far back :func:`codex_turn_settings` reads before giving up on a turn's
#: start. A turn longer than this reports ``not_found``: no reading beats a
#: reading that may have missed the turn's first record.
TURN_SETTINGS_MAX_BYTES = 64 * 1024 * 1024
_CHUNK = 1024 * 1024


@dataclass(frozen=True)
class TurnSettings:
    """What one Codex turn ran on, from the turn's own ``turn_context``.

    Codex writes a ``turn_context`` when a turn starts and again after each
    compaction, all carrying the settings the turn started with: a change
    partway through a turn is in none of them. Records of one turn that agree
    are one reading; records that disagree are no reading. A value Codex left
    out (an effort nobody picked: the model's default is not written down) is
    absent, never a level and never borrowed from ``config.toml``.
    """

    model: str | None = None
    effort: str | None = None
    #: Why each is None: :data:`ABSENT`, :data:`DISAGREE` or :data:`NOT_FOUND`.
    model_unrecorded: str | None = NOT_FOUND
    effort_unrecorded: str | None = NOT_FOUND


def _one_setting(records: list[dict[str, Any]], name: str) -> tuple[str | None, str | None]:
    values = {
        value if isinstance(value := record.get(name), str) and value.strip() else None
        for record in records
    }
    if len(values) > 1:
        return None, DISAGREE  # one record names it and another does not, or two differ
    [value] = values
    return (value, None) if value is not None else (None, ABSENT)


def codex_turn_settings(
    path: Path | str,
    session_id: str,
    turn_id: str,
    *,
    newest: bool = False,
    max_bytes: int = TURN_SETTINGS_MAX_BYTES,
) -> TurnSettings:
    """The model and effort ``turn_id`` started on, read off the rollout.

    Matched by the session (the rollout's ``session_meta``) and by the turn's
    own id, never by position. Read from the end, where the current turn is,
    back to the turn's ``task_started`` (or, on a Codex that writes none, to
    the first record of another turn), so every ``turn_context`` of the turn
    is seen, however long the turn ran, up to ``max_bytes``. Unreadable,
    another session's, or no start within the bound: :data:`NOT_FOUND`.

    ``newest``: the turn is the rollout's latest, as it is when its own prompt
    arrives. Codex can write the prompt before the turn's ``turn_context``
    (about one turn in nine on 0.162, mostly a session's first), so a record
    of another turn met before any of this one's means this turn's is not on
    disk yet: :data:`NOT_FOUND` at once, rather than a read back through the
    whole session for a record that is not there.
    """
    if not session_id or not turn_id:
        return TurnSettings()
    found: list[dict[str, Any]] = []
    try:
        with Path(path).open("rb") as handle:
            try:
                first = json.loads(handle.readline(1024 * 1024))
            except (json.JSONDecodeError, UnicodeDecodeError):
                return TurnSettings()
            meta = first.get("payload") if isinstance(first, dict) else None
            if (
                not isinstance(first, dict)
                or first.get("type") != "session_meta"
                or not isinstance(meta, dict)
                or meta.get("id") != session_id
            ):
                return TurnSettings()
            end = handle.seek(0, 2)
            position, carry, started = end, b"", False
            while position > 0 and not started:
                budget = max_bytes - (end - position)
                if budget <= 0:
                    return TurnSettings()
                step = min(_CHUNK, position, budget)
                position -= step
                handle.seek(position)
                lines = (handle.read(step) + carry).split(b"\n")
                # The first piece may be the tail of a record that began in the
                # chunk before; keep it for the next read unless at the start.
                carry = lines.pop(0) if position else b""
                if not position:
                    lines.insert(0, carry)
                for line in reversed(lines):
                    if b'"turn_context"' not in line and b'"task_started"' not in line:
                        continue
                    try:
                        record = json.loads(line)
                    except (json.JSONDecodeError, UnicodeDecodeError):
                        continue
                    payload = record.get("payload") if isinstance(record, dict) else None
                    if not isinstance(payload, dict):
                        continue
                    if record.get("type") == "turn_context":
                        whose = payload.get("turn_id")
                    elif (
                        record.get("type") == "event_msg" and payload.get("type") == "task_started"
                    ):
                        whose = payload.get("turn_id")
                        if whose == turn_id:
                            started = True  # every record of the turn is after this
                            break
                    else:
                        continue
                    if whose == turn_id and record.get("type") == "turn_context":
                        found.append(payload)
                    elif found:
                        started = True  # past the turn's first record, into the one before
                        break
                    elif newest:
                        return TurnSettings()  # the turn's own record is not written yet
    except OSError:
        return TurnSettings()
    if not found:
        return TurnSettings()
    model, model_unrecorded = _one_setting(found, "model")
    effort, effort_unrecorded = _one_setting(found, "effort")
    return TurnSettings(model, effort, model_unrecorded, effort_unrecorded)


def codex_originator(path: Path | str) -> str | None:
    """The ``originator`` of the rollout's ``session_meta``: which Codex app
    runs the session (``codex_exec``, ``Codex Desktop``, ``codex-tui``, ...).
    Read as :func:`codex_version` reads its version, from the first line
    alone (about 20 KB, under the same bound); None when that line is not a
    ``session_meta`` naming one."""
    try:
        with Path(path).open("rb") as handle:
            first = handle.readline(1024 * 1024)
        record = json.loads(first)
    except (OSError, json.JSONDecodeError, UnicodeDecodeError):
        return None
    if not isinstance(record, dict) or record.get("type") != "session_meta":
        return None
    payload = record.get("payload")
    originator = payload.get("originator") if isinstance(payload, dict) else None
    return originator if isinstance(originator, str) and originator else None


# --- the cursor ------------------------------------------------------------------


class Cursor:
    """How far this adapter has read one session file, kept in the client home.

    Its own file and its own lock: the collector's session lock is taken by
    every emit, and ``flock`` on a second descriptor of the same file would
    wait on itself.  Hooks are separate processes and Claude Code runs the
    tool hooks in the background, so two may read the same new lines at once;
    under this lock only one of them sends a response.
    """

    def __init__(self, home: Path | str | None, session_id: str, path: Path | str) -> None:
        root = Path(home) if home else Path(os.path.expanduser("~")) / ".vicaria"
        self.directory = root / "capture" / "transcripts"
        self.path = str(path)
        name = hashlib.sha256(f"{session_id}\0{self.path}".encode()).hexdigest()[:32]
        self.file = self.directory / f"{name}.json"

    @contextlib.contextmanager
    def locked(self) -> Iterator[None]:
        self.directory.mkdir(parents=True, exist_ok=True)
        handle = os.open(self.directory / "cursors.lock", os.O_RDWR | os.O_CREAT, 0o600)
        try:
            fcntl.flock(handle, fcntl.LOCK_EX)
            yield
        finally:
            os.close(handle)

    def load(self) -> dict[str, Any] | None:
        try:
            state = json.loads(self.file.read_text("utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        if not isinstance(state, dict) or state.get("path") != self.path:
            return None
        return {key: value for key, value in state.items() if key != "path"}

    def save(self, state: dict[str, Any]) -> None:
        self.directory.mkdir(parents=True, exist_ok=True)
        temporary = self.file.with_suffix(".tmp")
        temporary.write_text(json.dumps({"path": self.path, **state}), "utf-8")
        os.replace(temporary, self.file)
