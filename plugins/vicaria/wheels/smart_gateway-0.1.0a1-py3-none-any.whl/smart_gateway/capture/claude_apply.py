"""``/vicaria:apply`` for Claude Code: a saved suggestion into the harness's own settings.

F3 (Oct 22): the plugin applies the latest suggestion F1 saved
(:mod:`smart_gateway.control.recommendation_records`) by writing Claude Code's own
user settings, and gives its lesson to the model through SessionStart
``additionalContext``.  There is no proxy and nothing changes the session that is
running: Claude Code reads ``model`` and ``modelSettings`` once, at session start
(code.claude.com/docs/en/settings), so every change takes effect from the next one.

- ``model`` is the settings key for the default model.
- Effort is written where ``/effort`` writes it, ``modelSettings.<model>.effortLevel``.
  A top-level ``effortLevel`` in user settings is the older form and does not count
  for Opus 5.5 (docs/en/model-config); the per-model key counts for every model.
  Settings accept ``low``, ``medium``, ``high`` and ``xhigh``, never ``max``.
- The lesson is stated as a fact the person chose, not an instruction from us.

Three commands, each answered by the hook and never by the model:

- ``/vicaria:apply`` shows the latest suggestion, checked against the workspace's
  current policy, and the code that confirms exactly that suggestion;
- ``/vicaria:apply yes <code>`` writes it;
- ``/vicaria:apply undo`` restores what the last apply replaced, key by key, and keeps
  any value the person changed since.

``/vicaria:status`` then compares the session it runs in with what was applied
(F4): the model the transcript says was configured and served, the effort Claude
Code reports to hooks, and whether this session started with the lesson.
"""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import tempfile
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from smart_gateway.config import resolve_data_dir
from smart_gateway.control import running
from smart_gateway.control.recommendation_records import latest_recommendation
from smart_gateway.ids import utc_now_iso
from smart_gateway.rawlog import append_line, iter_lines, shard_path

HARNESS = "claude-code"
STATE_SCHEMA = "sg.applied.v1"
SETTINGS_EFFORTS = ("low", "medium", "high", "xhigh")
MAX_SETTINGS_BYTES = 1 << 20
MAX_LESSON_CHARS = 4000

NONE_LINE = (
    "vicaria: there's no suggestion to apply yet. One appears after a prompt "
    "in a connected session. Nothing was changed."
)
USAGE_LINE = (
    "vicaria: type /vicaria:apply to see the latest suggestion, /vicaria:apply yes <code> "
    "to apply it, or /vicaria:apply undo to put back what it replaced."
)
NOT_HERE_LINE = (
    "vicaria: applying a suggestion isn't available in this harness yet. Nothing was changed."
)
NOTHING_TO_UNDO_LINE = (
    "vicaria: nothing applied by /vicaria:apply is in place. Nothing was changed."
)
UNLINKED_LINE = (
    "vicaria: this computer isn't connected, so the suggestion can't be checked against your "
    "workspace's policy. Type /vicaria:connect. /vicaria:apply undo works without a connection. "
    "Nothing was changed."
)


class ApplyRefused(Exception):
    """A reason, in the person's words, why nothing was written."""


class ApplyIncomplete(Exception):
    """Part of the work committed and part did not: said as it is, with what to type next."""


def command(
    payload: Mapping[str, Any],
    device: Mapping[str, Any] | None,
    *,
    environ: Mapping[str, str] | None = None,
) -> str:
    """Answer one ``/vicaria:apply`` invocation; never raises for a refusal.

    ``device`` is this computer's link, or ``None``.  Showing and applying ask the
    workspace's policy through it; ``undo`` is local and needs no link, because a
    lesson it put in place is given at every start whether or not one exists.
    """
    env = os.environ if environ is None else environ
    data_dir = resolve_data_dir(env)
    args = payload.get("command_args")
    words = args.split() if isinstance(args, str) else []
    cwd = payload.get("cwd") if isinstance(payload.get("cwd"), str) else None
    try:
        if len(words) == 1 and words[0].lower() == "undo":
            return undo(data_dir, env)
        if not words or (words[0].lower() == "yes" and len(words) == 2):
            if device is None:
                return UNLINKED_LINE
            if not words:
                return preview(data_dir, device, env, cwd)
            return confirm(data_dir, device, words[1], env, cwd)
    except ApplyRefused as refusal:
        return f"vicaria: {refusal} Nothing was changed."
    except ApplyIncomplete as partial:
        return f"vicaria: {partial}"
    return USAGE_LINE


# --- what is applied -----------------------------------------------------------------


def settings_path(environ: Mapping[str, str]) -> Path:
    """The user settings file: ``$CLAUDE_CONFIG_DIR/settings.json``, else ``~/.claude``."""
    home = environ.get("CLAUDE_CONFIG_DIR")
    return (
        Path(home).expanduser() / "settings.json"
        if home
        else Path.home() / ".claude" / "settings.json"
    )


def code_of(recommendation: Mapping[str, Any]) -> str:
    """The confirmation code: binds a ``yes`` to the one suggestion the person saw."""
    seed = f"{recommendation.get('decision_id')}|{recommendation.get('recorded_at')}"
    return hashlib.sha256(seed.encode()).hexdigest()[:8]


def _plan(recommendation: Mapping[str, Any]) -> dict[str, Any]:
    """What an apply writes: the model, the effort and for which model, the lesson."""
    suggested = recommendation.get("suggested")
    base = recommendation.get("base")
    if not isinstance(suggested, Mapping) or not isinstance(base, Mapping):
        raise ApplyRefused("the saved suggestion is incomplete.")
    model = suggested.get("model")
    target = running.canonical(
        model if isinstance(model, str) and model else str(base.get("model") or "")
    )
    if not target.startswith("claude-"):
        raise ApplyRefused("the saved suggestion names no Claude model to apply it to.")
    effort = suggested.get("effort")
    if effort is not None and effort not in SETTINGS_EFFORTS:
        raise ApplyRefused(f"Claude Code's settings can't hold effort {effort}.")
    lesson = recommendation.get("lesson")
    text = None
    if lesson is not None:
        text = lesson.get("text") if isinstance(lesson, Mapping) else None
        if not isinstance(text, str) or not text.strip() or len(text) > MAX_LESSON_CHARS:
            raise ApplyRefused("the saved lesson is unreadable.")
    if model is None and effort is None and text is None:
        raise ApplyRefused("the saved suggestion changes nothing Claude Code's settings hold.")
    return {
        "model": target if model is not None else None,
        "effort": effort,
        "effort_model": target,
        "lesson": text,
    }


def _check_policy(
    recommendation: Mapping[str, Any], device: Mapping[str, Any], plan: Mapping[str, Any]
) -> None:
    """The suggestion against the workspace's policy as it is now, not as it was."""
    from smart_gateway.capture.api import CaptureApi

    server = str(device.get("server") or "").rstrip("/")
    if recommendation.get("server") != server + "/device":
        raise ApplyRefused(
            "the saved suggestion came from a different server than this computer's connection."
        )
    outcome = CaptureApi(server, str(device.get("token") or ""), timeout_s=5.0)._request(
        "GET", "/device/advice-config", None
    )
    allowed = (
        outcome.value.get("allowed_models")
        if outcome.ok and isinstance(outcome.value, dict)
        else None
    )
    if (
        not isinstance(allowed, list)
        or not allowed
        or not all(isinstance(m, str) and m for m in allowed)
    ):
        raise ApplyRefused("couldn't check the workspace's current policy.")
    # The model the written settings will run: the new one, or, for an effort-only
    # suggestion, the one its effort is written for (found in review, #108).
    target = (
        plan["model"]
        if plan["model"] is not None
        else (plan["effort_model"] if plan["effort"] is not None else None)
    )
    if target is not None and target not in allowed:
        raise ApplyRefused(
            f"the workspace's policy no longer allows {target}. "
            f"Allowed: {', '.join(sorted(allowed))}."
        )


def _read_settings(path: Path) -> dict[str, Any]:
    if not path.exists():
        return {}
    try:
        if path.stat().st_size > MAX_SETTINGS_BYTES:
            raise ApplyRefused(f"{path} is larger than this command will edit.")
        document = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise ApplyRefused(f"{path} isn't readable JSON, so it was left alone.") from None
    if not isinstance(document, dict):
        raise ApplyRefused(f"{path} doesn't hold a settings object, so it was left alone.")
    return document


def _write_settings(path: Path, document: Mapping[str, Any]) -> None:
    """Replace the file whole, in its own directory, keeping its mode.

    A ``settings.json`` that is a link into a dotfiles repository stays a link:
    the file it points at is the one replaced, never the link itself.
    """
    path = path.resolve()
    path.parent.mkdir(parents=True, exist_ok=True)
    mode = path.stat().st_mode & 0o777 if path.exists() else 0o600
    fd, tmp = tempfile.mkstemp(prefix=".settings.", suffix=".vicaria", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(document, handle, indent=2, ensure_ascii=False)
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


#: A key that was not there: stored in the record, restored by deleting.
_ABSENT = {"__vicaria_absent__": True}


def _get(document: Mapping[str, Any], key: tuple[str, ...]) -> Any:
    node: Any = document
    for part in key:
        if not isinstance(node, Mapping) or part not in node:
            return _ABSENT
        node = node[part]
    return node


def _set(document: dict[str, Any], key: tuple[str, ...], value: Any) -> None:
    node = document
    for part in key[:-1]:
        child = node.get(part)
        if not isinstance(child, dict):
            child = node[part] = {}
        node = child
    if value == _ABSENT:
        node.pop(key[-1], None)
        # Leave no empty object behind that the apply created.
        if len(key) > 1 and not node:
            _set(document, key[:-1], _ABSENT)
    else:
        node[key[-1]] = value


def _writes(plan: Mapping[str, Any]) -> list[tuple[tuple[str, ...], Any]]:
    out: list[tuple[tuple[str, ...], Any]] = []
    if plan["model"] is not None:
        out.append((("model",), plan["model"]))
    if plan["effort"] is not None:
        out.append((("modelSettings", plan["effort_model"], "effortLevel"), plan["effort"]))
    return out


def _shown(value: Any) -> str:
    return "not set" if value == _ABSENT else str(value)


def _overrides(
    plan: Mapping[str, Any],
    settings: Mapping[str, Any],
    environ: Mapping[str, str],
    cwd: str | None,
) -> list[str]:
    """What would win over the user settings at the next start (docs/en/settings)."""
    notes = []
    env_sources = [("your environment", environ)]
    user_env = settings.get("env")
    if isinstance(user_env, Mapping):
        env_sources.append(("the env block in your user settings", user_env))
    project_files = []
    if cwd:
        for name in ("settings.local.json", "settings.json"):
            path = Path(cwd) / ".claude" / name
            try:
                document = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None
            except (OSError, ValueError):
                document = None
            if isinstance(document, Mapping):
                project_files.append((str(path), document))
                if isinstance(document.get("env"), Mapping):
                    env_sources.append((str(path), document["env"]))
    for where, env in env_sources:
        if plan["model"] is not None and env.get("ANTHROPIC_MODEL"):
            notes.append(f"ANTHROPIC_MODEL in {where} overrides the model setting")
        if plan["effort"] is not None and env.get("CLAUDE_CODE_EFFORT_LEVEL"):
            notes.append(f"CLAUDE_CODE_EFFORT_LEVEL in {where} overrides the effort setting")
    for where, document in project_files:
        if plan["model"] is not None and "model" in document:
            notes.append(f"{where} sets model, which overrides your user settings in that project")
        if plan["effort"] is not None and (
            "effortLevel" in document
            or _get(document, ("modelSettings", plan["effort_model"])) != _ABSENT
        ):
            notes.append(f"{where} sets effort, which overrides your user settings in that project")
    return notes


# --- the three commands ------------------------------------------------------------------


def _describe(plan: Mapping[str, Any], settings: Mapping[str, Any]) -> list[str]:
    parts = []
    for key, value in _writes(plan):
        name = "model" if key == ("model",) else f"effort for {plan['effort_model']}"
        parts.append(f"{name}: {_shown(_get(settings, key))} → {value}")
    if plan["lesson"] is not None:
        parts.append(f'lesson: "{plan["lesson"]}"')
    return parts


def preview(
    data_dir: Path, device: Mapping[str, Any], environ: Mapping[str, str], cwd: str | None
) -> str:
    recommendation = latest_recommendation(data_dir, HARNESS)
    if recommendation is None:
        return NONE_LINE
    plan = _plan(recommendation)
    _check_policy(recommendation, device, plan)
    path = settings_path(environ)
    settings = _read_settings(path)
    kind = "configured setting" if recommendation.get("label") == "configured" else "recommendation"
    lines = [
        f"vicaria: the latest {kind} (from {recommendation.get('recorded_at')}):",
        *(f"  {part}" for part in _describe(plan, settings)),
        f"It goes into {path} and takes effect when you start a new Claude Code session; "
        "this session keeps running as it is.",
    ]
    notes = _overrides(plan, settings, environ, cwd)
    if notes:
        lines.append("Heads up: " + "; ".join(notes) + ".")
    lines.append(f"To apply it, type /vicaria:apply yes {code_of(recommendation)}")
    return "\n".join(lines)


def confirm(
    data_dir: Path,
    device: Mapping[str, Any],
    code: str,
    environ: Mapping[str, str],
    cwd: str | None,
) -> str:
    recommendation = latest_recommendation(data_dir, HARNESS)
    if recommendation is None:
        return NONE_LINE
    if code.lower() != code_of(recommendation):
        raise ApplyRefused(
            "that code doesn't match the latest suggestion; type /vicaria:apply to see it."
        )
    plan = _plan(recommendation)
    # Every read that can refuse happens before any write (found in review, #108).
    stack = _stack(data_dir)
    _check_policy(recommendation, device, plan)
    path = settings_path(environ)
    settings = _read_settings(path)
    described = _describe(plan, settings)
    entry = {
        "schema": STATE_SCHEMA,
        "harness": HARNESS,
        "decision_id": recommendation.get("decision_id"),
        "label": recommendation.get("label"),
        "policy_version": recommendation.get("policy_version"),
        "settings_path": str(path),
        "writes": [
            {"key": list(key), "before": _get(settings, key), "after": value}
            for key, value in _writes(plan)
        ],
        "lesson": plan["lesson"],
        "applied_at": utc_now_iso(),
    }
    updated = json.loads(json.dumps(settings))
    for key, value in _writes(plan):
        _set(updated, key, value)
    # The undo record is written first, so a settings change always has one. A
    # settings write that then fails takes the record back with it.
    _save_stack(data_dir, [*stack, entry])
    if entry["writes"]:
        try:
            _write_settings(path, updated)
        except OSError as failure:
            why = failure.strerror or failure
            try:
                _write_stack(data_dir, stack)
            except OSError:
                # The settings are unchanged and the record still names this
                # apply (its lesson included): say so, and how to clear it.
                raise ApplyIncomplete(
                    f"couldn't write {path} ({why}), so your settings weren't changed, but the "
                    "record of this apply couldn't be taken back. Type /vicaria:apply undo to "
                    "clear it; until then its lesson is still given."
                ) from None
            raise ApplyRefused(f"couldn't write {path} ({why}).") from None
    _history(data_dir, {**entry, "kind": "applied"})
    lines = [
        "vicaria: applied — " + ", ".join(described) + ".",
        "It takes effect when you start a new Claude Code session. "
        "/vicaria:status in that session checks it; /vicaria:apply undo puts back what was there.",
    ]
    notes = _overrides(plan, updated, environ, cwd)
    if notes:
        lines.append("Heads up: " + "; ".join(notes) + ".")
    return "\n".join(lines)


def undo(data_dir: Path, environ: Mapping[str, str]) -> str:
    stack = _stack(data_dir)
    if not stack:
        return NOTHING_TO_UNDO_LINE
    entry = stack[-1]
    path = Path(entry["settings_path"])
    settings = _read_settings(path)
    restored, already, kept = [], [], []
    updated = json.loads(json.dumps(settings))
    for write in entry["writes"]:
        key = tuple(write["key"])
        name = "model" if key == ("model",) else f"effort for {key[1]}"
        current = _get(settings, key)
        if current == write["before"]:
            # Back already: an undo stopped after its restore, or an apply
            # stopped before its write.  Nothing to write; the record still goes.
            already.append(f"{name} already {_shown(write['before'])}")
        elif current == write["after"]:
            _set(updated, key, write["before"])
            restored.append(f"{name} back to {_shown(write['before'])}")
        else:
            kept.append(f"{name} (you changed it since)")
    # Settings first, record second: the record outlives the restore, so an undo
    # that fails or is cut off can be run again (found in review, #108).
    if restored:
        try:
            _write_settings(path, updated)
        except OSError as failure:
            raise ApplyRefused(f"couldn't write {path} ({failure.strerror or failure}).") from None
    try:
        _write_stack(data_dir, stack[:-1])
    except OSError as failure:
        raise ApplyIncomplete(
            "your settings are back"
            + (f" ({', '.join(restored)})" if restored else "")
            + f", but the record of the apply couldn't be updated ({failure.strerror or failure}). "
            "Type /vicaria:apply undo again to finish; until then its lesson is still given."
        ) from None
    _history(
        data_dir,
        {
            "schema": STATE_SCHEMA,
            "kind": "undone",
            "harness": HARNESS,
            "decision_id": entry.get("decision_id"),
            "restored": restored,
            "kept": kept,
            "undone_at": utc_now_iso(),
        },
    )
    parts = restored + already + (["lesson removed"] if entry.get("lesson") else [])
    line = "vicaria: undone — " + (", ".join(parts) if parts else "nothing needed restoring") + "."
    if kept:
        line += " Left as you set them: " + ", ".join(kept) + "."
    return line + " It takes effect when you start a new Claude Code session."


# --- the applied state, the lesson and the check ---------------------------------------


def _state_path(data_dir: Path) -> Path:
    return data_dir / "state" / "apply" / f"{HARNESS}.json"


def _stack(data_dir: Path) -> list[dict[str, Any]]:
    path = _state_path(data_dir)
    try:
        document = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        return []
    except (OSError, ValueError):
        raise ApplyRefused("the record of what was applied is unreadable.") from None
    entries = document.get("applied") if isinstance(document, dict) else None
    return [e for e in entries if isinstance(e, dict)] if isinstance(entries, list) else []


def _history(data_dir: Path, record: Mapping[str, Any]) -> None:
    """The append-only account of applies, undos and lessons given; never the authority."""
    with contextlib.suppress(OSError):
        append_line(shard_path(data_dir, "applied"), record)


def _save_stack(data_dir: Path, stack: list[dict[str, Any]]) -> None:
    try:
        _write_stack(data_dir, stack)
    except OSError as failure:
        raise ApplyRefused(
            f"couldn't save the record that undo needs ({failure.strerror or failure})."
        ) from None


def _write_stack(data_dir: Path, stack: list[dict[str, Any]]) -> None:
    path = _state_path(data_dir)
    for parent in (path.parent.parent, path.parent):
        parent.mkdir(mode=0o700, exist_ok=True)
        os.chmod(parent, 0o700)
    fd, tmp = tempfile.mkstemp(prefix=".apply.", dir=path.parent)
    with os.fdopen(fd, "w", encoding="utf-8") as handle:
        json.dump({"schema": STATE_SCHEMA, "applied": stack}, handle, sort_keys=True)
    os.chmod(tmp, 0o600)
    os.replace(tmp, path)


def active() -> dict[str, Any] | None:
    """What the last apply put in place, or ``None``."""
    try:
        stack = _stack(resolve_data_dir())
    except ApplyRefused:
        return None
    return stack[-1] if stack else None


def session_context(session_id: str | None) -> str | None:
    """SessionStart's ``additionalContext``: the applied lesson, as a stated fact."""
    entry = active()
    if entry is None or not entry.get("lesson"):
        return None
    _history(
        resolve_data_dir(),
        {
            "schema": STATE_SCHEMA,
            "kind": "lesson_given",
            "harness": HARNESS,
            "session_id": session_id,
            "decision_id": entry.get("decision_id"),
            "given_at": utc_now_iso(),
        },
    )
    return (
        "The user applied this working lesson with /vicaria:apply on "
        f"{str(entry.get('applied_at'))[:10]}: {entry['lesson']}"
    )


def _lesson_given(session_id: str, decision_id: Any) -> bool:
    folder = resolve_data_dir() / "applied"
    for path in sorted(folder.glob("*.jsonl")) if folder.is_dir() else ():
        for _line, record in iter_lines(path):
            if (
                record.get("kind") == "lesson_given"
                and record.get("session_id") == session_id
                and record.get("decision_id") == decision_id
            ):
                return True
    return False


def status_lines(
    payload: Mapping[str, Any], environ: Mapping[str, str] | None = None
) -> str | None:
    """F4: this session against what was applied, from what the harness itself reports."""
    env = os.environ if environ is None else environ
    entry = active()
    if entry is None:
        return None
    wanted = {tuple(w["key"]): w["after"] for w in entry.get("writes", [])}
    applied = [
        f"{'model' if k == ('model',) else 'effort for ' + k[1]} {v}" for k, v in wanted.items()
    ]
    if entry.get("lesson"):
        applied.append("a lesson")
    lines = [
        f"Applied {str(entry.get('applied_at'))[:16].replace('T', ' ')}Z "
        f"({entry.get('label') or 'suggestion'}): {', '.join(applied)}."
    ]
    checks = []
    seen = running.read(payload.get("transcript_path"))
    if ("model",) in wanted:
        configured = running.canonical(seen.model_id) if seen.model_id else None
        served = running.canonical(seen.served_id) if seen.served_id else None
        if configured is None and served is None:
            checks.append("model not reported yet in this session")
        else:
            ok = wanted[("model",)] in {configured, served} and (
                served in (None, wanted[("model",)])
            )
            checks.append(
                f"model {served or configured} ({'matches' if ok else 'differs'}"
                f"{'' if served else ', configured; no reply yet'})"
            )
    effort_keys = [k for k in wanted if k[0] == "modelSettings"]
    if effort_keys:
        now = env.get("CLAUDE_EFFORT")
        want = wanted[effort_keys[0]]
        checks.append(
            f"effort {now} ({'matches' if now == want else 'differs'})"
            if now
            else "effort not reported to hooks in this session"
        )
    if entry.get("lesson"):
        session = payload.get("session_id")
        given = isinstance(session, str) and _lesson_given(session, entry.get("decision_id"))
        checks.append(
            "lesson given at session start"
            if given
            else "lesson not given (this session started before the apply)"
        )
    lines.append("This session: " + "; ".join(checks) + ".")
    return "\n".join(lines)
