"""The collector: gates, notice, confirmation, queue, upload, stop.

One collector serves one client home.  It holds no session in memory that it has
not also written to disk, because the processes it lives in are short — a
plugin's hook runs and exits, on Claude Code and on Codex alike — and anything
kept only in memory would be lost between them.

The order of the four gates is load-bearing
-------------------------------------------
:meth:`CaptureCollector.gates` checks them in the order the design fixes, and
the machine opt-out is checked before anything that could depend on an
organization's settings.  A developer who turned capture off on their laptop has
made a decision that an organization setting cannot reverse, and an
implementation that checked the organization first would have to remember to
undo it.

Absence is never consent.  A missing home, an unreadable receipt, a session file
that will not parse, an expired interval: all of them mean off.  There is
deliberately no branch anywhere in this module where a failure to determine
something results in capture being on.

What a refusal looks like
-------------------------
:class:`CaptureRefused` carries a machine-readable ``reason`` from a closed set,
because callers act on it: a hook stays silent on ``not_marked`` (an unmarked
session must add no work and print nothing) and on ``opted_out_on_this_machine``
(the opt-out landed between its gate and the write), and the CLI prints the
notice again on ``no_notice_receipt``.
"""

from __future__ import annotations

import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from smart_gateway.capture import coverage as coverage_module
from smart_gateway.capture import events as event_builder
from smart_gateway.capture.api import CaptureApi, Outcome
from smart_gateway.capture.notice import Notice, notice_for
from smart_gateway.capture.store import CaptureStore, NoticeReceipt, utc_now

#: Re-exported from :mod:`smart_gateway.capture.coverage`, which owns it.
#: Two copies of "which instant does this identity carry" is how the CLI
#: and the publisher came to disagree.
COVERAGE_PUBLISHED_AT = coverage_module.COVERAGE_PUBLISHED_AT

#: The two authorities a session's mark can rest on. Written into the session
#: state so `status` can say which, and so a session start can tell "the
#: person switched this session off" from "the harness ended and resumed it".
SESSION_CONFIRM = "session_confirm"
STANDING_CONSENT = "standing_consent"

#: The one line a mint from standing consent says to the collector's surface.
#: No `sg` command mints, and the Claude Code hook's surface is stderr, which
#: Claude Code does not show from a hook that exits 0, so this is the
#: developer's debug output. The person reads `claude_code.START_ON_LINE`
#: instead, from the hook's reply: at a session start (`claude_code.start`),
#: and at the prompt that mints when the start did not (`claude_code.handle`
#: with `say`; not checked against a live Claude Code).
STANDING_LINE = (
    "vicaria capture: collecting under your standing consent · /vicaria:off pauses this session"
)
#: Said once when a mark or mint found the session switched off meanwhile.
OFF_STANDS_LINE = "vicaria capture: switched off while the session was being marked; off stands"

#: The contract's shape for a notice digest (session-event.schema.json,
#: ``$defs/digest``). A standing grant names the website's notice, whose bytes
#: this adapter never displayed, so equality with the local notice is not the
#: check there --- the shape still is, because an event carrying anything else
#: is refused by the service after it is already queued.
_DIGEST = re.compile(r"^sha256:[0-9a-f]{64}$")

#: Why capture did not happen. Closed, because callers branch on it.
#: The state's own reason for a closed interval when this adapter's notice
#: moved under it.  Not ``developer_unmarked``: that is the person saying no,
#: and the standing mint never retries it, so a notice change written as one
#: switched a linked session off for good (found in review, 2026-09-30).  The
#: local vocabulary is the state's, not the contract's ``STOP_REASONS``, which
#: no collection.stopped event here carries.
NOTICE_CHANGED = "notice_changed"

REFUSALS = (
    "not_sampled",
    "opted_out_on_this_machine",
    "excluded_path",
    "not_marked",
    "no_notice_receipt",
    "notice_changed",
    "already_marked",
    "service_refused",
    "unreachable",
    # A stop made under another credential on this machine has not reached
    # the service; a mark under this one waits for it.
    "undelivered_stop",
)


#: Bound work per upload as well as wire size. The service admits documents
#: individually; a 200-event batch can exceed a hook's request budget even
#: when it fits under the service's 16 MiB body limit. F8's paced drain still
#: saw a 25-event request take 17 s, so normal offers start smaller. These are
#: conservative request targets, not a latency guarantee or a content limit:
#: a single event over CHUNK_BYTES goes alone and is never cut here.
CHUNK_EVENTS = 10
CHUNK_BYTES = 256 * 1024


def _chunks(pending: list[dict[str, Any]], batch: int, limit: int) -> list[list[dict[str, Any]]]:
    """``pending`` in order, cut into chunks of at most ``batch`` events and,
    where the events allow, at most ``limit`` wire bytes."""
    chunks: list[list[dict[str, Any]]] = []
    current: list[dict[str, Any]] = []
    size = 0
    for event in pending:
        wire = _wire_bytes([event])
        if current and (len(current) >= batch or size + wire > limit):
            chunks.append(current)
            current, size = [], 0
        current.append(event)
        size += wire
    if current:
        chunks.append(current)
    return chunks


def _wire_bytes(documents: list[dict[str, Any]]) -> int:
    r"""The size of the request body these documents are sent as.

    ``sum(len(str(event)))`` was near enough for ASCII and not near enough for
    anything else: ``str`` is the Python repr, and ``json.dumps`` escapes a
    non-ASCII character as ``\uXXXX``, so a prompt in French or Japanese was
    logged at about two thirds of the bytes that actually left the machine ---
    under-reporting, in the flattering direction, on the one number the design
    says a developer can check for themselves. This is what
    :meth:`CaptureApi._request` encodes.
    """
    return len(json.dumps(documents).encode("utf-8"))


def _switched_off_meanwhile(before: dict[str, Any] | None, current: dict[str, Any] | None) -> bool:
    """Whether a switch-off was written between two reads of a state: off now,
    and either not off before or off again since (a later ``stopped_at``)."""
    if current is None or current.get("stop_reason") != "developer_unmarked":
        return False
    if (before or {}).get("stop_reason") != "developer_unmarked":
        return True
    return current.get("stopped_at") != (before or {}).get("stopped_at")


def _turn_before(state: dict[str, Any], turn_index: int) -> bool:
    """Whether the state already names a turn past ``turn_index``."""
    current = state.get("turn_index")
    return isinstance(current, int) and not isinstance(current, bool) and current > turn_index


class CaptureRefused(RuntimeError):
    """``reason`` is this client's name for the refusal; ``error`` and
    ``status`` are the service's, when it was the service that refused."""

    def __init__(
        self, reason: str, detail: str, *, error: str | None = None, status: int | None = None
    ) -> None:
        super().__init__(f"{reason}: {detail}")
        if reason not in REFUSALS:
            raise ValueError(f"unknown refusal {reason!r}")
        self.reason = reason
        self.detail = detail
        self.error = error
        self.status = status


@dataclass
class Adapter:
    """Which adapter is speaking, for the identity every event carries."""

    harness: str
    harness_version: str
    adapter_id: str
    adapter_version: str

    def document(self) -> dict[str, Any]:
        return {
            "adapter_id": self.adapter_id,
            "adapter_version": self.adapter_version,
            "coverage_id": event_builder.coverage_id(
                self.harness, self.harness_version, self.adapter_version
            ),
        }


@dataclass
class CaptureCollector:
    """Consent-bound capture against one service, from one client home."""

    org_id: str
    server: str
    token: str
    adapter: Adapter
    store: CaptureStore
    #: Minted on first use, never at construction. The module below promises
    #: that an unmarked session opens no file, and minting eagerly broke that
    #: promise for every machine a hook ever fired on: constructing a collector
    #: created ``~/.vicaria/capture/producer-id`` and the two directories above
    #: it before the first gate was even read. See :meth:`producer`.
    producer_id: str | None = None
    api: CaptureApi | None = None
    #: Where a surfaced line goes. A hook passes something that writes to the
    #: harness's own surface; the CLI passes print.
    surface: Any = None
    #: How long a flush may keep starting new chunks, in seconds; None is no
    #: limit.  A hook sets it from its event's time limit so a backlog does
    #: not run the hook past what the harness allows.
    deadline_s: float | None = None
    _notice: Notice | None = field(default=None, init=False, repr=False)
    #: The revoke outcomes this process has already had, by session: one
    #: attempt per process, because `stop`, the flush inside it and the
    #: hook's own flush would otherwise each ask again inside one budget.
    _revoked: dict[str, Outcome] = field(default_factory=dict, init=False, repr=False)
    #: Set once a request in this process found the service unreachable; a
    #: later flush in the same process then offers nothing, because it would
    #: pay the same timeout for the same answer.
    _unreachable: bool = field(default=False, init=False, repr=False)
    #: The process's flush clock: started by the first flush, before its
    #: revoke pass, and shared by every later flush in the process, so the
    #: deadline bounds the whole hook and not each call.
    _clock: float | None = field(default=None, init=False, repr=False)
    #: Whether any chunk has been offered in this process; the first chunk
    #: of a process is always offered, later ones only inside the deadline.
    _offered: bool = field(default=False, init=False, repr=False)
    #: Whether the skipped-offer line was written in this process: one line
    #: per skipped attempt, and the attempt is skipped once.
    _skip_logged: bool = field(default=False, init=False, repr=False)
    #: Whether the line about another credential's queued events was said in
    #: this process: once, however many flushes share the process.
    _others_said: bool = field(default=False, init=False, repr=False)

    def __post_init__(self) -> None:
        if self.api is None:
            self.api = CaptureApi(self.server, self.token)
        self._notice = notice_for(self.adapter.harness)

    @property
    def notice(self) -> Notice:
        assert self._notice is not None  # set in __post_init__
        return self._notice

    def say(self, line: str) -> None:
        if self.surface is not None:
            self.surface(line)

    def producer(self) -> str:
        """This home's producer id, minted the first time an event needs one.

        Deliberately not resolved in :func:`collector_for`. A Claude Code hook
        constructs a collector on every event of every session, marked or not;
        resolving the id there wrote a file into the home of a developer who had
        marked nothing, which is exactly what this package's docstring says does
        not happen. Only :meth:`_emit` needs the id, and by the time it runs the
        four gates have already passed.
        """
        if self.producer_id is None:
            self.producer_id = self.store.producer_id()
        return self.producer_id

    # --- gates ---------------------------------------------------------------

    def gates(
        self, *, sampled: bool, session_id: str, excluded: bool = False
    ) -> tuple[bool, str | None]:
        """All four, in order. Returns ``(open, refusal_reason)``.

        ``sampled`` is gate 1 as the caller resolved it — an organization's
        sampling decision, which this client does not make.  Gate 4 is the
        session's own interval, which :meth:`confirm` (the organization's
        mark) or :meth:`mint_from_standing_consent` (a linked device) opens.
        """
        if not sampled:
            return False, "not_sampled"
        if self.store.opted_out():
            return False, "opted_out_on_this_machine"
        # The seam for the third gate, and nothing passes it: `excluded` is
        # always the default, so this branch is dead.  Kept rather than deleted
        # because it is where the exclusion stage lands when it is built, and
        # removed from silence by the test that pins the hold --- wiring a
        # caller here without also flipping the coverage document's
        # `enforced_before_upload` fails that test, which is the whole point.
        if excluded:
            return False, "excluded_path"
        state = self.store.session(session_id)
        if not state or not state.get("active"):
            return False, "not_marked"
        if self._notice_moved(state):
            # A widened scope asks again (RFC 0048), and an open interval is
            # where that was escaped: the plugin refreshes its runtime
            # mid-session, the notice moves, and the session went on
            # collecting the new material under the authorization given for
            # the old.  The interval is closed here, on disk and without a
            # word to the service, so everything downstream reads the session
            # as off: a linked device's next prompt mints a new one, which
            # the service grants only against the notice the person has now
            # agreed to, and an organization's developer is refused until
            # they read the new notice and confirm again.
            self.close_for_changed_notice(session_id)
            return False, "notice_changed"
        return True, None

    def _notice_moved(self, state: dict[str, Any]) -> bool:
        """Whether this adapter's notice changed since the interval opened.

        A state that names no notice was written before this field existed
        --- which is to say before the scope this notice widened --- so it
        counts as moved.  Treating it as nothing to compare left exactly the
        upgrade this guard exists for collecting under the old grant (found
        in review, 2026-09-30: the regression test built its state with the
        new code, so it never saw one).
        """
        opened_under = state.get("adapter_notice_version")
        if not isinstance(opened_under, str):
            return True
        return opened_under != self.notice.version

    def close_for_changed_notice(self, session_id: str) -> dict[str, Any] | None:
        """Close an interval whose notice has moved, on disk alone.

        No stop is kept for the service and none is sent: the events already
        queued were captured under the grant that authorized them, and this
        client has nothing to tell the service that the next mint will not.
        """
        state = self.store.session(session_id)
        if state is None or not state.get("active") or not self._notice_moved(state):
            return state
        with self.store.session_lock():
            state = self.store.session(session_id)
            if state is None or not state.get("active") or not self._notice_moved(state):
                return state
            return self._switch_off_locked(
                session_id, rescope=False, reason=NOTICE_CHANGED, gesture="unmark"
            )

    def active(self, session_id: str) -> bool:
        state = self.store.session(session_id)
        return bool(state and state.get("active"))

    # --- notice and confirmation --------------------------------------------

    def show_notice(self, session_id: str) -> NoticeReceipt:
        """Display the notice in full and record only that it was displayed.

        This makes no network request and stores no session content.  A
        developer who reads it and walks away has left nothing behind but a
        local receipt saying the text was shown.
        """
        self.say(self.notice.text)
        receipt = NoticeReceipt(
            session_id=session_id,
            org_id=self.org_id,
            server=self.api.server if self.api else self.server,
            harness=self.adapter.harness,
            notice_version=self.notice.version,
            notice_digest=self.notice.digest,
            shown_at=utc_now(),
        )
        self.store.save_notice_receipt(receipt)
        return receipt

    def confirm(
        self, session_id: str, *, turn_index: int = 0, repository: str | None = None
    ) -> dict[str, Any]:
        """The confirmation gesture. Refused before any request without a receipt,
        and on an opted-out machine.

        The receipt has to exist for this session, organization, endpoint *and*
        the digest of the notice text currently in the code.  Editing the notice
        therefore invalidates confirmations taken against the old words, which
        is the behaviour that makes "the grant binds what was shown" true rather
        than aspirational.
        """
        self._refuse_if_opted_out(session_id)
        receipt = self.store.notice_receipt(
            session_id=session_id,
            org_id=self.org_id,
            server=self.api.server if self.api else self.server,
            notice_digest=self.notice.digest,
        )
        if receipt is None:
            raise CaptureRefused(
                "no_notice_receipt",
                "no receipt that this session's notice was displayed at this endpoint; "
                "show the notice first",
            )
        if receipt.notice_version != self.notice.version:
            raise CaptureRefused(
                "notice_changed",
                f"the receipt is for notice {receipt.notice_version}, the adapter now "
                f"shows {self.notice.version}; the notice must be read again",
            )
        state = self.store.session(session_id)
        if state is not None and state.get("active"):
            raise CaptureRefused("already_marked", f"{session_id} already carries an open interval")
        state, _revoked_first = self._deliver_stop_before_marking(
            session_id, state, record_refusal=False
        )

        assert self.api is not None
        outcome = self.api.mark(
            {
                "session_id": session_id,
                "org_id": self.org_id,
                "turn_index": turn_index,
                "notice_version": self.notice.version,
                "notice_digest": self.notice.digest,
                "gesture": f"{self.adapter.harness}_command_confirm",
            }
        )
        if not outcome.ok:
            raise CaptureRefused(
                "unreachable" if outcome.reason == "unreachable" else "service_refused",
                outcome.detail,
            )

        authorization = _authorization_from(outcome.value, notice=self.notice)
        if authorization is None:
            # Without the immutable interval on the grant there is nothing for
            # an event's consent block to name, and an event that named a
            # client-invented interval would be the client asserting its own
            # authorization. Nothing is collected.
            raise CaptureRefused(
                "service_refused",
                "the mark response omitted the immutable authorization interval; "
                "nothing will be collected",
            )

        marked = self._save_marked(
            session_id,
            authorization=authorization,
            turn_index=turn_index,
            repository=repository,
            authority=SESSION_CONFIRM,
            before=state,
        )
        if not marked["active"]:
            self.say(OFF_STANDS_LINE)
            return authorization
        # No consent.changed event is emitted here, and that is deliberate.
        # The service records the grant itself on POST /v1/sessions; a client
        # that also emitted one would be offering its own account of an
        # authorization the server holds. The OpenCode collector emits none for
        # the same reason, and the admission rule agrees: a consent.changed
        # states its effective turn, and an unmark's effective turn is by
        # definition the first turn *outside* the interval it closes, so the
        # event would be refused as outside_authorized_interval.
        # Published before the first event so the session's coverage_id
        # resolves to a document from the moment the audit surface sees it.
        self._refuse_if_opted_out_after_the_request(session_id)
        if not self._start_recorded(session_id, repository):
            return authorization
        self.ensure_coverage_published()
        # Read once more before saying it collects: an opt-out landing since
        # the check above is answered as the opt-out answers.
        self._refuse_if_opted_out_after_the_request(session_id)
        self.say(
            "vicaria capture: collecting from the next turn; eligibility and this "
            "authorization do not decide whether the session is worth testing"
        )
        return authorization

    def _deliver_stop_before_marking(
        self, session_id: str, state: dict[str, Any] | None, *, record_refusal: bool = True
    ) -> tuple[dict[str, Any] | None, bool]:
        """A stop the service never acknowledged goes before a new interval.

        Whatever the service answers, the mark or mint that follows decides:
        either the old interval was closed and a new one opens, or it was
        never closed and the service hands the open one back; neither leaves
        a revoke to deliver, and the new state carries none.  An unreachable
        answer is the mark's answer too: one budget, not two, for the same
        service.  A stop made under another credential is not this one's to
        deliver and must not be written over either: the mark is refused
        until a flush under that credential has sent it.  Returns the state
        as re-read after the revoke and whether one was sent.
        """
        pending = state.get("pending_revoke") if state is not None else None
        if not isinstance(pending, dict):
            return state, False
        if pending.get("org_id") != self.org_id:
            detail = (
                f"an undelivered stop under {pending.get('org_id')}; "
                f"`sg capture flush --session {session_id}` under that credential delivers it"
            )
            if record_refusal:
                self.store.append_drop_log(
                    {
                        "at": utc_now(),
                        "event_id": None,
                        "session_id": session_id,
                        "reason": "mint_refused",
                        "turn_index": None,
                        "status": None,
                        "detail": detail,
                    }
                )
            raise CaptureRefused("undelivered_stop", detail)
        # Gate 2 once more, where the revoke reads it too: an opt-out landing
        # since the caller's check would hold the stop back and let the mark
        # go out, whose save then drops the stop.  Neither goes.
        self._refuse_if_opted_out(session_id)
        outcome = self._revoke_pending(session_id)
        if outcome is not None and outcome.reason == "unreachable":
            raise CaptureRefused("unreachable", outcome.detail)
        return self.store.session(session_id), outcome is not None

    def _save_marked(
        self,
        session_id: str,
        *,
        authorization: dict[str, Any],
        turn_index: int,
        repository: str | None,
        authority: str,
        before: dict[str, Any] | None,
    ) -> dict[str, Any]:
        """Write the open interval under the lock, on top of what is there now.

        The lock is not held across the request that opened the interval, so
        the state is read again under it: what another process wrote
        meanwhile (a stop from a second terminal, a resumed session's late
        hook) carries into the new state rather than being written over.  A
        session switched off while the request was in flight stays off: the
        interval the service just opened is closed by the next flush, from
        its first turn, as `stop` would.  Returns the state written.
        """
        with self.store.session_lock():
            current = self.store.session(session_id)
            marked = self._marked_state(
                session_id,
                authorization=authorization,
                turn_index=turn_index,
                repository=repository,
                authority=authority,
                previous=current or before,
            )
            if _switched_off_meanwhile(before, current):
                marked["active"] = False
                marked["stopped_at"] = utc_now()
                marked["stop_reason"] = "developer_unmarked"
                marked["pending_revoke"] = {
                    "state": "revoked",
                    "org_id": self.org_id,
                    "turn_index": turn_index,
                    "authorized_interval_id": authorization["authorized_interval_id"],
                    "gesture": "switch_off",
                }
            self.store.save_session(marked)
        return marked

    def _marked_state(
        self,
        session_id: str,
        *,
        authorization: dict[str, Any],
        turn_index: int,
        repository: str | None,
        authority: str,
        previous: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """The session state an open interval is written as, from either authority.

        One shape for both, so nothing downstream --- the gate, the emitter,
        `status` --- has to know which door the grant came through. ``previous``
        is the state of a session whose earlier interval was closed and is now
        reopened: the `session.started` flag and the provenance edge carry over,
        so the new interval does not announce a second start of the same
        session and its first event still names the event before the gap.
        """
        assert self.api is not None
        previous = previous or {}
        return {
            "session_id": session_id,
            "org_id": self.org_id,
            "server": self.api.server,
            "harness": self.adapter.harness,
            "active": True,
            "authority": authority,
            "authorization": authorization,
            "turn_index": turn_index - 1,
            "last_event_id": previous.get("last_event_id"),
            "marked_at": utc_now(),
            # The adapter notice this interval was opened under.  The grant's
            # own `notice_version` is the *service's* (on a linked device, the
            # notice the person read on the website), so it cannot answer
            # "has what this adapter says it collects changed since?".
            "adapter_notice_version": self.notice.version,
            "repository": repository if repository is not None else previous.get("repository"),
            "session_started_recorded": bool(previous.get("session_started_recorded")),
        }

    def next_turn(self, session_id: str) -> int:
        """The first turn an interval confirmed now would cover (see ``_next_turn``).

        What ``sg capture confirm`` marks from when no turn is given: a session
        stopped at the end of a harness run resumes one past the turn it
        reached, which the service accepts, where turn 0 would be refused.
        """
        return self._next_turn(self.store.session(session_id))

    @staticmethod
    def _next_turn(state: dict[str, Any] | None) -> int:
        """The turn a mint taken now covers from: the next prompt's.

        A session with no state starts at 0. One with state resumes one past
        the turn it reached --- the same turn `stop` closed the previous
        interval at, which the service allows ("equal turns are allowed") and
        which is the first turn the closed interval does not cover, so nothing
        falls in a gap and nothing is claimed retroactively.
        """
        if state is None:
            return 0
        current = state.get("turn_index")
        if isinstance(current, bool) or not isinstance(current, int):
            return 0
        return current + 1

    def mint_from_standing_consent(
        self,
        session_id: str,
        *,
        turn_index: int | None = None,
        repository: str | None = None,
        record_refusal: bool = True,
    ) -> dict[str, Any]:
        """Open this session's interval from the consent the person gave once.

        The other door to the same grant. The person agreed to the website's
        notice, the service holds that consent, and ``POST /device/sessions``
        asks it to mint an interval for this session under it. The descriptor
        that comes back is the store's own grant row --- the same shape a
        per-session mark returns --- and it is copied onto every event exactly
        as :meth:`confirm` copies its own, so the events of the two paths are
        indistinguishable to the service and to the audit surface.

        What is *not* checked here, and why: :meth:`confirm` demands a local
        receipt that the notice was shown and that the grant names the bytes
        this adapter displayed. Neither applies. The notice was shown on the
        website, the receipt is the service's consent row, and the digest the
        grant carries is the website's; :func:`_authorization_from` with
        ``standing=True`` therefore accepts the server's digest while still
        requiring every key the contract requires.

        A refusal is silent by design. A 403 means nothing stands --- never
        agreed, withdrawn, or a notice that changed --- and a person who has not
        agreed is not nagged; the website says what stands. One line goes to
        the drop log so the developer's own record still says the session was
        not captured, and why. ``record_refusal=False`` is for the retry a
        prompt makes on a session that was never minted, which would otherwise
        write that line once per prompt.
        """
        self._refuse_if_opted_out(session_id)
        state = self.store.session(session_id)
        if state is not None and state.get("active"):
            raise CaptureRefused("already_marked", f"{session_id} already carries an open interval")
        state, revoked_first = self._deliver_stop_before_marking(
            session_id, state, record_refusal=record_refusal
        )
        if turn_index is None:
            turn_index = self._next_turn(state)

        body: dict[str, Any] = {
            "session_id": session_id,
            "turn_index": turn_index,
            "harness": self.adapter.harness,
        }
        if self.adapter.harness_version != "unknown":
            # "unknown" is this client's placeholder, and the service falls
            # back to the version the device linked with; sending the
            # placeholder would overwrite a known version with an unknown one.
            body["harness_version"] = self.adapter.harness_version
        assert self.api is not None
        outcome = self.api.mint_session(body)
        if not outcome.ok:
            if outcome.reason == "unreachable":
                raise CaptureRefused("unreachable", outcome.detail)
            error = outcome.value.get("error") if isinstance(outcome.value, dict) else None
            detail = outcome.detail
            if isinstance(error, str) and error and error not in detail:
                detail = f"{error}: {detail}"
            if record_refusal:
                self.store.append_drop_log(
                    {
                        "at": utc_now(),
                        "event_id": None,
                        "session_id": session_id,
                        "reason": "mint_refused",
                        "turn_index": turn_index,
                        "status": outcome.status,
                        "detail": detail,
                    }
                )
            raise CaptureRefused(
                "service_refused",
                detail,
                error=error if isinstance(error, str) and error else None,
                status=outcome.status,
            )

        authorization = _authorization_from(outcome.value, notice=self.notice, standing=True)
        if authorization is None:
            detail = (
                "the mint response omitted the immutable authorization interval; "
                "nothing will be collected"
            )
            if record_refusal:
                # A refusal all the same, and said where the others are.
                self.store.append_drop_log(
                    {
                        "at": utc_now(),
                        "event_id": None,
                        "session_id": session_id,
                        "reason": "mint_refused",
                        "turn_index": turn_index,
                        "status": outcome.status,
                        "detail": detail,
                    }
                )
            raise CaptureRefused("service_refused", detail)

        marked = self._save_marked(
            session_id,
            authorization=authorization,
            turn_index=turn_index,
            repository=repository,
            authority=STANDING_CONSENT,
            before=state,
        )
        if not marked["active"]:
            self.say(OFF_STANDS_LINE)
            return authorization
        # As in `confirm`: no consent.changed from the client, the session start
        # queued once, and the coverage document published once per identity.
        # The start is queued BEFORE the coverage round trip so a hook killed
        # at its time budget leaves a session whose first event is on disk;
        # the coverage document still reaches the service before that event,
        # because the queue is offered only at the next flush.
        self._refuse_if_opted_out_after_the_request(session_id)
        if not self._start_recorded(session_id, repository):
            return authorization
        if not revoked_first:
            self.ensure_coverage_published()
        self._refuse_if_opted_out_after_the_request(session_id)
        self.say(STANDING_LINE)
        return authorization

    def _refuse_if_opted_out(self, session_id: str) -> None:
        """Gate 2 before a mark or a mint: no request leaves an opted-out
        machine, whoever calls.  Every caller in this package reads it first;
        this holds for the one that does not."""
        if self.store.opted_out():
            raise CaptureRefused(
                "opted_out_on_this_machine",
                f"this machine is opted out; {session_id} is not marked until "
                "`sg capture opt-out --undo`",
            )

    def _refuse_if_opted_out_after_the_request(self, session_id: str) -> None:
        """Gate 2 again once the mark's or mint's answer is saved.

        An opt-out that landed during the request cannot unsay it: the
        service opened the interval, and the state saved it (on, so a later
        `--undo` records under it).  Nothing more is sent (the coverage
        document, whose publish would otherwise follow) and nothing says it
        collects: the caller is answered as the opt-out answers.  Read again
        after the coverage document, just before the line that says so.
        """
        if self.store.opted_out():
            raise CaptureRefused(
                "opted_out_on_this_machine",
                f"this machine opted out while {session_id} was being marked; nothing "
                "more is sent until `sg capture opt-out --undo`",
            )

    def _start_recorded(self, session_id: str, repository: str | None) -> bool:
        """Queue the session start after a mark; False when a stop landed
        between the save and this write, which is the off-stands case: the
        state is off with the stop's own revoke, and the caller says so.  An
        opt-out that landed during the mark's request is answered before
        this, by :meth:`_refuse_if_opted_out_after_the_request`; one landing
        after that check raises out of the event write here where the start
        is still to be written, and is answered by the same check after the
        coverage document where it was written already."""
        try:
            self.record_session_started(session_id, repository=repository)
        except CaptureRefused as refusal:
            if refusal.reason != "not_marked":
                raise
            self.say(OFF_STANDS_LINE)
            return False
        return True

    def ensure_coverage_published(self) -> dict[str, Any]:
        """Publish the coverage document unless this home already had it accepted.

        The document is immutable per identity, so one accepted publish per
        client home is the whole job; :meth:`publish_coverage` still offers it
        unconditionally for the operator who asks.
        """
        coverage_id = coverage_module.coverage_id(
            self.adapter.harness, self.adapter.harness_version, self.adapter.adapter_version
        )
        if self.store.opted_out():
            # Gate 2, read here too: an opt-out landing after a mark's or a
            # mint's own checks sends nothing, the coverage document included.
            return {"published": False, "outcome": "opted_out", "coverage_id": coverage_id}
        if self.store.coverage_published(coverage_id):
            return {"published": True, "outcome": "already_published", "coverage_id": coverage_id}
        result = self.publish_coverage()
        if result.get("published"):
            self.store.mark_coverage_published(result["coverage_id"])
        return result

    def publish_coverage(self) -> dict[str, Any]:
        """Publish this adapter's coverage document, once per identity.

        The audit surface renders a missing tool input as "not captured by the
        adapter" *only if* it can find the coverage document the event's
        ``coverage_id`` names. Both ends of that mechanism were built and
        nothing connected them: `/v1/captures` accepts
        ``cb.adapter_coverage.v1``, the client API layer knows the receipt type,
        and no client ever posted one — which is why the demo's queue item reads
        ``coverage_document_missing``.

        Coverage carries no organization or session material, so it is
        deliberately outside the session fence and may be published before any
        session is marked. A repeat of the same bytes is a retry; the same id
        with different bytes is a conflict the service refuses, which is what
        makes the identity immutable.
        """
        document = coverage_module.document(
            self.adapter.harness,
            harness_version=self.adapter.harness_version,
            adapter_version=self.adapter.adapter_version,
            # Pinned to the adapter's identity rather than to the clock: a
            # document whose bytes changed only because it was published again
            # would collide with its own id.
            published_at=COVERAGE_PUBLISHED_AT,
        )
        assert self.api is not None
        outcome = self.api.captures([document])
        if not outcome.ok:
            # Not fatal. A session whose coverage could not be published is a
            # session whose omissions are shown as unknown, which is worse than
            # showing them and better than not capturing.
            self.store.append_upload_log(
                {
                    "at": utc_now(),
                    "capture_id": document["coverage_id"],
                    "session_id": None,
                    "byte_count": _wire_bytes([document]),
                    "outcome": outcome.reason or "refused",
                    "detail": outcome.detail,
                }
            )
            return {"published": False, "detail": outcome.detail}
        receipt = outcome.value["results"][0]
        return {
            "published": receipt["outcome"] in ("stored", "retry"),
            "outcome": receipt["outcome"],
            "coverage_id": document["coverage_id"],
        }

    # --- recording -----------------------------------------------------------

    def _next(self, session_id: str) -> dict[str, Any]:
        state = self.store.session(session_id)
        if state is None:
            raise CaptureRefused("not_marked", f"{session_id} is not marked")
        return state

    def _emit(
        self,
        session_id: str,
        *,
        event_type: str,
        payload: dict[str, Any],
        turn_index: int | None,
        omissions: list[dict[str, Any]] | None = None,
        subagent_id: str | None = None,
        event_time: str | None = None,
        prompt_id: str | None = None,
        structure: event_builder.Structure | None = None,
    ) -> dict[str, Any]:
        with self.store.session_lock():
            return self._emit_locked(
                session_id,
                event_type=event_type,
                payload=payload,
                turn_index=turn_index,
                omissions=omissions,
                subagent_id=subagent_id,
                event_time=event_time,
                prompt_id=prompt_id,
                structure=structure,
            )

    def _emit_locked(
        self,
        session_id: str,
        *,
        event_type: str,
        payload: dict[str, Any],
        turn_index: int | None,
        omissions: list[dict[str, Any]] | None,
        subagent_id: str | None,
        event_time: str | None,
        prompt_id: str | None = None,
        structure: event_builder.Structure | None = None,
    ) -> dict[str, Any]:
        if event_type != "collection.stopped" and self.store.opted_out():
            # Opted out after the caller's gate: the Codex wrapper reads the
            # gates once, before a run that may last minutes.  The opt-out
            # beats every setting above it, so nothing more is recorded.
            raise CaptureRefused(
                "opted_out_on_this_machine", f"this machine opted out; {session_id} records nothing"
            )
        state = self._next(session_id)
        if not state.get("active") and event_type != "collection.stopped":
            # Switched off between the caller's gate and this write: an
            # event queued now would sit inside the interval after its
            # terminal event.  Refused as the gate would have refused it.
            raise CaptureRefused("not_marked", f"{session_id} is switched off")
        # Per producer, not per session: see CaptureStore.next_sequence.
        sequence = self.store.next_sequence()
        observed = utc_now()
        when = observed if event_time is None else event_time
        if event_time is None:
            # This observation is made after the service's grant arrived. A
            # client clock a few milliseconds behind the service must not put
            # it before that grant. Keep the raw local clock in observed_at;
            # bound only timestamps we generate now, never historical times
            # supplied by a caller or immutable events replayed from the queue.
            start = state["authorization"]["interval_start"]
            if event_builder.primitives().before(when, start) is True:
                when = start
            if event_type == "session.started":
                payload = {**payload, "started_at": when}
        # The OpenCode plugin's published recipe, from the harness's own
        # prompt identity. The control hook journals that same id as the plan
        # request's revision, so the service can join a captured prompt to its
        # decision on identity rather than on timing.
        recipe = (
            None
            if prompt_id is None
            else event_builder.stable_id(
                "evt", str(state["org_id"]), session_id, event_type, prompt_id
            )
        )
        first_use = (
            recipe is not None
            and prompt_id is not None
            # Belt and braces behind the record: enqueue keeps the first
            # document under an id and drops any later one silently.
            and not self.store.queued(recipe)
            # Reserved before the event is queued, not recorded after: a hook
            # killed between the two would leave a queued recipe the record
            # does not name, and once it settled a repeat would take its id.
            and self.store.reserve_prompt_id(session_id, event_type, prompt_id)
        )
        if first_use and recipe is not None:
            event_id = recipe
        else:
            # No prompt id, or one an earlier event of this type already took:
            # Claude Code hands a background task's <task-notification> to
            # UserPromptSubmit with the prompt id of the turn that queued it,
            # and the recipe again would name a different message with the
            # same id (the service refused two as event_conflict, 2026-10-08).
            event_id = event_builder.stable_id(
                "evt", session_id, str(sequence), event_type, str(turn_index)
            )
        structure = self._with_harness_turn(state, event_type, turn_index, prompt_id, structure)
        document = event_builder.build(
            event_type=event_type,
            event_id=event_id,
            org_id=str(state["org_id"]),
            session_id=session_id,
            producer_id=self.producer(),
            producer_seq=sequence,
            event_time=when,
            observed_at=observed,
            turn_index=turn_index,
            parent_event_id=state.get("last_event_id"),
            correlation_id=(
                None
                if turn_index is None
                else event_builder.stable_id("turn", session_id, str(turn_index))
            ),
            subagent_id=subagent_id,
            consent=state["authorization"],
            adapter=self.adapter.document(),
            payload=payload,
            recorded_omissions=[*(omissions or []), *(structure.omissions if structure else ())]
            or None,
            structure=structure.fields if structure else None,
        )
        self.store.enqueue(document)
        if event_type == "session.started":
            self.store.open_prompt_ledger(session_id)
        state["last_producer_seq"] = sequence
        state["last_event_id"] = event_id
        if turn_index is not None and not _turn_before(state, turn_index):
            # Never lower: an asynchronous tool hook that read turn 0 and
            # queued behind the prompt that advanced to turn 1 must not write
            # 0 back, or the next prompt lands on turn 1 again and the stop
            # closes the interval one turn early, outside the turn's own
            # queued events.
            state["turn_index"] = turn_index
        self.store.save_session(state)
        return document

    @staticmethod
    def _with_harness_turn(
        state: dict[str, Any],
        event_type: str,
        turn_index: int | None,
        prompt_id: str | None,
        structure: event_builder.Structure | None,
    ) -> event_builder.Structure | None:
        """v7 ``harness_turn_id``: the harness's own id for the prompt that
        opened this turn, remembered from that prompt and carried on every
        later event of the same turn.  Absent when the harness gave none, or
        gave one the contract would not take as an id."""
        if event_type == "user_message.recorded" and turn_index is not None:
            harness_turn = event_builder.routable(prompt_id)
            state["harness_turn"] = (
                {"turn_index": turn_index, "id": harness_turn} if harness_turn else None
            )
        remembered = state.get("harness_turn")
        if not remembered or turn_index is None or remembered.get("turn_index") != turn_index:
            return structure
        return event_builder.with_fields(structure, harness_turn_id=remembered["id"])

    def record_session_started(
        self, session_id: str, *, repository: str | None = None
    ) -> dict[str, Any] | None:
        state = self._next(session_id)
        if not state.get("active"):
            # Before the short-circuit: a reopened session whose start was
            # recorded long ago still has to answer a stop that landed
            # between the mark's save and this call.
            raise CaptureRefused("not_marked", f"{session_id} is switched off")
        if state.get("session_started_recorded"):
            return None
        document = self._emit(
            session_id,
            event_type="session.started",
            turn_index=None,
            payload=event_builder.session_started(
                harness=self.adapter.harness,
                harness_version=self.adapter.harness_version,
                started_at=utc_now(),
                repository=repository or state.get("repository"),
            ),
        )
        with self.store.session_lock():
            # Re-read under the lock, after `_emit` has released it: a stop
            # that landed between the two must not be written back on.
            state = self._next(session_id)
            state["session_started_recorded"] = True
            self.store.save_session(state)
        return document

    def record_user_message(
        self, session_id: str, *, turn_index: int, text: str, prompt_id: str | None = None
    ) -> dict[str, Any]:
        """``prompt_id`` is the harness's identity for this prompt, when it has one."""
        return self._emit(
            session_id,
            event_type="user_message.recorded",
            turn_index=turn_index,
            prompt_id=prompt_id,
            payload=event_builder.user_message(turn_index=turn_index, text=text),
            omissions=[
                event_builder.omission(
                    "attachment",
                    "This adapter receives no attachment list on a message, so an attachment "
                    "is invisible rather than absent.",
                )
            ],
        )

    def record_assistant_message(
        self,
        session_id: str,
        *,
        turn_index: int,
        text: str | None,
        turn_termination: str,
        usage: dict[str, Any] | None = None,
        usage_note: str | None = None,
        reasoning: str | None = None,
        reasoning_note: str | None = None,
        subagent_id: str | None = None,
        structure: event_builder.Structure | None = None,
        response_id: Any = event_builder.ABSENT,
        response_note: str | None = None,
    ) -> dict[str, Any]:
        """One assistant message, with the reasoning the harness received for it.

        No reasoning is a recorded omission, never an empty string, and the
        caller says why when it knows (``reasoning_note``): a harness that
        received a thinking block without its text is a different hole from
        one whose adapter reads no reasoning at all.  A note beside some
        reasoning is recorded too: part of it arrived without its text.
        """
        omissions = []
        if reasoning is None or reasoning_note:
            omissions.append(
                event_builder.omission(
                    "provider_reasoning",
                    reasoning_note
                    or "The harness does not expose provider-side reasoning to this adapter.",
                )
            )
        if turn_termination == event_builder.UNOBSERVED_TERMINATION:
            # The contract obliges this one, and it is added here rather than at
            # each call site because there are three of them and the one that
            # reaches `not_observed` -- a Codex stream that ends with text and
            # no terminal event, which is what an interrupted run looks like --
            # is the one nobody exercises by hand. Without it the service
            # refuses the event as a contract violation and the turn is lost.
            omissions.append(
                event_builder.omission(
                    "turn_termination",
                    "The stream ended without a terminal event, so how the turn ended was "
                    "never stated. Missing is not 'completed'.",
                )
            )
        if response_id is None:
            omissions.append(
                event_builder.omission(
                    "response_id",
                    response_note or "The harness wrote no response id on this reply's record.",
                )
            )
        if usage is None:
            omissions.append(
                event_builder.omission(
                    "token_usage",
                    usage_note
                    or "The harness reported no token counts for this turn. Missing counts are "
                    "not zero.",
                )
            )
        return self._emit(
            session_id,
            event_type="assistant_message.recorded",
            turn_index=turn_index,
            subagent_id=subagent_id,
            structure=structure,
            payload=event_builder.assistant_message(
                turn_index=turn_index,
                text=text,
                turn_termination=turn_termination,
                usage=usage,
                reasoning=reasoning,
                response_id=response_id,
            ),
            omissions=omissions or None,
        )

    def record_tool_started(
        self,
        session_id: str,
        *,
        turn_index: int,
        tool_call_id: str,
        tool_name: str,
        input: Any = None,
        subagent_id: str | None = None,
        structure: event_builder.Structure | None = None,
        response_id: Any = event_builder.ABSENT,
        response_note: str | None = None,
    ) -> dict[str, Any]:
        """``input`` is the call's input as the harness exposed it, or None when
        it exposed none (vicaria-docs RFC 0039).  Nothing is redacted; a body
        over the inline limit is cut and the cut is recorded."""
        omissions = []
        if input is None:
            omissions.append(
                event_builder.omission(
                    "tool_call_input", "The harness exposed no input for this call."
                )
            )
        else:
            text = event_builder.canonical_text(input)
            kept, dropped = event_builder.cut_body(text)
            if dropped:
                # The contract has no input_truncated_bytes: the cut text
                # travels as the input and the note carries the count.
                input = kept
                omissions.append(
                    event_builder.omission(
                        "tool_call_input",
                        f"{dropped} bytes over the inline limit were cut; nothing else "
                        "was removed.",
                        reason="body_too_large",
                    )
                )
        if response_id is None:
            omissions.append(
                event_builder.omission(
                    "response_id",
                    response_note
                    or "The reply that issued this call was not in the transcript when the hook "
                    "ran.",
                )
            )
        return self._emit(
            session_id,
            event_type="tool.started",
            turn_index=turn_index,
            subagent_id=subagent_id,
            structure=structure,
            payload=event_builder.tool_started(
                tool_call_id=tool_call_id,
                tool_name=tool_name,
                turn_index=turn_index,
                input=input,
                response_id=response_id,
            ),
            omissions=omissions or None,
        )

    def record_tool_finished(
        self,
        session_id: str,
        *,
        turn_index: int,
        tool_call_id: str,
        completion_status: str | None,
        exit_status: int | None = None,
        output: str | None = None,
        subagent_id: str | None = None,
        structure: event_builder.Structure | None = None,
        launched_workflow_run_id: str | None = None,
    ) -> dict[str, Any]:
        """``output`` is the call's output as the harness exposed it, or None
        when it exposed none (RFC 0039); an empty string is a body."""
        omissions = []
        output_truncated_bytes = None
        if output is None:
            omissions.append(
                event_builder.omission(
                    "tool_result", "The harness exposed no output for this call."
                )
            )
        else:
            output, dropped = event_builder.cut_body(output)
            if dropped:
                output_truncated_bytes = dropped
                omissions.append(
                    event_builder.omission(
                        "tool_result",
                        f"{dropped} bytes over the inline limit were cut; nothing else "
                        "was removed.",
                        reason="body_too_large",
                    )
                )
        if exit_status is None:
            omissions.append(
                event_builder.omission(
                    "tool_completion",
                    "The harness exposes a terminal state but not a numeric process exit "
                    "status; exit_status is left unknown rather than invented.",
                )
            )
        return self._emit(
            session_id,
            event_type="tool.finished",
            turn_index=turn_index,
            subagent_id=subagent_id,
            structure=structure,
            payload=event_builder.tool_finished(
                tool_call_id=tool_call_id,
                turn_index=turn_index,
                completion_status=completion_status,
                exit_status=exit_status,
                output=output,
                output_truncated_bytes=output_truncated_bytes,
                launched_workflow_run_id=launched_workflow_run_id,
            ),
            omissions=omissions or None,
        )

    def record_feedback(
        self,
        session_id: str,
        *,
        turn_index: int,
        direction: str,
        comment: str | None = None,
        tool_call_id: str | None = None,
        arrived_late: bool = False,
    ) -> dict[str, Any]:
        """A thumbs up or down on a turn, with the comment as typed (RFC 0039).

        Nothing is redacted: the text travels with its length beside it, and
        None means the person gave no comment, not that one was withheld.
        """
        anchor: dict[str, Any] = {"turn_index": turn_index}
        if tool_call_id is not None:
            anchor["tool_call_id"] = tool_call_id
        return self._emit(
            session_id,
            event_type="feedback.added",
            turn_index=turn_index,
            payload=event_builder.feedback(
                anchor=anchor,
                direction=direction,
                comment_text=comment,
                arrived_late=arrived_late,
            ),
        )

    # --- upload --------------------------------------------------------------

    def flush(
        self,
        session_id: str | None = None,
        *,
        batch: int = CHUNK_EVENTS,
        deadline_s: float | None = None,
    ) -> dict[str, Any]:
        """Offer the queue and settle what the service stored.

        ``deadline_s`` (default :attr:`deadline_s`) bounds how long new
        chunks keep being started; what is left stays queued for the next
        flush, settled per chunk, so nothing is lost by stopping early.

        A ``retry`` receipt means the service already stored these exact
        bytes, so it settles the event like ``stored``; the counts keep the
        two apart. A ``refused`` receipt drops
        it after archiving the event and receipt, and writes the reason to the
        drop log. If the archive cannot be written, only that event stays
        queued: ``archive_failed`` counts it separately from settled refusals,
        and the upload log records the local error. Other receipts and chunks
        still settle normally.

        The upload log is one line per upload, and its counts are that upload's.
        They were the running totals: three chunks that each stored five events
        wrote ``stored: 5``, ``stored: 10``, ``stored: 15``, so a developer
        summing the column to answer "what left my machine" got 30 for 15
        events. The coverage document calls this log the one claim in the design
        a developer can verify for themselves, and it was over-counting in the
        flattering direction.
        """
        if self.store.opted_out():
            # Gate 2, for every caller (the CLI, the hook's own flush, the
            # Codex wrapper's closing one, a stop's): no stop and no upload
            # leaves an opted-out machine, and what is queued waits for
            # `sg capture opt-out --undo`.  Nothing is read, so the two
            # counts of what the queue holds are not counted either.
            return {
                "offered": 0,
                "stored": 0,
                "retry": 0,
                "refused": 0,
                "archive_failed": 0,
                "deferred": False,
                "unreadable": 0,
                "other_credential": 0,
                "opted_out": True,
            }
        # Before offering: a queue file that will not parse is skipped by
        # `pending`, so without this it is never offered, never dropped and
        # never logged --- consented material quietly going nowhere.
        unreadable = self.store.quarantine_unreadable()
        if unreadable:
            self.say(
                f"vicaria capture: {len(unreadable)} queued event(s) could not be read "
                "and were moved aside; see ~/.vicaria/records/drops.jsonl"
            )
        # The clock starts before the revoke pass, once per process: the
        # revoke's budget counts against the deadline, and a second flush in
        # the same process (the hook's, after `stop`) continues the clock
        # rather than starting one of its own.
        if self._clock is None:
            self._clock = time.monotonic()
        started = self._clock
        if deadline_s is None:
            deadline_s = self.deadline_s
        # A stop the service has not heard of yet goes first: the person's
        # decision reaches the service before the material it closes.  One
        # session's flush reads that one session's state, not the directory.
        if session_id is not None:
            self._revoke_pending(session_id)
        else:
            for state in list(self.store.sessions()):
                # A home-wide flush delivers only the stops this credential
                # made: the revoke names its workspace itself, and the
                # state's own org is whichever credential last wrote it (a
                # switch-off under the other rewrites it and keeps the
                # revoke), so the revoke is asked, not the state.
                pending_here = state.get("pending_revoke")
                if isinstance(pending_here, dict) and pending_here.get("org_id") == self.org_id:
                    self._revoke_pending(str(state["session_id"]))

        # One session's flush stays in the credential's scope as well: a
        # device-minted session offered under an organization's token (the
        # environment set in a shell, on a linked machine) would be refused
        # per document and dropped.  It waits for a flush under its own.
        queued = self.store.pending(session_id)
        pending = [event for event in queued if event.get("org_id") == self.org_id]
        others = len(queued) - len(pending)
        if others and not self._others_said:
            # Not silent: what waits for the other credential is counted in
            # the result and named once, so a queue that never drains under
            # this one is a line on the surface, not a mystery in `status`.
            self._others_said = True
            self.say(
                f"vicaria capture: {others} queued event(s) belong to another credential "
                "and wait for a flush under it"
            )
        if not pending:
            return {
                "offered": 0,
                "stored": 0,
                "retry": 0,
                "refused": 0,
                "archive_failed": 0,
                "deferred": False,
                "unreadable": len(unreadable),
                "other_credential": others,
            }

        assert self.api is not None
        stored = retried = refused = archive_failed = 0
        deferred = False
        if self._unreachable:
            # Already found unreachable in this process: the same timeout
            # would buy the same answer.  The queue waits for the next hook,
            # and the upload log says so once, as it would had the offer been
            # made.
            deferred = True
            if not self._skip_logged:
                self._skip_logged = True
                self.store.append_upload_log(
                    {
                        "at": utc_now(),
                        "capture_id": event_builder.stable_id("cap", str(pending[0]["event_id"])),
                        "session_id": session_id or pending[0]["session_id"],
                        "byte_count": 0,
                        "outcome": "unreachable",
                        "detail": (
                            "not offered: the service was unreachable earlier in this process"
                        ),
                    }
                )
                self.say(
                    "vicaria capture: upload deferred (service unreachable); "
                    "content stays queued locally"
                )
            pending = []
        offered = 0
        opted_out = False
        for start, chunk in enumerate(_chunks(pending, batch, CHUNK_BYTES)):
            if self.store.opted_out():
                # Gate 2 before every chunk, not only at the top: an opt-out
                # taken while a long flush runs (a backlog, several chunks)
                # stops the chunks after it, and the rest waits for `--undo`.
                opted_out = deferred = True
                break
            past = deadline_s is not None and time.monotonic() - started >= deadline_s
            if past and (start or self._offered):
                deferred = True
                break
            self._offered = True
            offered += len(chunk)
            byte_count = _wire_bytes(chunk)
            chunk_stored = chunk_retried = chunk_refused = 0
            archive_errors = []
            outcome = self.api.captures(chunk)
            if not outcome.ok:
                deferred = True
                if outcome.reason == "unreachable":
                    self._unreachable = True
                self.store.append_upload_log(
                    {
                        "at": utc_now(),
                        "capture_id": event_builder.stable_id("cap", str(chunk[0]["event_id"])),
                        "session_id": session_id or chunk[0]["session_id"],
                        "byte_count": byte_count,
                        "outcome": outcome.reason or "refused",
                        "detail": outcome.detail,
                    }
                )
                self.say(
                    f"vicaria capture: upload deferred ({outcome.detail}); "
                    "content stays queued locally"
                )
                break
            for event, receipt in zip(chunk, outcome.value["results"], strict=True):
                if receipt["outcome"] == "stored":
                    self.store.settle(str(event["event_id"]))
                    chunk_stored += 1
                elif receipt["outcome"] == "retry":
                    # The service already holds these exact bytes (a lost
                    # response replayed); keeping them queued would replay
                    # them on every flush forever.
                    self.store.settle(str(event["event_id"]))
                    chunk_retried += 1
                else:
                    try:
                        retained = self.store.retain_refusal(event, receipt)
                    except OSError as exc:
                        # Keep the original queued bytes if diagnostics cannot
                        # be saved, without starving unrelated accepted events.
                        deferred = True
                        archive_errors.append({"event_id": event["event_id"], "detail": str(exc)})
                        self.say(
                            f"vicaria capture: could not archive refusal for {event['event_id']} "
                            f"({exc}); event stays queued locally"
                        )
                        continue
                    self.store.drop(
                        str(event["event_id"]),
                        reason="refused_by_service",
                        session_id=str(event["session_id"]),
                        detail=": ".join(
                            str(receipt[key]) for key in ("error", "detail") if receipt.get(key)
                        ),
                        retained_at=str(retained),
                    )
                    chunk_refused += 1
            self.store.append_upload_log(
                {
                    "at": utc_now(),
                    "capture_id": event_builder.stable_id("cap", str(chunk[0]["event_id"])),
                    "session_id": session_id or chunk[0]["session_id"],
                    "byte_count": byte_count,
                    "outcome": "sent",
                    # This upload's counts, not the run's: see the docstring.
                    "stored": chunk_stored,
                    "retry": chunk_retried,
                    "refused": chunk_refused,
                    "archive_failed": len(archive_errors),
                    **({"archive_errors": archive_errors} if archive_errors else {}),
                }
            )
            stored += chunk_stored
            retried += chunk_retried
            refused += chunk_refused
            archive_failed += len(archive_errors)
        result = {
            "offered": offered,
            "stored": stored,
            "retry": retried,
            "refused": refused,
            "archive_failed": archive_failed,
            "deferred": deferred,
            "unreadable": len(unreadable),
            "other_credential": others,
        }
        if opted_out:
            result["opted_out"] = True
        return result

    # --- stopping ------------------------------------------------------------

    def stop(
        self,
        session_id: str,
        *,
        reason: str = "developer_unmarked",
        gesture: str = "unmark",
        defer_upload: bool = False,
    ) -> dict[str, Any]:
        """Close the interval. Stopping is not erasing, and says so.

        The decision is written to the state first; the stop event is queued
        after it and the service is told after that, through the flush, so a
        collector that dies here leaves the switch off on disk for the next
        process to deliver.  If the stop event's own write fails after the
        flip, it is not queued again: the service's revoke row, which the
        pending revoke keeps asking for, is the record of the stop, and the
        session's event stream ends without a terminal event.

        ``defer_upload`` leaves the persisted revoke and event for delivery
        controlled by the hook. Direct/CLI calls flush immediately by default.

        ``gesture`` is what the service records on the revoke row. The default
        is the per-session unmark; the Claude Code switch passes ``switch_off``
        so a reader of the consent rows can tell the two apart, the way the
        service's own ``standing_account_consent`` gesture tells the grants
        apart. ``reason`` is kept on the session state as well, because a
        session start needs to know whether the closed interval was the
        person's decision (``developer_unmarked``, which stands) or the
        harness's (``session_ended``, which a resume reopens).
        """
        with self.store.session_lock():
            state = self.store.session(session_id)
            if state is None or not state.get("active"):
                return {"stopped": False, "reason": "not_marked"}

            # Explicit None test: turn 0 is falsy, so `or 0` would close the
            # interval at turn 1 for a session that only ever reached turn 0.
            current = state.get("turn_index")
            turn_index = (
                (current + 1) if isinstance(current, int) and not isinstance(current, bool) else 0
            )
            # The decision first, on disk, before anything that can fail: the
            # stop event needs a sequence number and the revoke needs the
            # network, and a stop that died in either used to leave the
            # session active --- the switch thrown and nothing switched.  The
            # revoke body is kept on the state until the service has it, so a
            # later flush can deliver it.
            state["active"] = False
            state["stopped_at"] = utc_now()
            state["stop_reason"] = reason
            state["pending_revoke"] = {
                "state": "revoked",
                # The workspace the interval was minted in, which is what the
                # revoke names, not the credential this process happens to
                # hold.
                "org_id": str(state.get("org_id") or self.org_id),
                "turn_index": turn_index,
                "authorized_interval_id": state["authorization"]["authorized_interval_id"],
                "gesture": gesture,
            }
            self.store.save_session(state)

        self._emit(
            session_id,
            event_type="collection.stopped",
            turn_index=None,
            payload=event_builder.collection_stopped(
                reason=reason,
                # No adapter here has wired a client-side erasure
                # request, so this is never true. Erasure is a separate
                # typed request against the service.
                erasure_invoked=False,
            ),
        )
        # Hooks persist the stop before their separately bounded delivery.
        # CLI callers keep the immediate revoke/flush and its receipt.
        if defer_upload:
            return {"stopped": True, "service_acknowledged": False, "deferred": True}
        # The flush delivers the revoke first, then the queue: one place, one
        # attempt per process.
        flushed = self.flush(session_id)
        outcome = self._revoked.get(session_id)
        detail = outcome.detail if outcome else ""
        if outcome is None:
            kept = (self.store.session(session_id) or {}).get("pending_revoke")
            if isinstance(kept, dict) and kept.get("org_id") != self.org_id:
                detail = f"stop kept for a flush under {kept.get('org_id')}"
        self.say("vicaria capture: stopped; material already sent was not erased")
        return {
            "stopped": True,
            "service_acknowledged": bool(outcome and outcome.ok),
            "detail": detail,
            "flush": flushed,
        }

    def _revoke_pending(self, session_id: str) -> Outcome | None:
        """Tell the service about a stop it has not acknowledged, if any.

        ``None`` when nothing is pending.  A definite refusal (a 4xx) clears
        it --- the service has answered and will answer the same again.  An
        unreachable service, a 5xx or a body that is not JSON (a proxy's
        error page) leaves it for the next flush: those are the transient
        failures the pending revoke exists for.  One attempt per process:
        `stop`, the flush inside it and the hook's own flush share the answer.
        """
        if self.store.opted_out():
            # Gate 2 here too: the home-wide flush's revoke pass runs one stop
            # after another, and an opt-out taken during it keeps the rest.
            return None
        state = self.store.session(session_id)
        if not state or not isinstance(state.get("pending_revoke"), dict):
            return None
        if state["pending_revoke"].get("org_id") != self.org_id:
            # Another credential's stop: sent under this one it would be a
            # definite refusal (`org_mismatch`) and cleared with the interval
            # still open on the service.  It waits for its own.
            return None
        if session_id in self._revoked:
            return self._revoked[session_id]
        if self._unreachable:
            return None
        assert self.api is not None
        sent = dict(state["pending_revoke"])
        outcome = self.api.revoke(session_id, sent)
        self._revoked[session_id] = outcome
        if outcome.reason == "unreachable":
            self._unreachable = True
        # Definite means the service itself answered: a 4xx that is not a
        # "try again later" (408, 425, 429), with the service's own error
        # shape in the body.  A proxy's 403 page has the status and not the
        # body; an empty body is not a body; neither is an answer to anything.
        definite = (
            outcome.status is not None
            and 400 <= outcome.status < 500
            and outcome.status not in (408, 425, 429)
            and isinstance(outcome.value, dict)
            and isinstance(outcome.value.get("error"), str)
        )
        if outcome.ok or (outcome.reason == "refused" and definite):
            with self.store.session_lock():
                state = self.store.session(session_id) or state
                # The one that was sent: a stop written meanwhile (a later
                # interval's, by another process) is not the one the service
                # answered and stays for its own delivery.
                if state.get("pending_revoke") == sent:
                    state.pop("pending_revoke", None)
                self.store.save_session(state)
        return outcome

    def note_session_ended_opted_out(self, session_id: str) -> dict[str, Any] | None:
        """Record a session's end on an opted-out machine, on disk alone.

        The machine opt-out closes every gate, the session end's included, so
        a session on when the opt-out was taken stayed on on disk, and
        ``sg capture opt-out --undo`` found it collecting after the harness
        had ended it.  Its end is written as a closed interval leaves it
        (``session_ended``, which a resume on a linked device reopens); no
        stop is kept, and the service is told nothing, now or later.  A
        session that is not on is left as it is, and the state is read before
        the lock, so an unmarked session's end creates no file, the lock's
        included.
        """
        state = self.store.session(session_id)
        if state is None or not state.get("active"):
            return state
        with self.store.session_lock():
            state = self.store.session(session_id)
            if state is None or not state.get("active"):
                return state
            # `unmark`, the gesture of a session end's stop: kept only if the
            # opt-out was undone a moment ago, when the stop is owed after all.
            return self._switch_off_locked(
                session_id, rescope=False, reason="session_ended", gesture="unmark"
            )

    def switch_off_before_mint(self, session_id: str, *, rescope: bool = True) -> dict[str, Any]:
        """Record ``/vicaria off`` on disk, sending nothing.

        On a linked machine the next prompt would mint an interval; the
        person said not to, so their decision is written where the mint looks
        first, in the same shape a closed interval leaves
        (``developer_unmarked``, which stands until ``/vicaria on``).  Nothing
        is sent.  An interval found open under the lock (another process's
        mint saved a moment ago) keeps a stop for the service, unless the
        machine is opted out; and an opted-out machine calls this on an active
        session too, to switch it off without telling anyone.  ``rescope``
        writes this credential's workspace and server onto the state: the
        device path's `/vicaria off` on a state a start or a resume would
        mint over (none, an ended or an unreachable one, and the one a
        `SessionEnd` racing the off just ended), which becomes this link's
        decision.  ``rescope=False`` keeps the state's own: an opted-out
        switch-off of an active state, `sg capture off`, the already-off
        branch (and a `/vicaria off` that found a switch-off from elsewhere
        racing it) and an opted-out session's end, so a session stays the
        credential's that minted it.
        """
        assert self.api is not None
        # What a readable previous state carried (a session start already
        # recorded, the last event) is kept for the interval `/vicaria on`
        # opens later; an unreadable file is replaced by this readable off.
        with self.store.session_lock():
            return self._switch_off_locked(session_id, rescope=rescope)

    def _switch_off_locked(
        self,
        session_id: str,
        *,
        rescope: bool = True,
        reason: str = "developer_unmarked",
        gesture: str = "switch_off",
    ) -> dict[str, Any]:
        assert self.api is not None
        previous = self.store.session(session_id) or {}
        interval = (previous.get("authorization") or {}).get("authorized_interval_id")
        # An opted-out machine tells the service nothing, now or later: it
        # keeps no stop to deliver after `--undo`.
        opened = (
            bool(previous.get("active"))
            and bool(interval)
            and not isinstance(previous.get("pending_revoke"), dict)
            and not self.store.opted_out()
        )
        state = {
            **previous,
            "session_id": session_id,
            "org_id": self.org_id if rescope else previous.get("org_id") or self.org_id,
            "server": self.api.server if rescope else previous.get("server") or self.api.server,
            "harness": self.adapter.harness,
            "active": False,
            # A session that had an authority keeps it: an organization's
            # session switched off here stays the organization's, and an
            # unlink must not count it as the link's.  Every state this
            # package writes names one, so a state kept as it was
            # (``rescope=False``) that names none is `main`'s per-session
            # confirm's, not the link's.
            "authority": previous.get("authority")
            or (STANDING_CONSENT if rescope or not previous else SESSION_CONFIRM),
            "stop_reason": reason,
            "stopped_at": utc_now(),
        }
        state.pop("attempted_at", None)
        if opened:
            # An interval opened between the caller's read and this lock (a
            # resume's mint, saved a moment ago): switched off here, it keeps
            # a stop for the service, as `stop` would write, rather than
            # staying open there with no local record of it.
            current = previous.get("turn_index")
            state["pending_revoke"] = {
                "state": "revoked",
                "org_id": str(previous.get("org_id") or self.org_id),
                "turn_index": (
                    current + 1 if isinstance(current, int) and not isinstance(current, bool) else 0
                ),
                "authorized_interval_id": interval,
                "gesture": gesture,
            }
        self.store.save_session(state)
        return state

    def note_unreachable(self, session_id: str, previous: dict[str, Any] | None) -> dict[str, Any]:
        """Record that the standing mint could not reach the service.

        Without this every prompt of the session retried, and each retry cost
        the whole hook budget while the laptop was offline.  The record is
        the state a closed interval leaves, with ``service_unreachable`` as
        the reason and the time of the attempt, so the mint can be tried
        again after a while rather than on every keystroke.  What the
        previous state carried (a session start already recorded, the last
        event) is kept for the interval a later mint opens.  A switch-off
        typed meanwhile, and an interval another process's mint opened
        meanwhile, are left as they are.
        """
        assert self.api is not None
        # The state on disk first: a revoke delivered a moment ago popped
        # `pending_revoke` there, and the copy the caller read before it
        # would put it back.
        with self.store.session_lock():
            current = self.store.session(session_id)
            if current is not None and current.get("stop_reason") == "developer_unmarked":
                # Switched off while the mint was in flight: the person's
                # decision stands over the service's silence, and a later
                # start does not retry, so there is nothing to write.
                return current
            if current is not None and current.get("active"):
                # Another process's mint reached the service meanwhile and
                # saved an open interval (this one saves nothing before its
                # request): an off state over it would leave that interval
                # open on the service with nothing on disk to stop it.
                return current
            base = current if current is not None else (previous or {})
            state = {
                **base,
                "session_id": session_id,
                "org_id": self.org_id,
                "server": self.api.server,
                "harness": self.adapter.harness,
                "active": False,
                # An organization's session that could not be re-minted
                # stays the organization's.
                "authority": base.get("authority") or STANDING_CONSENT,
                "stop_reason": "service_unreachable",
                "attempted_at": utc_now(),
            }
            # This try did not reach the service, so no refusal stands for
            # it; the status must not read an earlier one's stamp as this
            # try's (the two instants can be one millisecond).
            state.pop("refused_at", None)
            self.store.save_session(state)
        return state

    def note_refused(self, session_id: str) -> dict[str, Any] | None:
        """Record that a retry of an unreachable mint reached the service,
        which refused it.

        The retry is paced from ``attempted_at``; a refusal writes no state,
        so without this the unreachable record kept its old stamp and every
        later prompt tried again at once, and ``/vicaria:status`` kept saying
        the service could not be reached.  Both stamps are the same instant;
        a later unreachable attempt removes ``refused_at`` (``note_unreachable``),
        so it is told apart even when it falls in the refusal's millisecond.
        Written over whatever is there under the lock: both fields are read
        only on an unreachable record, so on a state another process changed
        meanwhile (an interval it opened, a switch-off) they change nothing.
        A session with no state is left with none.
        """
        with self.store.session_lock():
            current = self.store.session(session_id)
            if current is None:
                return None
            now = utc_now()
            state = {**current, "attempted_at": now, "refused_at": now}
            self.store.save_session(state)
        return state

    # --- reporting -----------------------------------------------------------

    def status(self, session_id: str | None = None) -> dict[str, Any]:
        """What this machine holds, for a developer who wants to look."""
        sessions = [
            state
            for state in self.store.sessions()
            if session_id is None or state.get("session_id") == session_id
        ]
        device = self.store.device()
        return {
            "home": str(self.store.home),
            "opted_out": self.store.opted_out(),
            "harness": self.adapter.harness,
            "notice_version": self.notice.version,
            # Read from the file, like everything else here. `linked` is
            # whether this machine holds a link; whether the service agrees
            # is a heartbeat, which `sg capture link` sent and the website
            # shows. The token itself is not reported.
            "device": {
                "linked": device is not None,
                "server": device.get("server") if device else None,
                "name": device.get("name") if device else None,
                "device_id": device.get("device_id") if device else None,
                "linked_at": device.get("linked_at") if device else None,
            },
            "sessions": [
                {
                    "session_id": state.get("session_id"),
                    "active": bool(state.get("active")),
                    "authority": state.get("authority"),
                    "turn_index": state.get("turn_index"),
                    "marked_at": state.get("marked_at"),
                    "stopped_at": state.get("stopped_at"),
                    "stop_reason": state.get("stop_reason"),
                }
                for state in sessions
            ],
            "pending_events": len(self.store.pending(session_id)),
            "uploads_logged": len(self.store.upload_log()),
            "drops_logged": len(self.store.drop_log()),
        }

    def status_line(self, session_id: str | None = None) -> str:
        """:meth:`status` as the one line a harness surface can show."""
        status = self.status(session_id)
        parts: list[str] = []
        if status["opted_out"]:
            parts.append("opted out on this machine")
        if session_id is not None:
            found = [row for row in status["sessions"] if row["session_id"] == session_id]
            if not found:
                parts.append("not collecting this session (never marked)")
            elif found[0]["active"]:
                authority = found[0]["authority"] or SESSION_CONFIRM
                if status["opted_out"]:
                    # An interval is held (a session on when the opt-out was
                    # taken, or one an overtaken mint left saved), and
                    # nothing is collected under it until the opt-out is
                    # undone.
                    parts.append(
                        f"this session's interval ({authority.replace('_', ' ')}) is held "
                        "and nothing is collected until `sg capture opt-out --undo`"
                    )
                else:
                    parts.append(
                        f"collecting this session (turn {found[0]['turn_index']}, "
                        f"{authority.replace('_', ' ')})"
                    )
            else:
                parts.append(f"off for this session ({found[0]['stop_reason'] or 'stopped'})")
        device = status["device"]
        if device["linked"]:
            parts.append(
                f"device linked as {device['name'] or device['device_id']} · {device['server']}"
            )
        else:
            parts.append("no device link on this machine")
        parts.append(
            f"{status['pending_events']} queued · {status['uploads_logged']} uploads logged · "
            f"{status['drops_logged']} drops logged"
        )
        return "vicaria capture: " + " · ".join(parts)


def _authorization_from(
    value: Any, *, notice: Notice, standing: bool = False
) -> dict[str, Any] | None:
    """The consent block every event carries, copied from the service's grant.

    Copied, not composed.  The server holds the authorization and verifies every
    event against the grant it recorded — including the subject block and the
    exact interval instant — so a client that assembled this from its own
    request would be asserting an authorization rather than carrying one, and
    every event it produced would be refused with
    ``event_authorization_descriptor_mismatch``.  Which is exactly what happened
    the first time this was written the other way round.

    ``notice`` is not used to fill anything in.  It is here to *check* that the
    grant the server issued names the notice this adapter actually displayed: a
    grant for different bytes is not a grant for what the developer read.

    ``standing`` is the one case where that check does not apply, because the
    premise does not hold: a grant minted from the account's standing consent
    names the notice the person read *on the website*, and this adapter never
    displayed anything.  The digest is then accepted as the server's --- it is
    the server's consent row, not a claim this client can check against bytes
    it does not have --- while every key the contract requires stays required
    and the digest still has to be one (``sha256:`` and 64 hex digits), since
    an event carrying anything else is refused after it is already queued.
    """
    if not isinstance(value, dict):
        return None
    grant = value.get("authorization") if isinstance(value.get("authorization"), dict) else value

    required = (
        "authorization_id",
        "authorized_interval_id",
        "scope",
        "notice_version",
        "notice_digest",
        "first_consented_turn",
        "interval_start",
        "subject",
    )
    if any(key not in grant for key in required):
        return None
    if not isinstance(grant.get("subject"), dict):
        return None
    if not isinstance(grant.get("first_consented_turn"), int) or isinstance(
        grant.get("first_consented_turn"), bool
    ):
        return None
    if standing:
        digest = grant.get("notice_digest")
        version = grant.get("notice_version")
        if not isinstance(digest, str) or not _DIGEST.match(digest):
            return None
        if not isinstance(version, str) or not version:
            return None
    elif grant.get("notice_digest") != notice.digest:
        # The server granted against a different notice than the one shown.
        # Nothing here can reconcile that, and carrying on would bind events to
        # text the developer never saw.
        return None

    return {
        "authorization_id": grant["authorization_id"],
        "authorized_interval_id": grant["authorized_interval_id"],
        "scope": grant["scope"],
        "notice_version": grant["notice_version"],
        "notice_digest": grant["notice_digest"],
        "policy_pin": grant.get("policy_pin"),
        "first_consented_turn": grant["first_consented_turn"],
        "interval_start": grant["interval_start"],
        "interval_end": grant.get("interval_end"),
        "subject": grant["subject"],
    }


def collector_for(
    harness: str,
    *,
    org_id: str,
    server: str,
    token: str,
    home: Path | str | None = None,
    harness_version: str = "unknown",
    adapter_version: str = "0.1.11",
    surface: Any = None,
    api: CaptureApi | None = None,
    timeout_s: float | None = None,
    deadline_s: float | None = None,
) -> CaptureCollector:
    """A collector for one harness, with the ids that harness publishes.

    ``timeout_s`` is the per-request budget and ``deadline_s`` how long a
    flush keeps starting chunks; a hook sets both from its own event's time
    limit so two round trips, or a backlog, fit inside one hook.
    """
    store = CaptureStore(home)
    if api is None and timeout_s is not None:
        api = CaptureApi(server, token, timeout_s=timeout_s)
    return CaptureCollector(
        org_id=org_id,
        server=server,
        token=token,
        adapter=Adapter(
            harness=harness,
            harness_version=harness_version,
            adapter_id=f"adapter_{harness.replace('-', '_')}",
            adapter_version=adapter_version,
        ),
        store=store,
        api=api,
        surface=surface,
        deadline_s=deadline_s,
    )
