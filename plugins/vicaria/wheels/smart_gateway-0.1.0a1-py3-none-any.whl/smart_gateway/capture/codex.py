"""Codex capture: wrapping ``codex exec --json`` and reading its event stream.

Codex has no plugin that can hold a collector and no hook that runs on every
turn, so the integration is a wrapper: it runs ``codex exec --json``, passes the
output through untouched, and maps the stream's events to capture events as they
go past.  A developer sees exactly what ``codex exec`` prints.

Why the consent gate looks different here, and why it is not weaker
-------------------------------------------------------------------
``codex exec`` is non-interactive.  There is no turn at which a notice can be
shown and a gesture read back, and inventing one — a prompt on stderr, a "press
y" — would be a consent flow that a script running in CI answers by accident.

So the mark is taken *out of band*, before the run: ``sg capture confirm`` in a
terminal, where a person reads the notice and confirms, recording a receipt and
opening an interval for that working directory.  This wrapper then refuses to
capture unless that interval is already open.  The gate is the same four; only
the place the fourth one is satisfied has moved, and the notice for Codex says
so in its own words.  The coverage document records the recording indicator as
``at_mark_only`` rather than claiming parity with a harness that can show a
marker every turn.

The stream
----------
``thread.started`` opens, ``turn.started``/``turn.completed``/``turn.failed``
bracket a turn and carry the authoritative per-turn token usage, and
``item.completed`` carries the work: ``agent_message``, ``reasoning``,
``command_execution``, ``file_change``, ``mcp_tool_call``, ``web_search``.  A
top-level ``error`` is fatal for the stream --- for the *stream*, and so it ends
the turn in progress and never opens one of its own.  An error arriving after a
turn has closed cleanly is the stream dying between turns, and recording a turn
for it would put a model turn with no prompt, no text and no token counts into
the bundle, which a reader downstream would take for an exchange that happened.

**The bracket is the turn boundary, and it is the only one there is.**  This
adapter ignored ``turn.started`` and advanced the turn only in
:meth:`CodexCapture.record_prompt`, so every turn of a multi-turn stream landed
on one index --- two answers, and every tool call of both, recorded as a single
exchange.  That is not cosmetic: the bundle then reads one model turn where
there were two, every probe downstream becomes a first turn, and a ``later_*``
stratum reports ``no_observations``, which reads as "these sessions had no later
turns" when the turns were merged.  The boundary is honoured in both directions
now --- an opening bracket starts a turn, a closing one ends it, and work that
arrives outside a bracket at all opens one --- so a stream from a Codex that
emits no ``turn.started`` still separates its turns on the closing bracket
alone.

Two things this wrapper does not do.  It does not read the persisted rollout
under ``~/.codex/sessions``: the rollout carries more (sub-agent activity, raw
reasoning), and collecting from a second source the notice does not describe
would be collecting beyond what was authorized.  And it does not parse a
command's exit code out of the item's aggregated output, because it is not
capturing that output — a number recovered from text you are not collecting is
an invented number.  The exit code it records is the item's own ``exit_code``
field, and the failure is the item's own ``status``.

Item ids restart at ``item_0`` in every ``codex exec`` run, and one capture
session spans many runs, so a tool call's native identity is the item id
qualified by the run's ``thread_id``.  A bare item id would name two different
calls in two turns, which the service cannot tell apart from one call that
crossed a turn.
"""

from __future__ import annotations

import json
import subprocess
from collections.abc import Iterable, Iterator
from typing import Any

from smart_gateway.capture import events as event_builder
from smart_gateway.capture.collector import CaptureCollector, CaptureRefused

#: ``item.completed`` types this adapter records as tool activity, under the
#: name of the tool the model called (Codex offers ``exec_command`` and
#: ``apply_patch``; the stream reports their items as ``command_execution`` and
#: ``file_change``). An item type outside this set is ignored rather than
#: recorded under a guessed name.
TOOL_ITEMS = {
    "command_execution": "exec_command",
    "file_change": "apply_patch",
    "mcp_tool_call": "mcp",
    "web_search": "web_search",
}

#: Item statuses that say the call did not succeed. An item with no status
#: completed as an item; that is all it says, and it is recorded as completed.
FAILED_ITEM_STATUSES = ("failed", "declined")

#: The fields of each item that are the call's input, in the stream's own
#: names (vicaria-docs RFC 0039).  Recorded as the stream carries them.
TOOL_INPUT_FIELDS = {
    "command_execution": ("command",),
    "file_change": ("changes",),
    "mcp_tool_call": ("server", "tool", "arguments"),
    "web_search": ("query",),
}


def _tool_input(item: dict[str, Any]) -> dict[str, Any] | None:
    """The item's own input fields, or None when it carries none of them."""
    fields = {
        key: item[key]
        for key in TOOL_INPUT_FIELDS.get(str(item.get("type")), ())
        if item.get(key) is not None
    }
    return fields or None


def _tool_output(item: dict[str, Any]) -> str | None:
    """A command's aggregated output as Codex cut it; an MCP call's result, or
    its error, as canonical text.  A file change and a web search carry no
    output in the stream, so theirs is None and the finish says so."""
    kind = item.get("type")
    if kind == "command_execution":
        output = item.get("aggregated_output")
        return output if isinstance(output, str) else None
    if kind == "mcp_tool_call":
        for key in ("result", "error"):
            if item.get(key) is not None:
                return event_builder.canonical_text(item[key])
    return None


def stream_events(lines: Iterable[str]) -> Iterator[dict[str, Any]]:
    """Parse the JSONL stream, skipping anything that is not a JSON object.

    ``codex exec`` writes other things to stdout in some configurations, and a
    line that does not parse is not an event; dropping it is correct, and
    failing the whole capture over it would lose the turn that did parse.
    """
    for line in lines:
        line = line.strip()
        if not line or not line.startswith("{"):
            continue
        try:
            document = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(document, dict) and isinstance(document.get("type"), str):
            yield document


def _completion(item: dict[str, Any]) -> str:
    """``error`` for an item Codex reports failed or declined, else ``completed``."""
    return "error" if item.get("status") in FAILED_ITEM_STATUSES else "completed"


def _exit_code(item: dict[str, Any]) -> int | None:
    """A command item's own ``exit_code`` field; nothing is read from its output."""
    code = item.get("exit_code")
    if item.get("type") != "command_execution" or isinstance(code, bool):
        return None
    return code if isinstance(code, int) else None


def _usage(turn_event: dict[str, Any]) -> dict[str, Any] | None:
    """Per-turn token usage, or None when Codex reported none.

    Only ``input_tokens`` and ``output_tokens`` are carried, because those are
    the only two ``cb.session_event.v2`` defines.  Codex also reports
    ``cached_input_tokens``, and it is dropped rather than folded into the input
    count: adding it would overstate the input, and inventing a field the
    contract does not define would be refused at the service. The coverage
    document records that the breakdown is not representable, so the loss is
    stated somewhere a consumer reads.
    """
    usage = turn_event.get("usage")
    if not isinstance(usage, dict):
        return None
    counted = {
        key: usage[key]
        for key in ("input_tokens", "output_tokens")
        if isinstance(usage.get(key), int) and not isinstance(usage.get(key), bool)
    }
    return counted or None


class CodexCapture:
    """Maps one ``codex exec --json`` stream onto a marked session."""

    def __init__(
        self, collector: CaptureCollector, session_id: str, *, sampled: bool = True
    ) -> None:
        self.collector = collector
        self.session_id = session_id
        open_gate, refusal = collector.gates(sampled=sampled, session_id=session_id)
        if refusal == "opted_out_on_this_machine":
            raise CaptureRefused(
                refusal,
                "this machine is opted out: nothing is captured until `sg capture opt-out --undo`",
            )
        if refusal == "not_sampled":
            raise CaptureRefused(
                refusal,
                "capture is not offered for this session: set VICARIA_CAPTURE_SAMPLE=on or "
                "run `sg capture --sampled codex ...`",
            )
        if not open_gate:
            raise CaptureRefused(
                refusal or "not_marked",
                "codex exec cannot show a notice mid-run, so capture needs an interval "
                "opened beforehand: run 'sg capture confirm --harness codex --session "
                f"{session_id}' and try again",
            )
        stored = (collector.store.session(session_id) or {}).get("turn_index")
        # Explicit None test for the same reason as the Claude Code adapter:
        # turn 0 is falsy and `or -1` would restart every run at turn 0.
        self.turn = stored if isinstance(stored, int) and not isinstance(stored, bool) else -1
        self._recorded_reasoning = False
        #: The run's thread, which qualifies its item ids; see the module notes.
        self._thread: str | None = None
        #: Whether a turn is currently being accumulated. A stream brackets its
        #: turns, and the bracket is the only thing that says where one ends and
        #: the next begins; see :meth:`_open_turn`.
        self._turn_open = False
        self._pending_text: list[str] = []
        #: Set when the session was switched off (another terminal's `sg
        #: capture off`), or the machine opted out, while the stream was
        #: being recorded: what came after is not recorded, and the run is
        #: not failed for it.
        self.switched_off = False

    def _advance_turn(self) -> None:
        """Move to the next turn, and write the number down.

        The collector already persists `turn_index` on every event it emits, so
        for a turn that records anything this is redundant. It is here for the
        turn that records nothing --- a bracket that opened and then the stream
        ended, or a turn whose only item was a `reasoning` summary, which is
        held rather than recorded. Without it the session file would still name
        the previous turn, and `CaptureCollector.stop` reads exactly that number
        to decide which turn the interval closes after.
        """
        self.turn += 1
        with self.collector.store.session_lock():
            state = self.collector.store.session(self.session_id)
            if state is not None:
                state["turn_index"] = self.turn
                self.collector.store.save_session(state)

    def record_prompt(self, prompt: str, *, prompt_id: str | None = None) -> None:
        """The request, which the wrapper holds because it passed it to Codex.

        ``prompt_id`` is the id the run's plan request was journaled under, when
        one was asked for; the captured prompt's event id is derived from it, so
        the service can join the turn to its decision.
        """
        self._advance_turn()
        self.collector.record_user_message(
            self.session_id, turn_index=self.turn, text=prompt, prompt_id=prompt_id
        )
        # The turn this prompt opened is the one the stream's first bracket
        # belongs to, so that bracket must not advance past it.
        self._turn_open = True

    def _open_turn(self, counts: dict[str, int]) -> None:
        """Make sure work arriving now is attributed to a turn of its own.

        A stream brackets its turns --- ``turn.started`` before the work,
        ``turn.completed`` or ``turn.failed`` after it --- and the bracket is
        the only thing in the stream that says where one turn ends and the next
        begins. This adapter ignored ``turn.started`` entirely and advanced the
        turn only in :meth:`record_prompt`, so every turn of a multi-turn run
        landed on one index: two answers, and every tool call of both, recorded
        as a single exchange. Downstream that is not a cosmetic error --- the
        bundle reads one model turn where there were two, every probe becomes a
        first turn, and a `later_*` stratum then reports `no_observations`,
        which reads as "these sessions had no later turns" when in fact the
        turns were merged.

        The flush below is a guard on an invariant, not a live path, and saying
        so is the point: text accumulates only while a turn is open, and every
        route that closes a turn clears the text with it, so there is today no
        stream that reaches this line with anything pending --- an exhaustive
        sweep of the event vocabulary confirms it, and
        ``test_no_stream_shape_strands_text_on_the_wrong_turn`` pins it. It
        stays because if that invariant ever breaks, text produced in one turn
        would otherwise be recorded against the next one, and silently
        reattributing a developer's material is worse than one dead call.
        """
        if self._turn_open:
            return
        self._close_unobserved(counts)
        self._advance_turn()
        self._turn_open = True

    def _close_unobserved(self, counts: dict[str, int]) -> None:
        """Record text whose turn never reported how it ended.

        Not a blank and not a `completed`: something was produced and nobody
        said how it finished, which is what `not_observed` means. The contract
        obliges a matching omission beside it and the collector adds one.
        """
        if not self._pending_text:
            return
        self.collector.record_assistant_message(
            self.session_id,
            turn_index=max(self.turn, 0),
            text="\n".join(self._pending_text),
            turn_termination="not_observed",
            usage=None,
            reasoning_available=self._recorded_reasoning,
        )
        counts["messages"] += 1
        self._pending_text = []
        self._recorded_reasoning = False

    def _close_turn(
        self, counts: dict[str, int], *, termination: str, usage: dict[str, Any] | None
    ) -> None:
        self.collector.record_assistant_message(
            self.session_id,
            turn_index=max(self.turn, 0),
            text="\n".join(self._pending_text) if self._pending_text else None,
            turn_termination=termination,
            usage=usage,
            reasoning_available=self._recorded_reasoning,
        )
        counts["messages"] += 1
        self._pending_text = []
        self._recorded_reasoning = False
        self._turn_open = False

    def consume(self, events: Iterable[dict[str, Any]]) -> dict[str, int]:
        """Record every event of one run. Returns a small count for the caller.

        A switch-off from another terminal mid-stream, or the machine
        opt-out taken during the run, ends the recording, not the run: the
        counts so far come back and ``switched_off`` says why they stop
        there (the closing flush says ``opted_out`` for the second)."""
        counts = {"items": 0, "messages": 0, "tools": 0, "turns": 0}
        try:
            self._consume(events, counts)
        except CaptureRefused as refusal:
            if refusal.reason not in ("not_marked", "opted_out_on_this_machine"):
                raise
            self.switched_off = True
        return counts

    def _consume(self, events: Iterable[dict[str, Any]], counts: dict[str, int]) -> None:
        for event in events:
            kind = event.get("type")
            if kind == "thread.started":
                thread = event.get("thread_id")
                self._thread = thread if isinstance(thread, str) and thread else None
            elif kind == "turn.started":
                self._open_turn(counts)
            elif kind == "item.completed":
                item = event.get("item")
                if not isinstance(item, dict):
                    continue
                # Work arriving outside a bracket still belongs to a turn. An
                # older `codex exec` that emits no `turn.started` therefore
                # still separates its turns, on the closing bracket alone.
                self._open_turn(counts)
                counts["items"] += 1
                item_type = item.get("type")
                if item_type == "agent_message":
                    text = item.get("text")
                    if isinstance(text, str) and text:
                        self._pending_text.append(text)
                elif item_type == "reasoning":
                    # Recorded as availability, never as content: the summary is
                    # a summary and the chain of thought stays encrypted.
                    self._recorded_reasoning = True
                elif item_type in TOOL_ITEMS:
                    call_id = str(item.get("id") or f"item_{counts['items']}")
                    if self._thread is not None:
                        call_id = f"{self._thread}:{call_id}"
                    self.collector.record_tool_started(
                        self.session_id,
                        turn_index=max(self.turn, 0),
                        tool_call_id=call_id,
                        tool_name=TOOL_ITEMS[item_type],
                        input=_tool_input(item),
                    )
                    self.collector.record_tool_finished(
                        self.session_id,
                        turn_index=max(self.turn, 0),
                        tool_call_id=call_id,
                        completion_status=_completion(item),
                        exit_status=_exit_code(item),
                        output=_tool_output(item),
                    )
                    counts["tools"] += 1
            elif kind in ("turn.completed", "turn.failed"):
                # These do open a turn when none is in progress, unlike the
                # stream-level error above: a turn bracket carries that turn's
                # authoritative token usage, so it is evidence a turn ran. The
                # alternative -- folding a second turn's usage into the first
                # turn's message -- would overstate the first.
                self._open_turn(counts)
                self._close_turn(
                    counts,
                    termination="completed" if kind == "turn.completed" else "error",
                    usage=_usage(event),
                )
                # Counted once written: a switch-off inside `_close_turn`
                # ends the recording before this turn's message is queued.
                counts["turns"] += 1
            elif kind == "error" and self._turn_open:
                # A fatal stream error ends the turn *in progress*. The assistant
                # text seen so far is still what the model produced and is
                # recorded, with the termination saying the turn errored.
                #
                # It does not open one. A top-level error is fatal for the
                # stream, not a turn of its own, and calling _open_turn here
                # meant that an error arriving after a turn had already closed
                # cleanly manufactured an empty turn: a second model turn with
                # no prompt, no text and no usage, which the bundle downstream
                # would read as an exchange that happened. Nothing observed is
                # nothing recorded.
                self._close_turn(counts, termination="error", usage=None)
        # The stream ended with a bracket still open, or with text and no
        # terminal event at all --- an interrupted run.
        self._close_unobserved(counts)


def run(
    collector: CaptureCollector,
    session_id: str,
    prompt: str,
    *,
    argv: list[str] | None = None,
    sampled: bool = True,
    echo: Any = None,
    surface: Any = None,
    advise: bool = True,
) -> dict[str, Any]:
    """Run ``codex exec --json`` under an open interval and record the stream.

    The child's stdout is passed through as it arrives, so wrapping Codex does
    not change what the developer sees; the capture happens on the way past.
    With a control configuration, the run's plan is asked for first and what it
    recommends goes to ``surface`` (stderr in the CLI), never into the run.
    """
    capture = CodexCapture(collector, session_id, sampled=sampled)
    advice = None
    if advise:
        from smart_gateway.control import codex as control

        advice = control.advise(session_id, prompt)
        if advice.message and surface is not None:
            surface(advice.message)
    capture.record_prompt(
        prompt, prompt_id=advice.prompt_id if advice and advice.decision_id else None
    )
    # `--` first: `codex exec` reads `review`, `resume`, `fork` and `help` as
    # subcommands and a leading `-` as an option, and the prompt is neither.
    command = argv or ["codex", "exec", "--json", "--", prompt]

    lines: list[str] = []
    process = subprocess.Popen(
        command,
        stdout=subprocess.PIPE,
        stderr=None,
        text=True,
        # codex exec waits on an open non-TTY stdin, so it is closed here.
        stdin=subprocess.DEVNULL,
    )
    assert process.stdout is not None
    for line in process.stdout:
        if echo is not None:
            echo(line.rstrip("\n"))
        lines.append(line)
    code = process.wait()

    counts = capture.consume(stream_events(lines))
    flushed = collector.flush(session_id)
    return {
        "exit_code": code,
        **counts,
        "switched_off": capture.switched_off,
        "decision_id": advice.decision_id if advice else None,
        "flush": flushed,
    }
