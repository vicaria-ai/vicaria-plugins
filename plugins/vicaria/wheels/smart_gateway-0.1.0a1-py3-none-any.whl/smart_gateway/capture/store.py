"""The client home: notice receipts, session state, the queue, and the logs.

Everything here is on the developer's own disk, in files they can read.  That is
not incidental — the design's one verifiable promise to a developer is that they
can count what left their machine by reading a file rather than by trusting a
dashboard on someone else's server, and this module is where that file is
written.

Layout under the client home (``$VICARIA_HOME`` or ``~/.vicaria``)::

    capture/notice-receipts/<digest>.json   a notice was displayed (never sent)
    capture/sessions/<session>.json         the authorization state of a session
    capture/queue/<event_id>.json           one pending event, byte-identical
    capture/refused/<event_id>.json         refused event and full service receipt
    capture/opt-out                         the machine opt-out, if present
    capture/device.json                     this machine's device link, mode 0600
    capture/announce/<sha256>               a link made in that session, not yet announced
    capture/coverage-published/<cov_id>     the coverage identities the service accepted
    capture/backlog.lock                    one automatic uploader, with last attempt time
    records/backlog.jsonl                   bounded worker outcomes (not upload receipts)
    records/uploads.jsonl                   one line per upload attempt
    records/drops.jsonl                     one line per item purged, with reason

Durability, and what "byte-identical" buys
------------------------------------------
A queued event is written once, as the exact bytes that will be sent, and never
rewritten.  A process that dies between enqueue and upload leaves those bytes
behind for a replacement collector to find and send, and the service's receipt
is then checked against the digest the file already carried.  If the bytes could
be regenerated instead, a replay after a restart could differ from the event the
developer authorized in some small way — a re-read clock, a re-serialized number
— and the receipt check would be checking the new bytes against themselves.

Writes go through a temporary file and ``os.replace`` so a reader never sees a
half-written event; a crash leaves either the old state or the new one.
"""

from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
import tempfile
import uuid
from collections.abc import Iterator
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

#: Why an item left the queue without being stored by the service. Closed: an
#: omission has to stay weightable, which means countable *by reason*, not just
#: countable.
#: The reasons this collector actually writes today.  Kept apart from the ones
#: below because a closed vocabulary is only useful if it says which of its
#: names can really appear: a developer reading their drop log to find out what
#: did not leave their machine needs to know which entries are possible, and a
#: list padded with categories nothing emits does not tell them.
DROP_REASONS_EMITTED = (
    "refused_by_service",
    #: A turn the hook could not record.  It was already being written --- by
    #: `hook._record_failure`, straight through `append_drop_log` --- while
    #: being absent from this tuple, because only `drop` validated and that
    #: path does not go through `drop`.  A "closed" set with an unguarded
    #: writer beside it is not closed.
    "hook_failed",
    #: The bytes are on disk and cannot be read back. Not "never happened":
    #: `_write_atomic` makes a torn write impossible, so this means the file was
    #: damaged after it was written, and the developer consented to material
    #: that is now not going anywhere. See `quarantine_unreadable`.
    "unreadable_on_disk",
    #: A session on a linked device that the service would not mint from the
    #: account's standing consent --- nothing stands (never agreed, withdrawn,
    #: the notice changed) or the device itself was refused.  Nothing was
    #: queued and nothing is printed, because a person who has not agreed is
    #: not nagged; the website says what stands.  The line is here so the
    #: developer's own log still says the session was not captured, and why.
    #: Written by `CaptureCollector.mint_from_standing_consent`, once per
    #: session start rather than once per prompt.
    "mint_refused",
    #: The device link was forgotten (`sg capture unlink`, or a link to
    #: another workspace) while this event was still queued and a last flush
    #: could not deliver it, or (`event_id: None`) before the service
    #: acknowledged a session's stop, or while a session the settle left on
    #: was still open (switched off here, the service not told).  Without
    #: the token nothing can send any of these later, so each leaves here
    #: with its reason, rather than sitting on disk forever under neither
    #: log.
    "unlinked",
    #: Reserved, and not a cause: the catch-all for a reason that reached
    #: `append_drop_log` without being one of these names.  It is recorded
    #: rather than refused --- losing a drop record over an unfamiliar label
    #: would be the exact omission this log exists to prevent --- and the
    #: original text travels in `detail`.  `drop` still raises on an unknown
    #: reason, because there the reason is a literal at a call site and a raise
    #: catches the typo while someone is looking at it.
    "unclassified",
)

#: Named, but nothing writes them yet.  Each belongs to a path this collector
#: has not built: path and repository exclusions, client-side erasure, a queue
#: bound, an operator purge.  They are kept rather than deleted so the vocabulary
#: says what the design intends, and the test beside them fails the day one
#: starts being emitted without moving up --- which is the day the distinction
#: would otherwise quietly stop being true.
DROP_REASONS_RESERVED = (
    "excluded_path",
    "excluded_repository",
    "session_erased",
    "queue_limit",
    "operator_purge",
)

#: Not a drop, and not about the queue at all: a line of one of these logs
#: could not itself be read back.  It shares the `reason` field because it
#: appears in the same lines a developer reads, and it is declared because
#: anything that can appear there has to be: a name in the file that the
#: vocabulary does not list is how `hook_failed` went unnoticed.  It is kept out
#: of `DROP_REASONS` so `drop` cannot be handed it --- nothing left the queue.
LOG_INTEGRITY_REASONS = ("unreadable_log_line",)

#: What `drop` accepts.  Closed: an omission has to stay weightable, which
#: means countable *by reason*, not just countable.
DROP_REASONS = DROP_REASONS_EMITTED + DROP_REASONS_RESERVED

#: What a device link has to hold to count as one. The token is the
#: credential, the server is where it is honoured, and the org is the scope
#: every event of a session minted from it carries; a file missing any of the
#: three is read as no link at all (see `CaptureStore.device`).
DEVICE_KEYS_REQUIRED = ("server", "org_id", "device_id", "token")

#: How long a session's question is kept after it was last written (asked or
#: answered).  A week: longer than any terminal session stays open, so a
#: question is never pruned from under a person who can still answer it, and
#: short enough that a machine opening many sessions keeps a handful of files.
QUESTION_KEEP_S = 7 * 24 * 60 * 60


def utc_now() -> str:
    """An RFC 3339 instant in UTC, to milliseconds."""
    return datetime.now(UTC).isoformat(timespec="milliseconds").replace("+00:00", "Z")


def default_home() -> Path:
    return Path(os.environ.get("VICARIA_HOME") or (Path.home() / ".vicaria"))


def _write_atomic(path: Path, payload: str, *, mode: int | None = None) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    # Not a context manager on purpose: the file has to outlive the block so
    # os.replace can move it into place, and closing it early is part of the
    # sequence below rather than something `with` should do at the end.
    handle = tempfile.NamedTemporaryFile(  # noqa: SIM115
        "w", encoding="utf-8", dir=str(path.parent), delete=False
    )
    try:
        if mode is not None:
            # Before the bytes, so a secret is never on disk under a looser
            # mode than the one it will be kept under.
            os.chmod(handle.fileno(), mode)
        handle.write(payload)
        handle.flush()
        os.fsync(handle.fileno())
        handle.close()
        os.replace(handle.name, path)
    except BaseException:
        # The partial file is removed rather than left for a later reader to
        # find: os.replace never ran, so nothing downstream ever named it.
        handle.close()
        Path(handle.name).unlink(missing_ok=True)
        raise


@dataclass(frozen=True)
class NoticeReceipt:
    """Proof that the notice was displayed. It authorizes nothing by itself."""

    session_id: str
    org_id: str
    server: str
    harness: str
    notice_version: str
    notice_digest: str
    shown_at: str

    def to_document(self) -> dict[str, Any]:
        return {
            "session_id": self.session_id,
            "org_id": self.org_id,
            "server": self.server,
            "harness": self.harness,
            "notice_version": self.notice_version,
            "notice_digest": self.notice_digest,
            "shown_at": self.shown_at,
        }

    @classmethod
    def from_document(cls, document: dict[str, Any]) -> NoticeReceipt:
        return cls(
            session_id=str(document["session_id"]),
            org_id=str(document["org_id"]),
            server=str(document["server"]),
            harness=str(document.get("harness", "")),
            notice_version=str(document["notice_version"]),
            notice_digest=str(document["notice_digest"]),
            shown_at=str(document.get("shown_at", "")),
        )

    def key(self) -> str:
        """The receipt's file name: the identity a confirmation must match.

        Session, organization, server and the digest of the exact notice text
        all take part, so a confirmation cannot be satisfied by a receipt from
        a different endpoint or from before the notice was edited.
        """
        import hashlib

        parts = "\u0000".join([self.session_id, self.org_id, self.server, self.notice_digest])
        return hashlib.sha256(parts.encode("utf-8")).hexdigest()


class CaptureStore:
    """Files under one client home. No process-wide state, so two collectors
    for two sessions never see each other's queue by accident."""

    def __init__(self, home: Path | str | None = None) -> None:
        self.home = Path(home) if home is not None else default_home()
        self.capture = self.home / "capture"
        self.records = self.home / "records"

    # --- the machine opt-out -------------------------------------------------

    @property
    def opt_out_path(self) -> Path:
        return self.capture / "opt-out"

    def opted_out(self) -> bool:
        """Gate 2. It beats every setting above it, including an organization's.

        Checked by presence of a file rather than by a value inside one: a
        parse failure on an opt-out must never read as "not opted out".
        """
        return self.opt_out_path.exists()

    def set_opt_out(self, on: bool) -> None:
        if on:
            _write_atomic(self.opt_out_path, f"opted out on this machine at {utc_now()}\n")
        else:
            self.opt_out_path.unlink(missing_ok=True)

    # --- the coverage marker -------------------------------------------------

    @property
    def coverage_dir(self) -> Path:
        return self.capture / "coverage-published"

    def coverage_published(self, coverage_id: str) -> bool:
        """Whether this home already had ``coverage_id`` accepted by the service.

        A coverage document is immutable per identity and the service treats a
        repeat as a retry, so publishing it on every mark or mint is a wasted
        round trip inside a hook's time budget. The marker is written only
        after an accepted publish, and only by a collector that already holds
        a session state, so an unmarked session still creates no file.
        """
        return (self.coverage_dir / coverage_id).is_file()

    def mark_coverage_published(self, coverage_id: str) -> None:
        _write_atomic(self.coverage_dir / coverage_id, utc_now() + "\n")

    # --- the device link -----------------------------------------------------

    @property
    def device_path(self) -> Path:
        return self.capture / "device.json"

    def device(self) -> dict[str, Any] | None:
        """This machine's device link, or None.

        Absence means unlinked, and so does anything that will not read as a
        complete link: a token without a server is not a credential, and a
        file that cannot be parsed is not one either. The same rule as every
        other gate here --- a failure to determine something never reads as on.
        """
        path = self.device_path
        if not path.is_file():
            return None
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        if not isinstance(document, dict):
            return None
        for key in DEVICE_KEYS_REQUIRED:
            if not isinstance(document.get(key), str) or not document[key]:
                return None
        return document

    def save_device(self, document: dict[str, Any]) -> Path:
        """Write the link with the token inside, readable by this user only.

        The mode is set on the temporary file before ``os.replace`` moves it
        into place, so there is no instant at which the token sits on disk
        world-readable. A re-link overwrites: one machine holds one link (the
        CLI settles the previous link's sessions first when the workspace or
        the server differs).
        """
        for key in DEVICE_KEYS_REQUIRED:
            if not isinstance(document.get(key), str) or not document[key]:
                raise ValueError(f"a device link needs a non-empty {key}")
        path = self.device_path
        _write_atomic(path, json.dumps(document, indent=2, sort_keys=True) + "\n", mode=0o600)
        return path

    def forget_device(self) -> bool:
        """Remove the link, and every announcement its making left
        (:meth:`forget_announcements`).  Returns whether there was a link to
        remove."""
        existed = self.device_path.is_file()
        self.device_path.unlink(missing_ok=True)
        self.forget_announcements()
        return existed

    # --- a link just made ------------------------------------------------------
    #
    # `connect.finish` stores the link at whatever hook event it completes on.
    # At a tool or stop event (or a compaction's start) no session is minted,
    # so "connected" is all that is said there.  This marker carries "say what
    # came of it" to the first event of the same session that mints: a session
    # start, which says it anyway, or a prompt, which says it only when the
    # marker is there.
    #
    # One file per terminal session, named by a digest of the session id
    # (``capture/announce/<sha256>``), as the questions are: the link was made
    # in the terminal the person is looking at.  One file for the machine was
    # taken by whichever terminal's prompt came first, so a link finished
    # mid-turn in one terminal was announced in another, and the terminal it
    # was made in said nothing of its own refused mint.  Every marker goes
    # with the link (`forget_device`).

    @property
    def announce_dir(self) -> Path:
        return self.capture / "announce"

    def announce_path(self, session_id: str) -> Path:
        if not isinstance(session_id, str) or not session_id:
            raise ValueError("an announcement belongs to a session: a non-empty session id")
        digest = hashlib.sha256(session_id.encode("utf-8")).hexdigest()
        return self.announce_dir / digest

    def mark_announce_next_mint(self, session_id: str) -> None:
        _write_atomic(self.announce_path(session_id), utc_now() + "\n")

    def take_announce_next_mint(self, session_id: str) -> bool:
        """Whether a link was made in this session and nothing has yet said
        what came of it.  Another session's marker is never taken.

        Taken once.  The claim is a rename of the marker to a name no other
        caller uses, and only then its removal: on macOS APFS, of several
        processes unlinking one file at once, more than one was told it had
        removed it (8 processes: 30 to 40% of rounds in review, 134 of 150 on
        another run), while a rename of one file to distinct names had exactly
        one winner (150 rounds of 150, on both).  A marker already gone when
        this call renames it was another hook's.
        """
        path = self.announce_path(session_id)
        claimed = path.with_name(f"{path.name}.{os.getpid()}.{uuid.uuid4().hex}")
        try:
            os.rename(path, claimed)
        except FileNotFoundError:
            return False
        # The claim is made; a claimed name left behind is never read, and
        # goes with the link.
        with contextlib.suppress(OSError):
            claimed.unlink()
        return True

    def forget_announcements(self) -> int:
        """Every session's marker, and any claimed name left behind.

        Best effort: the link is already gone, and a marker left behind at
        worst has its session say once, under a later link, what came of a
        mint, which is still true.
        """
        try:
            paths = sorted(self.announce_dir.iterdir())
        except OSError:
            return 0
        forgotten = 0
        for path in paths:
            with contextlib.suppress(OSError):
                path.unlink()
                forgotten += 1
        return forgotten

    # --- a connection in progress -------------------------------------------
    #
    # `/vicaria:connect` asked the service for a code and is waiting for the
    # person to approve it in the browser.  The poll token inside is the whole
    # credential for finishing the link, so the file has the link's mode.

    @property
    def connect_path(self) -> Path:
        return self.capture / "connect.json"

    def connect(self) -> dict[str, Any] | None:
        path = self.connect_path
        if not path.is_file():
            return None
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        if not isinstance(document, dict):
            return None
        for key in ("server", "poll_token", "user_code"):
            if not isinstance(document.get(key), str) or not document[key]:
                return None
        return document

    def save_connect(self, document: dict[str, Any]) -> Path:
        for key in ("server", "poll_token", "user_code"):
            if not isinstance(document.get(key), str) or not document[key]:
                raise ValueError(f"a connection in progress needs a non-empty {key}")
        path = self.connect_path
        _write_atomic(path, json.dumps(document, indent=2, sort_keys=True) + "\n", mode=0o600)
        return path

    def forget_connect(self) -> bool:
        existed = self.connect_path.is_file()
        self.connect_path.unlink(missing_ok=True)
        return existed

    # --- the one question -----------------------------------------------------
    #
    # The question a session start asked (RFC 0032 §2): which task, named how,
    # on which server.  An answer typed later binds to this task.  No token in
    # it, but the title is the first line of a prompt, so the link's mode.
    #
    # One file per terminal session, named by a digest of the session id
    # (``capture/questions/<sha256>.json``): the question belongs to the
    # session it was shown in.  A single file for the machine let
    # ``/vicaria:no`` typed in one terminal answer the task another terminal
    # was asked about, and let a second start with nothing to ask delete the
    # first terminal's question.  A ``question.json`` left by that layout is
    # never read.  Files older than :data:`QUESTION_KEEP_S` are pruned when a
    # new one is written, so sessions nobody answered do not pile up.

    @property
    def questions_dir(self) -> Path:
        return self.capture / "questions"

    def question_path(self, session_id: str) -> Path:
        if not isinstance(session_id, str) or not session_id:
            raise ValueError("a question belongs to a session: a non-empty session id")
        digest = hashlib.sha256(session_id.encode("utf-8")).hexdigest()
        return self.questions_dir / f"{digest}.json"

    def question(self, session_id: str) -> dict[str, Any] | None:
        path = self.question_path(session_id)
        if not path.is_file():
            return None
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        if not isinstance(document, dict):
            return None
        for key in ("task_id", "server"):
            if not isinstance(document.get(key), str) or not document[key]:
                return None
        return document

    def save_question(self, session_id: str, document: dict[str, Any]) -> Path:
        for key in ("task_id", "server"):
            if not isinstance(document.get(key), str) or not document[key]:
                raise ValueError(f"a question needs a non-empty {key}")
        path = self.question_path(session_id)
        _write_atomic(path, json.dumps(document, indent=2, sort_keys=True) + "\n", mode=0o600)
        self._prune_questions()
        return path

    def forget_question(self, session_id: str) -> bool:
        path = self.question_path(session_id)
        existed = path.is_file()
        path.unlink(missing_ok=True)
        return existed

    #: How long a question set aside by ``/clear`` waits for the session that
    #: clear starts: the end and the start fire together, so a minute is slack.
    CLEARED_QUESTION_S = 60

    @property
    def cleared_question_path(self) -> Path:
        # Outside ``questions/``: no session's question, and never pruned.
        return self.capture / "question-cleared.json"

    def set_aside_question(self, session_id: str) -> bool:
        """``/clear`` ends a session and starts another, with a new id, in the
        same terminal: the question this one showed and nobody answered is
        set aside for the one starting (found in review: after a clear it
        could no longer be answered in that terminal, and the service had
        already recorded asking it)."""
        document = self.question(session_id)
        if document is None or document.get("answer"):
            return False
        _write_atomic(
            self.cleared_question_path,
            json.dumps({**document, "set_aside_at": utc_now()}, sort_keys=True) + "\n",
            mode=0o600,
        )
        return True

    def take_cleared_question(self, session_id: str) -> dict[str, Any] | None:
        """The question a ``/clear`` set aside, kept now for the session it
        started, if it was set aside within :data:`CLEARED_QUESTION_S`."""
        path = self.cleared_question_path
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return None
        finally:
            path.unlink(missing_ok=True)
        if not isinstance(document, dict) or not isinstance(document.get("task_id"), str):
            return None
        stamp = document.pop("set_aside_at", None)
        try:
            then = datetime.fromisoformat(str(stamp).replace("Z", "+00:00"))
        except ValueError:
            return None
        if (datetime.now(UTC) - then).total_seconds() > self.CLEARED_QUESTION_S:
            return None
        self.save_question(session_id, {**document, "asked_in": session_id})
        return document

    def forget_questions(self) -> int:
        """Every session's question: the link they were asked under is gone."""
        forgotten = 0
        for path in self._question_files():
            with contextlib.suppress(FileNotFoundError):
                path.unlink()
                forgotten += 1
        return forgotten

    def _question_files(self) -> list[Path]:
        try:
            return sorted(self.questions_dir.glob("*.json"))
        except OSError:
            return []

    def _prune_questions(self) -> None:
        """Remove the questions of sessions last written to over a week ago.

        By the file's modification time, which an answer refreshes, so the
        file just written is never among them.  Best effort: a file another
        hook removed first, or one this process cannot stat, is left to the
        next write.
        """
        cutoff = datetime.now(UTC).timestamp() - QUESTION_KEEP_S
        for path in self._question_files():
            with contextlib.suppress(OSError):
                if path.stat().st_mtime < cutoff:
                    path.unlink()

    # --- notice receipts -----------------------------------------------------

    def save_notice_receipt(self, receipt: NoticeReceipt) -> Path:
        path = self.capture / "notice-receipts" / f"{receipt.key()}.json"
        _write_atomic(path, json.dumps(receipt.to_document(), indent=2, sort_keys=True) + "\n")
        return path

    def notice_receipt(
        self, *, session_id: str, org_id: str, server: str, notice_digest: str
    ) -> NoticeReceipt | None:
        probe = NoticeReceipt(
            session_id=session_id,
            org_id=org_id,
            server=server,
            harness="",
            notice_version="",
            notice_digest=notice_digest,
            shown_at="",
        )
        path = self.capture / "notice-receipts" / f"{probe.key()}.json"
        if not path.is_file():
            return None
        try:
            return NoticeReceipt.from_document(json.loads(path.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, KeyError, ValueError):
            # A receipt that cannot be read is not a receipt. Refusing is the
            # safe direction: the developer is asked to read the notice again.
            return None

    # --- session state -------------------------------------------------------

    def session_path(self, session_id: str) -> Path:
        """One file per session id, and never one file for two of them.

        The sanitizer alone was not injective: every character outside the safe
        set became ``_``, so ``fix the parser`` and ``fix/the/parser`` resolved
        to the same file. That is not a tidiness problem. Gate 4 is "the
        developer marked *this* session", and it is answered by reading this
        path --- so a session nobody had marked opened the gate on the
        authorization of one they had, and its events would have gone out under
        an interval that never covered them. Capture without consent is the
        worst thing this package can do, and a naming scheme was doing it.

        So the identity is a digest of the exact id, and the readable prefix is
        only there so a developer can tell the files apart by eye. The prefix is
        bounded as well: a long session id used to produce a file name over the
        255-byte limit and an OSError from the first write.
        """
        safe = "".join(
            character if character.isalnum() or character in "_.:@+,=~-" else "_"
            for character in session_id
        )[:64]
        fingerprint = hashlib.sha256(session_id.encode("utf-8")).hexdigest()[:16]
        return self.capture / "sessions" / f"{safe}.{fingerprint}.json"

    def session_file_present(self, session_id: str) -> bool:
        """Whether *any* state file exists for the session, readable or not.

        :meth:`session` answers ``None`` for a missing file and for one that
        will not read back, and for the gate that is right: a failure to
        determine something never reads as on.  The standing mint needs the
        other half of the distinction, because "no file" means a session
        nobody has decided about and "a file I cannot read" does not --- the
        person may have switched it off --- and a mint on the second would turn
        an unreadable byte into consent.
        """
        return self.session_path(session_id).is_file()

    def session(self, session_id: str) -> dict[str, Any] | None:
        path = self.session_path(session_id)
        if not path.is_file():
            return None
        try:
            document = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            # Unreadable for any reason --- permissions, bytes that are not
            # UTF-8, not JSON --- is absence, and absence is off.  A raise
            # here would fail every hook of every session for one bad file.
            return None
        if not isinstance(document, dict):
            return None
        if document.get("session_id") != session_id:
            # Belt and braces behind the digest above, and the reason the gate
            # is safe even if a file arrives here by some other route: a state
            # file that names a different session is not this session's state.
            # Absence means off, so it is read as absence.
            return None
        return document

    def save_session(self, state: dict[str, Any]) -> None:
        _write_atomic(
            self.session_path(str(state["session_id"])),
            json.dumps(state, indent=2, sort_keys=True) + "\n",
        )

    def _prompt_ids_path(self, session_id: str) -> Path:
        # Beside the sessions, not among them: sessions() reads every *.json there.
        return self.capture / "prompt-ids" / (self.session_path(session_id).stem + ".ids")

    @staticmethod
    def _prompt_id_key(event_type: str, prompt_id: str) -> str:
        return hashlib.sha256(f"{event_type}\0{prompt_id}".encode()).hexdigest()

    def open_prompt_ledger(self, session_id: str) -> None:
        """Start the session's record of prompt ids, when its start is recorded.

        Only a session with this record may give a message the prompt-id
        recipe (:meth:`reserve_prompt_id`).  A session already running when
        this release installed has none, and its earlier prompts' ids are not
        known here.  Best effort: a record that cannot be made leaves the
        session on ids of its own, which loses the control join and nothing
        else.
        """
        path = self._prompt_ids_path(session_id)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            os.close(os.open(path, os.O_WRONLY | os.O_CREAT, 0o600))
        except OSError:
            pass

    def reserve_prompt_id(self, session_id: str, event_type: str, prompt_id: str) -> bool:
        """Claim ``prompt_id``'s id for this session's ``event_type``, before it is queued.

        Claude Code hands a background task's ``<task-notification>`` to
        UserPromptSubmit with the prompt id of the turn that queued it, however
        many prompts ago that was.  A second message under the recipe is one id
        for two documents: refused by the service as ``event_conflict``, or,
        while the first is still queued, dropped here by :meth:`enqueue`.  So
        the claim succeeds only on a record that exists, reads, lacks the key,
        and takes the appended key; nothing in it is ever evicted.  Every other
        answer is no, and the message takes an id of its own.  A record that
        cannot be appended to is removed, so the session falls back to ids of
        its own rather than keep a record that may be missing a key.  Callers
        hold :meth:`session_lock` from the claim through :meth:`enqueue`.
        """
        path = self._prompt_ids_path(session_id)
        key = self._prompt_id_key(event_type, prompt_id)
        try:
            if key in path.read_text(encoding="utf-8").splitlines():
                return False
        except (OSError, ValueError):
            return False
        line = (key + "\n").encode("ascii")
        try:
            handle = os.open(path, os.O_WRONLY | os.O_APPEND)
            try:
                if os.write(handle, line) != len(line):
                    raise OSError("short write to the prompt-id record")
                # On disk before the event is: enqueue syncs its queue file, so
                # a claim left in the page cache could be lost to a power cut
                # that the queued event survives (found in review).  A record
                # that is lost whole only costs the join; one that kept the
                # event and lost its key would hand a repeat the same id.
                os.fsync(handle)
            finally:
                os.close(handle)
        except OSError:
            with contextlib.suppress(OSError):
                path.unlink(missing_ok=True)
            return False
        return True

    def sessions(self) -> Iterator[dict[str, Any]]:
        directory = self.capture / "sessions"
        if not directory.is_dir():
            return
        for path in sorted(directory.glob("*.json")):
            try:
                document = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if isinstance(document, dict):
                yield document

    # --- producer identity ---------------------------------------------------

    @property
    def producer_path(self) -> Path:
        return self.capture / "producer-id"

    def _home_lock(self) -> int:
        """An exclusive lock over this home's producer identity and counter.

        A file of its own rather than either of the files it guards:
        `_write_atomic` finishes with `os.replace`, which swaps the inode, and a
        lock is held on an inode --- so locking a file that is about to be
        replaced hands the next waiter a lock on a file that is no longer the
        one that matters.
        """
        self.capture.mkdir(parents=True, exist_ok=True)
        handle = os.open(self.capture / "producer.lock", os.O_RDWR | os.O_CREAT, 0o600)
        fcntl.flock(handle, fcntl.LOCK_EX)
        return handle

    @staticmethod
    def _release(handle: int) -> None:
        fcntl.flock(handle, fcntl.LOCK_UN)
        os.close(handle)

    @contextlib.contextmanager
    def session_lock(self) -> Iterator[None]:
        """An exclusive lock over the session states, for a read-modify-write.

        Hooks are separate processes and Claude Code runs the tool hooks
        asynchronously: a `PostToolUse` hook recording a tool's end could read
        a session's state, a `SessionEnd` hook or `/vicaria off` flip it off,
        and the `PostToolUse` hook then save the copy it had read --- the
        switch thrown and written back on.  Every read-modify-write of a state
        holds this lock.  Its own file, not the
        producer lock: `next_sequence` takes that one inside the window, and
        `flock` on a second descriptor of the same file would wait on itself.
        """
        self.capture.mkdir(parents=True, exist_ok=True)
        handle = os.open(self.capture / "sessions.lock", os.O_RDWR | os.O_CREAT, 0o600)
        fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            yield
        finally:
            self._release(handle)

    def producer_id(self) -> str:
        """This home's producer id, minted once and kept.

        Derived-from-the-path was the first attempt and is wrong: the producer
        sequence lives in the home, so a home that is removed and recreated
        restarts the sequence while keeping the same derived id, and every
        event the new home produces is refused as ``producer_sequence_reused``.
        Minting the id alongside the counter ties the two together — a new home
        is a new producer with a fresh sequence, which is exactly what it is.
        """
        handle = self._home_lock()
        try:
            # Re-read inside the lock: two first hooks both found no file, both
            # minted, and both returned their own id while only one reached
            # disk. Measured: 32 concurrent first calls on a fresh home handed
            # out 4 distinct ids, 3 of which nothing would ever use again, so
            # one session's events arrived under several producers --- each
            # sharing the single counter the id is supposed to be paired with.
            if self.producer_path.is_file():
                existing = self.producer_path.read_text(encoding="utf-8").strip()
                if existing:
                    return existing
            minted = "prod_" + uuid.uuid4().hex[:24]
            _write_atomic(self.producer_path, minted + "\n")
            return minted
        finally:
            self._release(handle)

    # --- the producer sequence ----------------------------------------------

    @property
    def sequence_path(self) -> Path:
        return self.capture / "producer-seq"

    def next_sequence(self) -> int:
        """The next producer sequence for this home, monotonic across sessions.

        The counter belongs to the *producer*, not to a session.  Keeping it
        per session looks natural and is wrong: the service rejects a sequence
        a producer has already used, so a second session from the same client
        home restarts at 1 and every one of its events is refused with
        ``producer_sequence_reused``.  Found exactly that way.

        Read-increment-write is done under an exclusive lock, because the
        processes racing for it are the ordinary case rather than an exotic one.
        This used to say the race needed "another process sharing this home",
        and that a shared home was acceptable because one belongs to one
        developer on one machine. Both halves were wrong. A Claude Code hook is
        a *separate process per event*, and a turn with parallel tool calls
        fires several at once --- one developer, one machine, one home, and
        several processes in the counter at the same time. Measured before the
        lock: 64 concurrent takes returned 13 distinct sequences, so 51 events
        would have been queued and then refused one at a time as
        ``producer_sequence_reused``. Recorded in the drop log rather than lost
        in silence, but most of a busy turn never reaching the service is not a
        failure mode worth accepting.

        The lock is :meth:`_home_lock`, shared with :meth:`producer_id`, because
        the id and the counter are one identity: "a new home is a new producer
        with a fresh sequence" is only true if nothing can mint one without the
        other.
        """
        handle = self._home_lock()
        try:
            current = 0
            if self.sequence_path.is_file():
                try:
                    current = int(self.sequence_path.read_text(encoding="utf-8").strip() or 0)
                except ValueError:
                    # An unreadable counter must not restart the sequence: every
                    # event after it would be refused. Refusing to guess is right,
                    # but so is not silently going backwards, so this raises.
                    raise ValueError(
                        f"{self.sequence_path} does not hold an integer; the producer "
                        "sequence cannot be continued safely"
                    ) from None
            nxt = current + 1
            _write_atomic(self.sequence_path, f"{nxt}\n")
            return nxt
        finally:
            self._release(handle)

    # --- the queue -----------------------------------------------------------

    def queued(self, event_id: str) -> bool:
        """Whether an event with this id is waiting in the queue."""
        return (self.capture / "queue" / f"{event_id}.json").exists()

    def enqueue(self, event: dict[str, Any]) -> Path:
        """Write the exact bytes that will be sent, once."""
        path = self.capture / "queue" / f"{event['event_id']}.json"
        if path.exists():
            return path
        _write_atomic(path, json.dumps(event, sort_keys=True, separators=(",", ":")))
        return path

    def pending(self, session_id: str | None = None) -> list[dict[str, Any]]:
        """Queued events, oldest producer sequence first.

        Ordering by ``producer_seq`` rather than by file mtime matters after a
        restart: mtimes are the times the files were written, which a replay
        can reorder, while the sequence is the order the events happened in.
        """
        directory = self.capture / "queue"
        if not directory.is_dir():
            return []
        events: list[dict[str, Any]] = []
        for path in directory.glob("*.json"):
            try:
                document = json.loads(path.read_text(encoding="utf-8"))
            except FileNotFoundError:
                # Settled by a concurrent flush between the listing and the
                # read. Claude Code flushed on Stop, StopFailure and SessionEnd
                # at the time (SessionEnd alone now) --- separate processes,
                # and the last two arrived together at the end of a session
                # --- so this raised `FileNotFoundError` out of `flush` on the
                # one flush that matters most, the last one before the
                # harness exits.
                continue
            except (OSError, json.JSONDecodeError, UnicodeDecodeError):
                # Left for `quarantine_unreadable`, which records it rather
                # than skipping it forever: a file that will not parse, and
                # one that cannot be read at all (a directory of that name,
                # a file this process may not open) alike.  `status` and the
                # discard list the queue without a quarantine before them.
                continue
            if not isinstance(document, dict):
                continue
            if session_id is None or document.get("session_id") == session_id:
                events.append(document)
        events.sort(key=lambda event: int(event.get("producer_seq") or 0))
        return events

    def quarantine_unreadable(self) -> list[str]:
        """Move queue files that will not parse aside, and record each once.

        :meth:`pending` skips an unreadable file so one damaged event cannot
        block the rest of the queue --- which is right, and on its own was a
        silent hole. The file was skipped again on every later flush, never
        offered, never dropped and never written to the drop log: consented
        material that was never going to leave the machine, and nothing
        anywhere said so. `flush` reported `offered: 0` and looked like a queue
        with nothing in it.

        The same module refuses to guess past an unreadable producer counter
        for exactly this reason. This is the other half of that rule.

        The bytes are moved rather than deleted, because a file that will not
        parse today may still be recoverable by hand, and the id is taken from
        the file name --- which :meth:`enqueue` set from the event id, so it
        survives the contents becoming unreadable.
        """
        directory = self.capture / "queue"
        if not directory.is_dir():
            return []
        quarantined: list[str] = []
        for path in sorted(directory.glob("*.json")):
            # Already recorded by a sweep that could not move it.
            marker = path.with_suffix(path.suffix + ".dropped")
            if marker.exists():
                continue
            try:
                document = json.loads(path.read_text(encoding="utf-8"))
                readable = isinstance(document, dict)
            except FileNotFoundError:
                # Gone between the listing and the read: another flush settled
                # it, which is delivery, not damage. `FileNotFoundError` is an
                # `OSError`, so the broad catch below swallowed it and this
                # recorded a DELIVERED event in the drop log as
                # `unreadable_on_disk` --- a false omission, which for a
                # developer reading that file to learn what did not leave their
                # machine is as wrong as a missing one.
                continue
            except (json.JSONDecodeError, OSError, UnicodeDecodeError):
                readable = False
            if readable:
                continue
            event_id = path.stem
            destination = self.capture / "unreadable" / path.name
            moved = True
            try:
                # Inside the try, with the replace. `mkdir` was above it, so a
                # `capture/unreadable` that exists as a FILE raised
                # `FileExistsError` straight out of this method --- and `flush`
                # calls it before it offers anything, so one malformed path in
                # the client home stopped every upload for that home, not just
                # the damaged event.
                destination.parent.mkdir(parents=True, exist_ok=True)
                os.replace(path, destination)
            except OSError:
                # Cannot move it: leave it where it is rather than lose it, but
                # still say so, because the whole point is that it is not silent.
                destination = path
                moved = False
            if not moved:
                # Record it exactly once. Without this the file stays in the
                # queue, is found unreadable again on the next flush, and is
                # written to the drop log again --- one line per flush, forever,
                # inflating without bound the one count this design tells a
                # developer they can trust.
                # The record below still happens if this fails; a repeat is
                # the cost, and a repeated record beats a lost one.
                with contextlib.suppress(OSError):
                    marker.write_text("unreadable_on_disk\n", encoding="utf-8")
            self.append_drop_log(
                {
                    "at": utc_now(),
                    "event_id": event_id,
                    "session_id": None,
                    "reason": "unreadable_on_disk",
                    "detail": f"the queued event could not be parsed; kept at {destination}",
                }
            )
            quarantined.append(event_id)
        return quarantined

    def settle(self, event_id: str) -> bool:
        """Remove a queued event the service has stored.  False when it was
        already gone (settled by another process meanwhile)."""
        path = self.capture / "queue" / f"{event_id}.json"
        try:
            path.unlink()
        except FileNotFoundError:
            return False
        return True

    def retain_refusal(self, event: dict[str, Any], receipt: dict[str, Any]) -> Path:
        """Keep the offered event and the complete refusal before removing it
        from the queue. If this write fails, the queue remains available for
        retry; a refusal must not destroy the evidence needed to diagnose it.
        These records are never offered automatically by :meth:`pending`."""
        path = self.capture / "refused" / f"{event['event_id']}.json"
        _write_atomic(
            path,
            json.dumps({"event": event, "receipt": receipt}, sort_keys=True),
            mode=0o600,
        )
        return path

    def drop(
        self,
        event_id: str,
        *,
        reason: str,
        session_id: str,
        detail: str = "",
        only_if_queued: bool = False,
        retained_at: str | None = None,
    ) -> bool:
        """Remove a queued event without it having been stored, and say why.
        Returns whether the event was there to remove.

        With ``only_if_queued`` an event another process settled meanwhile
        (a hook that still held the credential and stored it) is not logged
        as dropped: the log then counts what left the queue unsent.  Without
        it the line is written whether or not the file was there, as the
        flush's refused drop has always done."""
        if reason not in DROP_REASONS:
            raise ValueError(f"drop reason must be one of {list(DROP_REASONS)}, got {reason!r}")
        removed = self.settle(event_id)
        if not removed and only_if_queued:
            return False
        self.append_drop_log(
            {
                "at": utc_now(),
                "event_id": event_id,
                "session_id": session_id,
                "reason": reason,
                "detail": detail,
                **({"retained_at": retained_at} if retained_at is not None else {}),
            }
        )
        return removed

    # --- the logs a developer can read --------------------------------------

    def append_upload_log(self, line: dict[str, Any]) -> None:
        """One line per upload attempt, with the fields the design fixed."""
        self._append(self.records / "uploads.jsonl", line)

    def append_backlog_log(self, line: dict[str, Any]) -> None:
        """Worker summaries, kept separate from per-request upload receipts."""
        self._append(self.records / "backlog.jsonl", line)

    def append_transport_log(self, line: dict[str, Any]) -> None:
        """Connection timing and reset replays; no credentials or event content."""
        self._append(self.records / "transport.jsonl", line)

    def append_drop_log(self, line: dict[str, Any]) -> None:
        """One line per item that left the queue without being stored.

        Every writer comes through here, so this is where the closed set is
        actually held.  It classifies rather than refuses: `hook._record_failure`
        writes from inside a `contextlib.suppress(Exception)`, so raising here
        would not surface the bad label --- it would silently discard the record
        of a turn that was never captured, which is precisely the silence this
        file exists to break.
        """
        reason = line.get("reason")
        if reason not in DROP_REASONS:
            line = {
                **line,
                "reason": "unclassified",
                "detail": f"unrecognized drop reason {reason!r}"
                + (f"; {line['detail']}" if line.get("detail") else ""),
            }
        self._append(self.records / "drops.jsonl", line)

    def _append(self, path: Path, line: dict[str, Any]) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(line, sort_keys=True) + "\n")
            handle.flush()
            os.fsync(handle.fileno())

    def upload_log(self) -> list[dict[str, Any]]:
        return self._read_lines(self.records / "uploads.jsonl")

    def drop_log(self) -> list[dict[str, Any]]:
        return self._read_lines(self.records / "drops.jsonl")

    def _read_lines(self, path: Path) -> list[dict[str, Any]]:
        if not path.is_file():
            return []
        lines: list[dict[str, Any]] = []
        for raw in path.read_text(encoding="utf-8").splitlines():
            raw = raw.strip()
            if not raw:
                continue
            try:
                document = json.loads(raw)
            except json.JSONDecodeError:
                # Not skipped. These two files are the claim the design says a
                # developer can check for themselves by counting lines, so a
                # line that cannot be read must not quietly shorten the count:
                # summing a log that silently omits its damaged lines under-
                # reports what left the machine, which is the one direction that
                # flatters. `_append` fsyncs one small line at a time, so this
                # takes a crash mid-write --- rare, and still not nothing.
                lines.append(
                    {
                        "reason": "unreadable_log_line",
                        "detail": f"a line in {path.name} could not be parsed",
                    }
                )
                continue
            if isinstance(document, dict):
                lines.append(document)
            else:
                lines.append(
                    {
                        "reason": "unreadable_log_line",
                        "detail": f"a line in {path.name} is not an object",
                    }
                )
        return lines
