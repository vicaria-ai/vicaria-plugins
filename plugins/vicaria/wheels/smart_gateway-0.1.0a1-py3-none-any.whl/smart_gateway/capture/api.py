"""The capture channel's HTTP client — a different door from the advice service.

The control service receives shape-only ``sg.control.v1`` records under one
token; this client sends consented trajectory *content* under a different
endpoint and a different credential.  The separation is the privacy boundary
expressed as two doors, and it is why this is not a method on the existing API
client: sharing one would make the separation a convention rather than a fact.

Ordinary calls never retry. Bounded delivery runs can reuse one connection and
replay an identical capture batch once after a reset, recording that replay in
the transport log. Device linking and authorization changes are never replayed.
"""

from __future__ import annotations

import contextlib
import http.client
import json
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from typing import Any

#: The shape of a per-document receipt the service answers with.
RECEIPT_OUTCOMES = ("stored", "retry", "refused")

#: What `/v1/captures` accepts, and the field naming each document's identity.
#: The endpoint takes two kinds: session events, which live inside a session's
#: consent fence, and an adapter's coverage document, which carries no
#: organization or session material at all and may therefore arrive before any
#: session is marked.
DOCUMENT_TYPES = {
    "cb.session_event.v1": ("session_event", "event_id"),
    "cb.session_event.v2": ("session_event", "event_id"),
    "cb.session_event.v3": ("session_event", "event_id"),
    # v4 (RFC 0039): feedback.added carries comment_text.  A version missing
    # here is a document whose receipt can never be matched, so every emitted
    # version is listed.
    "cb.session_event.v4": ("session_event", "event_id"),
    # v6 (RFC 0048): reasoning and the reasoning and cache counts.
    "cb.session_event.v6": ("session_event", "event_id"),
    # v7 (RFC 0049): the structure a trajectory is drawn from.
    "cb.session_event.v7": ("session_event", "event_id"),
    "cb.adapter_coverage.v1": ("adapter_coverage", "coverage_id"),
}


def _identity_of(document: dict[str, Any]) -> tuple[str | None, Any]:
    """The receipt type and id a document should be answered with."""
    entry = DOCUMENT_TYPES.get(str(document.get("schema_version")))
    if entry is None:
        return None, None
    document_type, id_key = entry
    return document_type, document.get(id_key)


@dataclass(frozen=True)
class Outcome:
    """The result of one request: reachable or not, refused or not."""

    ok: bool
    status: int | None
    value: Any = None
    reason: str | None = None
    detail: str = ""


class CaptureApi:
    def __init__(
        self, server: str, token: str, *, timeout_s: float = 10.0, opener: Any = None
    ) -> None:
        self.server = server.rstrip("/")
        self._token = token
        self._timeout_s = timeout_s
        # Injectable so tests drive the collector without a socket. The default
        # is urllib, which every supported Python has.
        self._opener = opener or urllib.request.urlopen
        self._custom_opener = opener is not None

    @contextlib.contextmanager
    def delivery_connection(self, log: Any, *, can_replay: Any = lambda: True):
        """Reuse a connection only for this bounded delivery run."""
        from smart_gateway.capture.transport import DeliveryConnection, direct_connection_allowed

        if getattr(self, "_custom_opener", True) or not direct_connection_allowed(self.server):
            yield
            return
        original = self._opener
        connection = DeliveryConnection(self.server, log, can_replay)

        def delivery_only(request: Any, *, timeout: float):
            path = urllib.parse.urlsplit(request.full_url).path
            prefix = urllib.parse.urlsplit(self.server).path.rstrip("/")
            if (request.method == "POST" and path == prefix + "/v1/captures") or (
                request.method == "PATCH"
                and path.startswith(prefix + "/v1/sessions/")
                and path.endswith("/authorization")
            ):
                return connection(request, timeout=timeout)
            return original(request, timeout=timeout)

        self._opener = delivery_only
        try:
            yield
        finally:
            self._opener = original
            connection.close()

    def mark(self, body: dict[str, Any]) -> Outcome:
        return self._request("POST", "/v1/sessions", body)

    # --- the device door ----------------------------------------------------
    #
    # The individual journey's routes live beside ``/v1`` on the same service,
    # and the same bearer slot carries the device token: on ``/v1/captures`` and
    # the authorization PATCH the service binds the write to the device's own
    # workspace, so nothing about the two methods above changes when the token
    # in this client is a device token rather than an organization's.

    def link_device(self, body: dict[str, Any]) -> Outcome:
        """Exchange a single-use link code for a device token.

        The one request this client makes with no credential at all: the code
        *is* the credential, minted on the website by a signed-in person and
        good for one exchange. The answer carries the token exactly once.
        """
        return self._request("POST", "/device/link", body, authenticated=False)

    def open_connect(self, body: dict[str, Any]) -> Outcome:
        """Ask for a connection code (RFC 0032 §6).  No credential: the poll
        token in the answer is the one this request mints."""
        return self._request("POST", "/device/connect", body, authenticated=False)

    def poll_connect(self) -> Outcome:
        """Was the code approved?  The bearer is the poll token; the answer
        carries the device token once, on the first poll after approval."""
        return self._request("POST", "/device/connect/poll", {})

    def heartbeat(self, body: dict[str, Any]) -> Outcome:
        """Tell the service this device is alive. *Linked* means a heartbeat arrived."""
        return self._request("POST", "/device/heartbeat", body)

    def mint_session(self, body: dict[str, Any]) -> Outcome:
        """Mint this session's authorization from the account's standing consent.

        201 carries a freshly opened interval's descriptor, 200 the one already
        open, and a 403 names why nothing stands (``no_standing_consent``,
        ``consent_withdrawn``, ``notice_changed``). The descriptor is the
        server's grant, copied onto every event exactly as a per-session mark's
        is.
        """
        return self._request("POST", "/device/sessions", body)

    def question(self, body: dict[str, Any], *, timeout_s: float | None = None) -> Outcome:
        """The one question a session start asks (RFC 0032 §2): the newest
        finished task, asked once anywhere, or ``{"question": null}``.

        ``timeout_s`` replaces this client's timeout for this request alone:
        the question is the third request a session start may make, and the
        hook gives it a shorter budget than the mint before it (see
        ``hook.QUESTION_BUDGET_S``)."""
        return self._request("POST", "/device/question", body, timeout_s=timeout_s)

    def answer(self, body: dict[str, Any]) -> Outcome:
        """The person's ``yes``, ``partly`` or ``no`` for one task."""
        return self._request("POST", "/device/answer", body)

    def revoke(self, session_id: str, body: dict[str, Any]) -> Outcome:
        return self._request(
            "PATCH", f"/v1/sessions/{urllib.parse.quote(session_id, safe='')}/authorization", body
        )

    def captures(self, events: list[dict[str, Any]]) -> Outcome:
        """Offer a batch. The answer must carry an identity-matched receipt each.

        A batch is explicitly partial: the service can refuse one row and store
        its siblings, and it reports that with a non-2xx status and a useful
        body.  So the status alone is not the answer — the receipts are — and a
        response whose receipts do not line up with what was offered is treated
        as no answer at all rather than as permission to drop the queue.
        """
        outcome = self._request("POST", "/v1/captures", events, receipts_expected=True)
        if not outcome.ok:
            return outcome
        results = (outcome.value or {}).get("results")
        if not isinstance(results, list) or len(results) != len(events):
            return Outcome(
                False,
                outcome.status,
                reason="refused",
                detail="the capture service answered without one receipt per document",
            )
        for offered, receipt in zip(events, results, strict=True):
            if not isinstance(receipt, dict):
                return Outcome(
                    False, outcome.status, reason="refused", detail="a receipt was not an object"
                )
            if receipt.get("outcome") not in RECEIPT_OUTCOMES:
                return Outcome(
                    False,
                    outcome.status,
                    reason="refused",
                    detail=f"unknown receipt outcome {receipt.get('outcome')!r}",
                )
            expected_type, expected_id = _identity_of(offered)
            if expected_type is None:
                return Outcome(
                    False,
                    outcome.status,
                    reason="refused",
                    detail=f"offered a document of unknown type {offered.get('schema_version')!r}",
                )
            if (
                receipt.get("document_type") != expected_type
                or receipt.get("document_id") != expected_id
            ):
                return Outcome(
                    False,
                    outcome.status,
                    reason="refused",
                    detail="a receipt did not name the document it answers for",
                )
            if receipt.get("outcome") == "refused" and not isinstance(receipt.get("error"), str):
                return Outcome(
                    False,
                    outcome.status,
                    reason="refused",
                    detail="a refusal receipt carried no error",
                )
        return Outcome(True, outcome.status, value={"results": results})

    def _request(
        self,
        method: str,
        path: str,
        body: Any,
        *,
        receipts_expected: bool = False,
        authenticated: bool = True,
        timeout_s: float | None = None,
    ) -> Outcome:
        headers = {"accept": "application/json"}
        if authenticated:
            headers["authorization"] = f"Bearer {self._token}"
        data = None
        if body is not None:
            headers["content-type"] = "application/json"
            data = json.dumps(body).encode()
        try:
            request = urllib.request.Request(
                self.server + path, data=data, headers=headers, method=method
            )
        except ValueError as failure:
            # urllib's answer to an address with no scheme ("unknown url
            # type"), raised by the constructor, not by the open: not a route
            # problem, but not a crash either.
            return Outcome(False, None, reason="unreachable", detail=f"bad address: {failure}")
        try:
            timeout = self._timeout_s if timeout_s is None else timeout_s
            with self._opener(request, timeout=timeout) as answer:
                status = answer.status
                raw = answer.read().decode(errors="replace")
        except urllib.error.HTTPError as failure:
            status = failure.code
            try:
                raw = failure.read().decode(errors="replace")
            except (OSError, http.client.HTTPException) as cut:
                # The status arrived and the body did not (a proxy closing a
                # 503 early).  Without the body no answer is definite, so it
                # is the same "not this time" as no answer at all.
                return Outcome(False, None, reason="unreachable", detail=str(cut))
        except (urllib.error.URLError, TimeoutError, OSError, http.client.HTTPException) as failure:
            # `IncompleteRead` (a proxy cutting a slow answer) is an
            # HTTPException, not an OSError: the same "not this time".
            return Outcome(False, None, reason="unreachable", detail=str(failure))

        try:
            value = json.loads(raw) if raw else {}
        except json.JSONDecodeError as failure:
            return Outcome(
                False,
                status,
                reason="refused",
                detail=f"unreadable JSON from the capture service: {failure}",
            )

        carries_receipts = (
            receipts_expected and isinstance(value, dict) and isinstance(value.get("results"), list)
        )
        if status >= 400 and not carries_receipts:
            detail = ""
            if isinstance(value, dict):
                detail = str(value.get("detail") or value.get("error") or "")
            # The body travels with the refusal: a ``/device/sessions`` 403
            # names *why* nothing stands, and a caller recording the refusal
            # needs the name, not only the prose.
            return Outcome(
                False, status, value=value, reason="refused", detail=detail or f"HTTP {status}"
            )
        return Outcome(True, status, value=value)
