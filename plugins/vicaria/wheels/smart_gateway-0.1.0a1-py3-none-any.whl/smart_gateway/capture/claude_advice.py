"""Claude Code's thin translator for plugin-only, next-session suggestions."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from smart_gateway.capture import claude_apply, claude_code
from smart_gateway.control import recommendations, running
from smart_gateway.control.adapter import ident, reading
from smart_gateway.control.config import EFFORT_UNSET


def advice(payload: dict[str, Any], *, device: dict[str, Any], budget_s: float = 5.0) -> str | None:
    """Ask after a successful session mint, never for commands or paused capture.

    First-prompt defaults are labelled as configured, not observed. If the
    harness has supplied no model and only an unresolved alias is known, wait
    for its configured-model transcript attachment rather than invent an ID.
    """
    if payload.get("hook_event_name") != "UserPromptSubmit" or claude_code.is_command(payload):
        return None
    session, prompt, prompt_id = (
        payload.get("session_id"),
        payload.get("prompt"),
        payload.get("prompt_id"),
    )
    if not all(isinstance(value, str) and value for value in (session, prompt, prompt_id)):
        return None
    seen = running.read(payload.get("transcript_path"))
    settings = _settings()
    model, model_source = _model(payload, seen.model_id, settings)
    if model is None:
        return "vicaria: waiting for this session's model before recommending a configuration."
    reported = payload.get("effort")
    effort = reading(reported.get("level") if isinstance(reported, dict) else None)
    effort = effort or reading(payload.get("reasoning_effort"))
    effort_source = running.HARNESS
    if effort is None:
        effort = reading(os.environ.get("CLAUDE_EFFORT"))
        effort_source = running.HARNESS
    if effort is None:
        effort = reading(os.environ.get("CLAUDE_CODE_EFFORT_LEVEL"))
        effort_source = running.ENVIRONMENT
    if effort is None:
        effort = _configured_effort(settings, model) or EFFORT_UNSET
        effort_source = running.CONFIGURED_DEFAULT
    return recommendations.advise(
        session,
        prompt,
        prompt_id=prompt_id,
        device=device,
        harness="claude-code",
        model=model,
        effort=effort,
        model_source=model_source,
        effort_source=effort_source,
        harness_version=payload.get("harness_version") or running.harness_version(os.environ),
        budget_s=budget_s,
        active_prompt=claude_apply.applied_prompt(session),
    ).message


def _settings() -> dict[str, Any]:
    home = Path(os.environ.get("CLAUDE_CONFIG_DIR") or Path.home() / ".claude")
    try:
        path = home / "settings.json"
        if path.stat().st_size > 1 << 20:
            return {}
        value = json.loads(path.read_text())
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def _configured_effort(settings: dict[str, Any], model: str) -> str | None:
    """The effort the settings give ``model``: where ``/effort`` and ``/vicaria:apply``
    write it, ``modelSettings.<model>.effortLevel``, before the older top-level key.

    The exact key comes first; it is the one apply writes. A dated key for the same
    model counts only when the exact one holds no effort, the newest date first, so
    the answer never depends on the order of keys in the file.
    """
    per_model = settings.get("modelSettings")
    if isinstance(per_model, dict):
        dated = sorted(
            (name for name in per_model if isinstance(name, str) and name != model),
            reverse=True,
        )
        for name in [model, *dated]:
            values = per_model.get(name)
            named = ident(name)
            if named and running.canonical(named) == model and isinstance(values, dict):
                effort = reading(values.get("effortLevel"))
                if effort:
                    return effort
    return reading(settings.get("effortLevel"))


def _model(payload, configured, settings):
    # The configured-model attachment is distinct from the model that answered.
    for value, source in (
        (payload.get("model"), running.HARNESS),
        (configured, running.TRANSCRIPT),
        (os.environ.get("ANTHROPIC_MODEL"), running.ENVIRONMENT),
        (settings.get("model"), running.CONFIGURED_DEFAULT),
    ):
        named = ident(value)
        if named and named.startswith("claude-"):
            return running.canonical(named), source
    return None, None
