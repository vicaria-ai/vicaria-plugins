"""Bounded delivery of this harness home's backlog, including ended sessions.

Hooks persist events before launching this child. SessionEnd also attempts its
own delivery synchronously for environments torn down at exit. No timer/daemon
is installed: later hooks retry what remains. Final delivery and workers share
a per-home lock and persistent outage backoff. Manual flushes are independent.
"""

from __future__ import annotations

import contextlib
import fcntl
import json
import math
import os
import signal
import subprocess
import sys
import tempfile
import time
from typing import Any

from smart_gateway.capture.api import CaptureApi
from smart_gateway.capture.store import CaptureStore, utc_now

EVENTS = frozenset({"SessionStart", "Stop", "StopFailure", "SessionEnd"})
HARNESS_NAMES = frozenset({"claude-code", "codex"})
MAX_SECONDS = 60.0
REQUEST_SECONDS = 5.0
COOLDOWN_SECONDS = 30.0
MAX_REQUEST_SECONDS = 10.0
BACKOFF_SECONDS = 60.0
MAX_BACKOFF_SECONDS = 900.0
REQUEST_GAP_SECONDS = 5.0
LOCK_GRACE_SECONDS = 1.0


def _disabled(store: CaptureStore) -> bool:
    return (store.capture / "backlog.disabled").exists()


@contextlib.contextmanager
def _final_priority(store: CaptureStore):
    """Publish a separate, live marker for each final sender until it returns.

    Lock the inode before publishing it. The held lock identifies a live
    caller without PID reuse or clock assumptions; a killed caller's marker
    is unlocked and can be ignored. Each caller removes only its own marker.
    """
    with tempfile.NamedTemporaryFile(mode="w+", prefix=".priority-", dir=store.capture) as marker:
        fcntl.flock(marker, fcntl.LOCK_EX)
        json.dump({"pid": os.getpid(), "at": utc_now()}, marker)
        marker.flush()
        path = store.capture / ("backlog-final-" + os.path.basename(marker.name))
        os.link(marker.name, path)
        try:
            yield
        finally:
            with contextlib.suppress(FileNotFoundError):
                path.unlink()


def _final_waiting(store: CaptureStore) -> bool:
    for path in store.capture.glob("backlog-final-*"):
        try:
            with path.open() as marker:
                try:
                    fcntl.flock(marker, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    return True
                # An unlocked marker belongs to a caller that exited/crashed.
                path.unlink(missing_ok=True)
        except FileNotFoundError:
            pass
        except OSError:
            return True  # Do not compete when priority cannot be established.
    return False


class _Deadline(BaseException):
    """Escape API exception handlers without mistaking an interrupted read for a receipt."""


def _expired(_signum: int, _frame: Any) -> None:
    raise _Deadline


class _Stopped(BaseException):
    """Stop before another request, after settling the last valid receipt."""


class _Yielded(BaseException):
    """A normal scheduling stop; it must not increase outage backoff."""


class _DeliveryApi:
    """Bound each delivery request and remember when further work must stop."""

    def __init__(self, api: Any, store: CaptureStore, *, automatic: bool, deadline: float) -> None:
        self.api = api
        self.store = store
        self.automatic = automatic
        self.deadline = deadline
        self.next_request = 0.0
        self.reason: str | None = None

    def __getattr__(self, name: str) -> Any:
        return getattr(self.api, name)

    def _ready(self) -> None:
        # Pacing is a normal, cooperatively bounded wait, not a failed request.
        # The next request installs its own alarm; queue scans retain the
        # enclosing alarm after each returned response.
        signal.setitimer(signal.ITIMER_REAL, 0)
        while True:
            now = time.monotonic()
            if now >= self.deadline:
                raise _Yielded("budget")
            if self.automatic:
                if _disabled(self.store):
                    raise _Yielded("disabled")
                if _final_waiting(self.store):
                    raise _Yielded("session_end")
            if not self.automatic or now >= self.next_request:
                return
            time.sleep(min(0.05, self.next_request - now, self.deadline - now))

    def _request(self, method: str, *args: Any) -> Any:
        if self.reason:
            raise _Stopped
        self._ready()
        started = time.monotonic()
        remaining = self.deadline - started
        if remaining <= 0:
            raise _Yielded("budget")
        # A later automatic request needs its full wall-time allowance. An
        # exhausted worker budget is a scheduling stop, not evidence of an
        # outage: cutting a healthy reply short here would retain its events
        # and increase persistent backoff on every otherwise healthy sweep.
        # Keep the final sender's bounded last opportunity, and the first
        # attempt of an explicitly short run, within their existing budgets.
        if self.automatic and self.next_request and remaining < MAX_REQUEST_SECONDS:
            raise _Yielded("budget")
        clipped = remaining < MAX_REQUEST_SECONDS
        signal.setitimer(signal.ITIMER_REAL, min(remaining, MAX_REQUEST_SECONDS))
        try:
            outcome = getattr(self.api, method)(*args)
        except _Deadline:
            if clipped:
                # The run used up its remaining budget; this request did not
                # receive the full allowance needed to establish an outage.
                raise _Yielded("budget") from None
            self.reason = "request_deadline"
            raise
        finally:
            # Keep the enclosing delivery deadline, rather than resetting it
            # on every request. The alarm also bounds trickling responses.
            signal.setitimer(
                signal.ITIMER_REAL,
                0
                if self.reason == "request_deadline"
                else max(0.0, self.deadline - time.monotonic()),
            )
        # If the overall budget passed as a valid reply completed, leave the
        # alarm off so its receipts can settle. _ready stops the next request.
        elapsed = time.monotonic() - started
        self.next_request = time.monotonic() + max(REQUEST_GAP_SECONDS, elapsed)
        from smart_gateway.capture.collector import _refused_for_a_document, _retry_after

        if not outcome.ok and _refused_for_a_document(outcome):
            # The door refused the request for a document's content, not
            # because it is out: the collector offers that chunk's documents
            # one at a time next, bounded by its SUSPECT_LIMIT. Stopping here
            # left the chunk at the head of the queue on every automatic
            # attempt (found in review).
            pass
        elif not outcome.ok:
            self.reason = outcome.reason or "request_failed"
        elif elapsed >= MAX_REQUEST_SECONDS:
            self.reason = "slow_request"
        elif method == "captures":
            receipts = outcome.value["results"]
            refused = [r for r in receipts if r.get("outcome") == "refused"]
            later = [r for r in refused if _retry_after(r) is not None]
            if len(later) < len(refused):
                self.reason = "receipt_refused"
            elif later and len(later) == len(receipts):
                # The service took none of it and asked to come back later
                # (disk_full, store_busy): it is out, so the attempt backs off.
                self.reason = "retry_after"
            # A retry-later refusal in an answer the service took some of
            # leaves that document queued and goes on (found in review: the
            # worker stopped there, and the rest of the queue waited).
        return outcome

    def captures(self, events: Any) -> Any:
        return self._request("captures", events)

    def revoke(self, session_id: str, body: Any) -> Any:
        return self._request("revoke", session_id, body)


def _save_schedule(lock: Any, *, failures: int, next_attempt: float) -> None:
    lock.seek(0)
    lock.truncate()
    json.dump({"failures": failures, "next_attempt": next_attempt}, lock)
    lock.flush()
    os.fsync(lock.fileno())


def _backoff(failures: int) -> float:
    return min(MAX_BACKOFF_SECONDS, BACKOFF_SECONDS * 2 ** min(max(0, failures - 1), 10))


def after_event(harness: str, payload: dict[str, Any], *, home: str | None) -> bool:
    if payload.get("hook_event_name") not in EVENTS or harness not in HARNESS_NAMES:
        return False
    store = CaptureStore(home)
    if not store.capture.is_dir() or store.opted_out() or _disabled(store):
        return False
    return launch(harness, home=str(store.home))


def launch(harness: str, *, home: str) -> bool:
    """Detach all streams and retain the exact interpreter, home and credential environment."""
    if _disabled(CaptureStore(home)):
        return False
    try:
        subprocess.Popen(
            [sys.executable, "-m", "smart_gateway.capture.background", harness],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            env={**os.environ, "VICARIA_HOME": home},
        )
    except OSError as failure:
        with contextlib.suppress(OSError):
            CaptureStore(home).append_backlog_log(
                {"at": utc_now(), "outcome": "launch_failed", "detail": str(failure)}
            )
        return False
    return True


def run(
    harness: str,
    *,
    collector: Any = None,
    session_id: str | None = None,
    max_seconds: float | None = None,
) -> None:
    """One worker, at most 60 seconds including queue scans and pending stops.

    The socket timeout bounds individual blocking reads, not a complete
    request. The alarm is a separate wall-time limit and releases the lock
    even if a server trickles data. Unacknowledged bytes remain queued.
    """
    seconds = MAX_SECONDS if max_seconds is None else max_seconds
    if harness not in HARNESS_NAMES or seconds <= 0:
        return
    from smart_gateway.capture.cli import resolve_credentials
    from smart_gateway.capture.collector import collector_for
    from smart_gateway.capture.hook import _home

    store = collector.store if collector is not None else CaptureStore(_home(harness))
    if not store.capture.is_dir() or store.opted_out():
        return
    if session_id is None and (_disabled(store) or _final_waiting(store)):
        return
    if collector is None:
        credentials = resolve_credentials(home=str(store.home))
        if credentials is None:
            return
        collector = collector_for(
            harness,
            org_id=credentials["org"],
            server=credentials["server"],
            token=credentials["token"],
            home=str(store.home),
            timeout_s=REQUEST_SECONDS,
            deadline_s=seconds - REQUEST_SECONDS - 1,
        )
    # Never unlink the lock: another process may already have opened its inode.
    with contextlib.ExitStack() as stack:
        if session_id is not None:
            stack.enter_context(_final_priority(store))
        fd = os.open(store.capture / "backlog.lock", os.O_CREAT | os.O_RDWR, 0o600)
        lock = stack.enter_context(os.fdopen(fd, "r+"))
        delivery_deadline = time.monotonic() + seconds
        lock_deadline = time.monotonic() + min(seconds, MAX_REQUEST_SECONDS + LOCK_GRACE_SECONDS)
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                # A Stop worker can still be sending when SessionEnd arrives.
                # The priority marker makes it yield before another request.
                # Bound even an uncooperative/older holder to one request plus
                # grace; background workers never queue behind each other.
                remaining = lock_deadline - time.monotonic()
                if session_id is None or remaining <= 0:
                    if session_id is not None:
                        store.append_backlog_log(
                            {"at": utc_now(), "outcome": "lock_busy", "session_id": session_id}
                        )
                    return
                time.sleep(min(0.05, remaining))
        seconds = delivery_deadline - time.monotonic()
        if seconds <= 0:
            return
        now = time.time()
        raw = lock.read()
        try:
            schedule = json.loads(raw) if raw else 0
            if isinstance(schedule, (int, float)) and math.isfinite(schedule):
                schedule = {"failures": 0, "next_attempt": schedule + COOLDOWN_SECONDS}
            if (
                not isinstance(schedule, dict)
                or not isinstance(schedule.get("failures"), int)
                or schedule["failures"] < 0
                or not isinstance(schedule.get("next_attempt"), (int, float))
                or not math.isfinite(schedule["next_attempt"])
            ):
                raise ValueError("invalid delivery schedule")
        except ValueError:
            # An unreadable schedule must not turn an outage into rapid retries.
            schedule = {"failures": 1, "next_attempt": now + BACKOFF_SECONDS}
            _save_schedule(lock, **schedule)
        failures = schedule["failures"]
        # Final delivery can bypass a healthy worker's ordinary cooldown, but
        # never an outage backoff. It shares the lock with automatic workers.
        if now < schedule["next_attempt"] and (session_id is None or failures):
            if session_id is not None:
                with contextlib.suppress(OSError):
                    store.append_backlog_log(
                        {
                            "at": utc_now(),
                            "outcome": "deferred",
                            "reason": "backoff",
                            "session_id": session_id,
                            "retry_after_s": schedule["next_attempt"] - now,
                        }
                    )
            return
        # Persist an uncertain attempt before network work. Even SIGKILL leaves
        # a conservative backoff; normal completion replaces it below.
        _save_schedule(
            lock, failures=failures + 1, next_attempt=now + seconds + _backoff(failures + 1)
        )
        started = time.monotonic()
        if isinstance(collector.api, CaptureApi):
            stack.enter_context(
                collector.api.delivery_connection(
                    lambda row: store.append_transport_log({"at": utc_now(), **row}),
                    can_replay=lambda: (
                        not store.opted_out()
                        and (
                            session_id is not None
                            or (not _disabled(store) and not _final_waiting(store))
                        )
                    ),
                )
            )
        previous = signal.signal(signal.SIGALRM, _expired)
        signal.setitimer(signal.ITIMER_REAL, seconds)
        result: dict[str, Any] = {"outcome": "finished"}
        original_api = collector.api
        delivery_api = _DeliveryApi(
            original_api,
            store,
            automatic=session_id is None,
            deadline=time.monotonic() + seconds,
        )
        collector.api = delivery_api
        try:
            # Stops must be delivered before any content. A transient failure
            # (including a non-timeout 5xx) ends this worker's attempt.
            states = store.sessions() if session_id is None else [store.session(session_id) or {}]
            for state in states:
                pending = state.get("pending_revoke")
                if isinstance(pending, dict) and pending.get("org_id") == collector.org_id:
                    outcome = collector._revoke_pending(str(state["session_id"]))
                    if outcome is not None and not outcome.ok:
                        result = {"outcome": "stop_deferred", "reason": outcome.reason}
                        break
            else:
                # Existing collector owns ordering, opt-out, scope and receipts.
                flushed = collector.flush(session_id)
                result = {
                    "outcome": "deferred" if flushed.get("deferred") else "finished",
                    "flush": flushed,
                }
        except _Deadline:
            result = {"outcome": "deadline"}
        except _Stopped:
            result = {"outcome": "deferred", "reason": delivery_api.reason}
        except _Yielded as yielded:
            result = {"outcome": "yielded", "reason": str(yielded)}
        except Exception as failure:
            result = {"outcome": "failed", "detail": f"{type(failure).__name__}: {failure}"}
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous)
            collector.api = original_api
            failed = delivery_api.reason or result["outcome"] in {"failed", "deadline"}
            failures = failures + 1 if failed else 0
            delay = _backoff(failures) if failed else COOLDOWN_SECONDS
            _save_schedule(lock, failures=failures, next_attempt=time.time() + delay)
            with contextlib.suppress(OSError):
                store.append_backlog_log(
                    {
                        "at": utc_now(),
                        "elapsed_s": time.monotonic() - started,
                        **result,
                        "session_id": session_id,
                        "backoff_s": delay if failed else 0,
                        "failure_reason": delivery_api.reason,
                    }
                )


def main() -> int:
    try:
        run(sys.argv[1] if len(sys.argv) == 2 else "")
    except Exception:
        # A missing/unwritable home cannot make the parent hook fail. No queue
        # file was settled; the next hook can retry once the home is usable.
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
