"""Bounded delivery of this harness home's backlog, including ended sessions.

Hooks persist events before launching this child. SessionEnd also attempts its
own delivery synchronously for environments torn down at exit. No timer/daemon
is installed: later hooks retry what remains. A child whose pass ran out of time
while the service was taking events, or gave way to a session end, runs further
passes, for at most ``CHAIN_SECONDS`` after it started; nothing outlives that. Final delivery and
workers share a per-home lock and persistent outage backoff. Manual flushes are
independent.
"""

from __future__ import annotations

import contextlib
import fcntl
import json
import math
import os
import signal
import subprocess
import sys
import tempfile
import time
from typing import Any

from smart_gateway.capture.api import CaptureApi
from smart_gateway.capture.store import CaptureStore, utc_now

EVENTS = frozenset({"SessionStart", "Stop", "StopFailure", "SessionEnd"})
HARNESS_NAMES = frozenset({"claude-code", "codex"})
MAX_SECONDS = 60.0
#: A capture upload's socket read timeout. 5 s timed out 7.8% of real uploads
#: (28-80 KB, Oct 23) and every one became an outage; the service is slow, not out.
REQUEST_SECONDS = 20.0
COOLDOWN_SECONDS = 30.0
#: Each request's own wall-time alarm: above the socket timeout, so the alarm
#: never cuts a request the socket would still allow.
MAX_REQUEST_SECONDS = 25.0
BACKOFF_SECONDS = 60.0
MAX_BACKOFF_SECONDS = 900.0
#: The pause after each request is as long as the request took, and at least
#: this: a struggling service still gets at least half of every cycle back. It
#: was 5 s, which on Oct 23 left a pass idle while 1-3 s requests waited.
REQUEST_GAP_SECONDS = 1.0
#: The most queued events one pass reads and offers, oldest first. A 60 s pass
#: sent at most ~50 on Oct 23; reading 500 takes ~0.1 s, the whole queue 9-22 s.
HEAD_EVENTS = 500
LOCK_GRACE_SECONDS = 1.0
#: How long one launched child may keep running passes back to back. Passes
#: started only by session starts and stops uploaded ~5% of the time on James's
#: Mac (Oct 24, 0.4.18) and both queues grew; four Codex passes that happened
#: to run back to back sent ~1,900 events an hour against ~850 arriving.
CHAIN_SECONDS = 900.0
#: How often a paused chain looks again for a live session-end delivery.
PAUSE_POLL_SECONDS = 0.5
#: Failures that say a request did not complete, not that the service refused.
#: After a pass has stored anything they are a slow request, not an outage.
TRANSIENT_REASONS = frozenset({"unreachable", "request_failed", "request_deadline", "slow_request"})


def _disabled(store: CaptureStore) -> bool:
    return (store.capture / "backlog.disabled").exists()


@contextlib.contextmanager
def _final_priority(store: CaptureStore):
    """Publish a separate, live marker for each final sender until it returns.

    Lock the inode before publishing it. The held lock identifies a live
    caller without PID reuse or clock assumptions; a killed caller's marker
    is unlocked and can be ignored. Each caller removes only its own marker.
    """
    with tempfile.NamedTemporaryFile(mode="w+", prefix=".priority-", dir=store.capture) as marker:
        fcntl.flock(marker, fcntl.LOCK_EX)
        json.dump({"pid": os.getpid(), "at": utc_now()}, marker)
        marker.flush()
        path = store.capture / ("backlog-final-" + os.path.basename(marker.name))
        os.link(marker.name, path)
        try:
            yield
        finally:
            with contextlib.suppress(FileNotFoundError):
                path.unlink()


def _final_waiting(store: CaptureStore) -> bool:
    for path in store.capture.glob("backlog-final-*"):
        try:
            with path.open() as marker:
                try:
                    fcntl.flock(marker, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    return True
                # An unlocked marker belongs to a caller that exited/crashed.
                path.unlink(missing_ok=True)
        except FileNotFoundError:
            pass
        except OSError:
            return True  # Do not compete when priority cannot be established.
    return False


class _Deadline(BaseException):
    """Escape API exception handlers without mistaking an interrupted read for a receipt."""


def _expired(_signum: int, _frame: Any) -> None:
    raise _Deadline


class _Stopped(BaseException):
    """Stop before another request, after settling the last valid receipt."""


class _Yielded(BaseException):
    """A normal scheduling stop; it must not increase outage backoff."""


class _DeliveryApi:
    """Bound each delivery request and remember when further work must stop."""

    def __init__(
        self,
        api: Any,
        store: CaptureStore,
        *,
        automatic: bool,
        deadline: float,
        on_progress: Any = None,
    ) -> None:
        self.api = api
        #: Documents the service took in this pass (``stored`` or ``retry``).
        self.progressed = 0
        self.on_progress = on_progress
        self.store = store
        self.automatic = automatic
        self.deadline = deadline
        self.next_request = 0.0
        self.reason: str | None = None

    def __getattr__(self, name: str) -> Any:
        return getattr(self.api, name)

    def _ready(self) -> None:
        # Pacing is a normal, cooperatively bounded wait, not a failed request.
        # The next request installs its own alarm; queue scans retain the
        # enclosing alarm after each returned response.
        signal.setitimer(signal.ITIMER_REAL, 0)
        while True:
            now = time.monotonic()
            if now >= self.deadline:
                raise _Yielded("budget")
            if self.automatic:
                if _disabled(self.store):
                    raise _Yielded("disabled")
                if _final_waiting(self.store):
                    raise _Yielded("session_end")
            if not self.automatic or now >= self.next_request:
                return
            time.sleep(min(0.05, self.next_request - now, self.deadline - now))

    def _request(self, method: str, *args: Any) -> Any:
        if self.reason:
            raise _Stopped
        self._ready()
        started = time.monotonic()
        remaining = self.deadline - started
        if remaining <= 0:
            raise _Yielded("budget")
        # A later automatic request needs its full wall-time allowance. An
        # exhausted worker budget is a scheduling stop, not evidence of an
        # outage: cutting a healthy reply short here would retain its events
        # and increase persistent backoff on every otherwise healthy sweep.
        # Keep the final sender's bounded last opportunity, and the first
        # attempt of an explicitly short run, within their existing budgets.
        if self.automatic and self.next_request and remaining < MAX_REQUEST_SECONDS:
            raise _Yielded("budget")
        clipped = remaining < MAX_REQUEST_SECONDS
        signal.setitimer(signal.ITIMER_REAL, min(remaining, MAX_REQUEST_SECONDS))
        try:
            outcome = getattr(self.api, method)(*args)
        except _Deadline:
            if clipped:
                # The run used up its remaining budget; this request did not
                # receive the full allowance needed to establish an outage.
                raise _Yielded("budget") from None
            self.reason = "request_deadline"
            raise
        finally:
            # Keep the enclosing delivery deadline, rather than resetting it
            # on every request. The alarm also bounds trickling responses.
            signal.setitimer(
                signal.ITIMER_REAL,
                0
                if self.reason == "request_deadline"
                else max(0.0, self.deadline - time.monotonic()),
            )
        # If the overall budget passed as a valid reply completed, leave the
        # alarm off so its receipts can settle. _ready stops the next request.
        elapsed = time.monotonic() - started
        self.next_request = time.monotonic() + max(REQUEST_GAP_SECONDS, elapsed)
        from smart_gateway.capture.collector import _refused_for_a_document, _retry_after

        if not outcome.ok and _refused_for_a_document(outcome):
            # The door refused the request for a document's content, not
            # because it is out: the collector offers that chunk's documents
            # one at a time next, bounded by its SUSPECT_LIMIT. Stopping here
            # left the chunk at the head of the queue on every automatic
            # attempt (found in review).
            pass
        elif not outcome.ok:
            self.reason = outcome.reason or "request_failed"
        elif elapsed >= MAX_REQUEST_SECONDS:
            self.reason = "slow_request"
        elif method == "captures":
            receipts = outcome.value["results"]
            took = sum(1 for r in receipts if r.get("outcome") in ("stored", "retry"))
            if took:
                first = not self.progressed
                self.progressed += took
                if first and self.on_progress is not None:
                    # The service is reachable: a pass cut short from here on
                    # (a timeout, a killed process) must not read as an outage.
                    with contextlib.suppress(OSError):
                        self.on_progress()
            refused = [r for r in receipts if r.get("outcome") == "refused"]
            later = [r for r in refused if _retry_after(r) is not None]
            if len(later) < len(refused):
                self.reason = "receipt_refused"
            elif later and len(later) == len(receipts):
                # The service took none of it and asked to come back later
                # (disk_full, store_busy): it is out, so the attempt backs off.
                self.reason = "retry_after"
            # A retry-later refusal in an answer the service took some of
            # leaves that document queued and goes on (found in review: the
            # worker stopped there, and the rest of the queue waited).
        return outcome

    def captures(self, events: Any) -> Any:
        return self._request("captures", events)

    def revoke(self, session_id: str, body: Any) -> Any:
        return self._request("revoke", session_id, body)


def _save_schedule(lock: Any, *, failures: int, next_attempt: float) -> None:
    lock.seek(0)
    lock.truncate()
    json.dump({"failures": failures, "next_attempt": next_attempt}, lock)
    lock.flush()
    os.fsync(lock.fileno())


def _backoff(failures: int) -> float:
    return min(MAX_BACKOFF_SECONDS, BACKOFF_SECONDS * 2 ** min(max(0, failures - 1), 10))


def after_event(harness: str, payload: dict[str, Any], *, home: str | None) -> bool:
    if payload.get("hook_event_name") not in EVENTS or harness not in HARNESS_NAMES:
        return False
    store = CaptureStore(home)
    if not store.capture.is_dir() or store.opted_out() or _disabled(store):
        return False
    return launch(harness, home=str(store.home))


def launch(harness: str, *, home: str) -> bool:
    """Detach all streams and retain the exact interpreter, home and credential environment."""
    if _disabled(CaptureStore(home)):
        return False
    try:
        subprocess.Popen(
            [sys.executable, "-m", "smart_gateway.capture.background", harness],
            stdin=subprocess.DEVNULL,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
            env={**os.environ, "VICARIA_HOME": home},
        )
    except OSError as failure:
        with contextlib.suppress(OSError):
            CaptureStore(home).append_backlog_log(
                {"at": utc_now(), "outcome": "launch_failed", "detail": str(failure)}
            )
        return False
    return True


def run(
    harness: str,
    *,
    collector: Any = None,
    session_id: str | None = None,
    max_seconds: float | None = None,
) -> dict[str, Any] | None:
    """One worker, at most 60 seconds including queue scans and pending stops.

    The socket timeout bounds individual blocking reads, not a complete
    request. The alarm is a separate wall-time limit and releases the lock
    even if a server trickles data. Unacknowledged bytes remain queued.

    Returns the pass's backlog summary and when the next pass may start, or
    ``None`` when no pass ran (another worker, cooldown, backoff, opt-out).
    """
    seconds = MAX_SECONDS if max_seconds is None else max_seconds
    if harness not in HARNESS_NAMES or seconds <= 0:
        return
    from smart_gateway.capture.cli import resolve_credentials
    from smart_gateway.capture.collector import collector_for
    from smart_gateway.capture.hook import _home

    store = collector.store if collector is not None else CaptureStore(_home(harness))
    if not store.capture.is_dir() or store.opted_out():
        return
    if session_id is None and (_disabled(store) or _final_waiting(store)):
        return
    if collector is None:
        credentials = resolve_credentials(home=str(store.home))
        if credentials is None:
            return
        collector = collector_for(
            harness,
            org_id=credentials["org"],
            server=credentials["server"],
            token=credentials["token"],
            home=str(store.home),
            timeout_s=REQUEST_SECONDS,
            deadline_s=seconds - REQUEST_SECONDS - 1,
        )
    # Never unlink the lock: another process may already have opened its inode.
    with contextlib.ExitStack() as stack:
        if session_id is not None:
            stack.enter_context(_final_priority(store))
        fd = os.open(store.capture / "backlog.lock", os.O_CREAT | os.O_RDWR, 0o600)
        lock = stack.enter_context(os.fdopen(fd, "r+"))
        delivery_deadline = time.monotonic() + seconds
        lock_deadline = time.monotonic() + min(seconds, MAX_REQUEST_SECONDS + LOCK_GRACE_SECONDS)
        while True:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                # A Stop worker can still be sending when SessionEnd arrives.
                # The priority marker makes it yield before another request.
                # Bound even an uncooperative/older holder to one request plus
                # grace; background workers never queue behind each other.
                remaining = lock_deadline - time.monotonic()
                if session_id is None or remaining <= 0:
                    if session_id is not None:
                        store.append_backlog_log(
                            {"at": utc_now(), "outcome": "lock_busy", "session_id": session_id}
                        )
                    return
                time.sleep(min(0.05, remaining))
        seconds = delivery_deadline - time.monotonic()
        if seconds <= 0:
            return
        now = time.time()
        raw = lock.read()
        try:
            schedule = json.loads(raw) if raw else 0
            if isinstance(schedule, (int, float)) and math.isfinite(schedule):
                schedule = {"failures": 0, "next_attempt": schedule + COOLDOWN_SECONDS}
            if (
                not isinstance(schedule, dict)
                or not isinstance(schedule.get("failures"), int)
                or schedule["failures"] < 0
                or not isinstance(schedule.get("next_attempt"), (int, float))
                or not math.isfinite(schedule["next_attempt"])
            ):
                raise ValueError("invalid delivery schedule")
        except ValueError:
            # An unreadable schedule must not turn an outage into rapid retries.
            schedule = {"failures": 1, "next_attempt": now + BACKOFF_SECONDS}
            _save_schedule(lock, **schedule)
        failures = schedule["failures"]
        # Final delivery can bypass a healthy worker's ordinary cooldown, but
        # never an outage backoff. It shares the lock with automatic workers.
        if now < schedule["next_attempt"] and (session_id is None or failures):
            if session_id is not None:
                with contextlib.suppress(OSError):
                    store.append_backlog_log(
                        {
                            "at": utc_now(),
                            "outcome": "deferred",
                            "reason": "backoff",
                            "session_id": session_id,
                            "retry_after_s": schedule["next_attempt"] - now,
                        }
                    )
            return
        # Persist an uncertain attempt before network work. Even SIGKILL leaves
        # a conservative backoff; normal completion replaces it below. Not for
        # a session end: the harness cancelling it at exit is not an outage.
        # Claude Code `-p` cancels it on every turn, and the failure it left
        # stopped every worker for ~2 min after each headless session end
        # (Oct 24, 0.4.18). Workers still record real failures, and a session
        # end still honors them above.
        if session_id is None:
            _save_schedule(
                lock, failures=failures + 1, next_attempt=now + seconds + _backoff(failures + 1)
            )
        started = time.monotonic()
        if isinstance(collector.api, CaptureApi):
            stack.enter_context(
                collector.api.delivery_connection(
                    lambda row: store.append_transport_log({"at": utc_now(), **row}),
                    can_replay=lambda: (
                        not store.opted_out()
                        and (
                            session_id is not None
                            or (not _disabled(store) and not _final_waiting(store))
                        )
                    ),
                )
            )
        previous = signal.signal(signal.SIGALRM, _expired)
        signal.setitimer(signal.ITIMER_REAL, seconds)
        result: dict[str, Any] = {"outcome": "finished"}
        original_api = collector.api
        pass_deadline = time.monotonic() + seconds
        delivery_api = _DeliveryApi(
            original_api,
            store,
            automatic=session_id is None,
            deadline=pass_deadline,
            # Replaces the uncertain attempt saved above: no outage, and no new
            # worker until this pass's budget and a cooldown have passed. A
            # session end saved none, and a cancelled one must not leave this
            # wait (up to its budget plus the cooldown) behind either.
            on_progress=None
            if session_id is not None
            else lambda: _save_schedule(
                lock,
                failures=0,
                next_attempt=time.time()
                + max(0.0, pass_deadline - time.monotonic())
                + COOLDOWN_SECONDS,
            ),
        )
        collector.api = delivery_api
        try:
            # Stops must be delivered before any content. A transient failure
            # (including a non-timeout 5xx) ends this worker's attempt.
            states = store.sessions() if session_id is None else [store.session(session_id) or {}]
            for state in states:
                pending = state.get("pending_revoke")
                if isinstance(pending, dict) and pending.get("org_id") == collector.org_id:
                    outcome = collector._revoke_pending(str(state["session_id"]))
                    if outcome is not None and not outcome.ok:
                        result = {"outcome": "stop_deferred", "reason": outcome.reason}
                        break
            else:
                # Existing collector owns ordering, opt-out, scope and receipts.
                flushed = collector.flush(
                    session_id, head=HEAD_EVENTS if session_id is None else None
                )
                result = {
                    "outcome": "deferred" if flushed.get("deferred") else "finished",
                    "flush": flushed,
                }
        except _Deadline:
            result = {"outcome": "deadline"}
        except _Stopped:
            result = {"outcome": "deferred", "reason": delivery_api.reason}
        except _Yielded as yielded:
            result = {"outcome": "yielded", "reason": str(yielded)}
        except Exception as failure:
            result = {"outcome": "failed", "detail": f"{type(failure).__name__}: {failure}"}
        finally:
            signal.setitimer(signal.ITIMER_REAL, 0)
            signal.signal(signal.SIGALRM, previous)
            collector.api = original_api
            failed = delivery_api.reason or result["outcome"] in {"failed", "deadline"}
            if (
                failed
                and delivery_api.progressed
                and (
                    delivery_api.reason in TRANSIENT_REASONS
                    or (delivery_api.reason is None and result["outcome"] == "deadline")
                )
            ):
                # A pass that stored anything is not an outage (Oct 23: one
                # timed-out upload after 21 stored sent a 35k-event queue into
                # 900 s backoff and held every session end behind it).
                failed = False
            failures = failures + 1 if failed else 0
            delay = _backoff(failures) if failed else COOLDOWN_SECONDS
            next_attempt = time.time() + delay
            _save_schedule(lock, failures=failures, next_attempt=next_attempt)
            summary = {
                "at": utc_now(),
                "elapsed_s": time.monotonic() - started,
                **result,
                "session_id": session_id,
                "backoff_s": delay if failed else 0,
                "failure_reason": delivery_api.reason,
                "progressed": delivery_api.progressed,
            }
            with contextlib.suppress(OSError):
                store.append_backlog_log(summary)
    return {**summary, "next_attempt": next_attempt, "home": str(store.home)}


def _chains(summary: dict[str, Any] | None) -> bool:
    """A background pass that ran out of time while the service took its events."""
    if summary is None or summary["session_id"] is not None:
        return False
    if summary["progressed"] <= 0 or summary["failure_reason"] is not None or summary["backoff_s"]:
        return False
    if summary["outcome"] == "yielded":
        return summary.get("reason") == "budget"
    # The flush's own deadline (39 s of a 60 s pass) stops it as "deferred";
    # only that stop, with nothing else deferred, is a healthy one (sanjay,
    # #117 review: a request that crossed it ended the chain).
    flush = summary.get("flush") or {}
    return (
        summary["outcome"] == "deferred"
        and flush.get("out_of_time") is True
        and not flush.get("opted_out")
        and not (flush.get("later") or flush.get("refused") or flush.get("archive_failed"))
    )


def _paused(summary: dict[str, Any]) -> bool:
    """A background pass that gave way to a session end, with nothing wrong.

    A session end pauses the chain rather than ending it: Claude Code `-p`
    cancels its SessionEnd hook within seconds on every turn, so on James's
    Mac (Oct 24, 0.4.19) 8 of 9 Claude Code chains ended for a delivery that
    never completed, and its queue kept growing while Codex's fell.
    """
    return (
        summary["session_id"] is None
        and summary["outcome"] == "yielded"
        and summary.get("reason") == "session_end"
        and summary["failure_reason"] is None
        and not summary["backoff_s"]
    )


def _saved_schedule(store: CaptureStore) -> dict[str, Any] | None:
    """The schedule as the last pass or session end left it, read without the lock."""
    try:
        raw = (store.capture / "backlog.lock").read_text()
        schedule = json.loads(raw) if raw else 0
    except (OSError, ValueError):
        return None
    if isinstance(schedule, (int, float)) and math.isfinite(schedule):
        return {"failures": 0, "next_attempt": schedule + COOLDOWN_SECONDS}
    if (
        isinstance(schedule, dict)
        and isinstance(schedule.get("failures"), int)
        and isinstance(schedule.get("next_attempt"), (int, float))
        and math.isfinite(schedule["next_attempt"])
    ):
        return schedule
    return None


def _ready_for_next(summary: dict[str, Any], cap: float) -> bool:
    """Wait, holding no lock, until the next pass of a chain may start.

    That is once no session-end delivery is alive and the cooldown last saved
    has passed: a session end that completed meanwhile saved its own, which
    the next pass would otherwise refuse and end the chain without a word.
    False when the next pass could not end by ``cap``, checked again after
    every wait (a late wake), or when an outage backoff was recorded.
    """
    store = CaptureStore(summary["home"])
    due = summary["next_attempt"]
    while True:
        if time.monotonic() + MAX_SECONDS > cap:
            return False
        if _final_waiting(store):
            time.sleep(PAUSE_POLL_SECONDS)
            continue
        saved = _saved_schedule(store)
        if saved is not None:
            if saved["failures"]:
                return False
            due = max(due, saved["next_attempt"])
        # An unreadable schedule is left to the next pass, which reads it
        # under the lock and backs off as it always has.
        wait = due - time.time()
        if wait <= 0:
            return True
        if time.monotonic() + wait + MAX_SECONDS > cap:
            return False
        time.sleep(wait + 0.05)


def drain(harness: str) -> None:
    """Run background passes back to back while each one runs out of time taking events.

    A pass that gave way to a session end pauses the chain until no session-end
    delivery is alive. The chain stops after a pass that finished its head of
    the queue, failed, or stopped for the disable switch; when a pass cannot
    start (another worker holds the lock, backoff, opt-out); and before any
    pass that could not end by ``CHAIN_SECONDS`` after this started. Between
    passes it waits out the saved cooldown, holding no lock, so session ends
    and hook workers go first as before.
    """
    cap = time.monotonic() + CHAIN_SECONDS
    summary = run(harness)
    while summary is not None and (_chains(summary) or _paused(summary)):
        if not _ready_for_next(summary, cap):
            return
        summary = run(harness)


def main() -> int:
    try:
        drain(sys.argv[1] if len(sys.argv) == 2 else "")
    except Exception:
        # A missing/unwritable home cannot make the parent hook fail. No queue
        # file was settled; the next hook can retry once the home is usable.
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
