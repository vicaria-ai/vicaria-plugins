"""The capture notice, per harness, and the digest a grant is bound to.

The notice is not boilerplate and it is not one string reused everywhere.  It
has to say what *this* adapter actually sends, because an adapter that omits
tool outputs and a notice that says tool outputs are collected are a pair that
misleads in the developer's favour right up until the day the adapter starts
sending them.  So each harness has its own text and its own version, and the
grant the service issues binds the digest of the exact bytes that were shown.

Three rules the text has to keep, from the design's commitments:

* It names the authorized scope in those words — every turn including the
  developer's own, every tool call, every tool call's output, the contents of
  every file the agent read, session metadata.  "Share this session to help
  improve the product" does not satisfy the requirement.
* It states, in the developer's own words, that redaction is not complete and
  cannot be.
* Until the erasure path exists for a harness, it may say only that stopping
  ends further sending.  It gains "and you can delete a session that has
  already been sent" when that path ships, and not before: a notice that
  promises deletion against a system with no delete path is the single most
  damaging thing this design could ship.
* It names the decision-model provider a typed question about the task text
  may go to, and the stand-in while it is live (RFC 0034 §2.1), checked off
  the text like the scope: a new sub-processor is a changed notice.

A changed notice asks again at the next confirmation: a grant binds the bytes
the developer read, and a new notice binds new marks, not open intervals.  A
session already collecting under the earlier text continues until it ends or
is switched off; a mark or a resumed session is not re-checked against the
notice a later process shows.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

#: The scope every notice must name, in the contract's own words.
AUTHORIZED_SCOPE = (
    "every_turn_including_the_developers_own",
    "every_tool_call",
    "every_tool_calls_output",
    "contents_of_every_file_the_agent_read",
    "session_metadata",
)

#: What each of those tokens has to look like in English for the notice to have
#: named it. Any one phrase satisfies its token, so the sentence can be reworded
#: --- but not quietly emptied.
#:
#: This mapping is the whole point. ``AUTHORIZED_SCOPE`` sat here read by
#: nothing while ``coverage.py`` published its own copy of the same list as a
#: claim about this text, and ``states_redaction_is_incomplete`` was a literal
#: ``True`` beside it. Both are contract constants, so the document swore the
#: notice named the scope and admitted redaction was incomplete whatever the
#: notice said. A coverage document is supposed to be evidence about the
#: adapter; a constant nobody reads is decoration.
SCOPE_PHRASES: dict[str, tuple[str, ...]] = {
    "every_turn_including_the_developers_own": ("user and assistant messages",),
    "every_tool_call": ("tool calls",),
    # Deliberately only the scope sentence's phrasing. "tool outputs" was an
    # alternative here until the drop test below showed that _ACTUALLY_SENT's
    # own sentence -- "Tool inputs, tool outputs ... are omitted" -- satisfied
    # it, so a scope sentence that stopped naming outputs was covered by the
    # sentence saying they are not sent. An alternative that a denial can
    # satisfy is not a check.
    "every_tool_calls_output": ("inputs and outputs",),
    "contents_of_every_file_the_agent_read": ("file contents read", "contents of every file"),
    "session_metadata": ("session metadata",),
}

#: The phrase that carries the redaction admission. Checked, not declared.
REDACTION_ADMISSION = "no promise that sensitive material is removed"

#: The decision-model provider the advice sentence names (RFC 0034 §2.1), and the
#: phrase by which it admits the stand-in a policy may put in that provider's
#: place while RFC 0016's stand-in is live. Checked off the text, not declared.
DECISION_MODEL_PROVIDER = "TypeSafe AI"
STAND_IN_ADMISSION = "names a model of its own"

_SCOPE_SENTENCE = (
    "If you confirm, you authorize session-scoped capture from the next turn: "
    "user and assistant messages, tool calls and their inputs and outputs, file "
    "contents read, explicit feedback, and session metadata may be collected by "
    "an adapter under this authorization. Collection is not retroactive."
)

#: Nothing is redacted, and nothing will be (vicaria-docs RFC 0036 §3, RFC
#: 0039): the sentence says so outright, and keeps the phrase the coverage
#: document reads its admission off.
_REDACTION_SENTENCE = (
    "Nothing is redacted, and no redaction will be built: captured material is "
    "kept as it was sent, and no promise that sensitive material is removed is "
    "being made."
)

#: What the advice does with the task text when the organization's policy lets
#: Vicaria read it (RFC 0034 §2.1): the one notice names the sub-processor, so a
#: new provider or a new use of the text is a changed notice that asks again.
#: The stand-in (RFC 0016) is named too while it is live: under a policy that
#: names a model of its own, that model is sent the text, and the journaled
#: decision record's ``advisor`` block says so (``text_seen``); the plan the
#: harness receives does not carry it, so the sentence says the record, not the
#: plan. RFC 0035's stage 3 retires the stand-in.
_ADVICE_SENTENCE = (
    "Separately from capture, when your organization's policy lets Vicaria read your "
    "task text to advise you, Vicaria's decision-model provider, TypeSafe AI, may be "
    "asked a typed question about that text (whether the evidence applies; what the "
    "task's intent is): no identifier, token or other turn goes with it, and every "
    "such call is recorded in your organization's ledger. Where the policy instead "
    "names a model of its own (the stand-in, until Vicaria's evidence-backed advisor "
    "is published), that model is sent the text, and your organization's decision "
    "record says so. No other provider reads it."
)

#: What each adapter *actually* sends today, stated after the scope sentence so
#: the developer can see the gap between what is authorized and what is taken.
_ACTUALLY_SENT = {
    "claude-code": (
        "This Claude Code development adapter currently sends user and assistant "
        "message text, including the messages between tool calls, the model's thinking "
        "where Claude Code receives its text, each reply's token counts with the "
        "thinking tokens, tool names, inputs, outputs and completion states, subagent "
        "boundaries, the session end instant, feedback direction and length, and "
        "limited session metadata. Feedback goes with the comment as you typed it. "
        "The thinking, the messages between tool calls and the counts are read from "
        "this session's own transcript, the file Claude Code writes for it on this "
        "machine; nothing from other sessions is read. Attachments and the model are "
        "omitted."
    ),
    "codex": (
        "This Codex development adapter, the Vicaria plugin for Codex, currently sends "
        "user and assistant message text, the reasoning summaries Codex emits (the "
        "reasoning itself stays encrypted and is never seen), tool names, inputs, "
        "outputs and completion states as its hooks expose them, subagent boundaries, "
        "per-turn token counts with the reasoning and cache tokens, feedback typed as "
        "vicaria feedback with its comment, and limited session metadata. The "
        "summaries and counts are read from this session's own rollout, the file Codex "
        "writes for it on this machine; nothing from other sessions is read. "
        "Attachments are omitted."
    ),
}

_STOP_SENTENCE = {
    "claude-code": (
        "Run /vicaria:off to stop future collection; stopping does not erase material already sent."
    ),
    "codex": (
        "Type vicaria off in Codex, or run sg capture off --harness codex --session "
        "<this session's id>, to stop future collection; stopping does not erase "
        "material already sent."
    ),
}

_INDICATOR_SENTENCE = {
    "claude-code": (
        "Claude Code offers no persistent recording indicator. The mark is visible "
        "when it is made, and /vicaria:status says at any time whether this session "
        "is being collected; that is weaker than a persistent indicator and is "
        "stated rather than glossed."
    ),
    "codex": (
        "Codex offers no persistent recording indicator. The plugin says at a "
        "session's start whether it is collected, and vicaria status says it at any "
        "time, with the session's id; that is weaker than a persistent indicator and is "
        "stated rather than glossed."
    ),
}

#: The command that confirms. `sg capture confirm` refuses to run without
#: `--session` (Claude Code's names it from v7), and without `--harness codex`
#: it checks the receipt against Claude Code's notice, so a Codex receipt is
#: "no receipt; show the notice first" (Codex's names both from v6).
_CONFIRM_SENTENCE = {
    "claude-code": (
        "To confirm for this session, run: sg capture confirm --session <this session's id>"
    ),
    "codex": (
        "To confirm for this session, run: sg capture confirm --harness codex "
        "--session <this session's id>"
    ),
}

#: Bumped whenever any sentence above changes for that harness. A grant binds
#: the digest, so an edited notice invalidates confirmations made against the
#: old text rather than silently covering them.
VERSIONS = {
    # v2 for both: the v1 texts each claimed something the adapter does not do.
    # Claude Code's said it sends "the model Claude Code reports at session start"
    # and "token counts when the harness reports them" --- the adapter handles no
    # SessionStart event, no capture payload carries a model at all, and every
    # assistant message goes out with usage=None. Its own coverage document said
    # token_usage was not observed, so the two documents this adapter publishes
    # side by side contradicted each other. Codex's said it sends "reasoning
    # summaries when Codex emits them"; it records whether one existed and never
    # the content, on purpose. Moving the version is what stops a confirmation
    # taken against the old words silently covering the new ones.
    # v3 for Claude Code: v2's stop sentence named `/vicaria capture off`, the
    # OpenCode spelling, which no Claude Code command answered. `/vicaria off`
    # now exists on this harness (the capture hook answers it), so the notice
    # names the command a developer can actually run.
    # v4 for Claude Code and v3 for Codex (2026-09-27): the notice names TypeSafe
    # AI, the decision-model provider that may be asked a typed question about
    # the task text the organization's policy lets Vicaria read (RFC 0034 §2.1).
    # A new sub-processor is a changed notice, which asks again.
    # v5 and v4 (2026-09-27, later): the sentence names the stand-in a policy may
    # put in the provider's place while it is live, and says the organization's
    # decision record, not the plan, records the text being sent. The earlier
    # versions had named two texts on one unmerged branch; no environment
    # confirmed under either, and one version names one text again.
    # v6 and v5 (2026-09-27, the seventh review): "nothing else reads it" read
    # as nothing else reading the session, which the first sentences say is
    # collected and reviewed; the sentence says no other provider reads the
    # text. No environment confirmed under v5 or v4.
    # v7 for Claude Code (2026-09-27, after v6 reached main): v6 and every
    # version before it promised a one-line marker on every turn as the whole
    # of the indication. The marker went to stderr from a hook that exits 0,
    # which Claude Code does not show, so the promise was never kept; it is
    # dropped (RFC 0032 § 9.1, decided 2026-09-26) and the notice says what is
    # actually visible. v7 also names the plugin's commands, `/vicaria:off` and
    # `/vicaria:status`: `/vicaria off`, typed, is answered "Unknown command" by
    # Claude Code before any hook runs (checked on 2.1.280; see `claude_code`'s
    # module docstring), so v3 to v6 named a command nobody could run. And its
    # confirm line names `--session`, without which `sg capture confirm`
    # refuses to run. No environment confirmed under v7 before these.
    # v6 for Codex (2026-09-27, after v7 and v5 reached main): v5 and every version
    # before it told the reader to run `sg capture confirm` and `sg capture off`.
    # Both refuse to run without `--session`, and without `--harness codex`
    # each acts as Claude Code: the confirmation looks for a receipt of Claude
    # Code's notice and finds none, and the stop is recorded by the wrong
    # adapter. So nobody could confirm by following the notice. `sg capture
    # status`, which needs no session, reported Claude Code's harness and
    # notice version. v6 names `--harness codex` in all three, and `--session`
    # in the two that need it.
    # v8 and v7 (2026-09-27, later; vicaria-docs RFC 0039): tool inputs and
    # outputs are sent as the harness exposes them, and the redaction sentence
    # says nothing is redacted and none will be built, instead of "not built in
    # this development slice", which promised a stage RFC 0036 §3 rules out.
    # v9 and v8 (2026-09-29; vicaria-docs RFC 0048): the adapters send the
    # model's reasoning where the harness received it and the token counts,
    # read from the session's own transcript or rollout, and Codex has a
    # plugin whose commands the notice names.  A widened scope asks again.
    "claude-code": "claude-code-continuous-benchmark-2026-09-29-v9",
    "codex": "codex-continuous-benchmark-2026-09-29-v8",
}

for _harness in ("opencode",):
    VERSIONS[_harness] = f"{_harness}-terminal-capture-2026-09-28-v1"
    _ACTUALLY_SENT[_harness] = (
        "The terminal launcher records the prompt, assistant text, and tool inputs "
        "and outputs exposed by this run's JSON stream. Token counts, attachments and "
        "provider reasoning are not observed by this adapter. Nothing from other sessions is read."
    )
    _STOP_SENTENCE[_harness] = (
        "Close the terminal command to stop this run. Stopping keeps what was already "
        "sent. Delete the session in the website's Settings to erase it."
    )
    _INDICATOR_SENTENCE[_harness] = (
        "The launcher prints that recording is on before starting the harness."
    )
    _CONFIRM_SENTENCE[_harness] = (
        "Connect your harness on the website and review its sharing notice once, then "
        "use the terminal run command."
    )

SUPPORTED = tuple(sorted(VERSIONS))


@dataclass(frozen=True)
class Notice:
    """The exact bytes shown, their version, and the digest a grant binds."""

    harness: str
    version: str
    text: str

    @property
    def digest(self) -> str:
        return "sha256:" + hashlib.sha256(self.text.encode("utf-8")).hexdigest()

    @property
    def scope_not_named(self) -> tuple[str, ...]:
        """The authorized-scope tokens this text does *not* name, if any.

        Empty is the only publishable answer: the contract writes
        ``names_the_authorized_scope`` as a ``const``, so a coverage document
        for a notice that dropped one of these cannot be built rather than
        being built with a false claim in it.
        """
        lowered = self.text.lower()
        return tuple(
            token
            for token in AUTHORIZED_SCOPE
            if not any(phrase.lower() in lowered for phrase in SCOPE_PHRASES[token])
        )

    @property
    def states_redaction_is_incomplete(self) -> bool:
        """Whether the text admits redaction is not complete and cannot be."""
        return REDACTION_ADMISSION.lower() in self.text.lower()

    @property
    def names_the_decision_model_provider(self) -> bool:
        """Whether the text names the decision-model provider a typed question about
        the task text may go to (RFC 0034 §2.1)."""
        return DECISION_MODEL_PROVIDER in self.text

    @property
    def names_the_stand_in(self) -> bool:
        """Whether the text admits the stand-in a policy may put in the provider's
        place while RFC 0016's stand-in is live."""
        return STAND_IN_ADMISSION in self.text

    @property
    def promises_deletion(self) -> bool:
        """Whether the text promises deletion of material already sent.

        False for both harnesses today, and the coverage document has to agree:
        the erasure path exists on the service, but no adapter here has wired a
        client-side erasure request, so the notice may not offer one.
        """
        return "delete a session that has already been sent" in self.text


def notice_for(harness: str) -> Notice:
    """The notice for ``harness``, assembled from the sentences above."""
    if harness not in VERSIONS:
        raise ValueError(f"no capture notice for harness {harness!r}; have {list(SUPPORTED)}")
    text = "\n\n".join(
        [
            "This session was selected for Vicaria continuous benchmarking. " + _SCOPE_SENTENCE,
            _ACTUALLY_SENT[harness],
            _REDACTION_SENTENCE,
            _ADVICE_SENTENCE,
            _STOP_SENTENCE[harness],
            _INDICATOR_SENTENCE[harness],
            _CONFIRM_SENTENCE[harness],
        ]
    )
    return Notice(harness=harness, version=VERSIONS[harness], text=text)
