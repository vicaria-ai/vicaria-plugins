"""The Vicaria plugin for Codex: Codex's hooks, read as Claude Code's are.

Codex (checked on codex-cli 0.144.1, 2026-09-29) runs a plugin's hooks from
``.codex-plugin/plugin.json`` with the same events and nearly the same
payloads as Claude Code: ``SessionStart`` (``source``), ``UserPromptSubmit``
(``prompt``), ``PreToolUse`` and ``PostToolUse`` (``tool_name``,
``tool_input``, ``tool_use_id``, ``tool_response``), ``Stop``
(``last_assistant_message``), ``SubagentStart``/``SubagentStop``, and every
payload carries ``session_id``, ``turn_id``, ``model`` and
``transcript_path``, the session's rollout.  So the plugin runs the same hook
(:mod:`smart_gateway.capture.hook`), and this module is the difference:

- **The commands are typed as a prompt.**  Codex answers ``/vicaria off`` with
  "Unrecognized command" before any hook runs, and a plugin registers no slash
  commands, so ``vicaria off`` (or ``$vicaria off``) typed as the whole prompt
  is the switch.  :func:`normalize` turns it into the plugin-command shape the
  Claude Code adapter answers, and the hook answers it with
  ``{"continue": false, "stopReason": ...}``, which Codex shows as "stop: …"
  and sends to no model.
- **The words.**  A line a person reads names ``vicaria off``, not
  ``/vicaria:off`` (:func:`words`).
- **The prompt id** is Codex's ``turn_id``.
- **The version** Codex names to no hook; the rollout's first record carries
  it (:func:`transcripts.codex_version`).
- **When the queue leaves.**  Codex 0.144.1 fires no ``SessionEnd`` (not at
  ``/quit``, not at the end of ``codex exec``), and that is where the Claude
  Code plugin used to upload. Both plugins now offer their home-wide backlog
  after turns through :mod:`smart_gateway.capture.background`, so no turn
  waits on the network and ended sessions get another delivery attempt.

Codex runs a plugin's hooks only once the person trusts them: the first
``codex`` after the install asks ("Hooks need review"), and untrusted hooks
are skipped without a word.  The website's setup guide says to choose "Trust
all and continue".
"""

from __future__ import annotations

import re
from typing import Any

from smart_gateway.capture import transcripts
from smart_gateway.capture.claude_code import PLUGIN_COMMANDS, PLUGIN_COMMANDS_WITH_ARGS

HARNESS = "codex"

#: The switch, typed as the whole prompt: ``vicaria off``, ``$vicaria off``
#: (Codex's mention form) or ``vicaria:off``, with the arguments ``connect``
#: and ``feedback`` take.  Anchored, and only the plugin's own verbs, so a
#: prompt that merely starts with the word is a prompt like any other.
COMMAND = re.compile(
    r"^\s*\$?vicaria(?::|\s+)\s*([a-z]+)(?:\s+(.*?))?\s*$", re.IGNORECASE | re.DOTALL
)


def command_of(prompt: Any) -> tuple[str, str | None] | None:
    """``("vicaria:off", None)`` for a prompt that is the switch, else None.

    A verb given an argument it does not take is not the switch --- ``vicaria
    off now`` is a prompt --- and it is refused *here*, before the payload is
    reshaped.  Reshaping first and letting the command reader refuse it left
    the prompt as neither: the adapter handles no expansion event, so it was
    never recorded and the turn never advanced, and the tool calls after it
    joined the turn before (found in review, 2026-09-30).  The shim's own
    reader makes the same check, in sh.
    """
    if not isinstance(prompt, str):
        return None
    matched = COMMAND.match(prompt)
    if not matched:
        return None
    name = f"vicaria:{matched.group(1).lower()}"
    if name not in PLUGIN_COMMANDS:
        return None
    args = matched.group(2) or None
    if args is not None and name not in PLUGIN_COMMANDS_WITH_ARGS:
        return None
    return name, args


def normalize(payload: dict[str, Any]) -> dict[str, Any]:
    """A Codex hook payload in the shape the Claude Code adapter reads."""
    shaped = dict(payload)
    turn = payload.get("turn_id")
    if isinstance(turn, str) and turn and not shaped.get("prompt_id"):
        shaped["prompt_id"] = turn
    if payload.get("hook_event_name") == "UserPromptSubmit":
        command = command_of(payload.get("prompt"))
        if command is not None:
            name, args = command
            shaped.update(
                hook_event_name="UserPromptExpansion",
                command_source="plugin",
                command_name=name,
                command_args=args or "",
            )
    if not shaped.get("harness_version"):
        path = payload.get("transcript_path")
        version = transcripts.codex_version(path) if isinstance(path, str) and path else None
        if version:
            shaped["harness_version"] = version
    return shaped


def advice(
    payload: dict[str, Any], *, device: dict[str, Any] | None = None, budget_s: float = 5.0
) -> str | None:
    """What the plan recommends for this prompt, as the person reads it, or None.

    Asked at ``UserPromptSubmit`` under Codex's turn id (:func:`normalize` made
    it the prompt id), so the decision and the captured prompt name one
    prompt.  Only when a control configuration names a plan source; a command
    is not a prompt and asks nothing.  Never fails the turn.
    """
    if payload.get("hook_event_name") != "UserPromptSubmit":
        return None
    session_id, prompt = payload.get("session_id"), payload.get("prompt")
    if not isinstance(session_id, str) or not session_id or not isinstance(prompt, str):
        return None
    from smart_gateway.control import codex as control

    prompt_id = payload.get("prompt_id")
    advised = control.advise(
        session_id, prompt, prompt_id=prompt_id if isinstance(prompt_id, str) else None,
        device=device, model=payload.get("model"), effort=payload.get("reasoning_effort"),
        harness_version=payload.get("harness_version"),
        budget_s=budget_s,
    )
    return advised.message


def words(line: str) -> str:
    """A line for a person, with the commands as Codex takes them."""
    return line.replace("/vicaria:", "vicaria ")


def after_event(collector: Any, payload: dict[str, Any], *, flush: Any = None) -> bool:
    """After a turn's ``Stop`` on a session being collected, offer its queue.

    The one place the Codex plugin uploads, since Codex fires no
    ``SessionEnd``; returns whether an offer was started.
    """
    session_id = payload.get("session_id")
    if payload.get("hook_event_name") != "Stop":
        return False
    if not isinstance(session_id, str) or not session_id or not collector.active(session_id):
        return False
    return (flush or flush_in_background)(session_id)


def flush_in_background(session_id: str) -> bool:
    """Compatibility entry: new hooks schedule a bounded home-wide worker."""
    from smart_gateway.capture.background import launch
    from smart_gateway.capture.hook import _home
    from smart_gateway.capture.store import CaptureStore

    return launch(HARNESS, home=str(CaptureStore(_home(HARNESS)).home))
