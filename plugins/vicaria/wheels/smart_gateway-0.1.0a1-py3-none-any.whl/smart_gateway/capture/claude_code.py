"""Claude Code capture: one hook invocation at a time.

A Claude Code hook is a process that starts, reads one JSON object on stdin, and
exits.  Nothing survives between invocations except what was written to disk, so
this module is a pure mapping from one hook payload to at most one capture
event, with the session's turn counter living in the client home.

The invariant that matters most here is **off is silent**.  An unmarked session
must write nothing, open no file beyond the session lookup, and print nothing:
a hook that announced itself on every prompt of every session would make capture
feel switched on for people who never switched it on.  So :func:`handle` returns
``None`` for an unmarked session before it looks at anything else, and the hook
shim discards stdout anyway.

Which hooks carry what
----------------------
=====================  ===================================================
``UserPromptSubmit``   ``prompt`` — the developer's text. Advances the turn.
``PreToolUse``         ``tool_name`` — the name, not the input (see coverage).
``PostToolUse``        success or failure of the call that just ran.
``Stop``               ``last_assistant_message`` — the turn's final message.
``StopFailure``        the turn ended in an error; no message text.
``SubagentStart/Stop`` a subagent boundary on the parent session.
``SessionEnd``         the session is over: capture stops, queue is flushed.
=====================  ===================================================

``Stop`` carries only the *final* assistant message of a turn, and no hook
carries a thinking block or a token count.  The session's transcript, which
every payload names in ``transcript_path``, carries all three, response by
response (:mod:`smart_gateway.capture.transcripts`).  So the adapter reads it
from a cursor (vicaria-docs RFC 0048): at ``PreToolUse`` every response written
since the last read is recorded as a ``continuing`` message with its text,
thinking and counts, before the tool call it asked for; at ``Stop`` the rest
are, and the final one's thinking and counts go on the turn's closing message.
A thinking block Claude Code received without its text (it asks for the text
only when ``showThinkingSummaries`` is on) is said in the message's omission.

Codex's plugin arrives here too (:mod:`smart_gateway.capture.codex_plugin`
turns its payloads into these shapes); its rollout writes a response's counts
only after the call's result, so its reasoning and counts are read per turn,
at ``Stop``.

The other authority: standing consent
-------------------------------------
On a linked device (``sg capture link``) the person agreed once, on the
website, and every session is captured unless they switch it off.  That is
the fourth gate inverted --- and it is *not* implemented by skipping the gate.
``SessionStart`` mints the session's interval from the standing consent
(:meth:`CaptureCollector.mint_from_standing_consent`, a server round trip that
returns the same immutable grant a per-session mark returns) and writes the
session state ``active``; the gate then reads that state exactly as before.
A session with no state stays silent, as it always did, because on an
unlinked machine nothing mints one.  The switch is the plugin's own commands:
``/vicaria:off`` closes the interval, ``/vicaria:on`` mints a new one from this
turn, and ``/vicaria:status`` prints one line; :func:`command` answers all
three locally. In Desktop the hook supplies the result to the command template,
which asks Claude to repeat it as a normal reply. The CLI stops locally.

The commands arrive at ``UserPromptExpansion``, not ``UserPromptSubmit``.
Claude Code answers a slash command it does not know --- ``/vicaria off``
typed as a prompt --- with "Unknown command" and runs no hook at all (checked
against Claude Code 2.1.280 on 2026-09-24), so the prompt form this module
first answered could never be typed.  A command the plugin registers
(``commands/off.md`` in a plugin named ``vicaria``) is announced to
``UserPromptExpansion`` with its name and arguments before it expands, and a
hook supplies Desktop's actual result as context for the command template.
The CLI keeps ``stopReason``, which Desktop could hide in earlier releases.
The prompt form is still answered locally for a harness that delivers it.
"""

from __future__ import annotations

import contextlib
import json
import re
from collections.abc import Callable
from dataclasses import replace
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from smart_gateway.capture import events as event_builder
from smart_gateway.capture import question, transcripts
from smart_gateway.capture.collector import NOTICE_CHANGED, CaptureCollector, CaptureRefused

#: The switch, typed as a prompt.  Anchored, so a sentence that merely mentions
#: the command is a prompt like any other.
COMMAND = re.compile(
    r"^\s*/vicaria\s+(?:(on|off|status)|(feedback)(?:\s+(.*?))?)\s*$", re.IGNORECASE
)

#: The switch as the plugin registers it: ``commands/on.md``, ``off.md`` and
#: ``status.md`` in the plugin named ``vicaria``, which Claude Code names
#: ``vicaria:on`` and so on.  Only a plugin's command counts, so a project
#: command that happens to share the name is left to the project.
PLUGIN_COMMANDS = {
    "vicaria:on": "on",
    "vicaria:off": "off",
    "vicaria:status": "status",
    "vicaria:feedback": "feedback",
    "vicaria:connect": "connect",
    "vicaria:yes": "yes",
    "vicaria:partly": "partly",
    "vicaria:no": "no",
}

#: The commands that take an argument: ``/vicaria:connect <server>``.
PLUGIN_COMMANDS_WITH_ARGS = {"vicaria:connect", "vicaria:feedback"}

#: What the person reads when the switch is thrown, in the notice's words
#: (collected, sent, delete) and never ours.  Stopping is not erasing, and
#: the line says where deletion lives.
OFF_LINE = (
    "Vicaria: off for this session. Nothing more from it is collected; what was already "
    "sent stays until you delete it on the website. /vicaria:on turns it back on."
)
ON_LINE = "Vicaria: on for this session, from your next prompt."
ALREADY_ON_LINE = "Vicaria: already on for this session."
NO_LINK_LINE = "Vicaria isn't connected on this computer. Type /vicaria:connect to connect it."
#: `/vicaria:feedback up|down [comment]` (RFC 0039): recorded with the session,
#: comment and all, on the turn just answered.
FEEDBACK_LINE = "Vicaria: noted, thumbs {direction} on the last reply{tail}."
NOT_COLLECTING_LINE = (
    "Vicaria isn't collecting this session, so nothing was recorded. /vicaria:on turns it on."
)
BAD_FEEDBACK_LINE = (
    "Vicaria: type /vicaria:feedback up or /vicaria:feedback down, with a comment after it "
    "if you like."
)
#: Feedback marks the reply just above it, in the session it was given in.
#: Given before any prompt of the session, or right after a resume (the
#: interval starts at the next turn), there is no reply inside this
#: session's collection to mark: recording one would anchor a turn the
#: service refuses (turn -1, or a turn before the interval), and the person
#: would be told "noted" for a mark that never arrived (found on
#: 2026-09-28: four such marks dropped as contract violations).
NO_REPLY_TO_MARK_LINE = (
    "Vicaria: nothing to mark yet in this session. /vicaria:feedback marks the reply just "
    "above it, so give it after a reply here."
)
#: The machine opt-out, as ``/vicaria:on`` and the answer commands say it.
#: Only a connected computer reaches either (an organization's ``on`` says
#: :data:`NO_LINK_LINE`), so it is said in the person's words: the opt-out
#: is a developer's switch, and its command is not the person's to type.
OPTED_OUT_LINE = "Vicaria is turned off on this computer, so nothing is sent."
OFF_BEFORE_MINT_LINE = (
    "Vicaria: off for this session; nothing from it will be sent. /vicaria:on turns it back on."
)
#: ``off`` before anything was opened, on an opted-out computer: reached on
#: a connected computer alone, like :data:`OPTED_OUT_LINE`.
OFF_BEFORE_MINT_OPTED_OUT_LINE = (
    "Vicaria: off for this session. Vicaria is turned off on this computer too, so nothing "
    "is sent, and this session stays off until /vicaria:on."
)
ALREADY_OFF_LINE = "Vicaria: already off for this session; nothing is being sent."
OFF_STANDS_ANSWER = (
    "Vicaria: off for this session; it was switched off while it was turning on. "
    "/vicaria:on turns it back on."
)
#: ``off`` on an opted-out computer with a session on.  Two lines, because
#: both paths reach it: an organization's developer reads the first, with
#: the terms of the tool they installed; a person reads the second.
OFF_OPTED_OUT_LINE = (
    "vicaria capture: off for this session; this machine is opted out, so nothing was being "
    "sent and the service is not told (the website shows the session shared until you stop "
    "it there)."
)
PERSON_OFF_OPTED_OUT_LINE = (
    "Vicaria: off for this session. Vicaria is turned off on this computer, so nothing was "
    "being sent; the website shows this session as shared until you stop it there."
)
#: ``off`` whose stop could not be completed: the decision is on disk and
#: nothing more is sent, which is what the person needs to know.  The
#: organization's line (inline in :func:`command`) names the refusal.
PERSON_OFF_UNFINISHED_LINE = (
    "Vicaria: off for this session; nothing more from it is sent. /vicaria:on turns it back on."
)
#: A command whose work failed on a connected computer.  The failure itself
#: is in the developer's drop log; the person is told what to do.
COMMAND_FAILED_LINE = (
    "Vicaria: that command didn't finish. Try it again in a moment; "
    "/vicaria:status says what is on."
)

#: How many of a session's most recent tool calls the cursor remembers having
#: recorded.  Only enough that the hooks running at one time can each find
#: their own call without waiting for a response another already took.
RECENT_CALLS = 64

#: A session starting on a connected computer says one line (RFC 0032 §2);
#: a session whose start did not mint says it at the prompt that does
#: (:func:`handle`).  With /vicaria:status that is the whole of what a person
#: is told while it collects; the per-turn marker is dropped (RFC 0032 § 9.1).
START_ON_LINE = "Vicaria: on · /vicaria:off pauses this session"
START_OFF_LINE = "Vicaria: off for this session · /vicaria:on turns it back on"
#: Nothing minted and nothing refused: said as it is rather than as on.
START_NOT_COLLECTING_LINE = "Vicaria: not collecting this session · /vicaria:on turns it on"
NOTICE_PAUSED_LINE = (
    "Vicaria: sharing is paused because its notice needs checking. "
    "/vicaria:on checks it before collecting again."
)
#: The retry is paced (:data:`UNREACHABLE_RETRY_S`): a prompt inside the
#: minute tries nothing, so the line does not promise the next prompt.
START_UNREACHABLE_LINE = (
    "Vicaria: couldn't reach {server}, so this session isn't collected yet. "
    "It tries again at your prompts, at most once a minute; /vicaria:on tries now."
)
ON_UNREACHABLE_LINE = (
    "Vicaria: couldn't reach {server}, so this session isn't collected. "
    "Try /vicaria:on again in a moment."
)
START_OPTED_OUT_LINE = "Vicaria: off on this computer (opted out); nothing is collected."
NOT_CONNECTED_LINE = "Vicaria is installed. Type /vicaria:connect to turn it on."

#: Why a session is not collected, when the service said no, by the
#: service's own name for it.  Anything else is said with its detail.
REFUSED_LINES = {
    "no_standing_consent": (
        "Vicaria: sharing isn't on for your account, so this session isn't collected. "
        "Turn it on at {site}."
    ),
    "consent_withdrawn": (
        "Vicaria: sharing is off for your account, so this session isn't collected. "
        "Turn it back on in Settings at {site}."
    ),
    "notice_changed": (
        "Vicaria: what Vicaria collects changed, so this session isn't collected until you "
        "agree to it at {site}."
    ),
    "session_erased": (
        "Vicaria: this session was deleted on the website, so nothing more from it is collected."
    ),
    "session_belongs_to_another_device": (
        "Vicaria: this session was started on another computer, so it isn't collected here."
    ),
}
#: Any other refusal.  The service's own words stay in the developer's drop
#: log (the collector writes them there); they are not the person's, and a
#: detail such as "this session id was minted from another device" is
#: nothing but our terms.
REFUSED_LINE = "Vicaria: this session isn't collected (the server refused it)."
#: A stop made under the other connection this computer holds (an
#: organization's, or a link to another account) has not reached the
#: website, and a new interval here waits for it.  The command that
#: delivers it is a developer's, and is in their drop log.
UNDELIVERED_STOP_LINE = (
    "Vicaria: this session was switched off under another connection on this computer, and "
    "the website hasn't been told yet, so it isn't collected here."
)
#: A computer removed on the website, as the answer commands say it too:
#: defined in :mod:`~smart_gateway.capture.question`, which this module
#: imports, and re-exported under the names the session start uses.
DISCONNECTED_ERRORS = question.DISCONNECTED_ERRORS
DISCONNECTED_LINE = question.DISCONNECTED_LINE

#: How long a session whose mint could not reach the service waits before a
#: prompt tries again.  Long enough that an offline laptop does not pay a
#: connect timeout on every keystroke; short enough that a VPN coming back is
#: noticed within the session.
UNREACHABLE_RETRY_S = 60.0

#: Hooks this adapter maps. Anything else is ignored rather than guessed at.
HANDLED = (
    "SessionStart",
    "UserPromptSubmit",
    "PreToolUse",
    "PostToolUse",
    "PostToolUseFailure",
    "Stop",
    "StopFailure",
    "SubagentStart",
    "SubagentStop",
    "SessionEnd",
)


#: Claude Code names itself to every hook in ``AI_AGENT``, as
#: ``claude-code_2-1-280_harness``; no hook payload carries the version.
AGENT_VERSION = re.compile(r"^claude-code_(\d+(?:-\d+){1,3})(?:_|$)")


def harness_version_from(environ: Any) -> str | None:
    """The running Claude Code's version, ``2.1.280``, from the hook's
    environment, or None.  The advice pool compares harness versions, and a
    session recorded as ``unknown`` joins no cell that can be compared."""
    matched = AGENT_VERSION.match(str(environ.get("AI_AGENT") or ""))
    return matched.group(1).replace("-", ".") if matched else None


def _stored_turn(state: dict[str, Any] | None) -> int | None:
    """The session's current turn, or None when it has had none.

    Written as an explicit None test rather than ``or -1``: turn 0 is falsy, so
    the shorter spelling reads the first turn as "no turn yet" and every prompt
    after the first stays on turn 0. Every event of a session then lands in one
    turn, which the service accepts and which makes the whole session read as a
    single exchange.
    """
    if state is None:
        return None
    value = state.get("turn_index")
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _first_consented_turn(state: dict[str, Any] | None) -> int:
    """The first turn the session's current interval covers, 0 when unknown:
    a resumed session is minted again from the next turn, so the reply before
    the resume is outside what this interval may carry."""
    authorization = (state or {}).get("authorization") or {}
    value = authorization.get("first_consented_turn")
    return value if isinstance(value, int) and not isinstance(value, bool) else 0


def _turn(collector: CaptureCollector, session_id: str) -> int:
    turn = _stored_turn(collector.store.session(session_id))
    return 0 if turn is None else turn


def _advance_turn(collector: CaptureCollector, session_id: str) -> int:
    # A read-modify-write of the state, like the collector's own: under the
    # session lock, so a Stop hook still writing the previous turn cannot
    # save its copy over this one.
    with collector.store.session_lock():
        state = collector.store.session(session_id)
        if state is None:
            raise KeyError(session_id)
        current = _stored_turn(state)
        turn = 0 if current is None else current + 1
        state["turn_index"] = turn
        collector.store.save_session(state)
    return turn


def command_verb(payload: dict[str, Any]) -> str | None:
    """``on``, ``off`` or ``status`` when this payload is the switch, else None.

    Two forms: the plugin's command announced at ``UserPromptExpansion``
    (``vicaria:off`` with no arguments), and ``/vicaria off`` typed as a
    prompt at ``UserPromptSubmit``.  A command given arguments it does not
    take is not the switch: ``/vicaria:off now`` expands to the command's
    own text, which says so.
    """
    session_id = payload.get("session_id")
    if not isinstance(session_id, str) or not session_id:
        return None
    event = payload.get("hook_event_name")
    if event == "UserPromptExpansion":
        if payload.get("command_source") != "plugin":
            return None
        name = str(payload.get("command_name") or "").lower()
        args = payload.get("command_args")
        given = args not in (None, "") and not (isinstance(args, str) and not args.strip())
        if given and name not in PLUGIN_COMMANDS_WITH_ARGS:
            return None
        return PLUGIN_COMMANDS.get(name)
    if event != "UserPromptSubmit":
        return None
    prompt = payload.get("prompt")
    if not isinstance(prompt, str):
        return None
    matched = COMMAND.match(prompt)
    return (matched.group(1) or matched.group(2)).lower() if matched else None


def is_command(payload: dict[str, Any]) -> bool:
    """Whether this payload is the switch, in either form.

    The one predicate, used by :func:`command` and by the hook before it
    builds anything: a command has to be answered even when the work behind
    it fails, so the hook needs to know it is one first.
    """
    return command_verb(payload) is not None


def is_plugin_command_prompt(payload: dict[str, Any]) -> bool:
    """The submit event used to display a namespaced plugin command's reply.

    Desktop continues after UserPromptExpansion so Claude can display the
    result. Its UserPromptSubmit carries the original /vicaria:... prompt,
    without the expansion metadata. Recognize only our valid command forms;
    this does not execute the command a second time.
    """
    if payload.get("hook_event_name") != "UserPromptSubmit":
        return False
    prompt = payload.get("prompt")
    if not isinstance(prompt, str):
        return False
    parts = prompt.strip().split(maxsplit=1)
    if not parts or not parts[0].startswith("/"):
        return False
    name = parts[0][1:].lower()
    return name in PLUGIN_COMMANDS and (len(parts) == 1 or name in PLUGIN_COMMANDS_WITH_ARGS)


def command(
    collector: CaptureCollector, payload: dict[str, Any], *, standing: bool = False
) -> str | None:
    """Answer the switch, ``/vicaria:on|off|status``, or ``None``.

    The plugin's command at ``UserPromptExpansion``, or a ``UserPromptSubmit``
    whose whole prompt is ``/vicaria on|off|status``.  The answer is one line
    for the person; the hook shows it and stops the command there, so it is
    never sent to the model.  ``off`` closes the
    interval through :meth:`CaptureCollector.stop` with the ``switch_off``
    gesture; ``on`` mints a new interval from this turn through the standing
    consent, which is the only authority a prompt can invoke (a per-session
    confirm needs the notice shown and the receipt written) and which needs
    the device link to be the credential in use --- ``standing`` says so, from
    the same resolution the hook made, rather than from a file that may exist
    beside an organization's variables; ``status`` reads files and asks the
    service nothing.  The machine opt-out beats every ``on``.
    """
    verb = command_verb(payload)
    if verb is None:
        return None
    session_id = payload["session_id"]
    if verb == "connect":
        from smart_gateway.capture import connect

        expansion = payload.get("hook_event_name") == "UserPromptExpansion"
        args = payload.get("command_args") if expansion else None
        return connect.command(
            collector.store,
            args if isinstance(args, str) else None,
            session_id=session_id,
            harness_version=collector.adapter.harness_version,
        )
    if verb == "status":
        if standing:
            return person_status_line(collector, session_id)
        line = collector.status_line(session_id)
        if collector.adapter.harness == "codex":
            # Codex mints its session id, and no flag names one in advance: an
            # organization's developer confirms the session by this id, as the
            # notice's confirm line says.
            line += f" · session {session_id}"
        return line
    if verb == "feedback":
        return _feedback(collector, payload, session_id, standing=standing)
    if verb in question.ANSWERS:
        if not standing or collector.store.device() is None or collector.api is None:
            return NO_LINK_LINE
        if collector.store.opted_out():
            return OPTED_OUT_LINE
        return question.answer(collector.store, collector.api, session_id, verb)
    state = collector.store.session(session_id)
    if verb == "off":
        if state is not None and state.get("active"):
            if collector.store.opted_out():
                # Gate 2: an opted-out machine sends nothing, the switch
                # included.  The state is turned off on disk and the service
                # is not told; the interval it holds admits nothing anyway.
                # An active state already names the credential that minted
                # it, and keeps it, as `stop` would: a device-minted session
                # stays the device's, an organization's the organization's.
                collector.switch_off_before_mint(session_id, rescope=False)
                return PERSON_OFF_OPTED_OUT_LINE if standing else OFF_OPTED_OUT_LINE
            try:
                stopped = collector.stop(
                    session_id, reason="developer_unmarked", gesture="switch_off"
                )
            except CaptureRefused as refusal:
                if standing:
                    return PERSON_OFF_UNFINISHED_LINE
                return (
                    f"vicaria capture: could not switch off cleanly ({refusal.detail}); "
                    "nothing further is queued for this session."
                )
            if not stopped.get("stopped"):
                # Something turned the state off between the read above and
                # the stop's lock, and the decision was not written.  On the
                # device path a `SessionEnd` (an ended state, which a resume
                # would mint over) is written as the branch below writes it,
                # this link's decision; anything else, and every state under
                # an organization's credentials, is written as the
                # already-off branch writes it, keeping the state's own
                # workspace.  Over an opt-out too, on disk alone, so it
                # stands after `--undo`.
                now = collector.store.session(session_id)
                ended = now is None or now.get("stop_reason") in (
                    "service_unreachable",
                    "session_ended",
                )
                if standing or now is not None:
                    collector.switch_off_before_mint(session_id, rescope=standing and ended)
            return OFF_LINE
        reopenable = state is None or state.get("stop_reason") in (
            "service_unreachable",
            "session_ended",
        )
        if standing and reopenable:
            # No interval yet on a linked machine, a state this process
            # cannot read, or one a resume or a retry would reopen: the next
            # start or prompt would mint.  The person said not to, and
            # "already off" would have been a lie the next mint exposed.
            # Written in the shape a closed interval leaves, which is where
            # the mint looks first.  On an opted-out machine nothing would
            # mint now, but `sg capture opt-out --undo` would let the next
            # prompt mint: the decision is written there too, on disk alone.
            collector.switch_off_before_mint(session_id)
            if collector.store.opted_out():
                return OFF_BEFORE_MINT_OPTED_OUT_LINE
            return OFF_BEFORE_MINT_LINE
        if state is not None:
            # Already off, and said again: written again, so a `/vicaria on`
            # or an organization's re-`confirm` in flight from another
            # terminal finds a switch-off later than the one it set out from
            # and lets it stand (over an opt-out too, on disk alone).  The
            # state keeps its own workspace and server, under either
            # credential.  A session with no state under an organization's
            # credentials, where nothing mints, is left with none.
            collector.switch_off_before_mint(session_id, rescope=False)
        return ALREADY_OFF_LINE
    if not standing or collector.store.device() is None:
        return NO_LINK_LINE
    if collector.store.opted_out():
        return OPTED_OUT_LINE
    if state is not None and state.get("active"):
        return ALREADY_ON_LINE
    try:
        collector.mint_from_standing_consent(session_id)
    except CaptureRefused as refusal:
        if refusal.reason == "unreachable":
            return ON_UNREACHABLE_LINE.format(server=collector.server)
        return refused_line(refusal, collector.server)
    if not collector.active(session_id):
        # Switched off from another terminal while the mint was in flight:
        # the collector said so, and "on" would be the switch thrown and
        # nothing switched.
        return OFF_STANDS_ANSWER
    return ON_LINE


def _feedback_args(payload: dict[str, Any]) -> tuple[str, str | None] | None:
    """``(direction, comment)`` from the command's arguments, or None when they
    do not start with ``up`` or ``down``."""
    if payload.get("hook_event_name") == "UserPromptExpansion":
        raw = payload.get("command_args")
    else:
        matched = COMMAND.match(str(payload.get("prompt") or ""))
        raw = matched.group(3) if matched else None
    words = str(raw or "").strip().split(None, 1)
    if not words or words[0].lower() not in ("up", "down"):
        return None
    comment = words[1].strip() if len(words) > 1 else ""
    return words[0].lower(), (comment or None)


def _feedback(
    collector: CaptureCollector, payload: dict[str, Any], session_id: str, *, standing: bool
) -> str:
    """Record ``/vicaria:feedback up|down [comment]`` on the turn just answered.

    Zero tokens: answered here and never sent to the model.  The comment goes
    as typed (RFC 0039); an uncollected session records nothing and says so.
    """
    parsed = _feedback_args(payload)
    if parsed is None:
        return BAD_FEEDBACK_LINE
    direction, comment = parsed
    if standing and collector.store.device() is None:
        return NO_LINK_LINE
    if collector.store.opted_out():
        return OPTED_OUT_LINE
    if not collector.active(session_id):
        return NOT_COLLECTING_LINE
    state = collector.store.session(session_id)
    turn = _stored_turn(state)
    if turn is None or turn < 0 or turn < _first_consented_turn(state):
        return NO_REPLY_TO_MARK_LINE
    try:
        collector.record_feedback(
            session_id,
            turn_index=turn,
            direction=direction,
            comment=comment,
        )
    except CaptureRefused:
        return NOT_COLLECTING_LINE
    return FEEDBACK_LINE.format(direction=direction, tail=", with your comment" if comment else "")


def _seconds_since(stamp: Any) -> float | None:
    """Seconds since an RFC 3339 instant the store wrote, or None if unreadable."""
    if not isinstance(stamp, str) or not stamp:
        return None
    try:
        then = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    except ValueError:
        return None
    if then.tzinfo is None:
        then = then.replace(tzinfo=UTC)
    return (datetime.now(UTC) - then).total_seconds()


def _mint_if_needed(
    collector: CaptureCollector,
    session_id: str,
    *,
    resumed: bool,
    at_prompt: bool = False,
) -> CaptureRefused | None:
    """Open an interval from the standing consent where one should be open.

    A session with no state at all is new: mint at turn 0.  A session whose
    interval the harness closed (``session_ended``) and that Claude Code now
    resumes is minted again from the next turn.  A session the person
    switched off stays off, whether or not it ever had an interval: their
    decision stands until they type ``/vicaria on``.  A session whose mint
    could not reach the service is tried again at a session start, and at a
    prompt only once :data:`UNREACHABLE_RETRY_S` has passed.  A state file
    this process cannot read is not a session nobody decided about, so it
    never mints.  A refusal writes no state (an opt-out that overtook the
    request leaves the interval the service opened saved), and leaves a
    drop-log line only at a session start (the collector writes it; a prompt's
    retry and an overtaken mint leave none).  An unreachable service is
    recorded on the state and re-raised, so the hook leaves its one line.
    Any other refusal is returned, so a session start can say why.

    Gate 2 is read first: the machine opt-out beats every setting above it,
    the website's standing consent included, and a mint is a write on the
    service and on this disk that an opted-out machine must never make.
    """
    if collector.store.opted_out():
        return None
    # Validate the local scope before treating an active interval as usable.
    # Otherwise a start says "on", and the next prompt's gate closes it only
    # after this mint opportunity, silently losing that entire turn. Missing
    # scope still closes the interval; only a fresh server grant can reopen it.
    state = collector.close_for_changed_notice(session_id)
    if state is None:
        if collector.store.session_file_present(session_id):
            return None
    elif state.get("active"):
        return None
    elif state.get("stop_reason") == NOTICE_CHANGED:
        # The notice moved under an open interval and it was closed (RFC 0048).
        # That is not the person's off: the next prompt asks the service for an
        # interval under the notice they have agreed to now, and the service
        # refuses it if they have not.
        pass
    elif state.get("stop_reason") == "session_ended":
        if not resumed:
            return None
    elif state.get("stop_reason") == "service_unreachable":
        since = _seconds_since(state.get("attempted_at"))
        if at_prompt and since is not None and since < UNREACHABLE_RETRY_S:
            return None
    else:
        return None
    try:
        collector.mint_from_standing_consent(session_id, record_refusal=not at_prompt)
    except CaptureRefused as refusal:
        if refusal.reason == "unreachable":
            collector.note_unreachable(session_id, state)
            raise
        if state is not None and state.get("stop_reason") == "service_unreachable":
            # The service answered this time.  A refusal writes no state, so
            # the unreachable record kept its old `attempted_at` (every later
            # prompt retried, unpaced) and `/vicaria:status` kept saying the
            # service could not be reached.  The answer is recorded on it.
            collector.note_refused(session_id)
        return refusal
    return None


def starts_unconnected(payload: dict[str, Any], environ: Any) -> bool:
    """Whether this is a fresh session start in a plugin a person installed
    to connect: the marketplace's build, which carries its own runtime
    (``wheels/``), under the shim that names its root.  An organization's
    machine without its variables stays silent, as it always did."""
    if payload.get("hook_event_name") != "SessionStart":
        return False
    if payload.get("source") not in (None, "startup"):
        return False
    root = str(environ.get("VICARIA_PLUGIN_ROOT") or "")
    return bool(root) and (Path(root) / "wheels").is_dir()


def refused_line(refusal: CaptureRefused, server: str) -> str:
    """Why this session is not collected, in the person's words."""
    if refusal.error in DISCONNECTED_ERRORS:
        return DISCONNECTED_LINE
    line = REFUSED_LINES.get(refusal.error or "")
    if line is not None:
        return line.format(site=question.site(server))
    # This client's own refusals, made before or after the request.
    if refusal.reason == "opted_out_on_this_machine":
        return OPTED_OUT_LINE
    if refusal.reason == "undelivered_stop":
        return UNDELIVERED_STOP_LINE
    return REFUSED_LINE


def _outcome_line(
    collector: CaptureCollector, refusal: CaptureRefused | None, session_id: str
) -> str:
    """What came of a prompt's mint, in a session start's words: on, or why not.

    Opted out first: an opt-out that overtook the request leaves the interval
    the service opened on disk, and returns the refusal, and nothing is sent
    from an opted-out computer, so "on" would be false.  Then the refusal, then
    the state the mint left or found: on, switched off by the person, the
    service unreachable or its last try refused (the retry paced within its
    minute), or not collected.
    """
    if collector.store.opted_out():
        return START_OPTED_OUT_LINE
    if refusal is not None:
        return refused_line(refusal, collector.server)
    state = collector.store.session(session_id)
    if state is not None and state.get("active"):
        return START_ON_LINE
    if state is not None and state.get("stop_reason") == "developer_unmarked":
        return START_OFF_LINE
    if state is not None and state.get("stop_reason") == "service_unreachable":
        if state.get("refused_at") and state.get("refused_at") == state.get("attempted_at"):
            # The last try reached the service, which said no
            # (`CaptureCollector.note_refused`), as `/vicaria:status` reads it.
            # Its reason is not kept, so it is said as a start says a refusal
            # of no known name.
            return REFUSED_LINE
        return START_UNREACHABLE_LINE.format(server=collector.server)
    return START_NOT_COLLECTING_LINE


def start(
    collector: CaptureCollector,
    payload: dict[str, Any],
    *,
    question_timeout_s: float | None = None,
    may_ask: Callable[[], bool] | None = None,
) -> list[str]:
    """A session starting on a connected computer: open its interval from the
    standing consent, and say so in one line (RFC 0032 §2).

    The line is what is true after the mint, read from the session's state:
    on, off because the person paused it (a resumed session keeps their
    decision), or not collected and why.  At a fresh start, and only there,
    the one question follows when the service has one: a resume or a
    ``/clear`` is the same sitting, and a compaction is the middle of one,
    which says nothing at all.  An unreachable service is raised, as
    :func:`_mint_if_needed` raises it, for the hook's one line and its
    drop-log record.

    The hook passes the question's own request budget and ``may_ask``,
    read after the mint: whether the time left in the hook still covers the
    question.  When it does not, the question is not asked this time (the
    service has not recorded asking it, so a later start asks), rather than
    risk the hook being killed with the start's line unsaid.
    """
    session_id = payload.get("session_id")
    source = payload.get("source")
    if not isinstance(session_id, str) or not session_id or source == "compact":
        return []
    if collector.store.opted_out():
        return [START_OPTED_OUT_LINE]
    refusal = _mint_if_needed(collector, session_id, resumed=source == "resume")
    if refusal is not None:
        return [refused_line(refusal, collector.server)]
    state = collector.store.session(session_id)
    if state is None or not state.get("active"):
        if state is not None and state.get("stop_reason") == "developer_unmarked":
            return [START_OFF_LINE]
        # Nothing minted and nothing refused: a state this process cannot
        # read, or an ended session started again without a resume.  Said
        # as it is rather than as on.
        return [START_NOT_COLLECTING_LINE]
    lines = [START_ON_LINE]
    if source == "clear":
        # The same terminal, a new session id: the question shown before the
        # clear, kept for this session and shown again on the cleared screen.
        # The service is not asked again; it recorded asking already.
        carried = collector.store.take_cleared_question(session_id)
        if carried is not None:
            lines.append(
                question.QUESTION_LINE.format(title=question.title_of(carried.get("title")))
            )
        return lines
    if source in (None, "startup") and collector.api is not None:
        if may_ask is not None and not may_ask():
            return lines
        asked = question.ask(
            collector.store, collector.api, session_id, timeout_s=question_timeout_s
        )
        if asked is not None:
            lines.append(asked)
    return lines


def person_status_line(collector: CaptureCollector, session_id: str) -> str:
    """``/vicaria:status`` for a person on a connected computer: what is on,
    where it goes, and the question waiting in this session (another
    terminal's question is that terminal's to answer), in their words.  Asks
    the service nothing, like the organization's line it stands beside."""
    store = collector.store
    device = store.device()
    if device is None:
        return NO_LINK_LINE
    site = question.site(device["server"])
    if store.opted_out():
        head = "off on this computer (opted out); nothing is collected"
    else:
        state = store.session(session_id)
        if state is not None and state.get("active"):
            head = "on for this session"
        elif state is not None and state.get("stop_reason") == "developer_unmarked":
            head = "off for this session (/vicaria:on turns it back on)"
        elif state is not None and state.get("stop_reason") == NOTICE_CHANGED:
            head = "paused: the sharing notice needs checking (/vicaria:on checks it)"
        elif state is not None and state.get("stop_reason") == "service_unreachable":
            if state.get("refused_at") and state.get("refused_at") == state.get("attempted_at"):
                # The last try reached the service, which said no.
                head = (
                    "not collecting this session (the server refused it); "
                    "it asks again at your prompts, at most once a minute"
                )
            else:
                head = (
                    f"not collecting this session: couldn't reach {device['server']}; "
                    "it tries again at your prompts, at most once a minute"
                )
        else:
            head = "not collecting this session"
    # What is queued is not said: a session's turns are sent when it ends,
    # so "waiting to be sent" is true of every session that is running.
    parts = [head, f"connected as {device.get('name') or 'this computer'}"]
    waiting = question.waiting(store, session_id)
    if waiting is not None and waiting.get("server") == device["server"].rstrip("/"):
        parts.append(
            f"waiting for your answer on “{question.title_of(waiting.get('title'))}”: "
            "/vicaria:yes · /vicaria:partly · /vicaria:no"
        )
    parts.append(f"your tasks: {site}")
    return "Vicaria: " + " · ".join(parts)


def handle(
    collector: CaptureCollector,
    payload: dict[str, Any],
    *,
    sampled: bool = True,
    standing: bool = False,
    say: Callable[[str], None] | None = None,
    announce: Callable[[str], None] | None = None,
    defer_upload: bool = False,
    allow_prompt_mint: bool = True,
) -> dict[str, Any] | None:
    """Map one hook payload to at most one capture event.

    Returns the event that was queued, or ``None`` when nothing was recorded —
    which is the ordinary case, because most sessions are not marked.

    ``standing`` says this machine holds a device link, so a session start (or
    the first prompt of a session that had none) mints its interval from the
    account's standing consent before the gate is read.  Without it nothing
    here writes a file for an unmarked session, exactly as before.

    ``defer_upload`` persists a SessionEnd stop without network delivery;
    the hook then controls bounded final delivery and the backlog worker.
    Direct adapter callers retain the immediate stop/flush by default.

    ``allow_prompt_mint`` is false for Desktop's command-display continuation:
    showing an already computed result must not open an interval after that
    result said capture was off. An already active session still records the
    command prompt and reply. The next ordinary prompt may mint as usual.

    ``say`` is where a line for the person goes (the hook passes its reply).
    A prompt's mint says :data:`START_ON_LINE` when it turns the session on;
    a notice change that interrupts capture says why it is paused. ``announce``
    is passed instead for the first prompt after
    a link was made in this session (the hook took this session's marker:
    this prompt finished the link, or a tool or stop event of the session
    before it did, which mints nothing and says only "connected"): what came
    of this prompt's mint is said there, on or why not, as a session start
    says it.  Once: a later prompt that is refused again says nothing, rather
    than the same line at every prompt.  An unreachable mint is raised, as
    everywhere; the hook says that one.
    """
    session_id = payload.get("session_id")
    if not isinstance(session_id, str) or not session_id:
        return None
    event = payload.get("hook_event_name")
    if event not in HANDLED:
        return None

    if event == "SessionEnd" and payload.get("reason") == "clear":
        # ``/clear`` starts another session in this terminal: the question
        # shown here goes with it (:func:`start` takes it up).
        collector.store.set_aside_question(session_id)

    if event == "SessionStart":
        if standing:
            _mint_if_needed(collector, session_id, resumed=payload.get("source") == "resume")
        return None

    if standing and event == "UserPromptSubmit" and allow_prompt_mint:
        # The harness did not fire SessionStart (or the link came after the
        # session began): mint from the standing consent at this turn, so the
        # session is captured from this prompt on.  A refusal is one cheap
        # request per prompt on a linked device without consent, and writes
        # nothing; SessionStart already left the drop-log line if it ran.  The
        # same decisions as at a session start --- the opt-out, an unreadable
        # file, the person's off, the retry pace --- are made in one place.
        was_on = collector.active(session_id)
        try:
            refusal = _mint_if_needed(collector, session_id, resumed=False, at_prompt=True)
        except CaptureRefused as refusal:
            if was_on and announce is None and say is not None and refusal.reason == "unreachable":
                say(START_UNREACHABLE_LINE.format(server=collector.server))
            raise
        if announce is not None:
            announce(_outcome_line(collector, refusal, session_id))
        elif say is not None and was_on and refusal is not None:
            # This session was collecting until the scope check. A refused
            # replacement grant must be visible, not silently drop the turn.
            say(_outcome_line(collector, refusal, session_id))
        elif say is not None and refusal is None and not was_on and collector.active(session_id):
            # The mark is visible when it is made, here as at a start: a start
            # that could not reach the service said it tries again, and until
            # this line the retry that worked said nothing.  Only a mint that
            # was not refused: an opt-out landing during the request leaves
            # the interval the service opened saved on (so a later `--undo`
            # records under it) and returns the refusal, and "on" would be false on an
            # opted-out machine.  The hook shows this as its `systemMessage`;
            # that Claude Code shows one at UserPromptSubmit has NOT been
            # checked against a live Claude Code (it was, on 2.1.280, at
            # SessionStart).
            say(START_ON_LINE)

    if event == "SessionEnd" and collector.store.opted_out():
        # Gate 2 closes the gate below, and the session's end went with it:
        # a session on when the opt-out was taken stayed on on disk, and
        # `--undo` found it collecting.  Its end is written on disk alone.
        collector.note_session_ended_opted_out(session_id)
        return None

    # Gate 4 first and cheaply. An unmarked session costs two reads of paths
    # that do not exist -- the machine opt-out and the session file -- and
    # nothing else: no network, no queue, no output, and no file created.
    open_gate, refusal = collector.gates(sampled=sampled, session_id=session_id)
    if not open_gate:
        if refusal == NOTICE_CHANGED and say is not None:
            # Tool hooks cannot renew consent mid-turn. Stop here and say so;
            # a later prompt or the person's on command can ask the service.
            say(NOTICE_PAUSED_LINE)
        if event == "SessionEnd" and refusal == "opted_out_on_this_machine":
            # The opt-out landed between the check above and the gate.
            collector.note_session_ended_opted_out(session_id)
        return None

    try:
        return _record(collector, session_id, event, payload, defer_upload=defer_upload)
    except CaptureRefused as refusal:
        if refusal.reason == NOTICE_CHANGED:
            if say is not None:
                say(NOTICE_PAUSED_LINE)
            return None
        if refusal.reason in ("not_marked", "opted_out_on_this_machine"):
            # Switched off, or opted out, between the gate and the write (a
            # late tool hook of a session the person stopped): nothing is
            # recorded, as the gate would have answered a moment later.
            return None
        raise


def _record(
    collector: CaptureCollector,
    session_id: str,
    event: Any,
    payload: dict[str, Any],
    *,
    defer_upload: bool = False,
) -> dict[str, Any] | None:
    if event == "UserPromptSubmit":
        prompt = payload.get("prompt")
        if not isinstance(prompt, str):
            return None
        # Whatever the transcript holds from before this prompt is not this
        # turn's: a resumed session's history, or the tail of a turn that
        # ended without a Stop.
        _skip_to_end(collector, session_id, payload)
        turn = _advance_turn(collector, session_id)
        # No line per turn (RFC 0032 § 9.1, decided 2026-09-26): one on every
        # prompt is the product speaking when nobody asked, and it went to
        # stderr, which Claude Code does not show, so it indicated nothing.
        return collector.record_user_message(
            session_id, turn_index=turn, text=prompt, prompt_id=_prompt_id(payload)
        )

    if event == "PreToolUse":
        name = payload.get("tool_name")
        call_id = payload.get("tool_use_id") or payload.get("tool_call_id")
        if not isinstance(name, str) or not isinstance(call_id, str):
            return None
        if collector.adapter.harness == "claude-code":
            # The response that asked for this call, and any before it the
            # last read did not see, go first: its thinking precedes the call.
            # The transcript catches up a moment after this hook runs, so the
            # read waits for the response that named this call.
            _flush(
                collector,
                session_id,
                payload,
                subagent_id=_subagent(payload),
                hold_last=False,
                awaiting=lambda state, rows: (
                    call_id in (state.get("calls") or [])
                    or any(
                        call_id in response.tool_use_ids
                        for response in transcripts.claude_code_responses(rows)
                    )
                ),
            )
        return collector.record_tool_started(
            session_id,
            turn_index=_turn(collector, session_id),
            tool_call_id=call_id,
            tool_name=name,
            # The input as Claude Code hands it to the hook (RFC 0039).
            input=payload.get("tool_input"),
            subagent_id=_subagent(payload),
            **_with_issue(
                _hook_structure(collector, payload, session_id, _subagent(payload)),
                _issued_by(collector, payload, session_id, call_id),
            ),
        )

    if event in ("PostToolUse", "PostToolUseFailure"):
        call_id = payload.get("tool_use_id") or payload.get("tool_call_id")
        if not isinstance(call_id, str):
            return None
        # PostToolUse carries what the tool returned, as Claude Code gives it
        # to the model; PostToolUseFailure carries the error in its place.  A
        # string goes as it is, a structure as canonical text (RFC 0039).
        response = (
            payload.get("error") if event == "PostToolUseFailure" else payload.get("tool_response")
        )
        return collector.record_tool_finished(
            session_id,
            turn_index=_turn(collector, session_id),
            tool_call_id=call_id,
            completion_status="error" if event == "PostToolUseFailure" else "completed",
            # A hook says the call failed, not with what code. Left unknown.
            exit_status=None,
            output=None if response is None else event_builder.canonical_text(response),
            subagent_id=_subagent(payload),
            structure=_hook_structure(collector, payload, session_id, _subagent(payload)),
            launched_workflow_run_id=_launched_run(collector, payload, response),
        )

    if event in ("Stop", "StopFailure", "SubagentStop"):
        text = payload.get("last_assistant_message")
        subagent = _subagent(payload)
        # What the hook says ended the turn is what the transcript is still
        # being written with: the read waits for it rather than recording the
        # turn without its thinking and counts.
        said = text.strip() if isinstance(text, str) and text.strip() else None
        sidechain = subagent is not None

        def awaiting_rows(state: dict[str, Any], rows: list[dict[str, Any]]) -> bool:
            assert said is not None
            if collector.adapter.harness == "codex":
                # Codex writes a response's counts after its message, so the
                # text alone is not the whole turn: a wait that ended there
                # recorded the counts of the part written so far, a wrong
                # number with no omission beside it (found in review).
                return transcripts.codex_counts_complete(rows, said)
            # Whole response against whole message, for the reason Codex's
            # is: a response that quotes what the closing reply will say
            # ended the wait early and was held as the turn's close, with
            # its own counts (found following up the Codex one, 2026-09-30).
            # Claude Code 2.1.285's last_assistant_message is the final
            # response's whole text, measured against the real binary,
            # multi-paragraph replies included.  Where this is wrong the turn
            # pays the whole budget and then records its closing message with
            # its counts omitted: no wrong number, but not free either --- an
            # earlier claim here that it cost only the wait was wrong, and was
            # wrong because `_flush` went on to hold an earlier reply as the
            # close (found in review, 2026-09-30).
            return any(
                said == (response.text or "").strip()
                for response in transcripts.claude_code_responses(rows, sidechain=sidechain)
            )

        awaiting = None if said is None else awaiting_rows
        if collector.adapter.harness == "codex":
            last = _codex_turn(
                collector, session_id, payload, subagent_id=subagent, awaiting=awaiting, said=said
            )
        else:
            last = _flush(
                collector,
                session_id,
                payload,
                subagent_id=subagent,
                hold_last=True,
                awaiting=awaiting,
                said=said,
            )
        read = last.text if isinstance(last, transcripts.Response) else None
        if collector.adapter.harness == "codex" and read:
            # The rollout has every assistant message of the turn; `Stop`
            # carries only the last, and taking the hook's in preference
            # dropped the commentary before it (found in review, 2026-09-30).
            # The hook's is appended only when the rollout has not caught up
            # with it, so nothing is said twice.  Whether it has is asked of
            # whole messages, not of the joined text: a reply that quoted the
            # closing words made `text in read` true and dropped the closing
            # reply as a repetition (found in review, 2026-09-30).
            said_twice = not isinstance(text, str) or last.has_closing_message
            text = read if said_twice else f"{read}\n\n{text}"
        elif not isinstance(text, str):
            text = read
        return collector.record_assistant_message(
            session_id,
            turn_index=_turn(collector, session_id),
            text=text,
            turn_termination="error" if event == "StopFailure" else "completed",
            # The final response's counts, or for Codex the turn's, from the
            # transcript; None beside its omission when there were none.
            usage=last.usage if isinstance(last, transcripts.Response) else None,
            usage_note=_usage_note_of(last, collector.adapter.harness),
            subagent_id=subagent,
            structure=_said_at(
                _close_structure(collector, payload, session_id, subagent, last, said),
                last if collector.adapter.harness == "claude-code" else None,
            ),
            **_closing_response(collector, last),
            **_reasoning_of(last, collector.adapter.harness),
        )

    if event == "SubagentStart":
        # A boundary, not a message: recorded as an assistant turn with the
        # subagent named and no text, so the parent/child structure survives
        # without inventing content for it.
        return collector.record_assistant_message(
            session_id,
            turn_index=_turn(collector, session_id),
            text=None,
            turn_termination="continuing",
            usage=None,
            subagent_id=_subagent(payload),
            structure=_hook_structure(collector, payload, session_id, _subagent(payload)),
        )

    if event == "SessionEnd":
        collector.stop(session_id, reason="session_ended", defer_upload=defer_upload)
        return None

    return None  # pragma: no cover - HANDLED is exhaustive above


#: Why a message carries no reasoning, or only part of it, by what the
#: transcript showed.  Said in the message's provider_reasoning omission.
THINKING_WITHOUT_TEXT_NOTE = (
    "Claude Code received {missing} of this reply's {blocks} thinking blocks without their "
    "text: it asks for the text only when its showThinkingSummaries setting is on. The "
    "thinking token count is in usage."
)
NO_THINKING_NOTE = "The transcript shows no thinking for this reply."
#: The counts were still being written when the read gave up waiting for them.
COUNTS_UNFINISHED_NOTE = (
    "This turn's token counts were still being written when it ended, so what was on disk was "
    "part of them; a partial count is not the turn's, and none is sent."
)
NO_TRANSCRIPT_NOTE = (
    "This reply was not in the session's transcript when the turn ended, so its thinking "
    "and token counts are unknown."
)
CODEX_NO_SUMMARY_NOTE = (
    "Codex wrote no reasoning summary for this turn; the reasoning itself stays encrypted."
)
CODEX_ENCRYPTED_NOTE = (
    "Codex received {missing} of this turn's {blocks} reasoning items with no summary; the "
    "reasoning itself stays encrypted. The reasoning token count is in usage."
)
CODEX_NO_ROLLOUT_NOTE = (
    "Codex's session file for this turn was not readable, so its reasoning and token counts "
    "are unknown."
)


def _usage_note_of(response: transcripts.Response | None, harness: str) -> str | None:
    """Why the closing message carries no counts, or None when it carries them.

    No response at all means the closing one was not in the session file when
    the turn ended --- the counts exist, they had not been written --- which
    is not the collector's "the harness reported no token counts", and is the
    same thing its reasoning says in :func:`_reasoning_of`.
    """
    if response is None:
        return CODEX_NO_ROLLOUT_NOTE if harness == "codex" else NO_TRANSCRIPT_NOTE
    return COUNTS_UNFINISHED_NOTE if response.usage_incomplete else None


def _reasoning_of(response: transcripts.Response | None, harness: str) -> dict[str, Any]:
    """``reasoning`` and, where it is missing or partial, the note that says why."""
    codex = harness == "codex"
    if response is None:
        return {
            "reasoning": None,
            "reasoning_note": CODEX_NO_ROLLOUT_NOTE if codex else NO_TRANSCRIPT_NOTE,
        }
    fields: dict[str, Any] = {"reasoning": response.reasoning}
    if response.reasoning_without_text:
        template = CODEX_ENCRYPTED_NOTE if codex else THINKING_WITHOUT_TEXT_NOTE
        fields["reasoning_note"] = template.format(
            missing=response.reasoning_without_text, blocks=response.reasoning_blocks
        )
    elif response.reasoning is None:
        fields["reasoning_note"] = CODEX_NO_SUMMARY_NOTE if codex else NO_THINKING_NOTE
    return fields


def _transcript(payload: dict[str, Any], session_id: str, subagent_id: str | None) -> Path | None:
    """The file this event's responses are in: the session's transcript, or a
    subagent's own (named by ``SubagentStop``, and beside the session's)."""
    main = payload.get("transcript_path")
    if subagent_id is None:
        return Path(main) if isinstance(main, str) and main else None
    named = payload.get("agent_transcript_path")
    if isinstance(named, str) and named:
        return Path(named)
    if isinstance(main, str) and main:
        return transcripts.claude_code_subagent_path(main, session_id, subagent_id)
    return None


def _skip_to_end(collector: CaptureCollector, session_id: str, payload: dict[str, Any]) -> None:
    """Move the session's cursor to the end of its transcript, and for Codex
    remember the running token totals there.  The prompt hook's own prompt
    is the one in effect from here: what the transcript gains next is its
    turn's (:func:`_reply_structure`)."""
    path = _transcript(payload, session_id, None)
    if path is None:
        return
    cursor = transcripts.Cursor(collector.store.home, session_id, path)
    with cursor.locked():
        try:
            size = path.stat().st_size
        except OSError:
            # Not written yet: Claude Code writes a new session's transcript
            # after this hook (2.1.285), so nothing in it is from before.
            size = 0
        state: dict[str, Any] = {"offset": size}
        prompt = event_builder.routable(_prompt_id(payload))
        if prompt:
            state["prompt_id"] = prompt
        if collector.adapter.harness == "codex":
            previous = cursor.load() or {}
            totals = previous.get("totals")
            if previous.get("offset") != size or not isinstance(totals, dict):
                totals = transcripts.codex_totals_before(path, size)
            state["totals"] = totals
        cursor.save(state)


def _catch_up(
    cursor: transcripts.Cursor, path: Path, awaiting: Any, *, first_read_from: int | None = None
) -> None:
    """Wait for what the hook calling us knows is there --- holding no lock.

    The wait was inside the cursor's lock, so hooks running at once (Claude
    Code runs the tool hooks in the background, several at a time) each paid
    the whole budget in turn for a response the first of them had already
    taken, and the later ones ran past the limit the harness allows (found in
    review, 2026-09-30).  Waiting here, against the offset as it stands
    *before* the lock, a response another hook has consumed is still in view,
    so the wait ends at once; the read under the lock then finds nothing new
    and records nothing, which is right, because that hook recorded it.
    """
    if awaiting is None:
        return
    state = cursor.load()
    if state is None:
        # A read whose cursor is made by the caller after this --- a
        # subagent's own file, read from its first line --- had no wait at
        # all, so its one read took the counts of the part written so far
        # (found in review, 2026-09-30).  ``first_read_from`` is where that
        # read will start.
        if first_read_from is None:
            return
        state = {"offset": first_read_from}
    # No shortcut for "already recorded" is needed: the first read inside
    # `read_new_until` asks the same question before it sleeps at all.
    transcripts.read_new_until(
        path, int(state.get("offset") or 0), lambda rows: awaiting(state, rows)
    )


def _flush(
    collector: CaptureCollector,
    session_id: str,
    payload: dict[str, Any],
    *,
    subagent_id: str | None,
    hold_last: bool,
    awaiting: Any = None,
    said: str | None = None,
) -> transcripts.Response | None:
    """Record the Claude Code responses written since the last read.

    Each is a ``continuing`` message with its text, thinking and counts.
    With ``hold_last`` the final one, when it asked for no tool, is returned
    instead of recorded: it is the turn's closing message, which the caller
    records.  Under the cursor's lock, so two hooks reading the same lines
    record them once.
    """
    path = _transcript(payload, session_id, subagent_id)
    if path is None:
        return None
    turn = _turn(collector, session_id)
    cursor = transcripts.Cursor(collector.store.home, session_id, path)
    _catch_up(cursor, path, awaiting, first_read_from=0 if subagent_id is not None else None)
    with cursor.locked():
        state = cursor.load()
        if state is None:
            # A subagent's file is its own from its first line.  A session's
            # transcript read for the first time mid-turn (capture came on
            # during it) starts at its end: what came before is not this
            # interval's.
            if subagent_id is not None:
                state = {"offset": 0}
            else:
                with contextlib.suppress(OSError):
                    cursor.save({"offset": path.stat().st_size})
                return None
        sidechain = subagent_id is not None
        records, offset = transcripts.read_new(path, int(state.get("offset") or 0))
        prompt = state.get("prompt_id")
        responses = transcripts.claude_code_responses(
            records, sidechain=sidechain, prompt_id=prompt
        )
        for record in records:
            prompt = transcripts.claude_code_prompt(record, prompt, sidechain=sidechain)
        # Only the closing response is held back for the caller to record as
        # the turn's close.  Holding whatever was last on disk gave the closing
        # message an earlier reply's counts when the wait ran out before the
        # closing response landed --- and, because holding a response is what
        # keeps it from being recorded here, made that earlier reply disappear
        # (found in review, 2026-09-30).
        last = None
        closing = (
            hold_last
            and responses
            and not responses[-1].has_tool_use
            and (said is None or said == (responses[-1].text or "").strip())
        )
        if closing:
            last = responses.pop()
        for response in responses:
            collector.record_assistant_message(
                session_id,
                turn_index=turn,
                text=response.text,
                turn_termination="continuing",
                usage=response.usage,
                subagent_id=subagent_id,
                structure=_said_at(
                    _reply_structure(collector, payload, session_id, subagent_id, response.turn_id),
                    response,
                ),
                response_id=event_builder.routable(response.message_id),
                **_reasoning_of(response, "claude-code"),
            )
        # The calls of the responses just recorded: a hook running beside this
        # one asks for its own call by name rather than waiting out the budget
        # for a response this one has already taken.
        taken = [call for response in responses for call in response.tool_use_ids]
        if last is not None:
            taken.extend(last.tool_use_ids)
        kept = [*(state.get("calls") or []), *taken][-RECENT_CALLS:]
        # And, for each, the reply that issued it and the instant on its record:
        # the call's own tool.started reads them here (v7 response_id and
        # harness_time), whichever hook took the reply from the transcript.
        issued = dict(state.get("issued") or {})
        for response in [*responses, *([last] if last is not None else [])]:
            for call, at in zip(response.tool_use_ids, response.tool_use_at, strict=False):
                issued[call] = [response.message_id, at]
        issued = {call: issued[call] for call in kept if call in issued}
        cursor.save(
            {**state, "offset": offset, "calls": kept, "issued": issued, "prompt_id": prompt}
        )
    return last


def _issued_by(
    collector: CaptureCollector, payload: dict[str, Any], session_id: str, call_id: str
) -> dict[str, Any]:
    """A Claude Code call's v7 ``response_id`` and ``harness_time``: the reply
    that issued it and the instant on the record that carries it, as the
    transcript read before this hook saved them.  A call whose reply was not
    in the transcript yet is a pair of named holes."""
    if collector.adapter.harness == "codex":
        return {
            "response_id": None,
            "issued_at": event_builder.Structure(),
            "response_note": CODEX_NO_RESPONSE_ID,
        }
    if collector.adapter.harness != "claude-code":
        return {}
    path = _transcript(payload, session_id, _subagent(payload))
    state = (
        transcripts.Cursor(collector.store.home, session_id, path).load() if path else None
    ) or {}
    message_id, at = (state.get("issued") or {}).get(call_id) or (None, None)
    response_id = event_builder.routable(message_id)
    structure = event_builder.Structure(
        fields={"harness_time": at},
        omissions=()
        if at
        else (
            event_builder.omission(
                "harness_time",
                "The reply that issued this call was not in the transcript when the hook ran.",
            ),
        ),
    )
    return {"response_id": response_id, "issued_at": structure}


def _codex_turn(
    collector: CaptureCollector,
    session_id: str,
    payload: dict[str, Any],
    *,
    subagent_id: str | None = None,
    awaiting: Any = None,
    said: str | None = None,
) -> transcripts.Response | None:
    """The Codex turn written since the prompt: its reasoning summaries, its
    messages and the change in its running token totals.

    ``said`` is the message the hook says closed the turn: the counts are the
    turn's only once one has been written after it.

    A subagent's are in its own rollout, which ``SubagentStop`` names
    (``agent_transcript_path``) and which is read from its first line; the
    session's rollout is left for the session's own ``Stop``.
    """
    if subagent_id is not None:
        named = payload.get("agent_transcript_path")
        path = Path(named) if isinstance(named, str) and named else None
    else:
        path = _transcript(payload, session_id, None)
    if path is None:
        return None
    cursor = transcripts.Cursor(collector.store.home, session_id, path)
    _catch_up(cursor, path, awaiting, first_read_from=0 if subagent_id is not None else None)
    with cursor.locked():
        state = cursor.load()
        if state is None and subagent_id is not None:
            state = {"offset": 0, "totals": None}
        if state is None:
            return None
        previous = state.get("totals")
        records, offset = transcripts.read_new(path, int(state.get("offset") or 0))
        anchor = state.get("prompt_id")
        turn, totals = transcripts.codex_turn(records, previous_totals=previous, turn_id=anchor)
        turn = replace(turn, has_closing_message=transcripts.codex_said_the_close(records, said))
        if turn.usage is not None and not transcripts.codex_counts_complete(records, said):
            # The wait gave up on a turn whose counts were half written.
            # Publishing those as the turn's is a wrong number with nothing
            # beside it to say so, so they are left out and the omission the
            # collector writes for an absent usage stands (found in review).
            # A turn the rollout never counted at all --- 125 of the 7,361
            # complete turns on this machine --- has no usage here either
            # way, and nothing was half written, so it keeps the plain
            # omission rather than being told a story about the harness.
            turn = replace(turn, usage=None, usage_incomplete=True)
        cursor.save(
            {
                "offset": offset,
                "totals": totals,
                "prompt_id": transcripts.codex_turn_after(records, anchor),
            }
        )
    return turn


def _prompt_id(payload: dict[str, Any]) -> str | None:
    """Claude Code's id for this prompt, accepted as the control hook accepts it.

    The control hook journals its plan request as ``<session>:<prompt_id>``;
    minting the captured prompt's event id from the same value is what lets
    the service join the two. A value the control hook would refuse
    (``control.adapter.ident``) is not used here either, and the event keeps
    the collector's own id.
    """
    value = payload.get("prompt_id")
    if isinstance(value, str) and 0 < len(value) <= 256 and value.isprintable():
        return value
    return None


#: Why a Codex event's v7 response_id is a hole (contracts #138): Codex writes
#: a response's id on the token_usage_record after its items, not on the record
#: that carries the call or the message, so it is not read here.
CODEX_NO_RESPONSE_ID = (
    "Codex writes the response id only on the usage record after a response's items, "
    "not on the record of this call or message."
)

#: The longest subagent name carried as written (the contract's bound); a
#: longer one is a hole, never cut.
SUBAGENT_LABEL_LIMIT = 200
_RUN_ID = re.compile(r"[A-Za-z0-9_.:@+,=~-]{1,200}")


def _subagent_file(payload: dict[str, Any], session_id: str, subagent_id: str) -> Path | None:
    """The subagent's own transcript: the one the hook names, else beside the
    session's, else in a Workflow run's directory (a lane's transcript is at
    ``<session>/subagents/workflows/<run id>/agent-<id>.jsonl``)."""
    path = _transcript(payload, session_id, subagent_id)
    if path is not None and path.exists():
        return path
    main = payload.get("transcript_path")
    if not (isinstance(main, str) and main) or path is None:
        return path
    lanes = sorted(
        (Path(main).parent / session_id / "subagents" / "workflows").glob(f"*/{path.name}")
    )
    return lanes[0] if len(lanes) == 1 else path


def _hook_structure(
    collector: CaptureCollector, payload: dict[str, Any], session_id: str, subagent_id: str | None
) -> event_builder.Structure | None:
    """The v7 members this hook's own input gives: the turn it names, then a
    subagent's members.

    Both harnesses put a turn on every hook's input, not only the prompt's:
    Claude Code's ``prompt_id`` ("correlating a user prompt with all
    subsequent events until the next prompt", 2.1.285, read when the hook
    fires) and Codex's ``turn_id`` (a child thread's is its own).  That is
    the turn the event belongs to as the harness wrote it, and v7 asks for
    that.  The turn remembered from the latest prompt is only for a hook
    that names none: a Codex hook of turn A arriving after prompt B, and a
    child thread's hook, took the latest prompt's turn from it (found in
    review, 2026-10-07).  ``turn_index`` stays the capture's own count, so
    the two can differ on such an event.  Only for the event the hook
    itself describes: a reply it reads from the transcript takes the turn
    the transcript shows (:func:`_reply_structure`)."""
    structure = _subagent_structure(collector, payload, session_id, subagent_id)
    turn = event_builder.routable(_prompt_id(payload))
    return event_builder.with_fields(structure, harness_turn_id=turn) if turn else structure


def _close_structure(
    collector: CaptureCollector,
    payload: dict[str, Any],
    session_id: str,
    subagent_id: str | None,
    last: transcripts.Response | None,
    said: str | None,
) -> event_builder.Structure | None:
    """A turn's close: the turn every part of it supports, else the hole.

    Its parts are what it read from the transcript (text, reasoning,
    counts), whose turn the read shows, and the hook's closing words, whose
    turn the hook names.  It names a turn only when every part names the
    same one: a Stop naming B on a read of A and B, and a late Stop of A
    whose words were appended to B's transcript text, each put one part's
    turn on both (found in re-review, 2026-10-07).  Words found in what was
    read are the transcript's, not a second part: Claude Code holds a reply
    only when its text is the hook's words, and Codex appends the hook's
    words only when the rollout has no such message.  A close that is wholly
    the hook's message is the hook's.
    """
    if not _read_anything(last):
        return _hook_structure(collector, payload, session_id, subagent_id)
    assert last is not None
    claims = {event_builder.routable(last.turn_id)}
    found = collector.adapter.harness == "claude-code" or last.has_closing_message
    if said is not None and not found:
        claims.add(event_builder.routable(_prompt_id(payload)))
    if len(claims) == 1:
        return _reply_structure(collector, payload, session_id, subagent_id, claims.pop())
    return _reply_structure(
        collector,
        payload,
        session_id,
        subagent_id,
        None,
        hole_note="This close joins parts that name different turns, or a part that names "
        "none, so which turn it belongs to is not shown.",
    )


def _read_anything(response: transcripts.Response | None) -> bool:
    """Whether a closing reply carries anything read from the transcript."""
    return isinstance(response, transcripts.Response) and bool(
        response.text
        or response.reasoning_blocks
        or response.usage is not None
        or response.has_tool_use
    )


def _reply_structure(
    collector: CaptureCollector,
    payload: dict[str, Any],
    session_id: str,
    subagent_id: str | None,
    turn_id: str | None,
    hole_note: str = (
        "No record read before this reply in the transcript names its turn, so which "
        "turn it belongs to is not shown."
    ),
) -> event_builder.Structure:
    """A reply read from the transcript: the turn its own records show
    (:attr:`transcripts.Response.turn_id`), never the reading hook's.  A hook
    of turn A running late reads whatever the transcript holds by then, turn
    B's replies included, and lent them its turn (found in re-review,
    2026-10-07).  Where no turn is shown, or its parts show two, the turn is
    a named hole saying which."""
    structure = _subagent_structure(collector, payload, session_id, subagent_id)
    turn = event_builder.routable(turn_id)
    if turn:
        return event_builder.with_fields(structure, harness_turn_id=turn)
    base = structure or event_builder.Structure()
    hole = event_builder.omission("harness_turn_id", hole_note)
    return event_builder.Structure(
        fields={**base.fields, "harness_turn_id": None}, omissions=(*base.omissions, hole)
    )


def _subagent_structure(
    collector: CaptureCollector, payload: dict[str, Any], session_id: str, subagent_id: str | None
) -> event_builder.Structure | None:
    """A Claude Code subagent's v7 members, from the meta file the harness
    writes beside its transcript (``agent-<id>.meta.json``) and the directory
    a Workflow lane's transcript is in; a Codex child thread's from its
    rollouts (:func:`_codex_subagent_structure`).  None for the main agent,
    and for a harness this reader does not cover."""
    if subagent_id is None:
        return None
    if collector.adapter.harness == "codex":
        return _codex_subagent_structure(collector, payload, session_id, subagent_id)
    if collector.adapter.harness != "claude-code":
        return None
    path = _subagent_file(payload, session_id, subagent_id)
    meta: dict[str, Any] = {}
    if path is not None:
        with contextlib.suppress(OSError, ValueError):
            loaded = json.loads(path.with_name(path.stem + ".meta.json").read_text("utf-8"))
            meta = loaded if isinstance(loaded, dict) else {}
    fields: dict[str, Any] = {}
    holes: list[dict[str, Any]] = []
    unread = "" if meta else " (its meta file was not readable)"
    call = meta.get("toolUseId")
    fields["spawned_by_tool_call_id"] = call if isinstance(call, str) and call else None
    if fields["spawned_by_tool_call_id"] is None:
        holes.append(
            event_builder.omission(
                "subagent_spawn",
                "Claude Code recorded no spawning call for this subagent"
                + unread
                + "; a Workflow lane's meta carries none.",
            )
        )
    parent = meta.get("parentAgentId")
    fields["parent_subagent_id"] = parent if isinstance(parent, str) and parent else None
    if fields["parent_subagent_id"] is None and meta.get("spawnDepth") != 1:
        # At spawnDepth 1 the main agent started it, which is the null itself.
        holes.append(
            event_builder.omission(
                "subagent_parent",
                "Claude Code did not record which agent started this subagent" + unread + ".",
            )
        )
    run = path.parent.name if path is not None and path.parent.parent.name == "workflows" else None
    fields["workflow_run_id"] = run if run and _RUN_ID.fullmatch(run) else None
    label = meta.get("description")
    if isinstance(label, str) and label.strip() and len(label) <= SUBAGENT_LABEL_LIMIT:
        fields["subagent_label"] = label
    else:
        fields["subagent_label"] = None
        long = isinstance(label, str) and len(label) > SUBAGENT_LABEL_LIMIT
        holes.append(
            event_builder.omission(
                "subagent_label",
                f"The name Claude Code wrote is {len(label)} characters, over the "
                f"{SUBAGENT_LABEL_LIMIT} carried; it was not cut."
                if long
                else "Claude Code wrote no name for this subagent" + unread + ".",
                reason="body_too_large" if long else "adapter_cannot_observe",
            )
        )
    return event_builder.Structure(fields=fields, omissions=tuple(holes))


def _codex_meta(path: Path) -> dict[str, Any]:
    """A Codex rollout's first record, its ``session_meta`` payload; {} if unreadable."""
    with contextlib.suppress(OSError, ValueError, StopIteration):
        with path.open("r", encoding="utf-8") as handle:
            record = json.loads(next(handle))
        if isinstance(record, dict) and record.get("type") == "session_meta":
            meta = record.get("payload")
            return meta if isinstance(meta, dict) else {}
    return {}


def _codex_spawn_call(parent: Path, child: str) -> str | None:
    """The call id of the ``SubAgentActivity`` in ``parent``'s rollout that
    started thread ``child`` (it is the ``spawn_agent`` call id).  Only the
    ``started`` activity: a later one for the same thread (``interacted``)
    names another call, and with the start missing it is a hole, not that
    call (found in review, 2026-10-07)."""
    needle = f'"agent_thread_id":"{child}"'
    with contextlib.suppress(OSError), parent.open("r", encoding="utf-8") as handle:
        for line in handle:
            if needle not in line.replace('": "', '":"'):
                continue
            with contextlib.suppress(ValueError):
                item = (json.loads(line).get("payload") or {}).get("item") or {}
                if (
                    item.get("type") == "SubAgentActivity"
                    and item.get("kind") == "started"
                    and item.get("agent_thread_id") == child
                ):
                    return event_builder.routable(item.get("id"))
    return None


def _codex_subagent_structure(
    collector: CaptureCollector, payload: dict[str, Any], session_id: str, child: str
) -> event_builder.Structure:
    """A Codex child thread's v7 members.

    Codex hands a thread-spawned subagent's hooks ``agent_id`` = the child's
    own thread id, and the child's rollout names its parent thread, depth and
    ``agent_path`` in its ``session_meta``; the spawning call is the
    ``SubAgentActivity`` in the parent's rollout whose ``agent_thread_id`` is
    the child (codex-rs ``subagent_hook_context``).  Codex has no Workflow.
    """
    candidates = [payload.get("agent_transcript_path"), payload.get("transcript_path")]
    meta: dict[str, Any] = {}
    child_path: Path | None = None
    for candidate in candidates:
        if isinstance(candidate, str) and candidate:
            found = _codex_meta(Path(candidate))
            if found.get("id") == child:
                meta, child_path = found, Path(candidate)
                break
    fields: dict[str, Any] = {"workflow_run_id": None}
    holes: list[dict[str, Any]] = []
    unread = "" if meta else " (the child's rollout was not readable)"
    parent = meta.get("parent_thread_id")
    root = meta.get("session_id") or session_id
    if isinstance(parent, str) and parent and parent != root:
        fields["parent_subagent_id"] = event_builder.routable(parent)
    else:
        fields["parent_subagent_id"] = None
    if fields["parent_subagent_id"] is None and not (isinstance(parent, str) and parent == root):
        holes.append(
            event_builder.omission(
                "subagent_parent",
                "Codex did not record which thread started this one" + unread + ".",
            )
        )
    call = None
    cache = collector.store.home / "subagents" / f"{child}.json"
    with contextlib.suppress(OSError, ValueError):
        call = json.loads(cache.read_text("utf-8")).get("spawned_by_tool_call_id")
    if call is None and isinstance(parent, str) and child_path is not None:
        sessions = child_path.parents[3] if len(child_path.parents) > 3 else child_path.parent
        rollouts = sorted(sessions.glob(f"*/*/*/rollout-*-{parent}.jsonl"))
        if len(rollouts) == 1:
            call = _codex_spawn_call(rollouts[0], child)
        if call is not None:
            with contextlib.suppress(OSError):
                cache.parent.mkdir(parents=True, exist_ok=True)
                cache.write_text(json.dumps({"spawned_by_tool_call_id": call}), "utf-8")
    fields["spawned_by_tool_call_id"] = call
    if call is None:
        holes.append(
            event_builder.omission(
                "subagent_spawn",
                "The spawning call was not found in the parent thread's rollout" + unread + ".",
            )
        )
    label = meta.get("agent_path")
    if isinstance(label, str) and label.strip() and len(label) <= SUBAGENT_LABEL_LIMIT:
        fields["subagent_label"] = label
    else:
        fields["subagent_label"] = None
        long = isinstance(label, str) and len(label) > SUBAGENT_LABEL_LIMIT
        holes.append(
            event_builder.omission(
                "subagent_label",
                f"The agent path Codex wrote is {len(label)} characters, over the "
                f"{SUBAGENT_LABEL_LIMIT} carried; it was not cut."
                if long
                else "Codex wrote no agent path for this thread" + unread + ".",
                reason="body_too_large" if long else "adapter_cannot_observe",
            )
        )
    return event_builder.Structure(fields=fields, omissions=tuple(holes))


def _launched_run(
    collector: CaptureCollector, payload: dict[str, Any], response: Any
) -> str | None:
    """The Workflow run a Claude Code Workflow call launched, as its structured
    result names it (``runId``; each lane's transcript is in that run's
    directory).  None for any other call, or a result without the id."""
    if collector.adapter.harness != "claude-code" or payload.get("tool_name") != "Workflow":
        return None
    run = response.get("runId") if isinstance(response, dict) else None
    return run if isinstance(run, str) and _RUN_ID.fullmatch(run) else None


def _said_at(
    structure: event_builder.Structure | None, response: transcripts.Response | None
) -> event_builder.Structure | None:
    """v7 ``harness_time`` for a reply read from the transcript: the instant
    on the reply's first record.  Unchanged when there is no such record."""
    if not isinstance(response, transcripts.Response) or not response.at:
        return structure
    return event_builder.with_fields(structure, harness_time=response.at)


def _closing_response(collector: CaptureCollector, last: Any) -> dict[str, Any]:
    """The closing reply's v7 ``response_id``, when it was read from a Claude
    Code transcript; nothing otherwise (the hook's own text has no id)."""
    if collector.adapter.harness == "codex":
        return {"response_id": None, "response_note": CODEX_NO_RESPONSE_ID}
    if collector.adapter.harness != "claude-code" or not isinstance(last, transcripts.Response):
        return {}
    return {"response_id": event_builder.routable(last.message_id)}


def _with_issue(structure: event_builder.Structure | None, issue: dict[str, Any]) -> dict[str, Any]:
    """The tool.started arguments for a call's subagent members and its issue."""
    if not issue:
        return {"structure": structure}
    issued_at = issue["issued_at"]
    base = structure or event_builder.Structure()
    return {
        "structure": event_builder.Structure(
            fields={**issued_at.fields, **base.fields},
            omissions=(*base.omissions, *issued_at.omissions),
        ),
        "response_id": issue["response_id"],
        **({"response_note": issue["response_note"]} if issue.get("response_note") else {}),
    }


def _subagent(payload: dict[str, Any]) -> str | None:
    agent = payload.get("agent_id")
    return agent if isinstance(agent, str) and agent else None
