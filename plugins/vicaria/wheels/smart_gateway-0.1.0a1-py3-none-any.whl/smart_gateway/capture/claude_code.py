"""Claude Code capture: one hook invocation at a time.

A Claude Code hook is a process that starts, reads one JSON object on stdin, and
exits.  Nothing survives between invocations except what was written to disk, so
this module is a pure mapping from one hook payload to at most one capture
event, with the session's turn counter living in the client home.

The invariant that matters most here is **off is silent**.  An unmarked session
must write nothing, open no file beyond the session lookup, and print nothing:
a hook that announced itself on every prompt of every session would make capture
feel switched on for people who never switched it on.  So :func:`handle` returns
``None`` for an unmarked session before it looks at anything else, and the hook
shim discards stdout anyway.

Which hooks carry what
----------------------
=====================  ===================================================
``UserPromptSubmit``   ``prompt`` — the developer's text. Advances the turn.
``PreToolUse``         ``tool_name`` — the name, not the input (see coverage).
``PostToolUse``        success or failure of the call that just ran.
``Stop``               ``last_assistant_message`` — the turn's final message.
``StopFailure``        the turn ended in an error; no message text.
``SubagentStart/Stop`` a subagent boundary on the parent session.
``SessionEnd``         the session is over: capture stops, queue is flushed.
=====================  ===================================================

``Stop`` carries only the *final* assistant message of a turn.  Intermediate
assistant messages are not delivered to any hook, so the adapter records what it
was given and the coverage document marks ``assistant_message_text`` partial
rather than letting a reader assume a turn had exactly one message.

The other authority: standing consent
-------------------------------------
On a linked device (``sg capture link``) the person agreed once, on the
website, and every session is captured unless they switch it off.  That is
the fourth gate inverted --- and it is *not* implemented by skipping the gate.
``SessionStart`` mints the session's interval from the standing consent
(:meth:`CaptureCollector.mint_from_standing_consent`, a server round trip that
returns the same immutable grant a per-session mark returns) and writes the
session state ``active``; the gate then reads that state exactly as before.
A session with no state stays silent, as it always did, because on an
unlinked machine nothing mints one.  The switch is the plugin's own commands:
``/vicaria:off`` closes the interval, ``/vicaria:on`` mints a new one from this
turn, and ``/vicaria:status`` prints one line; :func:`command` answers all
three and the hook tells Claude Code to stop there, so the command never
reaches the model.

The commands arrive at ``UserPromptExpansion``, not ``UserPromptSubmit``.
Claude Code answers a slash command it does not know --- ``/vicaria off``
typed as a prompt --- with "Unknown command" and runs no hook at all (checked
against Claude Code 2.1.280 on 2026-09-24), so the prompt form this module
first answered could never be typed.  A command the plugin registers
(``commands/off.md`` in a plugin named ``vicaria``) is announced to
``UserPromptExpansion`` with its name and arguments before it expands, and a
hook that answers ``{"continue": false, "stopReason": ...}`` ends it there
with that one line shown.  The prompt form is still answered, for a harness
that delivers it.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from smart_gateway.capture import events as event_builder
from smart_gateway.capture import question
from smart_gateway.capture.collector import CaptureCollector, CaptureRefused

#: The switch, typed as a prompt.  Anchored, so a sentence that merely mentions
#: the command is a prompt like any other.
COMMAND = re.compile(
    r"^\s*/vicaria\s+(?:(on|off|status)|(feedback)(?:\s+(.*?))?)\s*$", re.IGNORECASE
)

#: The switch as the plugin registers it: ``commands/on.md``, ``off.md`` and
#: ``status.md`` in the plugin named ``vicaria``, which Claude Code names
#: ``vicaria:on`` and so on.  Only a plugin's command counts, so a project
#: command that happens to share the name is left to the project.
PLUGIN_COMMANDS = {
    "vicaria:on": "on",
    "vicaria:off": "off",
    "vicaria:status": "status",
    "vicaria:feedback": "feedback",
    "vicaria:connect": "connect",
    "vicaria:yes": "yes",
    "vicaria:partly": "partly",
    "vicaria:no": "no",
}

#: The commands that take an argument: ``/vicaria:connect <server>``.
PLUGIN_COMMANDS_WITH_ARGS = {"vicaria:connect", "vicaria:feedback"}

#: What the person reads when the switch is thrown, in the notice's words
#: (collected, sent, delete) and never ours.  Stopping is not erasing, and
#: the line says where deletion lives.
OFF_LINE = (
    "Vicaria: off for this session. Nothing more from it is collected; what was already "
    "sent stays until you delete it on the website. /vicaria:on turns it back on."
)
ON_LINE = "Vicaria: on for this session, from your next prompt."
ALREADY_ON_LINE = "Vicaria: already on for this session."
NO_LINK_LINE = "Vicaria isn't connected on this computer. Type /vicaria:connect to connect it."
#: `/vicaria:feedback up|down [comment]` (RFC 0039): recorded with the session,
#: comment and all, on the turn just answered.
FEEDBACK_LINE = "Vicaria: noted, thumbs {direction} on the last reply{tail}."
NOT_COLLECTING_LINE = (
    "Vicaria isn't collecting this session, so nothing was recorded. /vicaria:on turns it on."
)
BAD_FEEDBACK_LINE = (
    "Vicaria: type /vicaria:feedback up or /vicaria:feedback down, with a comment after it "
    "if you like."
)
#: The machine opt-out, as ``/vicaria:on`` and the answer commands say it.
#: Only a connected computer reaches either (an organization's ``on`` says
#: :data:`NO_LINK_LINE`), so it is said in the person's words: the opt-out
#: is a developer's switch, and its command is not the person's to type.
OPTED_OUT_LINE = "Vicaria is turned off on this computer, so nothing is sent."
OFF_BEFORE_MINT_LINE = (
    "Vicaria: off for this session; nothing from it will be sent. /vicaria:on turns it back on."
)
#: ``off`` before anything was opened, on an opted-out computer: reached on
#: a connected computer alone, like :data:`OPTED_OUT_LINE`.
OFF_BEFORE_MINT_OPTED_OUT_LINE = (
    "Vicaria: off for this session. Vicaria is turned off on this computer too, so nothing "
    "is sent, and this session stays off until /vicaria:on."
)
ALREADY_OFF_LINE = "Vicaria: already off for this session; nothing is being sent."
OFF_STANDS_ANSWER = (
    "Vicaria: off for this session; it was switched off while it was turning on. "
    "/vicaria:on turns it back on."
)
#: ``off`` on an opted-out computer with a session on.  Two lines, because
#: both paths reach it: an organization's developer reads the first, with
#: the terms of the tool they installed; a person reads the second.
OFF_OPTED_OUT_LINE = (
    "vicaria capture: off for this session; this machine is opted out, so nothing was being "
    "sent and the service is not told (the website shows the session shared until you stop "
    "it there)."
)
PERSON_OFF_OPTED_OUT_LINE = (
    "Vicaria: off for this session. Vicaria is turned off on this computer, so nothing was "
    "being sent; the website shows this session as shared until you stop it there."
)
#: ``off`` whose stop could not be completed: the decision is on disk and
#: nothing more is sent, which is what the person needs to know.  The
#: organization's line (inline in :func:`command`) names the refusal.
PERSON_OFF_UNFINISHED_LINE = (
    "Vicaria: off for this session; nothing more from it is sent. /vicaria:on turns it back on."
)
#: A command whose work failed on a connected computer.  The failure itself
#: is in the developer's drop log; the person is told what to do.
COMMAND_FAILED_LINE = (
    "Vicaria: that command didn't finish. Try it again in a moment; "
    "/vicaria:status says what is on."
)

#: A session starting on a connected computer says one line (RFC 0032 §2);
#: a session whose start did not mint says it at the prompt that does
#: (:func:`handle`).  With /vicaria:status that is the whole of what a person
#: is told while it collects; the per-turn marker is dropped (RFC 0032 § 9.1).
START_ON_LINE = "Vicaria: on · /vicaria:off pauses this session"
START_OFF_LINE = "Vicaria: off for this session · /vicaria:on turns it back on"
#: Nothing minted and nothing refused: said as it is rather than as on.
START_NOT_COLLECTING_LINE = "Vicaria: not collecting this session · /vicaria:on turns it on"
#: The retry is paced (:data:`UNREACHABLE_RETRY_S`): a prompt inside the
#: minute tries nothing, so the line does not promise the next prompt.
START_UNREACHABLE_LINE = (
    "Vicaria: couldn't reach {server}, so this session isn't collected yet. "
    "It tries again at your prompts, at most once a minute; /vicaria:on tries now."
)
ON_UNREACHABLE_LINE = (
    "Vicaria: couldn't reach {server}, so this session isn't collected. "
    "Try /vicaria:on again in a moment."
)
START_OPTED_OUT_LINE = "Vicaria: off on this computer (opted out); nothing is collected."
NOT_CONNECTED_LINE = "Vicaria is installed. Type /vicaria:connect to turn it on."

#: Why a session is not collected, when the service said no, by the
#: service's own name for it.  Anything else is said with its detail.
REFUSED_LINES = {
    "no_standing_consent": (
        "Vicaria: sharing isn't on for your account, so this session isn't collected. "
        "Turn it on at {site}."
    ),
    "consent_withdrawn": (
        "Vicaria: sharing is off for your account, so this session isn't collected. "
        "Turn it back on in Settings at {site}."
    ),
    "notice_changed": (
        "Vicaria: what Vicaria collects changed, so this session isn't collected until you "
        "agree to it at {site}."
    ),
    "session_erased": (
        "Vicaria: this session was deleted on the website, so nothing more from it is collected."
    ),
    "session_belongs_to_another_device": (
        "Vicaria: this session was started on another computer, so it isn't collected here."
    ),
}
#: Any other refusal.  The service's own words stay in the developer's drop
#: log (the collector writes them there); they are not the person's, and a
#: detail such as "this session id was minted from another device" is
#: nothing but our terms.
REFUSED_LINE = "Vicaria: this session isn't collected (the server refused it)."
#: A stop made under the other connection this computer holds (an
#: organization's, or a link to another account) has not reached the
#: website, and a new interval here waits for it.  The command that
#: delivers it is a developer's, and is in their drop log.
UNDELIVERED_STOP_LINE = (
    "Vicaria: this session was switched off under another connection on this computer, and "
    "the website hasn't been told yet, so it isn't collected here."
)
#: A computer removed on the website, as the answer commands say it too:
#: defined in :mod:`~smart_gateway.capture.question`, which this module
#: imports, and re-exported under the names the session start uses.
DISCONNECTED_ERRORS = question.DISCONNECTED_ERRORS
DISCONNECTED_LINE = question.DISCONNECTED_LINE

#: How long a session whose mint could not reach the service waits before a
#: prompt tries again.  Long enough that an offline laptop does not pay a
#: connect timeout on every keystroke; short enough that a VPN coming back is
#: noticed within the session.
UNREACHABLE_RETRY_S = 60.0

#: Hooks this adapter maps. Anything else is ignored rather than guessed at.
HANDLED = (
    "SessionStart",
    "UserPromptSubmit",
    "PreToolUse",
    "PostToolUse",
    "PostToolUseFailure",
    "Stop",
    "StopFailure",
    "SubagentStart",
    "SubagentStop",
    "SessionEnd",
)


#: Claude Code names itself to every hook in ``AI_AGENT``, as
#: ``claude-code_2-1-280_harness``; no hook payload carries the version.
AGENT_VERSION = re.compile(r"^claude-code_(\d+(?:-\d+){1,3})(?:_|$)")


def harness_version_from(environ: Any) -> str | None:
    """The running Claude Code's version, ``2.1.280``, from the hook's
    environment, or None.  The advice pool compares harness versions, and a
    session recorded as ``unknown`` joins no cell that can be compared."""
    matched = AGENT_VERSION.match(str(environ.get("AI_AGENT") or ""))
    return matched.group(1).replace("-", ".") if matched else None


def _stored_turn(state: dict[str, Any] | None) -> int | None:
    """The session's current turn, or None when it has had none.

    Written as an explicit None test rather than ``or -1``: turn 0 is falsy, so
    the shorter spelling reads the first turn as "no turn yet" and every prompt
    after the first stays on turn 0. Every event of a session then lands in one
    turn, which the service accepts and which makes the whole session read as a
    single exchange.
    """
    if state is None:
        return None
    value = state.get("turn_index")
    if isinstance(value, bool) or not isinstance(value, int):
        return None
    return value


def _turn(collector: CaptureCollector, session_id: str) -> int:
    turn = _stored_turn(collector.store.session(session_id))
    return 0 if turn is None else turn


def _advance_turn(collector: CaptureCollector, session_id: str) -> int:
    # A read-modify-write of the state, like the collector's own: under the
    # session lock, so a Stop hook still writing the previous turn cannot
    # save its copy over this one.
    with collector.store.session_lock():
        state = collector.store.session(session_id)
        if state is None:
            raise KeyError(session_id)
        current = _stored_turn(state)
        turn = 0 if current is None else current + 1
        state["turn_index"] = turn
        collector.store.save_session(state)
    return turn


def command_verb(payload: dict[str, Any]) -> str | None:
    """``on``, ``off`` or ``status`` when this payload is the switch, else None.

    Two forms: the plugin's command announced at ``UserPromptExpansion``
    (``vicaria:off`` with no arguments), and ``/vicaria off`` typed as a
    prompt at ``UserPromptSubmit``.  A command given arguments it does not
    take is not the switch: ``/vicaria:off now`` expands to the command's
    own text, which says so.
    """
    session_id = payload.get("session_id")
    if not isinstance(session_id, str) or not session_id:
        return None
    event = payload.get("hook_event_name")
    if event == "UserPromptExpansion":
        if payload.get("command_source") != "plugin":
            return None
        name = str(payload.get("command_name") or "").lower()
        args = payload.get("command_args")
        given = args not in (None, "") and not (isinstance(args, str) and not args.strip())
        if given and name not in PLUGIN_COMMANDS_WITH_ARGS:
            return None
        return PLUGIN_COMMANDS.get(name)
    if event != "UserPromptSubmit":
        return None
    prompt = payload.get("prompt")
    if not isinstance(prompt, str):
        return None
    matched = COMMAND.match(prompt)
    return (matched.group(1) or matched.group(2)).lower() if matched else None


def is_command(payload: dict[str, Any]) -> bool:
    """Whether this payload is the switch, in either form.

    The one predicate, used by :func:`command` and by the hook before it
    builds anything: a command has to be answered even when the work behind
    it fails, so the hook needs to know it is one first.
    """
    return command_verb(payload) is not None


def command(
    collector: CaptureCollector, payload: dict[str, Any], *, standing: bool = False
) -> str | None:
    """Answer the switch, ``/vicaria:on|off|status``, or ``None``.

    The plugin's command at ``UserPromptExpansion``, or a ``UserPromptSubmit``
    whose whole prompt is ``/vicaria on|off|status``.  The answer is one line
    for the person; the hook shows it and stops the command there, so it is
    never sent to the model.  ``off`` closes the
    interval through :meth:`CaptureCollector.stop` with the ``switch_off``
    gesture; ``on`` mints a new interval from this turn through the standing
    consent, which is the only authority a prompt can invoke (a per-session
    confirm needs the notice shown and the receipt written) and which needs
    the device link to be the credential in use --- ``standing`` says so, from
    the same resolution the hook made, rather than from a file that may exist
    beside an organization's variables; ``status`` reads files and asks the
    service nothing.  The machine opt-out beats every ``on``.
    """
    verb = command_verb(payload)
    if verb is None:
        return None
    session_id = payload["session_id"]
    if verb == "connect":
        from smart_gateway.capture import connect

        expansion = payload.get("hook_event_name") == "UserPromptExpansion"
        args = payload.get("command_args") if expansion else None
        return connect.command(
            collector.store,
            args if isinstance(args, str) else None,
            session_id=session_id,
            harness_version=collector.adapter.harness_version,
        )
    if verb == "status":
        if standing:
            return person_status_line(collector, session_id)
        return collector.status_line(session_id)
    if verb == "feedback":
        return _feedback(collector, payload, session_id, standing=standing)
    if verb in question.ANSWERS:
        if not standing or collector.store.device() is None or collector.api is None:
            return NO_LINK_LINE
        if collector.store.opted_out():
            return OPTED_OUT_LINE
        return question.answer(collector.store, collector.api, session_id, verb)
    state = collector.store.session(session_id)
    if verb == "off":
        if state is not None and state.get("active"):
            if collector.store.opted_out():
                # Gate 2: an opted-out machine sends nothing, the switch
                # included.  The state is turned off on disk and the service
                # is not told; the interval it holds admits nothing anyway.
                # An active state already names the credential that minted
                # it, and keeps it, as `stop` would: a device-minted session
                # stays the device's, an organization's the organization's.
                collector.switch_off_before_mint(session_id, rescope=False)
                return PERSON_OFF_OPTED_OUT_LINE if standing else OFF_OPTED_OUT_LINE
            try:
                stopped = collector.stop(
                    session_id, reason="developer_unmarked", gesture="switch_off"
                )
            except CaptureRefused as refusal:
                if standing:
                    return PERSON_OFF_UNFINISHED_LINE
                return (
                    f"vicaria capture: could not switch off cleanly ({refusal.detail}); "
                    "nothing further is queued for this session."
                )
            if not stopped.get("stopped"):
                # Something turned the state off between the read above and
                # the stop's lock, and the decision was not written.  On the
                # device path a `SessionEnd` (an ended state, which a resume
                # would mint over) is written as the branch below writes it,
                # this link's decision; anything else, and every state under
                # an organization's credentials, is written as the
                # already-off branch writes it, keeping the state's own
                # workspace.  Over an opt-out too, on disk alone, so it
                # stands after `--undo`.
                now = collector.store.session(session_id)
                ended = now is None or now.get("stop_reason") in (
                    "service_unreachable",
                    "session_ended",
                )
                if standing or now is not None:
                    collector.switch_off_before_mint(session_id, rescope=standing and ended)
            return OFF_LINE
        reopenable = state is None or state.get("stop_reason") in (
            "service_unreachable",
            "session_ended",
        )
        if standing and reopenable:
            # No interval yet on a linked machine, a state this process
            # cannot read, or one a resume or a retry would reopen: the next
            # start or prompt would mint.  The person said not to, and
            # "already off" would have been a lie the next mint exposed.
            # Written in the shape a closed interval leaves, which is where
            # the mint looks first.  On an opted-out machine nothing would
            # mint now, but `sg capture opt-out --undo` would let the next
            # prompt mint: the decision is written there too, on disk alone.
            collector.switch_off_before_mint(session_id)
            if collector.store.opted_out():
                return OFF_BEFORE_MINT_OPTED_OUT_LINE
            return OFF_BEFORE_MINT_LINE
        if state is not None:
            # Already off, and said again: written again, so a `/vicaria on`
            # or an organization's re-`confirm` in flight from another
            # terminal finds a switch-off later than the one it set out from
            # and lets it stand (over an opt-out too, on disk alone).  The
            # state keeps its own workspace and server, under either
            # credential.  A session with no state under an organization's
            # credentials, where nothing mints, is left with none.
            collector.switch_off_before_mint(session_id, rescope=False)
        return ALREADY_OFF_LINE
    if not standing or collector.store.device() is None:
        return NO_LINK_LINE
    if collector.store.opted_out():
        return OPTED_OUT_LINE
    if state is not None and state.get("active"):
        return ALREADY_ON_LINE
    try:
        collector.mint_from_standing_consent(session_id)
    except CaptureRefused as refusal:
        if refusal.reason == "unreachable":
            return ON_UNREACHABLE_LINE.format(server=collector.server)
        return refused_line(refusal, collector.server)
    if not collector.active(session_id):
        # Switched off from another terminal while the mint was in flight:
        # the collector said so, and "on" would be the switch thrown and
        # nothing switched.
        return OFF_STANDS_ANSWER
    return ON_LINE


def _feedback_args(payload: dict[str, Any]) -> tuple[str, str | None] | None:
    """``(direction, comment)`` from the command's arguments, or None when they
    do not start with ``up`` or ``down``."""
    if payload.get("hook_event_name") == "UserPromptExpansion":
        raw = payload.get("command_args")
    else:
        matched = COMMAND.match(str(payload.get("prompt") or ""))
        raw = matched.group(3) if matched else None
    words = str(raw or "").strip().split(None, 1)
    if not words or words[0].lower() not in ("up", "down"):
        return None
    comment = words[1].strip() if len(words) > 1 else ""
    return words[0].lower(), (comment or None)


def _feedback(
    collector: CaptureCollector, payload: dict[str, Any], session_id: str, *, standing: bool
) -> str:
    """Record ``/vicaria:feedback up|down [comment]`` on the turn just answered.

    Zero tokens: answered here and never sent to the model.  The comment goes
    as typed (RFC 0039); an uncollected session records nothing and says so.
    """
    parsed = _feedback_args(payload)
    if parsed is None:
        return BAD_FEEDBACK_LINE
    direction, comment = parsed
    if standing and collector.store.device() is None:
        return NO_LINK_LINE
    if collector.store.opted_out():
        return OPTED_OUT_LINE
    if not collector.active(session_id):
        return NOT_COLLECTING_LINE
    try:
        collector.record_feedback(
            session_id,
            turn_index=_turn(collector, session_id),
            direction=direction,
            comment=comment,
        )
    except CaptureRefused:
        return NOT_COLLECTING_LINE
    return FEEDBACK_LINE.format(direction=direction, tail=", with your comment" if comment else "")


def _seconds_since(stamp: Any) -> float | None:
    """Seconds since an RFC 3339 instant the store wrote, or None if unreadable."""
    if not isinstance(stamp, str) or not stamp:
        return None
    try:
        then = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
    except ValueError:
        return None
    if then.tzinfo is None:
        then = then.replace(tzinfo=UTC)
    return (datetime.now(UTC) - then).total_seconds()


def _mint_if_needed(
    collector: CaptureCollector,
    session_id: str,
    *,
    resumed: bool,
    at_prompt: bool = False,
) -> CaptureRefused | None:
    """Open an interval from the standing consent where one should be open.

    A session with no state at all is new: mint at turn 0.  A session whose
    interval the harness closed (``session_ended``) and that Claude Code now
    resumes is minted again from the next turn.  A session the person
    switched off stays off, whether or not it ever had an interval: their
    decision stands until they type ``/vicaria on``.  A session whose mint
    could not reach the service is tried again at a session start, and at a
    prompt only once :data:`UNREACHABLE_RETRY_S` has passed.  A state file
    this process cannot read is not a session nobody decided about, so it
    never mints.  A refusal writes no state (an opt-out that overtook the
    request leaves the interval the service opened saved), and leaves a
    drop-log line only at a session start (the collector writes it; a prompt's
    retry and an overtaken mint leave none).  An unreachable service is
    recorded on the state and re-raised, so the hook leaves its one line.
    Any other refusal is returned, so a session start can say why.

    Gate 2 is read first: the machine opt-out beats every setting above it,
    the website's standing consent included, and a mint is a write on the
    service and on this disk that an opted-out machine must never make.
    """
    if collector.store.opted_out():
        return None
    state = collector.store.session(session_id)
    if state is None:
        if collector.store.session_file_present(session_id):
            return None
    elif state.get("active"):
        return None
    elif state.get("stop_reason") == "session_ended":
        if not resumed:
            return None
    elif state.get("stop_reason") == "service_unreachable":
        since = _seconds_since(state.get("attempted_at"))
        if at_prompt and since is not None and since < UNREACHABLE_RETRY_S:
            return None
    else:
        return None
    try:
        collector.mint_from_standing_consent(session_id, record_refusal=not at_prompt)
    except CaptureRefused as refusal:
        if refusal.reason == "unreachable":
            collector.note_unreachable(session_id, state)
            raise
        if state is not None and state.get("stop_reason") == "service_unreachable":
            # The service answered this time.  A refusal writes no state, so
            # the unreachable record kept its old `attempted_at` (every later
            # prompt retried, unpaced) and `/vicaria:status` kept saying the
            # service could not be reached.  The answer is recorded on it.
            collector.note_refused(session_id)
        return refusal
    return None


def starts_unconnected(payload: dict[str, Any], environ: Any) -> bool:
    """Whether this is a fresh session start in a plugin a person installed
    to connect: the marketplace's build, which carries its own runtime
    (``wheels/``), under the shim that names its root.  An organization's
    machine without its variables stays silent, as it always did."""
    if payload.get("hook_event_name") != "SessionStart":
        return False
    if payload.get("source") not in (None, "startup"):
        return False
    root = str(environ.get("VICARIA_PLUGIN_ROOT") or "")
    return bool(root) and (Path(root) / "wheels").is_dir()


def refused_line(refusal: CaptureRefused, server: str) -> str:
    """Why this session is not collected, in the person's words."""
    if refusal.error in DISCONNECTED_ERRORS:
        return DISCONNECTED_LINE
    line = REFUSED_LINES.get(refusal.error or "")
    if line is not None:
        return line.format(site=question.site(server))
    # This client's own refusals, made before or after the request.
    if refusal.reason == "opted_out_on_this_machine":
        return OPTED_OUT_LINE
    if refusal.reason == "undelivered_stop":
        return UNDELIVERED_STOP_LINE
    return REFUSED_LINE


def _outcome_line(
    collector: CaptureCollector, refusal: CaptureRefused | None, session_id: str
) -> str:
    """What came of a prompt's mint, in a session start's words: on, or why not.

    Opted out first: an opt-out that overtook the request leaves the interval
    the service opened on disk, and returns the refusal, and nothing is sent
    from an opted-out computer, so "on" would be false.  Then the refusal, then
    the state the mint left or found: on, switched off by the person, the
    service unreachable or its last try refused (the retry paced within its
    minute), or not collected.
    """
    if collector.store.opted_out():
        return START_OPTED_OUT_LINE
    if refusal is not None:
        return refused_line(refusal, collector.server)
    state = collector.store.session(session_id)
    if state is not None and state.get("active"):
        return START_ON_LINE
    if state is not None and state.get("stop_reason") == "developer_unmarked":
        return START_OFF_LINE
    if state is not None and state.get("stop_reason") == "service_unreachable":
        if state.get("refused_at") and state.get("refused_at") == state.get("attempted_at"):
            # The last try reached the service, which said no
            # (`CaptureCollector.note_refused`), as `/vicaria:status` reads it.
            # Its reason is not kept, so it is said as a start says a refusal
            # of no known name.
            return REFUSED_LINE
        return START_UNREACHABLE_LINE.format(server=collector.server)
    return START_NOT_COLLECTING_LINE


def start(
    collector: CaptureCollector,
    payload: dict[str, Any],
    *,
    question_timeout_s: float | None = None,
    may_ask: Callable[[], bool] | None = None,
) -> list[str]:
    """A session starting on a connected computer: open its interval from the
    standing consent, and say so in one line (RFC 0032 §2).

    The line is what is true after the mint, read from the session's state:
    on, off because the person paused it (a resumed session keeps their
    decision), or not collected and why.  At a fresh start, and only there,
    the one question follows when the service has one: a resume or a
    ``/clear`` is the same sitting, and a compaction is the middle of one,
    which says nothing at all.  An unreachable service is raised, as
    :func:`_mint_if_needed` raises it, for the hook's one line and its
    drop-log record.

    The hook passes the question's own request budget and ``may_ask``,
    read after the mint: whether the time left in the hook still covers the
    question.  When it does not, the question is not asked this time (the
    service has not recorded asking it, so a later start asks), rather than
    risk the hook being killed with the start's line unsaid.
    """
    session_id = payload.get("session_id")
    source = payload.get("source")
    if not isinstance(session_id, str) or not session_id or source == "compact":
        return []
    if collector.store.opted_out():
        return [START_OPTED_OUT_LINE]
    refusal = _mint_if_needed(collector, session_id, resumed=source == "resume")
    if refusal is not None:
        return [refused_line(refusal, collector.server)]
    state = collector.store.session(session_id)
    if state is None or not state.get("active"):
        if state is not None and state.get("stop_reason") == "developer_unmarked":
            return [START_OFF_LINE]
        # Nothing minted and nothing refused: a state this process cannot
        # read, or an ended session started again without a resume.  Said
        # as it is rather than as on.
        return [START_NOT_COLLECTING_LINE]
    lines = [START_ON_LINE]
    if source == "clear":
        # The same terminal, a new session id: the question shown before the
        # clear, kept for this session and shown again on the cleared screen.
        # The service is not asked again; it recorded asking already.
        carried = collector.store.take_cleared_question(session_id)
        if carried is not None:
            lines.append(
                question.QUESTION_LINE.format(title=question.title_of(carried.get("title")))
            )
        return lines
    if source in (None, "startup") and collector.api is not None:
        if may_ask is not None and not may_ask():
            return lines
        asked = question.ask(
            collector.store, collector.api, session_id, timeout_s=question_timeout_s
        )
        if asked is not None:
            lines.append(asked)
    return lines


def person_status_line(collector: CaptureCollector, session_id: str) -> str:
    """``/vicaria:status`` for a person on a connected computer: what is on,
    where it goes, and the question waiting in this session (another
    terminal's question is that terminal's to answer), in their words.  Asks
    the service nothing, like the organization's line it stands beside."""
    store = collector.store
    device = store.device()
    if device is None:
        return NO_LINK_LINE
    site = question.site(device["server"])
    if store.opted_out():
        head = "off on this computer (opted out); nothing is collected"
    else:
        state = store.session(session_id)
        if state is not None and state.get("active"):
            head = "on for this session"
        elif state is not None and state.get("stop_reason") == "developer_unmarked":
            head = "off for this session (/vicaria:on turns it back on)"
        elif state is not None and state.get("stop_reason") == "service_unreachable":
            if state.get("refused_at") and state.get("refused_at") == state.get("attempted_at"):
                # The last try reached the service, which said no.
                head = (
                    "not collecting this session (the server refused it); "
                    "it asks again at your prompts, at most once a minute"
                )
            else:
                head = (
                    f"not collecting this session: couldn't reach {device['server']}; "
                    "it tries again at your prompts, at most once a minute"
                )
        else:
            head = "not collecting this session"
    # What is queued is not said: a session's turns are sent when it ends,
    # so "waiting to be sent" is true of every session that is running.
    parts = [head, f"connected as {device.get('name') or 'this computer'}"]
    waiting = question.waiting(store, session_id)
    if waiting is not None and waiting.get("server") == device["server"].rstrip("/"):
        parts.append(
            f"waiting for your answer on “{question.title_of(waiting.get('title'))}”: "
            "/vicaria:yes · /vicaria:partly · /vicaria:no"
        )
    parts.append(f"your tasks: {site}")
    return "Vicaria: " + " · ".join(parts)


def handle(
    collector: CaptureCollector,
    payload: dict[str, Any],
    *,
    sampled: bool = True,
    standing: bool = False,
    say: Callable[[str], None] | None = None,
    announce: Callable[[str], None] | None = None,
) -> dict[str, Any] | None:
    """Map one hook payload to at most one capture event.

    Returns the event that was queued, or ``None`` when nothing was recorded —
    which is the ordinary case, because most sessions are not marked.

    ``standing`` says this machine holds a device link, so a session start (or
    the first prompt of a session that had none) mints its interval from the
    account's standing consent before the gate is read.  Without it nothing
    here writes a file for an unmarked session, exactly as before.

    ``say`` is where a line for the person goes (the hook passes its reply).
    One thing is said there: :data:`START_ON_LINE`, when a prompt's mint turns
    the session on.  ``announce`` is passed instead for the first prompt after
    a link was made in this session (the hook took this session's marker:
    this prompt finished the link, or a tool or stop event of the session
    before it did, which mints nothing and says only "connected"): what came
    of this prompt's mint is said there, on or why not, as a session start
    says it.  Once: a later prompt that is refused again says nothing, rather
    than the same line at every prompt.  An unreachable mint is raised, as
    everywhere; the hook says that one.
    """
    session_id = payload.get("session_id")
    if not isinstance(session_id, str) or not session_id:
        return None
    event = payload.get("hook_event_name")
    if event not in HANDLED:
        return None

    if event == "SessionEnd" and payload.get("reason") == "clear":
        # ``/clear`` starts another session in this terminal: the question
        # shown here goes with it (:func:`start` takes it up).
        collector.store.set_aside_question(session_id)

    if event == "SessionStart":
        if standing:
            _mint_if_needed(collector, session_id, resumed=payload.get("source") == "resume")
        return None

    if standing and event == "UserPromptSubmit":
        # The harness did not fire SessionStart (or the link came after the
        # session began): mint from the standing consent at this turn, so the
        # session is captured from this prompt on.  A refusal is one cheap
        # request per prompt on a linked device without consent, and writes
        # nothing; SessionStart already left the drop-log line if it ran.  The
        # same decisions as at a session start --- the opt-out, an unreadable
        # file, the person's off, the retry pace --- are made in one place.
        was_on = collector.active(session_id)
        refusal = _mint_if_needed(collector, session_id, resumed=False, at_prompt=True)
        if announce is not None:
            announce(_outcome_line(collector, refusal, session_id))
        elif say is not None and refusal is None and not was_on and collector.active(session_id):
            # The mark is visible when it is made, here as at a start: a start
            # that could not reach the service said it tries again, and until
            # this line the retry that worked said nothing.  Only a mint that
            # was not refused: an opt-out landing during the request leaves
            # the interval the service opened saved on (so a later `--undo`
            # records under it) and returns the refusal, and "on" would be false on an
            # opted-out machine.  The hook shows this as its `systemMessage`;
            # that Claude Code shows one at UserPromptSubmit has NOT been
            # checked against a live Claude Code (it was, on 2.1.280, at
            # SessionStart).
            say(START_ON_LINE)

    if event == "SessionEnd" and collector.store.opted_out():
        # Gate 2 closes the gate below, and the session's end went with it:
        # a session on when the opt-out was taken stayed on on disk, and
        # `--undo` found it collecting.  Its end is written on disk alone.
        collector.note_session_ended_opted_out(session_id)
        return None

    # Gate 4 first and cheaply. An unmarked session costs two reads of paths
    # that do not exist -- the machine opt-out and the session file -- and
    # nothing else: no network, no queue, no output, and no file created.
    open_gate, refusal = collector.gates(sampled=sampled, session_id=session_id)
    if not open_gate:
        if event == "SessionEnd" and refusal == "opted_out_on_this_machine":
            # The opt-out landed between the check above and the gate.
            collector.note_session_ended_opted_out(session_id)
        return None

    try:
        return _record(collector, session_id, event, payload)
    except CaptureRefused as refusal:
        if refusal.reason in ("not_marked", "opted_out_on_this_machine"):
            # Switched off, or opted out, between the gate and the write (a
            # late tool hook of a session the person stopped): nothing is
            # recorded, as the gate would have answered a moment later.
            return None
        raise


def _record(
    collector: CaptureCollector, session_id: str, event: Any, payload: dict[str, Any]
) -> dict[str, Any] | None:
    if event == "UserPromptSubmit":
        prompt = payload.get("prompt")
        if not isinstance(prompt, str):
            return None
        turn = _advance_turn(collector, session_id)
        # No line per turn (RFC 0032 § 9.1, decided 2026-09-26): one on every
        # prompt is the product speaking when nobody asked, and it went to
        # stderr, which Claude Code does not show, so it indicated nothing.
        return collector.record_user_message(
            session_id, turn_index=turn, text=prompt, prompt_id=_prompt_id(payload)
        )

    if event == "PreToolUse":
        name = payload.get("tool_name")
        call_id = payload.get("tool_use_id") or payload.get("tool_call_id")
        if not isinstance(name, str) or not isinstance(call_id, str):
            return None
        return collector.record_tool_started(
            session_id,
            turn_index=_turn(collector, session_id),
            tool_call_id=call_id,
            tool_name=name,
            # The input as Claude Code hands it to the hook (RFC 0039).
            input=payload.get("tool_input"),
            subagent_id=_subagent(payload),
        )

    if event in ("PostToolUse", "PostToolUseFailure"):
        call_id = payload.get("tool_use_id") or payload.get("tool_call_id")
        if not isinstance(call_id, str):
            return None
        # PostToolUse carries what the tool returned, as Claude Code gives it
        # to the model; PostToolUseFailure carries the error in its place.  A
        # string goes as it is, a structure as canonical text (RFC 0039).
        response = (
            payload.get("error") if event == "PostToolUseFailure" else payload.get("tool_response")
        )
        return collector.record_tool_finished(
            session_id,
            turn_index=_turn(collector, session_id),
            tool_call_id=call_id,
            completion_status="error" if event == "PostToolUseFailure" else "completed",
            # A hook says the call failed, not with what code. Left unknown.
            exit_status=None,
            output=None if response is None else event_builder.canonical_text(response),
            subagent_id=_subagent(payload),
        )

    if event in ("Stop", "StopFailure", "SubagentStop"):
        text = payload.get("last_assistant_message")
        return collector.record_assistant_message(
            session_id,
            turn_index=_turn(collector, session_id),
            text=text if isinstance(text, str) else None,
            turn_termination="error" if event == "StopFailure" else "completed",
            # No hook carries token counts; the omission is recorded rather
            # than the counts being read from a source the notice never named.
            usage=None,
            subagent_id=_subagent(payload),
        )

    if event == "SubagentStart":
        # A boundary, not a message: recorded as an assistant turn with the
        # subagent named and no text, so the parent/child structure survives
        # without inventing content for it.
        return collector.record_assistant_message(
            session_id,
            turn_index=_turn(collector, session_id),
            text=None,
            turn_termination="continuing",
            usage=None,
            subagent_id=_subagent(payload),
        )

    if event == "SessionEnd":
        collector.stop(session_id, reason="session_ended")
        return None

    return None  # pragma: no cover - HANDLED is exhaustive above


def _prompt_id(payload: dict[str, Any]) -> str | None:
    """Claude Code's id for this prompt, accepted as the control hook accepts it.

    The control hook journals its plan request as ``<session>:<prompt_id>``;
    minting the captured prompt's event id from the same value is what lets
    the service join the two. A value the control hook would refuse
    (``control.adapter.ident``) is not used here either, and the event keeps
    the collector's own id.
    """
    value = payload.get("prompt_id")
    if isinstance(value, str) and 0 < len(value) <= 256 and value.isprintable():
        return value
    return None


def _subagent(payload: dict[str, Any]) -> str | None:
    agent = payload.get("agent_id")
    return agent if isinstance(agent, str) and agent else None
