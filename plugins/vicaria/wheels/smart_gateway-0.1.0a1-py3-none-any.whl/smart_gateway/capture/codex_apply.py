"""Codex apply-next-session, explicit confirmation, local undo and honest status."""

from __future__ import annotations

import copy
import json
import os
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Any

from smart_gateway.capture import transcripts
from smart_gateway.capture.codex_settings import (
    Journal,
    RecoveryRequired,
    Refused,
    digest,
    document,
    encoded,
    patch_fields,
)
from smart_gateway.config import resolve_data_dir
from smart_gateway.control.plans import carries_a_credential_safely
from smart_gateway.control.recommendation_records import latest_recommendation
from smart_gateway.ids import utc_now_iso

HARNESS = "codex"
EFFORTS = {"none", "minimal", "low", "medium", "high", "xhigh", "max"}
POLICY_EFFORTS = ["low", "medium", "high"]
MAX_LESSON_CHARS = 4000
USAGE = (
    "vicaria: type vicaria apply to preview, vicaria apply yes <code> to confirm, "
    "vicaria apply undo, or vicaria apply recover."
)


def config_path(env: Mapping[str, str]) -> Path:
    return Path(env.get("CODEX_HOME") or Path.home() / ".codex").expanduser() / "config.toml"


def _effective(record: Mapping[str, Any]) -> dict:
    base, suggested = record.get("base"), record.get("suggested")
    if not isinstance(base, dict) or not isinstance(suggested, dict):
        raise Refused("the saved suggestion is incomplete; ask for a new one.")
    if not suggested or set(suggested) - {"model", "effort", "prompt"}:
        raise Refused("this suggestion changes controls this native apply path doesn't support.")
    model = suggested.get("model", base.get("model"))
    effort = suggested.get("effort", base.get("effort"))
    if not isinstance(model, str) or not model or any(c.isspace() for c in model):
        raise Refused("the suggestion has no usable model identity.")
    if effort == "default":
        effort = None
    elif not isinstance(effort, str) or effort not in EFFORTS:
        raise Refused("the suggestion's effort is not supported by this plugin.")
    lesson = record.get("lesson")
    if "prompt" in suggested:
        if (
            not isinstance(lesson, dict)
            or not isinstance(suggested["prompt"], str)
            or lesson.get("recipe") != suggested["prompt"]
            or not isinstance(lesson.get("text"), str)
            or not lesson["text"].strip()
            or len(lesson["text"]) > MAX_LESSON_CHARS
        ):
            raise Refused("the suggested lesson is missing or too large to apply safely.")
    elif lesson is not None:
        raise Refused("the saved lesson doesn't match the suggestion; ask for a new one.")
    return {"model": model, "effort": effort, "lesson": lesson}


def _policy(device: Mapping[str, Any] | None, record: Mapping[str, Any], plan: dict) -> None:
    from smart_gateway.capture.api import CaptureApi

    if not device:
        raise Refused(
            "connect this computer before applying a new suggestion. Local undo still works."
        )
    server = str(device.get("server") or "").rstrip("/")
    if not carries_a_credential_safely(server) or record.get("server") != server + "/device":
        raise Refused("the suggestion doesn't belong to this computer's secure server connection.")
    answer = CaptureApi(server, str(device.get("token") or ""), timeout_s=3.0)._request(
        "GET", "/device/advice-config", None
    )
    policy = answer.value if answer.ok and isinstance(answer.value, dict) else {}
    allowed, bounds, org = policy.get("allowed_models"), policy.get("effort"), policy.get("org_id")
    if (
        not isinstance(allowed, list)
        or not allowed
        or any(not isinstance(m, str) or not m for m in allowed)
        or len(set(allowed)) != len(allowed)
        or not isinstance(org, str)
        or not org
        or not isinstance(bounds, dict)
        or bounds.get("min") not in POLICY_EFFORTS
        or bounds.get("max") not in POLICY_EFFORTS
    ):
        raise Refused(
            "the server couldn't supply the current workspace and effort policy; "
            "nothing is applied."
        )
    pin = record.get("policy_version")
    match = re.fullmatch(r"(.+):policy:[0-9]+", pin) if isinstance(pin, str) else None
    if match is None or match[1] != org:
        raise Refused(
            "the suggestion came from another workspace or has no policy identity; "
            "ask for a new one."
        )
    if plan["model"] not in allowed:
        raise Refused(
            "the workspace no longer allows the target model. Allowed models: "
            + ", ".join(sorted(allowed))
            + "."
        )
    low, high = POLICY_EFFORTS.index(bounds["min"]), POLICY_EFFORTS.index(bounds["max"])
    if low > high:
        raise Refused("the current effort policy is invalid.")
    if (low, high) != (0, 2) and plan["effort"] not in POLICY_EFFORTS[low : high + 1]:
        raise Refused(
            "the workspace no longer allows the target effort; "
            f"allowed range is {bounds['min']}-{bounds['max']}."
        )


def _recipe(record: dict, doc: dict, stack: list[dict]) -> tuple[dict, str | None, str]:
    plan = _effective(record)
    # Apply the coherent model/effort pair, including retained dimensions from
    # the observed base. The preview exposes every actual user-default edit.
    changes = {"model": plan["model"], "model_reasoning_effort": plan["effort"]}
    block, replaced = None, ""
    if plan["lesson"] is not None:
        marker = digest(encoded(record))[:12]
        block = f"\n\n[Vicaria lesson {marker}]\n{plan['lesson']['text']}\n[/Vicaria lesson]\n"
        current = doc.get("developer_instructions", "")
        for entry in reversed(stack):
            old = entry.get("lesson_block")
            if isinstance(old, str) and current.count(old) == 1:
                replaced = old
                break
        changes["developer_instructions"] = (
            current.replace(replaced, block, 1) if replaced else current + block
        )
    return changes, block, replaced


def _overrides(path: Path, doc: dict, cwd: str | None) -> list[str]:
    notes = []
    if doc.get("profile"):
        notes.append("a named profile is selected; it can override these user defaults")
    if list(path.parent.glob("*.config.toml")):
        notes.append("named profile files exist; selecting one can override these defaults")
    if cwd:
        folder = Path(cwd).absolute()
        for parent in (folder, *folder.parents):
            project = parent / ".codex" / "config.toml"
            if project.exists() and project.resolve() != path.resolve():
                notes.append(f"project configuration at {project} may override user defaults")
    notes.append(
        "CLI overrides, managed settings and resumed sessions may keep different values; "
        "start a new session and check vicaria status"
    )
    return notes


def _preview(journal: Journal, record: dict, device, cwd: str | None) -> str:
    before = journal.snapshot()
    doc = document(journal.bytes(before))
    plan = _effective(record)
    _policy(device, record, plan)
    changes, _block, _replaced = _recipe(record, doc, journal.state["stack"])
    # Validate the proposed TOML now, before asking for confirmation.
    patch_fields(journal.bytes(before), changes)
    binding = {
        "recommendation": digest(encoded(record)),
        "before": before,
        "requested": str(journal.requested),
    }
    code = digest(encoded(binding))[:12]
    journal.state["preview"] = {**binding, "code": code}
    journal.save()
    kind = "configured setting" if record.get("label") == "configured" else "recommendation"
    lines = [
        f"vicaria: latest {kind}, recorded {record.get('recorded_at')}:",
        f"  model: {doc.get('model', 'not set')} → {plan['model']}",
        f"  effort: {doc.get('model_reasoning_effort', 'default')} → "
        f"{plan['effort'] or 'Codex default'}",
    ]
    if plan["lesson"]:
        lines.append("  lesson: " + plan["lesson"]["text"])
    lines += [
        f"Updates user defaults in {journal.requested} for new sessions. "
        "Provider and authentication stay as configured.",
        "Heads up: " + "; ".join(_overrides(journal.requested, doc, cwd)) + ".",
        "Provider availability is checked by your next run, not by this preview.",
        f"To apply exactly this preview, type vicaria apply yes {code}",
    ]
    return "\n".join(lines)


def _confirm(journal: Journal, record: dict, device, code: str) -> str:
    preview = journal.state.get("preview")
    before = journal.snapshot()
    if (
        not isinstance(preview, dict)
        or preview.get("code") != code.lower()
        or preview.get("recommendation") != digest(encoded(record))
        or preview.get("requested") != str(journal.requested)
        or preview.get("before") != before
    ):
        raise Refused(
            "the suggestion or settings changed, or the code wasn't previewed. "
            "Run vicaria apply again."
        )
    plan = _effective(record)
    _policy(device, record, plan)
    doc = document(journal.bytes(before))
    changes, block, replaced = _recipe(record, doc, journal.state["stack"])
    updated = patch_fields(journal.bytes(before), changes)
    entry = {
        "decision_id": record.get("decision_id"),
        "recorded_at": record.get("recorded_at"),
        "applied_at": utc_now_iso(),
        "label": record.get("label"),
        "policy_version": record.get("policy_version"),
        "before": before,
        "after_digest": digest(updated),
        "lesson_block": block,
        "replaced_block": replaced,
        "effective_lesson_block": block
        or next(
            (
                e.get("effective_lesson_block")
                for e in reversed(journal.state["stack"])
                if e.get("effective_lesson_block")
                and doc.get("developer_instructions", "").count(e["effective_lesson_block"]) == 1
            ),
            None,
        ),
        "model": plan["model"],
        "effort": plan["effort"],
        "writes": {key: {"before": doc.get(key), "after": value} for key, value in changes.items()},
    }
    journal.transact(before, updated, [*journal.state["stack"], entry])
    return (
        "vicaria: applied to Codex's user defaults. Start a new session, then run vicaria status. "
        "This session's model and effort were not changed. "
        "vicaria apply undo restores the previous values."
    )


def _undo(journal: Journal) -> str:
    stack = journal.state["stack"]
    if not stack:
        return (
            "vicaria: no Codex application is recorded for this configuration. Nothing was changed."
        )
    entry = stack[-1]
    before = journal.snapshot()
    raw = journal.bytes(before)
    doc = document(raw)
    changed, kept = {}, []
    if digest(raw) == entry["after_digest"]:
        updated = journal.bytes(entry["before"])
    else:
        for key, write in entry["writes"].items():
            if doc.get(key) == write["after"]:
                changed[key] = write["before"]
            elif key == "developer_instructions" and entry.get("lesson_block"):
                current = doc.get(key)
                block = entry["lesson_block"]
                if isinstance(current, str) and current.count(block) == 1:
                    changed[key] = current.replace(block, entry.get("replaced_block") or "", 1)
                else:
                    kept.append(key)
            else:
                kept.append(key)
        updated = patch_fields(raw, changed)
    exists = entry["before"]["exists"] or bool(updated)
    journal.transact(before, updated, stack[:-1], exists=exists)
    line = (
        "vicaria: undid the last Codex application. Start a new session to use the restored values."
    )
    if kept:
        line += " Left values you edited since: " + ", ".join(kept) + "."
    return line


def _recovery(journal: Journal, words: list[str]) -> str:
    pending = journal.checked_pending()
    if pending is None:
        return "vicaria: no interrupted Codex change needs recovery. Nothing was changed."
    current = journal.snapshot()
    binding = digest(
        encoded(
            {
                "pending": pending,
                "current": current,
                "stack": journal.state["stack"],
                "requested": str(journal.requested),
            }
        )
    )
    code = binding[:12]
    if words == ["recover"]:
        journal.state["preview"] = {"kind": "recovery", "binding": binding, "code": code}
        journal.save()
        return (
            "vicaria: an interrupted operation has local recovery copies. "
            "Discarding it leaves config.toml exactly as it is and keeps prior undo history, "
            "but removes the pending operation's recovery/undo information. "
            "Review the private journal before choosing this: " + str(journal.path) + ". "
            "To discard exactly this pending operation and current configuration, "
            "type vicaria apply recover discard " + code
        )
    preview = journal.state.get("preview")
    if (
        not isinstance(preview, dict)
        or preview.get("kind") != "recovery"
        or preview.get("binding") != binding
        or words[2].lower() != code
    ):
        raise Refused("the recovery state or settings changed; type vicaria apply recover again.")
    journal.state["pending"] = None
    journal.state["preview"] = None
    journal.save()  # Never write config.toml while discarding recovery metadata.
    return (
        "vicaria: discarded the pending operation's recovery information. "
        "Your current configuration and prior undo history were kept. "
        "Run vicaria apply again for a new preview."
    )


def command(
    payload: Mapping[str, Any],
    device: Mapping[str, Any] | None = None,
    *,
    environ: Mapping[str, str] | None = None,
) -> str:
    env = os.environ if environ is None else environ
    words = str(payload.get("command_args") or "").split()
    recovery = words == ["recover"] or (len(words) == 3 and words[:2] == ["recover", "discard"])
    if words and words != ["undo"] and not (len(words) == 2 and words[0] == "yes") and not recovery:
        return USAGE
    try:
        with Journal(resolve_data_dir(env), config_path(env), reconcile=not recovery) as journal:
            if recovery:
                return _recovery(journal, words)
            if words == ["undo"]:
                return _undo(journal)  # Local, including while unlinked or offline.
            record = latest_recommendation(resolve_data_dir(env), HARNESS)
            if record is None:
                return (
                    "vicaria: no saved Codex suggestion yet. "
                    "Run a task in a connected session first."
                )
            if not words:
                return _preview(journal, record, device, payload.get("cwd"))
            return _confirm(journal, record, device, words[1])
    except Refused as exc:
        return f"vicaria: {exc} Nothing was changed."
    except RecoveryRequired as exc:
        return f"vicaria: {exc}"
    except OSError:
        return (
            "vicaria: couldn't access the settings or private undo journal. "
            "No new settings write was started."
        )


def _lesson_seen(payload: Mapping[str, Any], block: str) -> bool:
    path, session = payload.get("transcript_path"), payload.get("session_id")
    if not isinstance(path, str) or not isinstance(session, str):
        return False
    try:
        with Path(path).open("rb") as stream:
            first = json.loads(stream.readline(1 << 20))
            if first.get("type") != "session_meta" or first.get("payload", {}).get("id") != session:
                return False
            # Instruction evidence is session-scoped. Never read another
            # session's file or infer it from the current config.toml.
            stream.seek(0)
            raw = stream.read(2 << 20)
        for line in raw.splitlines():
            row = json.loads(line)
            value = row.get("payload") or {}
            if row.get("type") == "session_meta" and block in str(
                value.get("developer_instructions") or ""
            ):
                return True
            if row.get("type") == "response_item" and value.get("role") == "developer":
                for content in value.get("content") or []:
                    if isinstance(content, dict) and block in str(content.get("text") or ""):
                        return True
    except (OSError, ValueError, AttributeError, TypeError):
        return False
    return False


def status_lines(
    payload: Mapping[str, Any], environ: Mapping[str, str] | None = None
) -> str | None:
    env = os.environ if environ is None else environ
    try:
        with Journal(resolve_data_dir(env), config_path(env)) as journal:
            if not journal.state["stack"]:
                return None
            entry = copy.deepcopy(journal.state["stack"][-1])
    except (Refused, RecoveryRequired, OSError) as exc:
        return f"Codex apply status unavailable: {exc}"
    lines = [
        f"Applied {entry['applied_at']} ({entry.get('label') or 'suggestion'}): "
        f"model {entry['model']}, effort {entry['effort'] or 'Codex default'}."
    ]
    path, session, turn = (payload.get(k) for k in ("transcript_path", "session_id", "turn_id"))
    reading = (
        transcripts.codex_turn_settings(path, session, turn)
        if all(isinstance(v, str) and v for v in (path, session, turn))
        else transcripts.TurnSettings()
    )
    checks = []
    for name, seen, wanted in (
        ("model", reading.model, entry["model"]),
        ("effort", reading.effort, entry["effort"]),
    ):
        if wanted is None:
            checks.append(f"{name}: uses the native default; not compared")
        elif seen is None:
            checks.append(f"{name}: not reported for this turn")
        else:
            checks.append(f"{name} {seen} ({'matches' if seen == wanted else 'differs'})")
    if entry.get("effective_lesson_block"):
        checks.append(
            "lesson found in recorded session instructions"
            if _lesson_seen(payload, entry["effective_lesson_block"])
            else "lesson not observed in recorded session instructions"
        )
    lines += [
        "Codex turn-context report: " + "; ".join(checks) + ".",
        "Provider request: not observed by this plugin; "
        "matching turn context is not wire verification.",
    ]
    return "\n".join(lines)
