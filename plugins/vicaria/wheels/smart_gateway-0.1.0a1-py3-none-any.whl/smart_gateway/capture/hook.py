"""``python3 -m smart_gateway.capture.hook <Event>``: the plugin's hook entry.

Claude Code's by default; Codex's when the shim says so (``VICARIA_HARNESS=
codex``, set by the Codex plugin's hooks), in which case the payload is read
through :mod:`smart_gateway.capture.codex_plugin`, the link is Codex's own
(``~/.vicaria/harnesses/codex``), the words name ``vicaria off``, and the
queue is offered after turns, just as Claude Code's is. The detached
:mod:`smart_gateway.capture.background` worker retries all sessions in that
harness's home. ``--flush <harness> <session>`` remains a legacy entry point.

Invisible by construction.  A hook runs on every event of every session, and the
overwhelming majority of sessions are not marked, so the fast path here is:
read stdin, look up one file, find no open interval, exit 0 having printed
nothing.  Everything that could be slow or noisy is behind that check.

Failure never stops the session, and it is never silent
------------------------------------------------------
A capture that cannot reach its service must not become a coding session that
will not start, so the exit code is 0. Claude Desktop plugin commands execute
locally, then pass their result to the command template through hook context.
Claude repeats that result as a normal reply. The terminal CLI and Codex keep
their local stopReason responses. The legacy ``/vicaria off`` prompt at
``UserPromptSubmit`` keeps exit 2 and its line on stderr. That
is not the same as saying nothing.  A deferred upload already left the events
on disk and a line in the developer's own upload log; this module owes the
same for the failures that happen *before* an upload is even attempted.

It did not.  ``except Exception: return 0`` covered the whole body, so a marked
session whose ``producer-seq`` file had been left holding something other than
an integer — which :meth:`CaptureStore.next_sequence` refuses to guess past, on
purpose — dropped every turn from then on with nothing written anywhere and
nothing printed, while the session's mark had already told the developer
capture was running.  A failure rendered as a silent success is
the one outcome this project does not permit, so the swallow now leaves a line
in the drop log and one on stderr, the developer's debug output (Claude Code
does not show stderr from a hook that exits 0).  The recording itself
is best-effort and wrapped: a hook that crashed while reporting a crash would be
the original bug again.
"""

from __future__ import annotations

import contextlib
import json
import os
import sys
import time
from pathlib import Path
from typing import Any

from smart_gateway.capture.store import CaptureStore

EXIT_ALWAYS = 0

#: The one other exit status, and only on ``UserPromptSubmit``: the prompt was
#: a ``/vicaria on|off|status`` command, the hook answered it on stderr, and
#: Claude Code's contract for exit 2 there is exactly what a command needs ---
#: the prompt is not sent to the model and stderr is shown to the person.
EXIT_SWALLOWED = 2


def answer_command(
    payload: dict[str, Any], line: str, out: Any, *, harness: str = "claude-code"
) -> int:
    """Deliver an executed command's result through the harness's visible path.

    Claude Desktop can hide stopReason and systemMessage. Its plugin commands
    therefore receive plain-text hook context, which the command
    template asks Claude to repeat as a normal reply. Only the hook performs
    the action. The CLI and Codex retain local stopReason responses; the legacy
    Claude prompt form retains stderr and exit 2.
    """
    if payload.get("hook_event_name") == "UserPromptExpansion":
        if harness == "claude-code" and os.environ.get("CLAUDE_CODE_ENTRYPOINT") in {
            "claude-desktop",
            "claude-desktop-3p",
        }:
            name = str(payload.get("command_name", "")).lower()
            out.write(f"VICARIA_COMMAND_RESULT {name}\n{line}\n")
        else:
            out.write(json.dumps({"continue": False, "stopReason": line}))
        out.flush()
        return EXIT_ALWAYS
    print(line, file=sys.stderr)
    return EXIT_SWALLOWED


class Reply:
    """What this hook shows the person: at most one answer on stdout.

    ``words`` rewrites every line for the harness (Codex takes ``vicaria off``
    where Claude Code takes ``/vicaria:off``).

    Lines said along the way (a connection that just finished, the session-start
    line, the question) are gathered and written once: as a command result when
    a command ends the hook, as one ``systemMessage`` otherwise.  Two objects
    were written when a connection finished on the prompt that was a
    command, and neither is a line anybody could rely on seeing.
    """

    def __init__(
        self, payload: dict[str, Any], out: Any, words: Any = None, *, harness: str = "claude-code"
    ) -> None:
        self.payload = payload
        self.out = out
        self.lines: list[str] = []
        self.done = False
        self.words = words or (lambda line: line)
        self.harness = harness

    def say(self, line: str) -> None:
        self.lines.append(self.words(line))

    def stop(self, line: str) -> int:
        self.done = True
        return answer_command(
            self.payload,
            "\n".join([*self.lines, self.words(line)]),
            self.out,
            harness=self.harness,
        )

    def flush(self) -> None:
        if not self.done and self.lines:
            self.done = True
            _say(self.payload, "\n".join(self.lines), self.out)


#: The hook events' own time limits, as ``hooks.json`` sets them.  Kept here
#: beside the budgets derived from them; a test holds the two in step.
HOOK_LIMIT_S = {
    "SessionStart": 15.0,
    "UserPromptSubmit": 10.0,
    "UserPromptExpansion": 10.0,
    "SubagentStop": 15.0,
    "Stop": 15.0,
    "StopFailure": 15.0,
    "SessionEnd": 60.0,
}
DEFAULT_LIMIT_S = 5.0

#: The per-request budget, from the hook event's own time limit: two round
#: trips (a mint and the coverage publish, or a revoke and a mint; a revoke
#: and a flush) have to fit inside one hook with room to answer, or a slow
#: service prevents the local command result from reaching the person. The
#: collector makes at most one revoke attempt and one deferred offer per
#: process and skips the coverage publish after a revoke, so two is the
#: count.  The budget is urllib's socket timeout, per blocking operation,
#: not a bound on the whole request: a service that answers in pieces can
#: take longer, and the harness's own limit is the last word.  `SessionEnd`
#: keeps the same per-request budget under its longer limit: the room goes
#: to the number of chunks a flush may start (`deadline_for`), not to one
#: slow answer.
BUDGET_S = {
    "SessionStart": 5.0,
    "UserPromptSubmit": 3.0,
    "UserPromptExpansion": 3.0,
    "SessionEnd": 5.0,
}
DEFAULT_BUDGET_S = 5.0

#: A session start on a connected computer can make three requests, not two:
#: the mint, the coverage publish (once per client version), and the one
#: question (RFC 0032 §2).  At the per-request budget each, 5 + 5 + 5 is the
#: whole of the 15 s limit, with nothing left to say the start's line.  So
#: the arithmetic is:
#:
#:     mint 5  +  coverage publish 5  +  question 3  +  margin 1  =  14  <  15
#:
#: The question gets its own, shorter budget, :data:`QUESTION_BUDGET_S`, and
#: is asked only while the time left in the hook still covers that budget
#: and :data:`ANSWER_MARGIN_S` (:func:`may_ask`): a mint or a publish that
#: ran long (the budget bounds each blocking read, not a whole request)
#: skips the question rather than get the hook killed with the line unsaid.
#: The margin is for writing the answer and for the interpreter's start,
#: which runs before :func:`main` begins the clock.  A question not asked
#: is not lost: the service records asking only when it is asked, so a later
#: start asks it.
QUESTION_BUDGET_S = 3.0
ANSWER_MARGIN_S = 1.0

#: The hook's clock, a module attribute so a test can stand in for it.
clock = time.monotonic


def may_ask(elapsed_s: float, event: Any = "SessionStart") -> bool:
    """Whether a hook that has run ``elapsed_s`` still has time to ask."""
    left = HOOK_LIMIT_S.get(str(event), DEFAULT_LIMIT_S) - elapsed_s
    return left >= QUESTION_BUDGET_S + ANSWER_MARGIN_S


#: What the drop log calls a turn that was never recorded at all. Not one of
#: ``CaptureStore.DROP_REASONS``: those name a queued item that was purged, and
#: this is material that never reached the queue.
HOOK_FAILED = "hook_failed"

#: Upload scheduling lives in background.py. Recording stays synchronous;
#: network delivery runs in a bounded child across this harness home's backlog.


def _payload(stream: Any) -> dict[str, Any]:
    try:
        raw = stream.read()
    except (OSError, ValueError):
        return {}
    if not raw:
        return {}
    try:
        document = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return document if isinstance(document, dict) else {}


def budget_for(event: Any) -> float:
    return BUDGET_S.get(str(event), DEFAULT_BUDGET_S)


def deadline_for(event: Any) -> float:
    """How long a flush may keep starting chunks: the hook's limit less one
    request's budget and a second to answer, so the last chunk started still
    ends inside the limit."""
    limit = HOOK_LIMIT_S.get(str(event), DEFAULT_LIMIT_S)
    return max(0.0, limit - budget_for(event) - 1.0)


def main(argv: list[str] | None = None) -> int:
    # stdout is contract: Claude Code reads a hook's stdout as its answer and,
    # on some events, hands plain text to the model.  Nothing in capture may
    # print there by accident, so it is stderr for the whole run, and the one
    # answer this hook gives is written to the real stream on purpose.
    started = clock()
    out = sys.stdout
    argv = list(sys.argv[1:] if argv is None else argv)
    if argv[:1] == ["--flush"]:
        with contextlib.redirect_stdout(sys.stderr):
            return _flush_only(argv[1:])
    harness = os.environ.get("VICARIA_HARNESS") or "claude-code"
    payload = _payload(sys.stdin)
    if not payload.get("hook_event_name") and argv:
        # The shim passes the event name as an argument as well, so a payload
        # that omits it still routes.
        payload["hook_event_name"] = argv[0]
    words = None
    if harness == "codex":
        from smart_gateway.capture import codex_plugin

        payload = codex_plugin.normalize(payload)
        words = codex_plugin.words
    reply = Reply(payload, out, words, harness=harness)
    with contextlib.redirect_stdout(sys.stderr):
        try:
            return _main(payload, reply, started, harness)
        finally:
            # What was said before a failure is still said: "Connected" on
            # a prompt whose recording then failed is still true.
            with contextlib.suppress(Exception):
                reply.flush()
            from smart_gateway.capture.background import after_event

            with contextlib.suppress(Exception):
                after_event(harness, payload, home=_home(harness))


def _home(harness: str) -> str | None:
    """The client home for this harness's link.  Codex's plugin keeps its own
    (the shim sets it), where the terminal launcher kept Codex's before it:
    a link names its app, and one app's link is not another's."""
    from smart_gateway.capture.cli import ENV

    home = os.environ.get(ENV["home"])
    if harness == "codex" and not home:
        return str(Path.home() / ".vicaria" / "harnesses" / "codex")
    return home


def _flush_only(argv: list[str]) -> int:
    """``--flush <harness> <session>``: offer one session's queue, then exit.

    Legacy entry point retained for callers already running the old hook.
    New hooks schedule the bounded home-wide worker in background.py.
    """
    try:
        harness, session_id = argv[0], argv[1]
        from smart_gateway.capture.cli import resolve_credentials
        from smart_gateway.capture.collector import collector_for

        home = _home(harness)
        credentials = resolve_credentials(home=home)
        if credentials is None:
            return EXIT_ALWAYS
        collector_for(
            harness,
            org_id=credentials["org"],
            server=credentials["server"],
            token=credentials["token"],
            home=home,
            timeout_s=DEFAULT_BUDGET_S,
        ).flush(session_id)
    except Exception as failure:
        _record_failure({"session_id": argv[1] if len(argv) > 1 else None}, failure, say=False)
    return EXIT_ALWAYS


def _main(
    payload: dict[str, Any], reply: Reply, started: float, harness: str = "claude-code"
) -> int:

    try:
        from smart_gateway.capture import claude_code
        from smart_gateway.capture.cli import _sampled_from_env, resolve_credentials
        from smart_gateway.capture.collector import CaptureRefused, collector_for

        is_command = claude_code.is_command(payload)
        home = _home(harness)
        # The session this event belongs to: a link finished here is
        # announced in this session, and only here (`connect.finish`).
        given = payload.get("session_id")
        session = given if isinstance(given, str) and given else None
        version = str(
            payload.get("harness_version")
            or claude_code.harness_version_from(os.environ)
            or "unknown"
        )
        if harness == "codex" and not is_command:
            # The plan for this prompt, shown and never applied (the plugin's
            # part of what `sg capture codex` did before it was retired).
            from smart_gateway.capture import codex_plugin

            advised = codex_plugin.advice(payload)
            if advised:
                reply.say(advised)
        if claude_code.command_verb(payload) == "connect":
            # Needs no credential: this is how the machine gets one.
            from smart_gateway.capture import connect

            args = payload.get("command_args")
            try:
                line = connect.command(
                    CaptureStore(home),
                    args if isinstance(args, str) else None,
                    session_id=session,
                    harness_version=version,
                    harness=harness,
                )
            except Exception as failure:
                # The failure, with its exception, goes to the drop log; the
                # person reads what to do, in their words.
                _record_failure(payload, failure, say=False)
                line = connect.CONNECT_FAILED_LINE
            return reply.stop(line)
        credentials = resolve_credentials(home=home)
        if credentials is None:
            # A connection the person approved in the browser is finished
            # here, at the next hook event, whatever the event: this is the
            # prompt after they came back from the browser.
            from smart_gateway.capture import connect

            said = connect.finish(CaptureStore(home), session_id=session, harness_version=version)
            if said is not None:
                credentials = resolve_credentials(home=home)
                # Says only "connected": whether a session is on is the
                # start's line to say, or the minting prompt's, after it
                # (`connect.finish` marked this session for that).
                reply.say(said)
        if credentials is None:
            # Not configured for capture at all --- no environment, no device
            # link: the ordinary case on a machine where nobody turned it on.
            # A `/vicaria` command still gets its locally computed answer,
            # and a session starting where a person installed the plugin to
            # connect says how, once per start.
            if is_command:
                return reply.stop(claude_code.NO_LINK_LINE)
            if not reply.lines and claude_code.starts_unconnected(payload, os.environ):
                reply.say(_unconnected_line(CaptureStore(home)))
            return EXIT_ALWAYS
        # A device link is the individual path: the person agreed once on the
        # website, and the link is the service-issued eligibility receipt, so
        # gate 1 is open without the environment flag.
        standing = credentials["source"] == "device"

        collector = collector_for(
            harness,
            org_id=credentials["org"],
            server=credentials["server"],
            token=credentials["token"],
            home=home,
            harness_version=version,
            # What a collector surfaces goes to stderr, not to stdout where a
            # hook's output is contract: Claude Code shows it only for a hook
            # that exits 2, so the person's lines go through `reply` instead.
            surface=lambda line: print(line, file=sys.stderr),
            timeout_s=budget_for(payload.get("hook_event_name")),
            deadline_s=deadline_for(payload.get("hook_event_name")),
        )
        if is_command:
            # The action stays local even if it fails. Desktop receives the
            # result through its command template; other entrypoints stop
            # locally. Never ask the model to perform the action again.
            try:
                answer = claude_code.command(collector, payload, standing=standing)
            except Exception as failure:
                # One line, not two: the drop-log record without the "this
                # turn was not recorded" sentence, which is about a turn and
                # this was a command.
                _record_failure(payload, failure, say=False)
                if standing:
                    # A person on a connected computer: the exception and
                    # the log's path are ours, and what to do is theirs.
                    answer = claude_code.COMMAND_FAILED_LINE
                else:
                    answer = (
                        "vicaria capture: the command could not be completed "
                        f"({type(failure).__name__}: {failure}); "
                        "see ~/.vicaria/records/drops.jsonl"
                    )
            return reply.stop(answer or claude_code.ALREADY_OFF_LINE)
        # A link was just made in this session, here or at a tool or stop
        # event before this: the first event of the session that mints says
        # what came of it, and takes the session's marker so nothing says it
        # twice.  Another session's marker is that session's to take.  A
        # session start says it anyway; a compaction's start mints nothing, so
        # it leaves the marker, and so does a command (answered above).  Only
        # on the device link: an organization's prompt mints nothing here, so
        # it leaves the marker for a prompt that does.
        event_name = payload.get("hook_event_name")
        announce = (
            standing
            and session is not None
            and (
                event_name == "UserPromptSubmit"
                or (event_name == "SessionStart" and payload.get("source") != "compact")
            )
            and CaptureStore(home).take_announce_next_mint(session)
        )
        if standing and payload.get("hook_event_name") == "SessionStart":
            # The session-start line and the one question (RFC 0032 §2), in
            # place of the mint `handle` would make: `start` makes it.
            try:
                lines = claude_code.start(
                    collector,
                    payload,
                    question_timeout_s=QUESTION_BUDGET_S,
                    may_ask=lambda: may_ask(clock() - started),
                )
                for line in lines:
                    reply.say(line)
            except CaptureRefused as refusal:
                if refusal.reason != "unreachable":
                    raise
                _record_failure(payload, refusal, say=False)
                reply.say(claude_code.START_UNREACHABLE_LINE.format(server=credentials["server"]))
            return EXIT_ALWAYS
        # A prompt that mints (the start could not, or never ran) says so in
        # the reply, as a start does; see `claude_code.handle`.  The first
        # prompt after a link was made in this session says what came of its
        # mint, on or why not: the person was told to keep working, and
        # "connected" alone reads as on.
        try:
            claude_code.handle(
                collector,
                payload,
                sampled=_sampled_from_env() or standing,
                standing=standing,
                say=reply.say,
                announce=reply.say if announce else None,
                defer_upload=True,
            )
        except CaptureRefused as refusal:
            if not (announce and refusal.reason == "unreachable"):
                raise
            _record_failure(payload, refusal, say=False)
            reply.say(claude_code.START_UNREACHABLE_LINE.format(server=credentials["server"]))
            return EXIT_ALWAYS

        if (harness == "codex" and not is_command and standing and session
                and collector.active(session)):
            # A personal request follows the successful session mint, so its
            # device grant exists before the advisor checks it. Paused and
            # unconnected sessions never ask through this path.
            from smart_gateway.capture import codex_plugin

            advised = codex_plugin.advice(
                payload, device=credentials,
                budget_s=max(0.0, HOOK_LIMIT_S.get(event_name, DEFAULT_LIMIT_S)
                             - (clock() - started) - 0.5),
            )
            if advised:
                reply.say(advised)

        if event_name == "SessionEnd" and session:
            # A benchmark/container may disappear as soon as this hook returns.
            # Keep one bounded synchronous delivery opportunity for its own
            # session, then let the detached worker retry the rest of the home.
            # The shared delivery lock and persisted outage backoff apply here
            # too; recording the stop above never waits for that lock.
            from smart_gateway.capture.background import run

            run(
                harness,
                collector=collector,
                session_id=session,
                max_seconds=max(0.0, HOOK_LIMIT_S["SessionEnd"] - (clock() - started) - 1),
            )

    except Exception as failure:
        _record_failure(payload, failure)
        return EXIT_ALWAYS
    return EXIT_ALWAYS


def _unconnected_line(store: CaptureStore) -> str:
    """Installed and not connected: how to connect, or the code waiting."""
    from smart_gateway.capture import connect

    pending = store.connect()
    if pending is not None:
        return (
            f"Vicaria: type code {pending['user_code']} at "
            f"{connect.approve_url(pending['server'])} to finish connecting."
        )
    from smart_gateway.capture import claude_code

    return claude_code.NOT_CONNECTED_LINE


def _say(payload: dict[str, Any], line: str, out: Any) -> None:
    """Show one line to the person on an event that is not a command.

    Claude Code shows a hook's ``systemMessage`` and hands the model none of
    it (verified on 2.1.280 at ``SessionStart``: "SessionStart:startup says:
    …").  stderr on exit 0 goes to the debug log, which nobody reads.
    """
    out.write(json.dumps({"systemMessage": line}))
    out.flush()


def _record_failure(payload: dict[str, Any], failure: BaseException, *, say: bool = True) -> None:
    """Leave a line the developer can find, and never raise doing it.

    Two places, because they answer different questions: the drop log answers
    "what did not make it off this machine" days later, and stderr answers "is
    capture working" now, for a developer reading the hook's debug output.
    Neither is a line the person sees: Claude Code does not show stderr from
    a hook that exits 0, and no notice points at it.
    """
    session_id = payload.get("session_id")
    event = payload.get("hook_event_name")
    detail = f"{type(failure).__name__}: {failure}"
    # A closed or broken stderr is not worth a crash on the way out.
    what = {"SessionStart": "session start", "SessionEnd": "session end"}.get(event, "turn")
    if say:
        with contextlib.suppress(Exception):
            print(
                f"vicaria capture: this {what} was not recorded ({detail}); "
                "capture is not running for it",
                file=sys.stderr,
            )
    # Reporting a failure may not cause one: an unwritable records directory
    # leaves the stderr line above as the whole of the record, which is thin
    # and is still not silence.
    with contextlib.suppress(Exception):
        from smart_gateway.capture.cli import ENV
        from smart_gateway.capture.store import CaptureStore, utc_now

        CaptureStore(os.environ.get(ENV["home"])).append_drop_log(
            {
                "at": utc_now(),
                "event_id": None,
                "session_id": session_id if isinstance(session_id, str) else None,
                "reason": HOOK_FAILED,
                "hook_event": event if isinstance(event, str) else None,
                "detail": detail,
            }
        )


if __name__ == "__main__":
    sys.exit(main())
