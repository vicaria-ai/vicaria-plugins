"""``python3 -m smart_gateway.capture.hook <Event>``: the Claude Code hook entry.

Invisible by construction.  A hook runs on every event of every session, and the
overwhelming majority of sessions are not marked, so the fast path here is:
read stdin, look up one file, find no open interval, exit 0 having printed
nothing.  Everything that could be slow or noisy is behind that check.

Failure never stops the session, and it is never silent
------------------------------------------------------
A capture that cannot reach its service must not become a coding session that
will not start, so the exit code is 0.  A command is answered where the person
sees it and the model does not: the plugin's ``/vicaria:off`` at
``UserPromptExpansion`` with ``{"continue": false, "stopReason": ...}`` on
stdout, the one thing this hook ever writes there, and ``/vicaria off`` typed
as a prompt at ``UserPromptSubmit`` with exit 2 and the line on stderr.  That
is not the same as saying nothing.  A deferred upload already left the events
on disk and a line in the developer's own upload log; this module owes the
same for the failures that happen *before* an upload is even attempted.

It did not.  ``except Exception: return 0`` covered the whole body, so a marked
session whose ``producer-seq`` file had been left holding something other than
an integer — which :meth:`CaptureStore.next_sequence` refuses to guess past, on
purpose — dropped every turn from then on with nothing written anywhere and
nothing printed, while the session's mark had already told the developer
capture was running.  A failure rendered as a silent success is
the one outcome this project does not permit, so the swallow now leaves a line
in the drop log and one on stderr, the developer's debug output (Claude Code
does not show stderr from a hook that exits 0).  The recording itself
is best-effort and wrapped: a hook that crashed while reporting a crash would be
the original bug again.
"""

from __future__ import annotations

import contextlib
import json
import os
import sys
import time
from typing import Any

from smart_gateway.capture.store import CaptureStore

EXIT_ALWAYS = 0

#: The one other exit status, and only on ``UserPromptSubmit``: the prompt was
#: a ``/vicaria on|off|status`` command, the hook answered it on stderr, and
#: Claude Code's contract for exit 2 there is exactly what a command needs ---
#: the prompt is not sent to the model and stderr is shown to the person.
EXIT_SWALLOWED = 2


def answer_command(payload: dict[str, Any], line: str, out: Any) -> int:
    """Show one line and stop the command there, in the form its event takes.

    ``UserPromptExpansion``: ``continue: false`` with the line as the stop
    reason, which Claude Code shows as "Operation stopped by hook: <line>"
    and sends nowhere else.  ``UserPromptSubmit``: the line on stderr and
    exit 2, the prompt swallowed.
    """
    if payload.get("hook_event_name") == "UserPromptExpansion":
        out.write(json.dumps({"continue": False, "stopReason": line}))
        out.flush()
        return EXIT_ALWAYS
    print(line, file=sys.stderr)
    return EXIT_SWALLOWED


class Reply:
    """What this hook shows the person: at most one answer on stdout.

    Claude Code reads one JSON object from a hook's stdout, so lines said
    along the way (a connection that just finished, the session-start line,
    the question) are gathered and written once: as the stop reason when a
    command ends the hook, as one ``systemMessage`` otherwise.  Two objects
    were written when a connection finished on the prompt that was a
    command, and neither is a line anybody could rely on seeing.
    """

    def __init__(self, payload: dict[str, Any], out: Any) -> None:
        self.payload = payload
        self.out = out
        self.lines: list[str] = []
        self.done = False

    def say(self, line: str) -> None:
        self.lines.append(line)

    def stop(self, line: str) -> int:
        self.done = True
        return answer_command(self.payload, "\n".join([*self.lines, line]), self.out)

    def flush(self) -> None:
        if not self.done and self.lines:
            self.done = True
            _say(self.payload, "\n".join(self.lines), self.out)


#: The hook events' own time limits, as ``hooks.json`` sets them.  Kept here
#: beside the budgets derived from them; a test holds the two in step.
HOOK_LIMIT_S = {
    "SessionStart": 15.0,
    "UserPromptSubmit": 10.0,
    "UserPromptExpansion": 10.0,
    "SubagentStop": 15.0,
    "Stop": 15.0,
    "StopFailure": 15.0,
    "SessionEnd": 60.0,
}
DEFAULT_LIMIT_S = 5.0

#: The per-request budget, from the hook event's own time limit: two round
#: trips (a mint and the coverage publish, or a revoke and a mint; a revoke
#: and a flush) have to fit inside one hook with room to answer, or a slow
#: service turns a ``/vicaria`` command into a prompt the model sees.  The
#: collector makes at most one revoke attempt and one deferred offer per
#: process and skips the coverage publish after a revoke, so two is the
#: count.  The budget is urllib's socket timeout, per blocking operation,
#: not a bound on the whole request: a service that answers in pieces can
#: take longer, and the harness's own limit is the last word.  `SessionEnd`
#: keeps the same per-request budget under its longer limit: the room goes
#: to the number of chunks a flush may start (`deadline_for`), not to one
#: slow answer.
BUDGET_S = {
    "SessionStart": 5.0,
    "UserPromptSubmit": 3.0,
    "UserPromptExpansion": 3.0,
    "SessionEnd": 5.0,
}
DEFAULT_BUDGET_S = 5.0

#: A session start on a connected computer can make three requests, not two:
#: the mint, the coverage publish (once per client version), and the one
#: question (RFC 0032 §2).  At the per-request budget each, 5 + 5 + 5 is the
#: whole of the 15 s limit, with nothing left to say the start's line.  So
#: the arithmetic is:
#:
#:     mint 5  +  coverage publish 5  +  question 3  +  margin 1  =  14  <  15
#:
#: The question gets its own, shorter budget, :data:`QUESTION_BUDGET_S`, and
#: is asked only while the time left in the hook still covers that budget
#: and :data:`ANSWER_MARGIN_S` (:func:`may_ask`): a mint or a publish that
#: ran long (the budget bounds each blocking read, not a whole request)
#: skips the question rather than get the hook killed with the line unsaid.
#: The margin is for writing the answer and for the interpreter's start,
#: which runs before :func:`main` begins the clock.  A question not asked
#: is not lost: the service records asking only when it is asked, so a later
#: start asks it.
QUESTION_BUDGET_S = 3.0
ANSWER_MARGIN_S = 1.0

#: The hook's clock, a module attribute so a test can stand in for it.
clock = time.monotonic


def may_ask(elapsed_s: float, event: Any = "SessionStart") -> bool:
    """Whether a hook that has run ``elapsed_s`` still has time to ask."""
    left = HOOK_LIMIT_S.get(str(event), DEFAULT_LIMIT_S) - elapsed_s
    return left >= QUESTION_BUDGET_S + ANSWER_MARGIN_S


#: What the drop log calls a turn that was never recorded at all. Not one of
#: ``CaptureStore.DROP_REASONS``: those name a queued item that was purged, and
#: this is material that never reached the queue.
HOOK_FAILED = "hook_failed"

#: The hook events that offer the queue to the service. Only the end of the
#: session, so no turn pays for a network round trip: every hook here is one
#: the manifest runs synchronously, and a synchronous hook that waits on a
#: server is a coding session that waits on a server.
#:
#: What this costs is durability between flushes, and it is a real cost rather
#: than a theoretical one. `Stop` used to upload every turn, so a session killed
#: mid-flight stranded at most one turn's events; now it strands the session's.
#: They are not lost — the queue is bytes on disk, `sg capture flush` offers them
#: again, and `records/uploads.jsonl` is how a developer sees what did and did
#: not leave — but nothing drains them automatically until some later command
#: does, because both automatic callers hang off `SessionEnd`. That is the
#: trade: a turn whose reply was never recorded cannot be recovered by anyone,
#: and a queue that has not been offered yet can.
FLUSH_EVENTS = ("SessionEnd",)


def _payload(stream: Any) -> dict[str, Any]:
    try:
        raw = stream.read()
    except (OSError, ValueError):
        return {}
    if not raw:
        return {}
    try:
        document = json.loads(raw)
    except json.JSONDecodeError:
        return {}
    return document if isinstance(document, dict) else {}


def budget_for(event: Any) -> float:
    return BUDGET_S.get(str(event), DEFAULT_BUDGET_S)


def deadline_for(event: Any) -> float:
    """How long a flush may keep starting chunks: the hook's limit less one
    request's budget and a second to answer, so the last chunk started still
    ends inside the limit."""
    limit = HOOK_LIMIT_S.get(str(event), DEFAULT_LIMIT_S)
    return max(0.0, limit - budget_for(event) - 1.0)


def main(argv: list[str] | None = None) -> int:
    # stdout is contract: Claude Code reads a hook's stdout as its answer and,
    # on some events, hands plain text to the model.  Nothing in capture may
    # print there by accident, so it is stderr for the whole run, and the one
    # answer this hook gives is written to the real stream on purpose.
    started = clock()
    out = sys.stdout
    argv = list(sys.argv[1:] if argv is None else argv)
    payload = _payload(sys.stdin)
    if not payload.get("hook_event_name") and argv:
        # The shim passes the event name as an argument as well, so a payload
        # that omits it still routes.
        payload["hook_event_name"] = argv[0]
    reply = Reply(payload, out)
    with contextlib.redirect_stdout(sys.stderr):
        try:
            return _main(payload, reply, started)
        finally:
            # What was said before a failure is still said: "Connected" on
            # a prompt whose recording then failed is still true.
            with contextlib.suppress(Exception):
                reply.flush()


def _main(payload: dict[str, Any], reply: Reply, started: float) -> int:

    try:
        from smart_gateway.capture import claude_code
        from smart_gateway.capture.cli import ENV, _sampled_from_env, resolve_credentials
        from smart_gateway.capture.collector import CaptureRefused, collector_for

        is_command = claude_code.is_command(payload)
        home = os.environ.get(ENV["home"])
        # The session this event belongs to: a link finished here is
        # announced in this session, and only here (`connect.finish`).
        given = payload.get("session_id")
        session = given if isinstance(given, str) and given else None
        version = str(
            payload.get("harness_version")
            or claude_code.harness_version_from(os.environ)
            or "unknown"
        )
        if claude_code.command_verb(payload) == "connect":
            # Needs no credential: this is how the machine gets one.
            from smart_gateway.capture import connect

            args = payload.get("command_args")
            try:
                line = connect.command(
                    CaptureStore(home),
                    args if isinstance(args, str) else None,
                    session_id=session,
                    harness_version=version,
                )
            except Exception as failure:
                # The failure, with its exception, goes to the drop log; the
                # person reads what to do, in their words.
                _record_failure(payload, failure, say=False)
                line = connect.CONNECT_FAILED_LINE
            return reply.stop(line)
        credentials = resolve_credentials(home=home)
        if credentials is None:
            # A connection the person approved in the browser is finished
            # here, at the next hook event, whatever the event: this is the
            # prompt after they came back from the browser.
            from smart_gateway.capture import connect

            said = connect.finish(CaptureStore(home), session_id=session, harness_version=version)
            if said is not None:
                credentials = resolve_credentials(home=home)
                # Says only "connected": whether a session is on is the
                # start's line to say, or the minting prompt's, after it
                # (`connect.finish` marked this session for that).
                reply.say(said)
        if credentials is None:
            # Not configured for capture at all --- no environment, no device
            # link: the ordinary case on a machine where nobody turned it on.
            # A `/vicaria` command still gets its answer rather than the model,
            # and a session starting where a person installed the plugin to
            # connect says how, once per start.
            if is_command:
                return reply.stop(claude_code.NO_LINK_LINE)
            if not reply.lines and claude_code.starts_unconnected(payload, os.environ):
                reply.say(_unconnected_line(CaptureStore(home)))
            return EXIT_ALWAYS
        # A device link is the individual path: the person agreed once on the
        # website, and the link is the service-issued eligibility receipt, so
        # gate 1 is open without the environment flag.
        standing = credentials["source"] == "device"

        collector = collector_for(
            "claude-code",
            org_id=credentials["org"],
            server=credentials["server"],
            token=credentials["token"],
            home=os.environ.get(ENV["home"]),
            harness_version=version,
            # What a collector surfaces goes to stderr, not to stdout where a
            # hook's output is contract: Claude Code shows it only for a hook
            # that exits 2, so the person's lines go through `reply` instead.
            surface=lambda line: print(line, file=sys.stderr),
            timeout_s=budget_for(payload.get("hook_event_name")),
            deadline_s=deadline_for(payload.get("hook_event_name")),
        )
        if is_command:
            # Answered with exit 2 whatever happens behind it: a command whose
            # work failed and then reached the model as a prompt would be the
            # switch thrown and nothing switched, told to the wrong party.
            try:
                answer = claude_code.command(collector, payload, standing=standing)
            except Exception as failure:
                # One line, not two: the drop-log record without the "this
                # turn was not recorded" sentence, which is about a turn and
                # this was a command.
                _record_failure(payload, failure, say=False)
                if standing:
                    # A person on a connected computer: the exception and
                    # the log's path are ours, and what to do is theirs.
                    answer = claude_code.COMMAND_FAILED_LINE
                else:
                    answer = (
                        "vicaria capture: the command could not be completed "
                        f"({type(failure).__name__}: {failure}); "
                        "see ~/.vicaria/records/drops.jsonl"
                    )
            return reply.stop(answer or claude_code.ALREADY_OFF_LINE)
        # A link was just made in this session, here or at a tool or stop
        # event before this: the first event of the session that mints says
        # what came of it, and takes the session's marker so nothing says it
        # twice.  Another session's marker is that session's to take.  A
        # session start says it anyway; a compaction's start mints nothing, so
        # it leaves the marker, and so does a command (answered above).  Only
        # on the device link: an organization's prompt mints nothing here, so
        # it leaves the marker for a prompt that does.
        event_name = payload.get("hook_event_name")
        announce = (
            standing
            and session is not None
            and (
                event_name == "UserPromptSubmit"
                or (event_name == "SessionStart" and payload.get("source") != "compact")
            )
            and CaptureStore(home).take_announce_next_mint(session)
        )
        if standing and payload.get("hook_event_name") == "SessionStart":
            # The session-start line and the one question (RFC 0032 §2), in
            # place of the mint `handle` would make: `start` makes it.
            try:
                lines = claude_code.start(
                    collector,
                    payload,
                    question_timeout_s=QUESTION_BUDGET_S,
                    may_ask=lambda: may_ask(clock() - started),
                )
                for line in lines:
                    reply.say(line)
            except CaptureRefused as refusal:
                if refusal.reason != "unreachable":
                    raise
                _record_failure(payload, refusal, say=False)
                reply.say(claude_code.START_UNREACHABLE_LINE.format(server=credentials["server"]))
            return EXIT_ALWAYS
        # A prompt that mints (the start could not, or never ran) says so in
        # the reply, as a start does; see `claude_code.handle`.  The first
        # prompt after a link was made in this session says what came of its
        # mint, on or why not: the person was told to keep working, and
        # "connected" alone reads as on.
        try:
            claude_code.handle(
                collector,
                payload,
                sampled=_sampled_from_env() or standing,
                standing=standing,
                say=reply.say,
                announce=reply.say if announce else None,
            )
        except CaptureRefused as refusal:
            if not (announce and refusal.reason == "unreachable"):
                raise
            _record_failure(payload, refusal, say=False)
            reply.say(claude_code.START_UNREACHABLE_LINE.format(server=credentials["server"]))
            return EXIT_ALWAYS

        # A marked session flushes when the session ends, and not once per turn.
        #
        # `Stop` used to flush too, which put a network round trip on the end of
        # every turn. That cost is why the manifest ran `Stop` in the background,
        # and running it in the background is why `claude -p` exited before the
        # hook had recorded anything: in every run measured, the reply was absent
        # from the trajectory at exit, at the flush that followed and on the
        # service — and a benchmark runner that tears its workspace down at exit
        # has no later point. `Stop` is synchronous now, so what it must do is the part that
        # cannot be redone later: write the event. The upload can wait for
        # `SessionEnd`, which is synchronous already and runs once. On a marked
        # session that is one flush more than strictly needed — `handle` routes
        # `SessionEnd` to `collector.stop`, which flushes on its way out — and
        # the second call is cheap against an empty queue and is what still
        # drains a session whose `stop` refused.
        if payload.get("hook_event_name") in FLUSH_EVENTS:
            session_id = payload.get("session_id")
            if isinstance(session_id, str) and session_id:
                # An opted-out machine's flush sends nothing; its answer says
                # `opted_out`, and the hook prints nothing of it.
                collector.flush(session_id)
    except Exception as failure:
        _record_failure(payload, failure)
        return EXIT_ALWAYS
    return EXIT_ALWAYS


def _unconnected_line(store: CaptureStore) -> str:
    """Installed and not connected: how to connect, or the code waiting."""
    from smart_gateway.capture import connect

    pending = store.connect()
    if pending is not None:
        return (
            f"Vicaria: type code {pending['user_code']} at "
            f"{connect.approve_url(pending['server'])} to finish connecting."
        )
    from smart_gateway.capture import claude_code

    return claude_code.NOT_CONNECTED_LINE


def _say(payload: dict[str, Any], line: str, out: Any) -> None:
    """Show one line to the person on an event that is not a command.

    Claude Code shows a hook's ``systemMessage`` and hands the model none of
    it (verified on 2.1.280 at ``SessionStart``: "SessionStart:startup says:
    …").  stderr on exit 0 goes to the debug log, which nobody reads.
    """
    out.write(json.dumps({"systemMessage": line}))
    out.flush()


def _record_failure(payload: dict[str, Any], failure: BaseException, *, say: bool = True) -> None:
    """Leave a line the developer can find, and never raise doing it.

    Two places, because they answer different questions: the drop log answers
    "what did not make it off this machine" days later, and stderr answers "is
    capture working" now, for a developer reading the hook's debug output.
    Neither is a line the person sees: Claude Code does not show stderr from
    a hook that exits 0, and no notice points at it.
    """
    session_id = payload.get("session_id")
    event = payload.get("hook_event_name")
    detail = f"{type(failure).__name__}: {failure}"
    # A closed or broken stderr is not worth a crash on the way out.
    what = {"SessionStart": "session start", "SessionEnd": "session end"}.get(event, "turn")
    if say:
        with contextlib.suppress(Exception):
            print(
                f"vicaria capture: this {what} was not recorded ({detail}); "
                "capture is not running for it",
                file=sys.stderr,
            )
    # Reporting a failure may not cause one: an unwritable records directory
    # leaves the stderr line above as the whole of the record, which is thin
    # and is still not silence.
    with contextlib.suppress(Exception):
        from smart_gateway.capture.cli import ENV
        from smart_gateway.capture.store import CaptureStore, utc_now

        CaptureStore(os.environ.get(ENV["home"])).append_drop_log(
            {
                "at": utc_now(),
                "event_id": None,
                "session_id": session_id if isinstance(session_id, str) else None,
                "reason": HOOK_FAILED,
                "hook_event": event if isinstance(event, str) else None,
                "detail": detail,
            }
        )


if __name__ == "__main__":
    sys.exit(main())
