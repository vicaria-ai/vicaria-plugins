"""The one question at a session start, and the answer typed where the work is.

RFC 0032 §2: at the start of the next session one line asks whether the
newest task worked, named by its first prompt so the person knows which, and
``/vicaria:yes``, ``/vicaria:partly`` or ``/vicaria:no`` answers it.  The
service picks the task and records that it asked, so a task is asked about
once on whichever machine starts first.

The question belongs to the terminal session it was shown in.  This module
keeps it in that session's own file (``capture/questions/<digest>.json``,
see :meth:`CaptureStore.question_path`), and an answer binds to the task
kept for the session the command was typed in: two terminals open side by
side each answer their own question, never the other's.  A session start
with nothing to ask clears its own session's file and no other: an answer
typed there has nothing to bind to, and says so rather than answering a
question the person was not shown in that session.  Answering twice
replaces the answer (the service keeps the latest), so a slip is corrected
by typing the other one.
"""

from __future__ import annotations

from typing import Any

from smart_gateway.capture.api import CaptureApi
from smart_gateway.capture.store import CaptureStore, utc_now

#: What the person types, as the commands name it.
ANSWERS = ("yes", "partly", "no")

#: How much of a task's first prompt names it in a line.
TITLE_LIMIT = 60

QUESTION_LINE = "Last time, “{title}”: did it work? /vicaria:yes · /vicaria:partly · /vicaria:no"
ANSWERED_LINES = {
    "yes": "Vicaria: thanks. “{title}” worked; that's recorded.",
    "partly": "Vicaria: thanks. “{title}” partly worked; that's recorded.",
    "no": "Vicaria: thanks. “{title}” didn't work; that's recorded.",
}
NOTHING_TO_ANSWER_LINE = (
    "Vicaria: there's no question waiting in this session. "
    "Your tasks, and their answers, are at {site}."
)
GONE_LINE = "Vicaria: that task was deleted on the website, so there's nothing to answer."
NOT_SHARING_LINE = (
    "Vicaria: sharing is off for your account, so the answer wasn't recorded. "
    "Turn it back on in Settings at {site}."
)
UNREACHABLE_LINE = (
    "Vicaria: couldn't reach {server}, so the answer wasn't recorded. Try again in a moment."
)
#: Any other refusal of an answer.  The service's words are not the
#: person's, so the line says what happened and where else to answer.
FAILED_LINE = (
    "Vicaria: the answer wasn't recorded (the server refused it). You can answer at {site}."
)

#: The service's names for a token that no longer opens anything: the
#: computer removed on the website (403), the account behind it deleted
#: (410), or a token it never issued (401).  Kept here, where the answer
#: needs them, and re-exported by :mod:`~smart_gateway.capture.claude_code`
#: (the session start) and :mod:`~smart_gateway.capture.connect` (the check
#: before connecting again), which import this module.
DISCONNECTED_ERRORS = frozenset({"device_revoked", "unknown_device_token", "account_deleted"})
#: A computer the person removed on the website: its token no longer opens,
#: at a session start or at an answer, and the line says what to do.
DISCONNECTED_LINE = (
    "Vicaria: this computer was disconnected on the website, so nothing is collected. "
    "Type /vicaria:connect to connect it again."
)


def site(server: str) -> str:
    """The website a person opens: the service's own page."""
    return server.rstrip("/") + "/app"


def title_of(text: Any) -> str:
    """A task named in a line: its first prompt on one line, cut short.

    An erased task has no title left; it is never asked about, and a line
    that somehow meets one says "your last task" rather than "None".
    """
    if not isinstance(text, str) or not text.strip():
        return "your last task"
    one_line = " ".join(text.split())
    if len(one_line) <= TITLE_LIMIT:
        return one_line
    return one_line[: TITLE_LIMIT - 1].rstrip() + "…"


def ask(
    store: CaptureStore, api: CaptureApi, session_id: str, *, timeout_s: float | None = None
) -> str | None:
    """Ask the service for this start's question; the line, or None.

    The question is kept for ``session_id``, the session starting.  Nothing
    to ask clears the question this session kept from an earlier start (a
    resumed session asked before), and no other session's.  A service that
    did not answer leaves the file as it was and shows nothing: the start
    already said what it could.  ``timeout_s`` is this request's own budget,
    which the hook sets shorter than the mint's.
    """
    outcome = api.question({"session_id": session_id}, timeout_s=timeout_s)
    if not outcome.ok:
        return None
    question = (outcome.value or {}).get("question") if isinstance(outcome.value, dict) else None
    if not isinstance(question, dict) or not isinstance(question.get("task_id"), str):
        store.forget_question(session_id)
        return None
    store.save_question(
        session_id,
        {
            "task_id": question["task_id"],
            "session_id": question.get("session_id"),
            "title": question.get("title"),
            "asked_in": session_id,
            "asked_at": utc_now(),
            "server": api.server,
        },
    )
    return QUESTION_LINE.format(title=title_of(question.get("title")))


def answer(store: CaptureStore, api: CaptureApi, session_id: str, said: str) -> str:
    """Record ``yes``, ``partly`` or ``no`` for the question this session was
    asked: ``session_id`` is the session the command was typed in."""
    if said not in ANSWERS:
        raise ValueError(f"an answer is one of {', '.join(ANSWERS)}")
    asked = store.question(session_id)
    if asked is None or asked.get("server") != api.server:
        # A question kept for another server (the machine was connected
        # again elsewhere) is not this server's task to answer.
        return NOTHING_TO_ANSWER_LINE.format(site=site(api.server))
    outcome = api.answer({"task_id": asked["task_id"], "answer": said})
    title = title_of(asked.get("title"))
    if outcome.ok:
        store.save_question(session_id, {**asked, "answer": said, "answered_at": utc_now()})
        return ANSWERED_LINES[said].format(title=title)
    error = outcome.value.get("error") if isinstance(outcome.value, dict) else None
    if error in DISCONNECTED_ERRORS:
        # Read before the status: the service answers a computer it no
        # longer knows with 403, 410 or 401, which by status alone said
        # "sharing is off" or "the task was deleted", neither true nor what
        # to do.  The question is kept; connecting again forgets it.
        return DISCONNECTED_LINE
    if outcome.status in (404, 410):
        store.forget_question(session_id)
        return GONE_LINE
    if outcome.status == 403:
        return NOT_SHARING_LINE.format(site=site(api.server))
    if outcome.reason == "unreachable":
        return UNREACHABLE_LINE.format(server=api.server)
    return FAILED_LINE.format(site=site(api.server))


def waiting(store: CaptureStore, session_id: str) -> dict[str, Any] | None:
    """The question this session was asked and not answered yet, for the
    status line."""
    asked = store.question(session_id)
    if asked is None or asked.get("answer"):
        return None
    return asked
