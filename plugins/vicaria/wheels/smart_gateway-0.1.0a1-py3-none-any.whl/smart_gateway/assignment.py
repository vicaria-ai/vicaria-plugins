"""The execution-assignment record: which configuration was assigned, and how.

`gate.py` reads four facts off every attempt — `assignment`, `config_label`,
`propensity` and `experiment` — and nothing in any repository writes them. This
module writes them.

WHY THE FIELDS ARE NOT OPTIONAL

`experiment` is the one that looks safe to omit and is not. `_population`
collects `_known_str(attempt.get("experiment"))` and stores the empty sentinel
when it is absent, then refuses with `mixed_experiments` only when two *named*
experiments would pool. Two labelled arms from separate experiments refuse
correctly; strip the labels and both collapse to `""`, the branch never fires,
and the gate compares arms that were never randomized against each other.
Omitting the identifier converts a correct refusal into a recommendation, so a
randomized assignment without one is refused here, at the writer — no reader
will catch it, because attempts are read permissively by design.

`propensity` is absent rather than 1.0 on a deterministic assignment. Absent and
certain are different claims, and the gate's vocabulary already distinguishes
known from unknown everywhere else; writing 1.0 would tell it a coin was flipped
and landed the same way every time.

WHAT IT DOES NOT DO

It does not decide. Something upstream chooses the configuration and the arm;
this records that choice in the shape the gate can read. It also proves nothing
about authenticity: every identifier is a string a caller supplies, so a
well-formed `experiment` naming a study this attempt was never part of reads
back clean.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from smart_gateway.measure import Measure, Reason

__all__ = [
    "ASSIGNMENT_FIELDS",
    "SCHEMA",
    "Assignment",
    "AssignmentKind",
]

SCHEMA = "sg.assignment.v1"

#: The attempt keys this record owns. Named so a caller merging it into an
#: attempt can assert it is not silently overwriting something else.
ASSIGNMENT_FIELDS = ("assignment", "config_label", "propensity", "experiment")

#: The source recorded on every Measure this module emits. The gate does not read
#: it, but a later investigation asking where a propensity came from does.
_SOURCE = "assignment_record"


class AssignmentKind(StrEnum):
    """How the configuration for this attempt was chosen.

    Only ``randomized`` is admitted to an arm comparison: `_arm_of` returns None
    for anything else, and a task carrying such an attempt is dropped as
    contaminated rather than compared. That is correct — a policy or reference
    assignment is not a coin flip — and it is why an offline matched design needs
    an estimator of its own rather than this record pretending to be randomized.
    """

    RANDOMIZED = "randomized"
    POLICY = "policy"
    REFERENCE = "reference"


@dataclass(frozen=True, slots=True)
class Assignment:
    """One attempt's assignment facts, in the shape `gate.py` reads."""

    decision_id: str
    episode_id: str
    kind: AssignmentKind
    config_label: str
    experiment: str | None = None
    propensity: float | None = None
    policy_bundle_id: str | None = None

    def __post_init__(self) -> None:
        for name in ("decision_id", "episode_id", "config_label"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value:
                raise ValueError(f"{name} must be a nonempty string, got {value!r}")
        if not isinstance(self.kind, AssignmentKind):
            raise ValueError(f"kind must be an AssignmentKind, got {type(self.kind).__name__}")

        if self.kind is AssignmentKind.RANDOMIZED:
            if not self.experiment:
                raise ValueError(
                    "a randomized assignment must name its experiment: without one the "
                    "gate's mixed_experiments refusal never fires and two arms that were "
                    "never randomized against each other are compared"
                )
            if self.propensity is None:
                raise ValueError(
                    "a randomized assignment must record the probability of this arm, or "
                    "the comparison cannot be weighted and the gate refuses on "
                    "unequal_propensity"
                )
        else:
            if self.propensity is not None:
                raise ValueError(
                    f"a {self.kind.value} assignment is not a draw, so it records no "
                    "propensity — absent and certain are different claims, and 1.0 would "
                    "assert a coin that always landed the same way"
                )

        if self.propensity is not None:
            if isinstance(self.propensity, bool) or not isinstance(self.propensity, int | float):
                raise ValueError(f"propensity must be a number, got {self.propensity!r}")
            if not 0.0 < float(self.propensity) <= 1.0:
                raise ValueError(
                    f"propensity must be in (0, 1], got {self.propensity!r} — a zero "
                    "probability means this arm could not have been drawn, which makes "
                    "the observation unprojectable rather than merely imprecise"
                )

        for name in ("experiment", "policy_bundle_id"):
            value = getattr(self, name)
            if value is not None and (not isinstance(value, str) or not value):
                raise ValueError(f"{name} must be a nonempty string when present, got {value!r}")

    @property
    def comparable(self) -> bool:
        """True when `gate.py` will admit this attempt to an arm."""
        return self.kind is AssignmentKind.RANDOMIZED

    def attempt_fields(self) -> dict[str, Any]:
        """The four keys the gate reads, ready to merge into an `sg.attempt.v1`.

        ``assignment`` is a bare string because `_arm_of` compares it directly;
        the other three are ``Measure`` JSON because the gate reads them through
        ``_measure``. Emitting the wrong encoding for either would read back as
        unknown and refuse the comparison — silently, and only at analysis time.
        """
        experiment = (
            Measure.known(self.experiment, _SOURCE)
            if self.experiment
            else Measure.unknown(Reason.NOT_CONFIGURED)
        )
        propensity = (
            Measure.known(float(self.propensity), _SOURCE)
            if self.propensity is not None
            else Measure.unknown(Reason.NOT_CONFIGURED)
        )
        return {
            "assignment": self.kind.value,
            "config_label": Measure.known(self.config_label, _SOURCE).to_json(),
            "propensity": propensity.to_json(),
            "experiment": experiment.to_json(),
        }

    def to_json(self) -> dict[str, Any]:
        """The standalone record, for the journal the decision is written to."""
        return {
            "schema": SCHEMA,
            "decision_id": self.decision_id,
            "episode_id": self.episode_id,
            "assignment": self.kind.value,
            "config_label": self.config_label,
            "experiment": self.experiment,
            "propensity": self.propensity,
            "policy_bundle_id": self.policy_bundle_id,
        }

    @classmethod
    def from_json(cls, obj: object) -> Assignment:
        if not isinstance(obj, dict):
            raise ValueError(f"assignment payload must be an object, got {type(obj).__name__}")
        schema = obj.get("schema")
        if schema != SCHEMA:
            raise ValueError(f"schema must be {SCHEMA!r}, got {schema!r}")
        kind = obj.get("assignment")
        if not isinstance(kind, str):
            raise ValueError(f"assignment must be a string, got {type(kind).__name__}")
        try:
            parsed = AssignmentKind(kind)
        except ValueError:
            valid = sorted(m.value for m in AssignmentKind)
            raise ValueError(f"assignment must be one of {valid}, got {kind!r}") from None
        return cls(
            decision_id=_require_str(obj, "decision_id"),
            episode_id=_require_str(obj, "episode_id"),
            kind=parsed,
            config_label=_require_str(obj, "config_label"),
            experiment=obj.get("experiment"),
            propensity=obj.get("propensity"),
            policy_bundle_id=obj.get("policy_bundle_id"),
        )


def _require_str(obj: dict[str, Any], key: str) -> str:
    value = obj.get(key)
    if not isinstance(value, str) or not value:
        raise ValueError(f"{key} must be a nonempty string, got {value!r}")
    return value
