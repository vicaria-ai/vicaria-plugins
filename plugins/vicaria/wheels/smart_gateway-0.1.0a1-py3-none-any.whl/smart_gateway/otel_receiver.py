"""Local OTLP http/json receiver for Claude Code's telemetry events (spec section 6.2).

Claude Code's exporter is the only channel that carries per-request token counts with a
request id, so the receiver's one job is to land those lines on disk without ever making
the exporter back up: every parsed-or-not batch is answered `200 {}`, and everything
else is a counter on the lifecycle lines. Attributes pass through a per-event allowlist
by construction; anything else (prompts, responses, tool parameters, e-mail) is recorded
by name only in `dropped_attribute_keys`, so a text-bearing attribute is visible as
dropped without its value ever touching the raw file.
"""

from __future__ import annotations

import contextlib
import json
import os
import re
import signal
import socketserver
import sys
import threading
import time
import zlib
from collections.abc import Callable
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from smart_gateway import __version__
from smart_gateway.config import ConfigError, ensure_data_dir, load_config, resolve_data_dir
from smart_gateway.ids import utc_now_iso
from smart_gateway.rawlog import append_line, atomic_write, shard_path

__all__ = [
    "ALLOWED_EVENTS",
    "DEFAULT_HEARTBEAT_S",
    "DEFAULT_IDLE_S",
    "LIFECYCLE_EVENTS",
    "MAX_BODY_BYTES",
    "PIDFILE",
    "SCHEMA",
    "BindError",
    "OtelRecord",
    "ParseStats",
    "PidRecord",
    "Receiver",
    "ReceiverStats",
    "error_class",
    "flatten_attributes",
    "parse_otlp_logs",
    "pidfile_path",
    "process_start",
    "read_pidfile",
    "read_pidfile_record",
    "serve",
]

SCHEMA = "sg.otel.v1"
PIDFILE = "otel.pid"
_START_KEY = "start="
_PROC = Path("/proc")
_PS_TIMEOUT_S = 2.0
MAX_BODY_BYTES = 8 << 20  # 8 MiB, before and after gzip
DEFAULT_HEARTBEAT_S = 60.0
DEFAULT_IDLE_S = 7200.0
# An allowlisted string longer than this cannot be an identifier; it is dropped by name
# so free text never reaches the raw file even through a key the table trusts.
MAX_STRING_LEN = 200

# Resource or record attributes that become top-level identifier fields. `app.version`
# is preferred over `service.version`; the record wins over the resource.
_ID_ATTRS: dict[str, tuple[str, ...]] = {
    "session_id": ("session.id",),
    "prompt_id": ("prompt.id",),
    "organization_id": ("organization.id",),
    "account_id": ("user.account_id",),
    "app_version": ("app.version", "service.version"),
}
_ID_KEYS = frozenset(k for keys in _ID_ATTRS.values() for k in keys)

# Spec section 6.2: per-event allowlist, OTLP key -> stored attrs key.
ALLOWED_EVENTS: dict[str, dict[str, str]] = {
    "claude_code.api_request": {
        "model": "model",
        "cost_usd_micros": "cost_usd_micros",
        "duration_ms": "duration_ms",
        "input_tokens": "input_tokens",
        "output_tokens": "output_tokens",
        "cache_read_tokens": "cache_read_tokens",
        "cache_creation_tokens": "cache_creation_tokens",
        "request_id": "request_id",
        "client_request_id": "client_request_id",
        "speed": "speed",
        "query_source": "query_source",
        "query_source_category": "query_source_category",
        "effort": "effort",
        "agent.name": "agent_name",
        "skill.name": "skill_name",
        "plugin.name": "plugin_name",
        "mcp_server.name": "mcp_server_name",
        "mcp_tool.name": "mcp_tool_name",
    },
    "claude_code.api_error": {
        "model": "model",
        "status_code": "status_code",
        "duration_ms": "duration_ms",
        "attempt": "attempt",
        "request_id": "request_id",
        "client_request_id": "client_request_id",
        "query_source": "query_source",
        "query_source_category": "query_source_category",
        "speed": "speed",
        "effort": "effort",
    },
    "claude_code.tool_result": {
        "tool_name": "tool_name",
        "tool_use_id": "tool_use_id",
        "success": "success",
        "duration_ms": "duration_ms",
        "error_type": "error_type",
        "decision_type": "decision_type",
        "decision_source": "decision_source",
        "tool_input_size_bytes": "tool_input_size_bytes",
        "tool_result_size_bytes": "tool_result_size_bytes",
    },
    "claude_code.user_prompt": {
        "prompt_length": "prompt_length",
        "message.uuid": "message_uuid",
    },
    "claude_code.assistant_response": {
        "model": "model",
        "request_id": "request_id",
        "message.uuid": "message_uuid",
        "response_length": "response_length",
    },
    "claude_code.api_refusal": {
        "model": "model",
        "request_id": "request_id",
    },
}
LIFECYCLE_EVENTS = ("sg.receiver.start", "sg.receiver.heartbeat", "sg.receiver.stop")

_EVENT_NAME_KEY = "event.name"
_EVENT_PREFIX = "claude_code."
_ERROR_KEY = "error"
_COST_USD_KEY = "cost_usd"
# The producer stringifies every scalar (`String(w.input_tokens)`, `success: "true"`), so
# these are coerced back on arrival; a value that does not parse is dropped, never guessed.
_INT_ATTRS = frozenset(
    {
        "cost_usd_micros",
        "duration_ms",
        "input_tokens",
        "output_tokens",
        "cache_read_tokens",
        "cache_creation_tokens",
        "status_code",
        "attempt",
        "prompt_length",
        "response_length",
        "tool_input_size_bytes",
        "tool_result_size_bytes",
    }
)
_BOOL_ATTRS = frozenset({"success"})
_ERROR_CLASS_RE = re.compile(r"[a-z_]{3,40}(?![a-z_])")


class BindError(OSError):
    """The port is taken (or otherwise unbindable): another receiver is serving it."""


@dataclass(frozen=True, slots=True)
class OtelRecord:
    """One `sg.otel.v1` line: an allowlisted event or a receiver lifecycle line."""

    recorded_at: str
    event: str
    time_unix_nano: int | None
    session_id: str | None
    prompt_id: str | None
    organization_id: str | None
    account_id: str | None
    app_version: str | None
    attrs: dict[str, object]
    dropped_attribute_keys: tuple[str, ...]

    def to_json(self) -> dict[str, object]:
        return {
            "schema": SCHEMA,
            "recorded_at": self.recorded_at,
            "recorder": {"component": "otel_receiver", "version": __version__},
            "event": self.event,
            "time_unix_nano": self.time_unix_nano,
            "session_id": self.session_id,
            "prompt_id": self.prompt_id,
            "organization_id": self.organization_id,
            "account_id": self.account_id,
            "app_version": self.app_version,
            "attrs": dict(self.attrs),
            "dropped_attribute_keys": list(self.dropped_attribute_keys),
        }

    @classmethod
    def from_json(cls, obj: object) -> OtelRecord:
        if not isinstance(obj, dict) or obj.get("schema") != SCHEMA:
            raise ValueError(f"not a {SCHEMA} record")
        attrs = obj.get("attrs")
        dropped = obj.get("dropped_attribute_keys")
        if not isinstance(attrs, dict) or not isinstance(dropped, list):
            raise ValueError("otel record needs an attrs object and a dropped_attribute_keys list")
        try:
            rec = cls(
                recorded_at=obj["recorded_at"],
                event=obj["event"],
                time_unix_nano=obj["time_unix_nano"],
                session_id=obj["session_id"],
                prompt_id=obj["prompt_id"],
                organization_id=obj["organization_id"],
                account_id=obj["account_id"],
                app_version=obj["app_version"],
                attrs=dict(attrs),
                dropped_attribute_keys=tuple(dropped),
            )
        except KeyError as e:
            raise ValueError(f"otel record is missing field {e.args[0]!r}") from None
        _check_str_or_none(rec.recorded_at, "recorded_at", required=True)
        _check_str_or_none(rec.event, "event", required=True)
        for name in _ID_ATTRS:
            _check_str_or_none(getattr(rec, name), name)
        if rec.time_unix_nano is not None and (
            isinstance(rec.time_unix_nano, bool) or not isinstance(rec.time_unix_nano, int)
        ):
            raise ValueError("time_unix_nano must be an int or null")
        if any(not isinstance(k, str) for k in rec.dropped_attribute_keys):
            raise ValueError("dropped_attribute_keys holds attribute names only")
        return rec


def _check_str_or_none(value: object, name: str, required: bool = False) -> None:
    if value is None and not required:
        return
    if not isinstance(value, str) or (required and not value):
        raise ValueError(f"{name} must be a {'' if required else 'nullable '}string")


@dataclass(slots=True)
class ParseStats:
    """What a batch contained beyond the records it yielded; fed into receiver counters."""

    records_seen: int = 0
    records_dropped_events: int = 0  # event name not in the allowlist
    records_malformed: int = 0  # a log record that is not an object or has no event name


def flatten_attributes(attributes: object) -> dict[str, object]:
    """OTLP `[{key, value:{stringValue|intValue|doubleValue|boolValue}}]` -> plain dict.

    intValue arrives as a decimal string in http/json and is converted to int; any other
    value kind (arrays, kvlists, bytes) or malformed entry is left out, so a key that was
    present but unflattenable shows up in `dropped_attribute_keys` rather than as junk.
    """
    out: dict[str, object] = {}
    if not isinstance(attributes, list):
        return out
    for entry in attributes:
        if not isinstance(entry, dict) or not isinstance(entry.get("key"), str):
            continue
        value = _flatten_value(entry.get("value"))
        if value is not None:
            out[entry["key"]] = value
    return out


def _flatten_value(value: object) -> str | int | float | bool | None:
    if not isinstance(value, dict):
        return None
    if "stringValue" in value:
        v = value["stringValue"]
        return v if isinstance(v, str) else None
    if "intValue" in value:
        v = value["intValue"]
        if isinstance(v, bool):
            return None
        if isinstance(v, int):
            return v
        if isinstance(v, str):
            try:
                return int(v, 10)
            except ValueError:
                return None
        return None
    if "doubleValue" in value:
        v = value["doubleValue"]
        return float(v) if isinstance(v, int | float) and not isinstance(v, bool) else None
    if "boolValue" in value:
        v = value["boolValue"]
        return v if isinstance(v, bool) else None
    return None


def error_class(error: object) -> str:
    """The leading `[a-z_]{3,40}` token of an API error, else "unclassified".

    Only a classifier-shaped token is kept because the rest of the attribute is free
    text from the API (and may quote the request).
    """
    if not isinstance(error, str):
        return "unclassified"
    m = _ERROR_CLASS_RE.match(error)
    return m.group(0) if m else "unclassified"


def _nanos(value: object) -> int | None:
    if isinstance(value, bool):
        return None
    if isinstance(value, int):
        return value
    if isinstance(value, str) and value.isdigit():
        return int(value)
    return None


def _event_name(record: dict, attrs: dict[str, object]) -> str | None:
    """The qualified event name, whichever half of the producer's pair carried it.

    Claude Code emits `body: "claude_code.<name>"` but `attributes["event.name"]: "<name>"`
    (verified in 2.1.261; see docs/design/producer-contract.md). Matching the short
    attribute against a qualified allowlist silently drops every real event, so both forms
    are normalized to the qualified one here.
    """
    for candidate in (attrs.get(_EVENT_NAME_KEY), _body_string(record)):
        if isinstance(candidate, str) and candidate:
            if candidate.startswith(_EVENT_PREFIX):
                return candidate
            return _EVENT_PREFIX + candidate
    return None


def _body_string(record: dict) -> str | None:
    body = record.get("body")
    if isinstance(body, dict) and isinstance(body.get("stringValue"), str) and body["stringValue"]:
        return body["stringValue"]
    return None


def _pick_id(record_attrs: dict, resource_attrs: dict, keys: tuple[str, ...]) -> str | None:
    for source in (record_attrs, resource_attrs):
        for key in keys:
            v = source.get(key)
            if isinstance(v, str) and v:
                return v
    return None


def _coerce_scalar(stored: str, value: object) -> object | None:
    """Numbers and booleans the producer sent as strings, back to their declared type."""
    if stored in _INT_ATTRS:
        if isinstance(value, bool):
            return None
        if isinstance(value, int):
            return value
        if isinstance(value, float):
            return int(value) if value.is_integer() else None
        if isinstance(value, str):
            text = value.strip()
            neg = text.startswith("-")
            if (text[1:] if neg else text).isdigit():
                return int(text)
        return None
    if stored in _BOOL_ATTRS:
        if isinstance(value, bool):
            return value
        if isinstance(value, str) and value.strip().lower() in ("true", "false"):
            return value.strip().lower() == "true"
        return None
    return value


def _allowlisted_attrs(event: str, raw: dict[str, object]) -> tuple[dict[str, object], set[str]]:
    """Apply the event's mapping table; return (attrs, keys consumed from `raw`)."""
    table = ALLOWED_EVENTS[event]
    attrs: dict[str, object] = {}
    consumed: set[str] = set()
    for key, stored in table.items():
        if key not in raw:
            continue
        value = raw[key]
        if isinstance(value, str) and len(value) > MAX_STRING_LEN:
            continue  # named as dropped: too long to be an identifier
        coerced = _coerce_scalar(stored, value)
        if coerced is None:
            continue  # unparseable for its declared type: dropped by name, never guessed
        attrs[stored] = coerced
        consumed.add(key)
    if event == "claude_code.api_error" and _ERROR_KEY in raw:
        attrs["error_class"] = error_class(raw[_ERROR_KEY])
        consumed.add(_ERROR_KEY)
    if event == "claude_code.api_request":
        micros = attrs.get("cost_usd_micros")
        if isinstance(micros, float) and micros.is_integer():
            attrs["cost_usd_micros"] = int(micros)
        elif not isinstance(micros, int) or isinstance(micros, bool):
            attrs.pop("cost_usd_micros", None)
            consumed.discard("cost_usd_micros")
            # 2.1.261 emits no cost_usd_micros at all and sends cost_usd as a string.
            cost = raw.get(_COST_USD_KEY)
            if isinstance(cost, str):
                try:
                    cost = float(cost)
                except ValueError:
                    cost = None
            if isinstance(cost, int | float) and not isinstance(cost, bool):
                attrs["cost_usd_micros"] = round(cost * 1e6)
        if _COST_USD_KEY in raw:
            consumed.add(_COST_USD_KEY)  # the harness figure is kept only as micros
    return attrs, consumed


def parse_otlp_logs(
    payload: dict,
    *,
    recorded_at: str | None = None,
    stats: ParseStats | None = None,
) -> list[OtelRecord]:
    """Pure: an OTLP/JSON logs export -> the allowlisted `sg.otel.v1` records, in order.

    Missing or mis-typed containers are treated as empty and malformed records are
    counted into `stats` rather than raised, because one bad record must not lose the
    rest of a batch. Only a non-object payload is an error.
    """
    if not isinstance(payload, dict):
        raise ValueError("an OTLP logs payload is a JSON object")
    stats = ParseStats() if stats is None else stats
    recorded_at = utc_now_iso() if recorded_at is None else recorded_at
    out: list[OtelRecord] = []
    for resource_logs in _dicts(payload.get("resourceLogs")):
        resource = resource_logs.get("resource")
        resource_attrs = flatten_attributes(
            resource.get("attributes") if isinstance(resource, dict) else None
        )
        for scope_logs in _dicts(resource_logs.get("scopeLogs")):
            for record in _items(scope_logs.get("logRecords")):
                stats.records_seen += 1
                if not isinstance(record, dict):
                    stats.records_malformed += 1
                    continue
                record_attrs = flatten_attributes(record.get("attributes"))
                event = _event_name(record, record_attrs)
                if event is None:
                    stats.records_malformed += 1
                    continue
                if event not in ALLOWED_EVENTS:
                    stats.records_dropped_events += 1
                    continue
                attrs, consumed = _allowlisted_attrs(event, record_attrs)
                consumed.add(_EVENT_NAME_KEY)
                dropped = {k for k in record_attrs if k not in consumed and k not in _ID_KEYS}
                dropped.update(k for k in resource_attrs if k not in _ID_KEYS)
                ids = {
                    name: _pick_id(record_attrs, resource_attrs, keys)
                    for name, keys in _ID_ATTRS.items()
                }
                out.append(
                    OtelRecord(
                        recorded_at=recorded_at,
                        event=event,
                        time_unix_nano=_nanos(record.get("timeUnixNano"))
                        or _nanos(record.get("observedTimeUnixNano")),
                        attrs=attrs,
                        dropped_attribute_keys=tuple(sorted(dropped)),
                        **ids,
                    )
                )
    return out


def _items(value: object) -> list:
    return value if isinstance(value, list) else []


def _dicts(value: object) -> list[dict]:
    return [v for v in _items(value) if isinstance(v, dict)]


# --------------------------------------------------------------------------- server


@dataclass(slots=True)
class ReceiverStats:
    """Live counters; the first five are what every lifecycle line carries."""

    requests_handled: int = 0
    batches_dropped_metrics: int = 0
    parse_errors: int = 0
    records_appended: int = 0
    records_dropped_events: int = 0
    write_errors: int = 0


def pidfile_path(data_dir: Path) -> Path:
    return data_dir / "state" / PIDFILE


@dataclass(frozen=True, slots=True)
class PidRecord:
    """What state/otel.pid says: the receiver's pid and when that process started.

    The file is the pid on one line and ``start=<token>`` on the next, the token being
    `process_start` of the receiver as it wrote the file. ``start`` is None for a file of
    the pid alone: an older sg wrote it, or the receiver could not read its own start.
    """

    pid: int
    start: str | None


def read_pidfile_record(data_dir: Path) -> PidRecord | None:
    """The pidfile of a running (or crashed) receiver, else None (no file, or no pid in it)."""
    try:
        lines = pidfile_path(data_dir).read_text(encoding="utf-8").strip().splitlines()
    except OSError:
        return None
    first = lines[0].strip() if lines else ""
    # Pid 0 is no process: a signal to it goes to the sender's own process group.
    if not (first.isascii() and first.isdigit()) or int(first) == 0:
        return None
    start = None
    if len(lines) > 1 and lines[1].startswith(_START_KEY):
        start = lines[1][len(_START_KEY) :].strip() or None
    return PidRecord(int(first), start)


def read_pidfile(data_dir: Path) -> int | None:
    """The pid recorded by a running (or crashed) receiver, else None."""
    record = read_pidfile_record(data_dir)
    return record.pid if record is not None else None


def process_start(pid: int) -> str | None:
    """When process ``pid`` started, as a token no later process at the same pid repeats;
    None when no such process exists or its start cannot be read.

    Linux: the boot id and the start in clock ticks since boot (field 22 of
    /proc/<pid>/stat), which a change of the wall clock cannot move. Elsewhere (macOS):
    ``ps -o lstart=`` with ``LC_ALL=C TZ=UTC``, so the caller's locale and time zone do not
    change the text. Its one-second resolution suffices: pids are handed out in order, so
    a pid comes back only after the whole pid space has been used.
    """
    return _proc_start(pid, _PROC) or _ps_start(pid)


def _proc_start(pid: int, proc: Path) -> str | None:
    try:
        stat = (proc / str(pid) / "stat").read_text(encoding="utf-8", errors="replace")
        boot_id = (proc / "sys" / "kernel" / "random" / "boot_id").read_text().strip()
    except OSError:
        return None
    # Field 2 (comm) is parenthesised and may itself hold spaces and ')'; the fields after
    # the last ')' begin at field 3 (state), which puts starttime, field 22, at index 19.
    fields = stat.rpartition(")")[2].split()
    if not boot_id or len(fields) < 20 or not fields[19].isdigit():
        return None
    return f"proc:{boot_id}:{fields[19]}"


def _ps_start(pid: int) -> str | None:
    import subprocess

    try:
        done = subprocess.run(
            ["ps", "-o", "lstart=", "-p", str(pid)],
            env={**os.environ, "LC_ALL": "C", "TZ": "UTC"},
            stdin=subprocess.DEVNULL,
            capture_output=True,
            text=True,
            timeout=_PS_TIMEOUT_S,
            check=False,
        )
    except (OSError, subprocess.SubprocessError):
        return None
    text = done.stdout.strip()  # nothing on stdout: no such process, or no lstart
    return f"lstart:{text}" if text else None


def _pidfile_text(pid: int) -> str:
    start = process_start(pid)
    return f"{pid}\n" if start is None else f"{pid}\n{_START_KEY}{start}\n"


class _Server(ThreadingHTTPServer):
    daemon_threads = True
    receiver: Receiver

    def server_bind(self) -> None:
        # HTTPServer.server_bind resolves the fqdn, which can stall on DNS; the receiver
        # only ever serves loopback so the name is known.
        socketserver.TCPServer.server_bind(self)
        self.server_name = "127.0.0.1"
        self.server_port = self.server_address[1]


class _Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"
    server: _Server

    def log_message(self, fmt: str, *args: object) -> None:
        return  # the raw shard and the lifecycle counters are the log

    def do_POST(self) -> None:
        rx = self.server.receiver
        rx._touch()
        path = self.path.partition("?")[0]
        body = self._read_body()
        if body is None:
            return
        if path == "/v1/metrics":
            rx._bump("batches_dropped_metrics")
            self._reply(200, b"{}")
            return
        if path != "/v1/logs":
            self._reply(404, b'{"error":"unknown path"}')
            return
        media = self.headers.get("Content-Type", "").partition(";")[0].strip().lower()
        if media and media != "application/json":
            self._reply(
                415,
                b"this receiver speaks OTLP http/json only; set "
                b"OTEL_EXPORTER_OTLP_PROTOCOL=http/json\n",
                content_type="text/plain",
            )
            return
        stats = ParseStats()
        try:
            body = self._decode(body)
            payload = json.loads(body)
            records = parse_otlp_logs(payload, stats=stats)
        except (ValueError, zlib.error, UnicodeDecodeError, RecursionError):
            rx._bump("parse_errors")
            self._reply(200, b"{}")
            return
        rx._bump("records_dropped_events", stats.records_dropped_events)
        rx._append(records)
        self._reply(200, b"{}")

    def do_GET(self) -> None:
        self._reply(404, b'{"error":"POST /v1/logs"}')

    def _read_body(self) -> bytes | None:
        length = self.headers.get("Content-Length")
        if length is None or not length.isdigit():
            self.close_connection = True
            self._reply(411, b'{"error":"Content-Length required"}')
            return None
        n = int(length)
        if n > MAX_BODY_BYTES:
            self.close_connection = True  # the body is left unread
            self._reply(413, b'{"error":"body exceeds 8 MiB"}')
            return None
        return self.rfile.read(n)

    def _decode(self, body: bytes) -> bytes:
        encoding = self.headers.get("Content-Encoding", "").strip().lower()
        if encoding in ("", "identity"):
            return body
        if encoding != "gzip":
            raise ValueError(f"unsupported content encoding {encoding!r}")
        d = zlib.decompressobj(zlib.MAX_WBITS | 16)
        out = d.decompress(body, MAX_BODY_BYTES + 1)
        if len(out) > MAX_BODY_BYTES or d.unconsumed_tail:
            raise ValueError("decompressed body exceeds 8 MiB")
        return out

    def _reply(self, status: int, body: bytes, content_type: str = "application/json") -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        self.server.receiver._bump("requests_handled")


class Receiver:
    """One receiver instance: bind, serve, heartbeat, idle exit, lifecycle lines.

    Usable in-process by tests (`port=0` for an ephemeral port, `heartbeat_s`/`idle_s`
    shortened) and by `serve()` for the detached process the SessionStart hook spawns.
    """

    def __init__(
        self,
        data_dir: Path,
        port: int,
        *,
        heartbeat_s: float = DEFAULT_HEARTBEAT_S,
        idle_s: float = DEFAULT_IDLE_S,
        clock: Callable[[], float] = time.monotonic,
        write_pidfile: bool = True,
    ) -> None:
        if heartbeat_s <= 0 or idle_s <= 0:
            raise ValueError("heartbeat_s and idle_s must be positive")
        self.data_dir = data_dir
        self.requested_port = port
        self.heartbeat_s = float(heartbeat_s)
        self.idle_s = float(idle_s)
        self.stats = ReceiverStats()
        self.stop_reason: str | None = None
        self._clock = clock
        self._write_pidfile = write_pidfile
        self._lock = threading.Lock()
        self._done = threading.Event()  # a stop was requested
        self._stopped = threading.Event()  # the stop line is written and the port released
        self._finished = False
        self._server: _Server | None = None
        self._threads: list[threading.Thread] = []
        self._started_at = 0.0
        self._last_post = 0.0

    @property
    def port(self) -> int:
        if self._server is None:
            raise RuntimeError("receiver is not bound")
        return self._server.server_address[1]

    @property
    def is_running(self) -> bool:
        return self._server is not None and not self._finished

    # -- lifecycle

    def start(self) -> None:
        """Bind (BindError when the port is taken), write the pidfile and start line, serve."""
        if self._server is not None:
            raise RuntimeError("receiver already started")
        try:
            server = _Server(("127.0.0.1", self.requested_port), _Handler)
        except OSError as e:
            raise BindError(*e.args) from e
        server.receiver = self
        self._server = server
        self._started_at = self._last_post = self._clock()
        if self._write_pidfile:
            # With its start, so `sg otel stop` can tell this process from a later one at
            # the same pid (after a crash and a reboot, say) and signal only this one.
            atomic_write(pidfile_path(self.data_dir), _pidfile_text(os.getpid()))
        self._lifecycle("sg.receiver.start")
        self._threads = [
            threading.Thread(target=server.serve_forever, name="sg-otel-serve", daemon=True),
            threading.Thread(target=self._heartbeat_loop, name="sg-otel-heartbeat", daemon=True),
        ]
        for t in self._threads:
            t.start()

    def request_stop(self, reason: str = "stop") -> None:
        """Signal-safe: ask `run()` (or `stop()`) to finish; never blocks."""
        with self._lock:
            if self.stop_reason is None:
                self.stop_reason = reason
        self._done.set()

    def stop(self, reason: str = "stop") -> None:
        """Shut the server down, write the stop line, remove the pidfile; idempotent."""
        self.request_stop(reason)
        self._finish()

    def run(self) -> str:
        """Block until stopped (idle, signal or `request_stop`); returns the stop reason."""
        if self._server is None:
            self.start()
        while not self._done.wait(1.0):
            pass
        self._finish()
        return self.stop_reason or "stop"

    def wait(self, timeout: float | None = None) -> bool:
        """True once a stop was requested (idle, signal or stop()); call stop() afterwards."""
        return self._done.wait(timeout)

    def _finish(self) -> None:
        """Run the shutdown once; a concurrent caller waits for it instead of returning early."""
        with self._lock:
            if self._server is None:
                return
            first = not self._finished
            self._finished = True
        if not first:
            if threading.current_thread() not in self._threads:
                self._stopped.wait(timeout=10)  # an idle exit is finishing on its own thread
            return
        self._server.shutdown()
        self._server.server_close()
        for t in self._threads:
            if t is not threading.current_thread():
                t.join(timeout=5)
        self._lifecycle("sg.receiver.stop")
        if self._write_pidfile:
            self._remove_pidfile()
        self._stopped.set()

    def _remove_pidfile(self) -> None:
        path = pidfile_path(self.data_dir)
        if read_pidfile(self.data_dir) == os.getpid():
            with contextlib.suppress(OSError):
                path.unlink()

    # -- background

    def _heartbeat_loop(self) -> None:
        next_beat = self._started_at + self.heartbeat_s
        while not self._done.is_set():
            now = self._clock()
            idle_deadline = self._last_post + self.idle_s
            if now >= idle_deadline:
                self.request_stop("idle")
                self._finish()  # self-contained: no run() needed for the stop line
                return
            if now >= next_beat:
                self._lifecycle("sg.receiver.heartbeat")
                next_beat = now + self.heartbeat_s
            if self._done.wait(max(0.0, min(next_beat, idle_deadline) - now)):
                return

    # -- counters and writes

    def _touch(self) -> None:
        with self._lock:
            self._last_post = self._clock()

    def _bump(self, name: str, by: int = 1) -> None:
        with self._lock:
            setattr(self.stats, name, getattr(self.stats, name) + by)

    def _append(self, records: list[OtelRecord]) -> None:
        path = shard_path(self.data_dir / "raw", "otel")
        for rec in records:
            try:
                append_line(path, rec.to_json())
            except OSError as e:
                self._bump("write_errors")
                print(f"sg otel: append failed: {e.__class__.__name__}", file=sys.stderr)
            else:
                self._bump("records_appended")

    def _lifecycle(self, event: str) -> None:
        with self._lock:
            attrs: dict[str, object] = {
                "pid": os.getpid(),
                "uptime_s": int(self._clock() - self._started_at),
                "requests_handled": self.stats.requests_handled,
                "batches_dropped_metrics": self.stats.batches_dropped_metrics,
                "parse_errors": self.stats.parse_errors,
            }
        rec = OtelRecord(
            recorded_at=utc_now_iso(),
            event=event,
            time_unix_nano=time.time_ns(),
            session_id=None,
            prompt_id=None,
            organization_id=None,
            account_id=None,
            app_version=None,
            attrs=attrs,
            dropped_attribute_keys=(),
        )
        try:
            append_line(shard_path(self.data_dir / "raw", "otel"), rec.to_json())
        except OSError as e:
            self._bump("write_errors")
            print(f"sg otel: lifecycle append failed: {e.__class__.__name__}", file=sys.stderr)


def serve(
    port: int | None = None,
    heartbeat_s: float = DEFAULT_HEARTBEAT_S,
    idle_s: float = DEFAULT_IDLE_S,
    data_dir: Path | None = None,
) -> int:
    """Run one receiver until SIGTERM/SIGINT or idle exit; the `sg otel serve` body.

    Returns the process exit code: 0 after a clean stop *and* when the port is already
    bound (another receiver is serving, and the spawning hook must not care), 2 on an
    invalid config.
    """
    if data_dir is None:
        data_dir = resolve_data_dir()
    data_dir = ensure_data_dir(data_dir)
    if port is None:
        try:
            port = load_config(data_dir, missing_ok=True)["otel"]["port"]
        except ConfigError as e:
            print(f"sg otel: {e}", file=sys.stderr)
            return e.exit_code
    receiver = Receiver(data_dir, port, heartbeat_s=heartbeat_s, idle_s=idle_s)
    try:
        receiver.start()
    except BindError:
        return 0  # single instance: someone else holds the port; say nothing
    _install_signal_handlers(receiver)
    receiver.run()
    return 0


def _install_signal_handlers(receiver: Receiver) -> None:
    def _on_signal(signum: int, _frame: object) -> None:
        receiver.request_stop(f"signal:{signal.Signals(signum).name}")

    for sig in (signal.SIGTERM, signal.SIGINT):
        with contextlib.suppress(ValueError):  # not the main thread: run() still stops on idle
            signal.signal(sig, _on_signal)
