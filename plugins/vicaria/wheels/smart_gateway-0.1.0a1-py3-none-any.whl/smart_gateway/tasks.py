"""Task ops: the `sg.task.v1` append-only record and its supersession (spec section 5.1).

`sg task …`, `sg bind` and `sg run` never edit anything: each writes one op line, and the
build resolves "latest recorded_at wins per (task_id, attempt_id, field)" while keeping every
superseded line in the task's history. Field values are short identifiers, never free text.
"""

from __future__ import annotations

import getpass
import os
import re
from collections.abc import Iterable, Iterator
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path

from smart_gateway import __version__
from smart_gateway.ids import load_or_create_salt, salted_hash, sanitize_task_id, utc_now_iso
from smart_gateway.rawlog import LineStats, append_line, iter_lines, shard_path

__all__ = [
    "ASSIGNMENTS",
    "EVALUATOR_KINDS",
    "OBSERVATION_COLUMNS",
    "OPS",
    "POPULATIONS",
    "TASK_SCHEMA",
    "HistoryEntry",
    "Signal",
    "TaskOp",
    "bindings",
    "build_op",
    "iter_ops",
    "iter_ops_raw",
    "ref_sort_key",
    "supersede",
    "validate_fields",
    "write_op",
]

TASK_SCHEMA = "sg.task.v1"
_RECORDER_COMPONENT = "cli"

OPS = ("new", "bind", "unbind", "label", "accept", "observe", "repair", "verify")
POPULATIONS = ("production", "benchmark")
EVALUATOR_KINDS = ("human", "ci", "script", "unknown")
ASSIGNMENTS = ("randomized", "observational")
ACCEPTED_BY = ("human", "ci")
OBSERVATION_COLUMNS = ("tests_passed", "reviewer_accepted", "task_reopened", "classifier_flagged")
MINUTES_SOURCES = ("entered", "timer")

# Labels, sources and experiment names are identifiers the team chooses ("ci:run-123");
# the alphabet keeps a pasted sentence or path from ever reaching disk.
_IDENT_RE = re.compile(r"[A-Za-z0-9._:/@-]{1,128}")
_REF_RE = re.compile(r"^(.*):(\d+)$")

# Every key each op may carry; missing nullable keys are stored as null so a line on disk
# is always complete, and a null never supersedes an earlier value (see supersede).
_FIELD_KEYS: dict[str, tuple[str, ...]] = {
    "new": ("population", "evaluator", "family", "created_at"),
    "bind": (),
    "unbind": (),
    "label": ("config_label", "assignment", "propensity", "experiment"),
    "accept": ("accepted_by", "at", "source"),
    "observe": ("column", "value", "source", "at"),
    "repair": (
        "human_minutes",
        "human_minutes_source",
        "follow_up_edits",
        "reopened",
        "source",
        "at",
    ),
    "verify": ("ci_minutes", "review_minutes", "source"),
}


def _fail(op: str, what: str) -> ValueError:
    return ValueError(f"task op {op}: {what}")


def _ident(op: str, name: str, value: object, nullable: bool) -> str | None:
    if value is None and nullable:
        return None
    if not isinstance(value, str) or not _IDENT_RE.fullmatch(value):
        raise _fail(op, f"{name} must be an identifier matching [A-Za-z0-9._:/@-]{{1,128}}")
    if value.startswith("/"):
        raise _fail(op, f"{name} must not look like a file path")
    return value


def _timestamp(op: str, name: str, value: object, nullable: bool) -> str | None:
    """Accept any aware ISO-8601 timestamp; store it in the canonical UTC form."""
    if value is None and nullable:
        return None
    if not isinstance(value, str):
        raise _fail(op, f"{name} must be an ISO-8601 timestamp")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        raise _fail(op, f"{name} must be an ISO-8601 timestamp") from None
    if parsed.tzinfo is None:
        raise _fail(op, f"{name} must carry a timezone")
    return utc_now_iso(parsed)


def _int(op: str, name: str, value: object, nullable: bool) -> int | None:
    if value is None and nullable:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise _fail(op, f"{name} must be a non-negative integer")
    return value


def _bool(op: str, name: str, value: object, nullable: bool) -> bool | None:
    if value is None and nullable:
        return None
    if not isinstance(value, bool):
        raise _fail(op, f"{name} must be true or false")
    return value


def _choice(op: str, name: str, value: object, choices: tuple[str, ...], nullable: bool):
    if value is None and nullable:
        return None
    if value not in choices:
        raise _fail(op, f"{name} must be one of {', '.join(choices)}")
    return value


def validate_fields(
    op: str, fields: dict, session_id: str | None = None, attempt_id: str | None = None
) -> dict:
    """Return the normalized per-op field object, or raise ValueError.

    Refuses unknown keys, wrong types, and a `label` op that claims `randomized`
    without a propensity (a randomized attempt with no known propensity cannot enter a gate).
    """
    if op not in OPS:
        raise ValueError(f"task op must be one of {', '.join(OPS)}")
    if not isinstance(fields, dict):
        raise _fail(op, "fields must be an object")
    unknown = sorted(set(fields) - set(_FIELD_KEYS[op]))
    if unknown:
        raise _fail(op, f"has unknown keys: {', '.join(unknown)}")
    if op in ("bind", "unbind", "label") and session_id is None and attempt_id is None:
        raise _fail(op, "needs a session_id or attempt_id")
    if op in ("bind", "unbind") and attempt_id is not None:
        raise _fail(op, "binds a session, not an attempt")
    f = {k: fields.get(k) for k in _FIELD_KEYS[op]}
    if op == "new":
        _choice(op, "population", f["population"], POPULATIONS, nullable=False)
        evaluator = f["evaluator"]
        if evaluator is None:
            evaluator = {"kind": "unknown", "id": None}
        if not isinstance(evaluator, dict) or set(evaluator) - {"kind", "id"}:
            raise _fail(op, "evaluator must be {kind, id}")
        f["evaluator"] = {
            "kind": _choice(op, "evaluator.kind", evaluator.get("kind"), EVALUATOR_KINDS, False),
            "id": _ident(op, "evaluator.id", evaluator.get("id"), nullable=True),
        }
        f["family"] = _ident(op, "family", f["family"], nullable=True)
        f["created_at"] = _timestamp(op, "created_at", f["created_at"], nullable=True)
    elif op == "label":
        _ident(op, "config_label", f["config_label"], nullable=False)
        _choice(op, "assignment", f["assignment"], ASSIGNMENTS, nullable=False)
        p = f["propensity"]
        if p is not None:
            if isinstance(p, bool) or not isinstance(p, int | float) or not 0 < p < 1:
                raise _fail(op, "propensity must be a number strictly between 0 and 1")
            f["propensity"] = float(p)
        elif f["assignment"] == "randomized":
            raise _fail(op, "assignment randomized requires a propensity")
        f["experiment"] = _ident(op, "experiment", f["experiment"], nullable=True)
    elif op == "accept":
        _choice(op, "accepted_by", f["accepted_by"], ACCEPTED_BY, nullable=False)
        f["at"] = _timestamp(op, "at", f["at"], nullable=False)
        f["source"] = _ident(op, "source", f["source"], nullable=True)
    elif op == "observe":
        _choice(op, "column", f["column"], OBSERVATION_COLUMNS, nullable=False)
        _bool(op, "value", f["value"], nullable=False)
        _ident(op, "source", f["source"], nullable=False)
        f["at"] = _timestamp(op, "at", f["at"], nullable=False)
    elif op == "repair":
        _int(op, "human_minutes", f["human_minutes"], nullable=True)
        _choice(op, "human_minutes_source", f["human_minutes_source"], MINUTES_SOURCES, True)
        if (f["human_minutes"] is None) != (f["human_minutes_source"] is None):
            raise _fail(op, "human_minutes and human_minutes_source go together")
        _int(op, "follow_up_edits", f["follow_up_edits"], nullable=True)
        _bool(op, "reopened", f["reopened"], nullable=True)
        f["source"] = _ident(op, "source", f["source"], nullable=True)
        f["at"] = _timestamp(op, "at", f["at"], nullable=True)
    elif op == "verify":
        _int(op, "ci_minutes", f["ci_minutes"], nullable=True)
        _int(op, "review_minutes", f["review_minutes"], nullable=True)
        f["source"] = _ident(op, "source", f["source"], nullable=True)
    return f


@dataclass(frozen=True, slots=True)
class TaskOp:
    """One `sg.task.v1` line. `fields` is the validated per-op object (see validate_fields)."""

    recorded_at: str
    recorder_version: str
    by_hash: str | None
    op: str
    task_id: str
    attempt_id: str | None
    session_id: str | None
    fields: dict

    def to_json(self) -> dict:
        return {
            "schema": TASK_SCHEMA,
            "recorded_at": self.recorded_at,
            "recorder": {"component": _RECORDER_COMPONENT, "version": self.recorder_version},
            "by_hash": self.by_hash,
            "op": self.op,
            "task_id": self.task_id,
            "attempt_id": self.attempt_id,
            "session_id": self.session_id,
            "fields": dict(self.fields),
        }

    @classmethod
    def from_json(cls, obj: object) -> TaskOp:
        if not isinstance(obj, dict) or obj.get("schema") != TASK_SCHEMA:
            raise ValueError(f"not a {TASK_SCHEMA} record")
        expected = {
            "schema",
            "recorded_at",
            "recorder",
            "by_hash",
            "op",
            "task_id",
            "attempt_id",
            "session_id",
            "fields",
        }
        if set(obj) != expected:
            raise ValueError(f"{TASK_SCHEMA} record has the wrong keys")
        recorder = obj["recorder"]
        if (
            not isinstance(recorder, dict)
            or recorder.get("component") != _RECORDER_COMPONENT
            or not isinstance(recorder.get("version"), str)
        ):
            raise ValueError(f"{TASK_SCHEMA} recorder must be {{component: cli, version}}")
        if not isinstance(obj["recorded_at"], str):
            raise ValueError(f"{TASK_SCHEMA}.recorded_at must be a string")
        if obj["by_hash"] is not None and not isinstance(obj["by_hash"], str):
            raise ValueError(f"{TASK_SCHEMA}.by_hash must be a string or null")
        op = obj["op"]
        task_id = sanitize_task_id(obj["task_id"])
        attempt_id = _ident(op, "attempt_id", obj["attempt_id"], nullable=True)
        session_id = _ident(op, "session_id", obj["session_id"], nullable=True)
        fields = validate_fields(op, obj["fields"], session_id, attempt_id)
        return cls(
            recorded_at=obj["recorded_at"],
            recorder_version=recorder["version"],
            by_hash=obj["by_hash"],
            op=op,
            task_id=task_id,
            attempt_id=attempt_id,
            session_id=session_id,
            fields=fields,
        )


def _os_user_hash(salt: bytes) -> str | None:
    try:
        user = getpass.getuser()
    except (KeyError, OSError):
        user = str(os.getuid())
    return salted_hash(salt, user) if user else None


def build_op(
    op: str,
    task_id: str,
    fields: dict,
    session_id: str | None = None,
    attempt_id: str | None = None,
    *,
    salt: bytes | None = None,
    now: datetime | None = None,
) -> TaskOp:
    """Validate and assemble one op without touching disk (`write_op` appends it)."""
    if op not in OPS:
        raise ValueError(f"task op must be one of {', '.join(OPS)}")
    task_id = sanitize_task_id(task_id)
    session_id = _ident(op, "session_id", session_id, nullable=True)
    attempt_id = _ident(op, "attempt_id", attempt_id, nullable=True)
    return TaskOp(
        recorded_at=utc_now_iso(now),
        recorder_version=__version__,
        by_hash=None if salt is None else _os_user_hash(salt),
        op=op,
        task_id=task_id,
        attempt_id=attempt_id,
        session_id=session_id,
        fields=validate_fields(op, fields, session_id, attempt_id),
    )


def write_op(
    data_dir: Path,
    op: str,
    task_id: str,
    fields: dict,
    session_id: str | None = None,
    attempt_id: str | None = None,
    *,
    now: datetime | None = None,
) -> tuple[Path, TaskOp]:
    """Validate, then append one `sg.task.v1` line to raw/tasks/<today>.jsonl."""
    salt = load_or_create_salt(data_dir)
    record = build_op(op, task_id, fields, session_id, attempt_id, salt=salt, now=now)
    path = shard_path(data_dir / "raw", "tasks", now)
    append_line(path, record.to_json())
    return path, record


def iter_ops_raw(
    raw_dir: Path, stats: dict[str, LineStats] | None = None
) -> Iterator[tuple[str, TaskOp]]:
    """Yield `("tasks/YYYY-MM-DD.jsonl:<line_no>", op)` for every intact op line under raw_dir.

    JSON lines that are not valid `sg.task.v1` count as corrupt, like torn lines.
    """
    tasks_dir = raw_dir / "tasks"
    if not tasks_dir.is_dir():
        return
    for path in sorted(tasks_dir.glob("*.jsonl")):
        rel = f"tasks/{path.name}"
        file_stats = LineStats()
        for line_no, obj in iter_lines(path, file_stats):
            try:
                record = TaskOp.from_json(obj)
            except ValueError:
                file_stats.corrupt_lines += 1
                file_stats.corrupt_line_nos.append(line_no)
                continue
            yield f"{rel}:{line_no}", record
        if stats is not None:
            stats[rel] = file_stats


def iter_ops(
    data_dir: Path, stats: dict[str, LineStats] | None = None
) -> Iterator[tuple[str, TaskOp]]:
    """`iter_ops_raw(data_dir / "raw")`."""
    yield from iter_ops_raw(data_dir / "raw", stats)


def ref_sort_key(ref: str) -> tuple[str, int]:
    """Order refs by (path, numeric line): "…:10" sorts after "…:9"."""
    m = _REF_RE.match(ref)
    if m is None:
        raise ValueError("ref must look like <path>:<line_no>")
    return m.group(1), int(m.group(2))


@dataclass(frozen=True, slots=True)
class Signal:
    """The current value of one field of one task (or attempt), with its provenance."""

    task_id: str
    attempt_id: str | None
    field: str
    value: object
    recorded_at: str
    ref: str
    op: str
    session_id: str | None


@dataclass(frozen=True, slots=True)
class HistoryEntry:
    """One raw op line and what replaced it.

    `replaced` maps each field the line set to the ref that later replaced it (None while
    current); `superseded_by` is set only once every field is gone, naming the last replacer.
    """

    ref: str
    op: str
    task_id: str
    attempt_id: str | None
    recorded_at: str
    superseded_by: str | None
    replaced: dict

    def to_json(self) -> dict:
        return {"ref": self.ref, "op": self.op, "superseded_by": self.superseded_by}


def _signals_of(op: TaskOp) -> list[tuple[str, object]]:
    """(field, value) pairs one op contributes; a null field contributes nothing.

    `source`/`at` annotations travel with the value they annotate (as in `observe`), so
    superseding a value never strands the note that described the old one.
    """
    f = op.fields
    if op.op == "new":
        return [(f"new.{k}", f[k]) for k in _FIELD_KEYS["new"] if f[k] is not None]
    if op.op == "bind":
        return [(f"bind:{op.session_id}", True)]
    if op.op == "unbind":
        return [(f"bind:{op.session_id}", False)]
    if op.op == "label":
        scope = "label" if op.session_id is None else f"label:{op.session_id}"
        return [(scope, dict(f))]
    if op.op == "accept":
        return [("accept", dict(f))]
    if op.op == "observe":
        return [
            (f"observe.{f['column']}", {"value": f["value"], "source": f["source"], "at": f["at"]})
        ]
    if op.op == "repair":
        out: list[tuple[str, object]] = []
        if f["human_minutes"] is not None:
            out.append(
                (
                    "repair.human_minutes",
                    {
                        "minutes": f["human_minutes"],
                        "minutes_source": f["human_minutes_source"],
                        "source": f["source"],
                        "at": f["at"],
                    },
                )
            )
        for k in ("follow_up_edits", "reopened"):
            if f[k] is not None:
                out.append((f"repair.{k}", {"value": f[k], "source": f["source"], "at": f["at"]}))
        return out
    return [
        (f"verify.{k}", {"value": f[k], "source": f["source"]})
        for k in ("ci_minutes", "review_minutes")
        if f[k] is not None
    ]


def supersede(
    ops: Iterable[tuple[str, TaskOp]],
) -> tuple[dict[tuple[str, str | None, str], Signal], list[HistoryEntry]]:
    """Resolve the latest value per `(task_id, attempt_id, field)`; list every line's fate.

    Order is by `recorded_at`, then by ref, so a rebuild from the same raw files is
    deterministic. A line is superseded once none of the fields it set is still current;
    `superseded_by` names the line that replaced the last of them.
    """
    ordered = sorted(ops, key=lambda item: (item[1].recorded_at, ref_sort_key(item[0])))
    stamps = {ref: (op.recorded_at, ref_sort_key(ref)) for ref, op in ordered}
    current: dict[tuple[str, str | None, str], Signal] = {}
    # Per line: the refs that replaced each of its fields (None while still current).
    fates: dict[str, dict[str, str | None]] = {}
    for ref, op in ordered:
        fates[ref] = {}
        for field, value in _signals_of(op):
            key = (op.task_id, op.attempt_id, field)
            previous = current.get(key)
            if previous is not None:
                fates[previous.ref][field] = ref
            fates[ref][field] = None
            current[key] = Signal(
                task_id=op.task_id,
                attempt_id=op.attempt_id,
                field=field,
                value=value,
                recorded_at=op.recorded_at,
                ref=ref,
                op=op.op,
                session_id=op.session_id,
            )
    history: list[HistoryEntry] = []
    for ref, op in ordered:
        replaced = fates[ref]
        superseded_by: str | None = None
        if replaced and all(v is not None for v in replaced.values()):
            superseded_by = max((v for v in replaced.values() if v is not None), key=stamps.get)
        history.append(
            HistoryEntry(
                ref, op.op, op.task_id, op.attempt_id, op.recorded_at, superseded_by, dict(replaced)
            )
        )
    return current, history


def bindings(
    current: dict[tuple[str, str | None, str], Signal],
) -> dict[str, tuple[str | None, str]]:
    """session_id -> (task_id, or None after an unbind; ref) from the latest bind/unbind.

    `current` keys binds by task, so "which task does this session hold now" is resolved here.
    """
    latest: dict[str, Signal] = {}
    for (_task_id, _attempt, field), signal in current.items():
        if not field.startswith("bind:"):
            continue
        session_id = field.partition(":")[2]
        held = latest.get(session_id)
        if held is None or (signal.recorded_at, ref_sort_key(signal.ref)) > (
            held.recorded_at,
            ref_sort_key(held.ref),
        ):
            latest[session_id] = signal
    return {
        sid: (signal.task_id if signal.value else None, signal.ref)
        for sid, signal in latest.items()
    }
