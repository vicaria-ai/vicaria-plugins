"""Measure: a quantity that is either observed (value + source) or unobserved (reason).

Every number the plugin cannot always observe is a Measure so that "unknown" can never
be confused with zero; the reason vocabulary is closed so reports can group missingness.
"""

from __future__ import annotations

import math
import re
from collections import Counter
from collections.abc import Iterable
from dataclasses import dataclass
from enum import StrEnum

__all__ = ["Measure", "MeasureUnknown", "Reason", "sum_known"]


class Reason(StrEnum):
    """Closed vocabulary for why a Measure is unknown (spec section 4)."""

    HOOK_ABSENT = "hook_absent"
    OTEL_ABSENT = "otel_absent"
    TRANSCRIPT_ABSENT = "transcript_absent"
    TRANSCRIPT_STREAMING_SNAPSHOT = "transcript_streaming_snapshot"
    NO_BINDING = "no_binding"
    NOT_REPORTED = "not_reported"
    NO_ATTESTATION_CHANNEL = "no_attestation_channel"
    NOT_CONFIGURED = "not_configured"
    NO_PRICE_FOR_MODEL = "no_price_for_model"
    CACHE_TTL_SPLIT_UNKNOWN = "cache_ttl_split_unknown"
    BILLING_NOT_FETCHED = "billing_not_fetched"
    ADMIN_KEY_ABSENT = "admin_key_absent"
    NO_BILLING_ROWS = "no_billing_rows"
    BUCKET_UNMATCHED = "bucket_unmatched"
    UNPRICED_CATEGORY = "unpriced_category"
    MODEL_UNMATCHED = "model_unmatched"
    NOT_ENTERED = "not_entered"
    NO_RATE_CONFIGURED = "no_rate_configured"
    NOT_YET_OBSERVED = "not_yet_observed"
    AMBIGUOUS = "ambiguous"
    MALFORMED = "malformed"
    NO_SESSION_END = "no_session_end"
    NO_SUBAGENT_STOP = "no_subagent_stop"
    NOT_MEASURED_IN_PILOT = "not_measured_in_pilot"
    PARTIAL = "partial"


# The detail suffix names a category, model or bucket, never user text: keep it to
# identifier-like characters so free text cannot leak through a reason string.
_DETAIL_RE = re.compile(r"[A-Za-z0-9._@/-]{1,80}")


class MeasureUnknown(ValueError):
    """Raised by Measure.expect() when the value was never observed."""

    def __init__(self, reason: str) -> None:
        super().__init__(f"measure is unknown: {reason}")
        self.reason = reason


def _validate_reason(reason: object) -> str:
    """Return "<code>[:detail]" or raise; the code must be a Reason member."""
    if isinstance(reason, Reason):
        return reason.value
    if not isinstance(reason, str) or not reason:
        raise ValueError("unknown reason must be a non-empty Reason member or string")
    code, sep, detail = reason.partition(":")
    if code not in Reason.__members__.values():
        raise ValueError(f"unknown reason code is not in the Reason vocabulary: {code!r}")
    if sep and not _DETAIL_RE.fullmatch(detail):
        raise ValueError("unknown reason detail must be identifier-like (no free text)")
    return reason


@dataclass(frozen=True, slots=True)
class Measure:
    """Exactly one of (value, source) or reason is set; see Measure.known / Measure.unknown."""

    is_known: bool
    value: int | float | str | bool | None
    source: str | None
    reason: str | None

    def __post_init__(self) -> None:
        if self.is_known:
            if self.value is None or not isinstance(self.value, int | float | str):
                raise ValueError("a known Measure needs a value of type int, float, str or bool")
            if isinstance(self.value, float) and not math.isfinite(self.value):
                raise ValueError("a known Measure cannot hold NaN or infinity")
            if not isinstance(self.source, str) or not self.source:
                raise ValueError("a known Measure needs a non-empty source")
            if self.reason is not None:
                raise ValueError("a known Measure carries no reason")
        else:
            if self.value is not None or self.source is not None:
                raise ValueError("an unknown Measure carries no value or source")
            _validate_reason(self.reason)

    @classmethod
    def known(cls, value: int | float | str | bool, source: str) -> Measure:
        return cls(True, value, source, None)

    @classmethod
    def unknown(cls, reason: Reason | str, detail: str | None = None) -> Measure:
        # None / 0 / "" are rejected here on purpose: "unknown" always has a stated reason.
        if not isinstance(reason, Reason | str) or not reason:
            raise ValueError("Measure.unknown needs a Reason; None and 0 are not reasons")
        text = reason.value if isinstance(reason, Reason) else reason
        if detail is not None:
            if ":" in text:
                raise ValueError("pass the detail once, not both in the reason and as detail")
            text = f"{text}:{detail}"
        return cls(False, None, None, _validate_reason(text))

    @property
    def reason_code(self) -> Reason | None:
        """The vocabulary member without its detail suffix; None for a known Measure."""
        if self.reason is None:
            return None
        return Reason(self.reason.partition(":")[0])

    def expect(self) -> int | float | str | bool:
        """The value, or MeasureUnknown carrying the reason (never a silent default)."""
        if not self.is_known:
            raise MeasureUnknown(self.reason or "")
        assert self.value is not None
        return self.value

    def to_json(self) -> dict[str, object]:
        if self.is_known:
            return {"value": self.value, "source": self.source}
        return {"unknown": self.reason}

    @classmethod
    def from_json(cls, obj: object) -> Measure:
        if not isinstance(obj, dict):
            raise ValueError("a Measure on disk is a JSON object")
        keys = set(obj)
        if keys == {"value", "source"}:
            return cls(True, obj["value"], obj["source"], None)
        if keys == {"unknown"}:
            reason = obj["unknown"]
            if not isinstance(reason, str):
                raise ValueError("Measure 'unknown' must be a reason string, never null or 0")
            return cls(False, None, None, reason)
        raise ValueError("a Measure on disk has exactly the keys {value, source} or {unknown}")


def sum_known(measures: Iterable[Measure]) -> tuple[int | float, int, int, Counter[str]]:
    """Sum the known numeric values; report how many were unknown and why.

    This is the only summation helper: an unknown term never counts as zero, and callers
    store the result as unknown("partial") whenever n_unknown > 0.
    """
    total: int | float = 0
    n_known = 0
    reasons: Counter[str] = Counter()
    for m in measures:
        if m.is_known:
            if isinstance(m.value, bool) or not isinstance(m.value, int | float):
                raise TypeError("sum_known only sums int or float Measures")
            total += m.value
            n_known += 1
        else:
            assert m.reason is not None
            reasons[m.reason] += 1
    return total, n_known, sum(reasons.values()), reasons
