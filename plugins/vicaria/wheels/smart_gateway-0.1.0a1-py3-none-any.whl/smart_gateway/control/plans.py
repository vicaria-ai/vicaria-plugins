"""The plan source: what the in-harness component asks and what the commit point re-reads.

This is the seam to the recommendation service — RFC 0009 §1's "server" — and
the shape here is the shape ``smart-gateway-bench/docs/design/
recommendation-service.md`` describes: the client sends its descriptor and
current configuration, the service returns a plan. The bench repository will
own the real service; this module owns the *client* both components use and a
reference server small enough to drive the conformance suite and stand in for
the service in tests.

Two calls, deliberately:

* ``POST /v1/plan`` — the hook's request. The response carries the plan *and* the
  recipe texts the plan names, so a prompt patch is staged from the same round
  trip that produced the plan and cannot drift from it.
* ``GET /v1/plan/<decision_id>`` — the commit point's re-read. The commit point
  never trusts the copy of the plan a hook could have carried in the request;
  it fetches the plan the service actually served under that id. A hook that
  could hand the commit point a plan of its own would be a hook that could apply
  a configuration nobody recommended.

Failure is a typed outcome, not an exception the caller has to classify:
:class:`PlanUnavailable` carries the :class:`~vicaria_contracts.decision.UnavailableReason`
the decision record needs, because "the server could not be reached" and "the
server refused" are different operational facts (§4.3).
"""

from __future__ import annotations

import json
import threading
from collections.abc import Callable, Mapping
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib import error, request
from urllib.parse import urlsplit

from vicaria_contracts.decision import UnavailableReason
from vicaria_contracts.plan import Plan

PLAN_REQUEST_SCHEMA = "vicaria.plan-request.v1"

#: The longest wait this client will adopt from a plan source's announced
#: budget, mirroring the service's own ceiling on what it may announce
#: (``vicaria_server/policy.py``'s ``CLIENT_PLAN_BUDGET_CAP_MS``, 10 s).
#:
#: The announcement is a number from the network, and the fallback discipline
#: it feeds exists so that a plan source which stops answering costs the
#: developer a bounded pause and nothing more. Adopting the figure unchecked
#: hands that bound to whatever sent it: one field saying ``3600000`` would
#: stall every prompt on that machine for an hour, with the record calling it
#: a timeout. A configured ``plan_timeout_s`` above this is still honoured ---
#: a local operator may wait as long as they like, a remote service may not
#: make them.
MAX_ANNOUNCED_BUDGET_S = 10.0

#: Hosts a credential may cross plaintext to reach. The reference
#: :class:`PlanServer`, the conformance drivers and every test here bind
#: loopback and speak plain HTTP, so requiring TLS unconditionally would
#: forbid the local development story this module exists to serve.
LOOPBACK = frozenset({"localhost", "127.0.0.1", "::1", "[::1]"})

#: Where the recommendation service serves plans, under the base URL
#: ``control.json`` names as ``plan_source`` (``vicaria_server/api.py``:
#: ``/v1/plan`` and ``/v1/plan/{decision_id}``). It was ``/plan`` here, which
#: only the reference :class:`PlanServer` below ever answered, so a
#: ``plan_source`` pointing at the service itself was answered 404 on every
#: prompt and the adapter ran the reference — with no error, because a plan
#: source that does not answer is an ordinary outcome. The OpenCode plugin has
#: always asked for ``/v1/plan`` (``plugin-opencode/src/api.ts``). One constant,
#: so this client and the reference server cannot drift apart again.
PLAN_PATH = "/v1/plan"


def carries_a_credential_safely(base_url: str) -> bool:
    """Whether an organization token may be sent to ``base_url``.

    Adding the token turned this client from one that leaked nothing to one
    that hands an organization's credential to whatever URL a ``control.json``
    names. ``plan_source`` is validated as "a URL or null" and nothing checks
    its scheme, so ``http://plans.internal`` would put a bearer token on the
    wire in clear text --- a regression introduced by fixing the 401, and
    invisible because it would keep working.
    """
    split = urlsplit(base_url)
    if split.scheme == "https":
        return True
    return (split.hostname or "") in LOOPBACK


class ControlCredentialError(Exception):
    """A credential was about to cross an unprotected hop. Never caught here.

    Deliberately not a :class:`PlanUnavailable`: that class is the typed
    outcome a caller records and carries on from, and carrying on is exactly
    what must not happen. Dropping the token silently instead would produce a
    ``401``, which arrives as ``REFUSED`` and reads like a service that
    considered the request --- the same misleading failure this client was
    changed to remove.
    """

    exit_code = 2


class PlanUnavailable(Exception):
    def __init__(self, reason: UnavailableReason, detail: str) -> None:
        super().__init__(detail)
        self.reason = reason
        self.detail = detail


@dataclass(frozen=True, slots=True)
class PlanResponse:
    plan: Plan
    recipes: Mapping[str, str]


class PlanClient:
    """The client both in-harness components use to reach the plan source.

    Two things this carries that a bare HTTP call would not.

    **The organization token.** The service authenticates every plan request as
    an organization (``Authorization: Bearer``) and answers ``401`` without one.
    Sending no credential at all is not "unauthenticated access", it is no
    access: until this client carried a token, every Claude Code plan request
    was refused before the service read the body.

    **The budget the service announced.** The plan response carries
    ``plan_budget_ms`` --- how long the service says a plan may take under the
    version that answered *this* decision. Waiting by a fixed local timeout
    instead means a promotion to a slower version reads as a timeout on the
    client, which the record then blames on the network. So the timeout for the
    next call is the budget the last plan announced, exactly the discipline the
    OpenCode plugin already follows by waiting on the episode's last plan.
    ``timeout_s`` is the first call's wait and the floor under every later one.
    """

    def __init__(self, base_url: str, timeout_s: float = 3.0, token: str | None = None) -> None:
        if token and not carries_a_credential_safely(base_url):
            raise ControlCredentialError(
                f"refusing to send an organization token to {base_url!r} in clear text: "
                "use https, or a loopback address for local development"
            )
        self.base_url = base_url.rstrip("/")
        self.timeout_s = timeout_s
        self.token = token
        #: The budget the most recent plan announced, in seconds; ``None`` until
        #: one has. Never lowers the wait below ``timeout_s``.
        self.announced_timeout_s: float | None = None

    def _headers(self, body: bool) -> dict[str, str]:
        headers = {"content-type": "application/json"} if body else {}
        if self.token:
            headers["authorization"] = f"Bearer {self.token}"
        return headers

    @property
    def _wait_s(self) -> float:
        if self.announced_timeout_s is None:
            return self.timeout_s
        return max(self.timeout_s, min(self.announced_timeout_s, MAX_ANNOUNCED_BUDGET_S))

    def _observe_budget(self, obj: Mapping[str, Any]) -> None:
        budget = obj.get("plan_budget_ms") if isinstance(obj, Mapping) else None
        if isinstance(budget, bool) or not isinstance(budget, int | float):
            return
        if budget > 0:
            self.announced_timeout_s = float(budget) / 1000.0

    def request(self, payload: Mapping[str, Any]) -> PlanResponse:
        body = json.dumps({"schema": PLAN_REQUEST_SCHEMA, **payload}).encode("utf-8")
        req = request.Request(
            self.base_url + PLAN_PATH,
            data=body,
            headers=self._headers(body=True),
            method="POST",
        )
        wait_s = self._wait_s
        try:
            with request.urlopen(req, timeout=wait_s) as resp:
                raw = resp.read()
        except error.HTTPError as exc:
            raise PlanUnavailable(
                UnavailableReason.REFUSED, f"plan source answered {exc.code}"
            ) from None
        except TimeoutError:
            raise PlanUnavailable(
                UnavailableReason.TIMED_OUT, f"plan source silent for {wait_s}s"
            ) from None
        except (error.URLError, ConnectionError, OSError) as exc:
            raise PlanUnavailable(UnavailableReason.UNREACHABLE, f"plan source: {exc}") from None
        try:
            obj = json.loads(raw)
            plan = Plan.from_dict(obj.get("plan"))
        except (json.JSONDecodeError, ValueError, AttributeError) as exc:
            raise PlanUnavailable(
                UnavailableReason.REFUSED, f"plan source returned an unreadable plan: {exc}"
            ) from None
        recipes = obj.get("recipes") or {}
        if not isinstance(recipes, dict) or not all(
            isinstance(k, str) and isinstance(v, str) for k, v in recipes.items()
        ):
            raise PlanUnavailable(UnavailableReason.REFUSED, "plan source recipes are malformed")
        self._observe_budget(obj)
        return PlanResponse(plan=plan, recipes=recipes)

    def fetch(self, decision_id: str) -> PlanResponse | None:
        """The plan served under ``decision_id``, or ``None`` if the source has none."""
        req = request.Request(
            self.base_url + PLAN_PATH + "/" + decision_id,
            headers=self._headers(body=False),
            method="GET",
        )
        try:
            with request.urlopen(req, timeout=self._wait_s) as resp:
                obj = json.loads(resp.read())
        except error.HTTPError as exc:
            if exc.code == 404:
                return None
            raise PlanUnavailable(UnavailableReason.REFUSED, f"plan source {exc.code}") from None
        except TimeoutError:
            raise PlanUnavailable(UnavailableReason.TIMED_OUT, "plan source silent") from None
        except (error.URLError, ConnectionError, OSError) as exc:
            raise PlanUnavailable(UnavailableReason.UNREACHABLE, f"plan source: {exc}") from None
        try:
            return PlanResponse(
                plan=Plan.from_dict(obj.get("plan")), recipes=obj.get("recipes") or {}
            )
        except (ValueError, AttributeError) as exc:
            raise PlanUnavailable(UnavailableReason.REFUSED, f"unreadable plan: {exc}") from None


#: A policy answers a plan request with ``(plan_dict, recipes)``, or raises
#: :class:`PlanRefused` to answer with an HTTP status.
Policy = Callable[[Mapping[str, Any]], tuple[Mapping[str, Any], Mapping[str, str]]]


class PlanRefused(Exception):
    def __init__(self, status: int, detail: str = "") -> None:
        super().__init__(detail)
        self.status = status
        self.detail = detail


class PlanServer:
    """A reference plan source: one policy callable, served over HTTP.

    Not the recommendation service. It has no evidence, no candidate set and no
    ranking — it answers with whatever its policy returns, which is exactly what
    a conformance driver needs and nothing a deployment should run.
    """

    def __init__(self, policy: Policy, host: str = "127.0.0.1", port: int = 0) -> None:
        self.policy = policy
        self.requests: list[dict[str, Any]] = []
        #: The ``authorization`` header of each request, in order, ``None``
        #: where none was sent. A conformance driver has to be able to see that
        #: a client sent a credential at all, because sending none is the one
        #: failure the service answers before it reads the body.
        self.authorizations: list[str | None] = []
        self.served: dict[str, tuple[Mapping[str, Any], Mapping[str, str]]] = {}
        self._lock = threading.Lock()
        server = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args: Any) -> None:
                pass

            def _json(self, status: int, obj: Mapping[str, Any]) -> None:
                data = json.dumps(obj).encode("utf-8")
                self.send_response(status)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def do_POST(self) -> None:
                length = int(self.headers.get("content-length") or 0)
                try:
                    payload = json.loads(self.rfile.read(length) or b"{}")
                except json.JSONDecodeError:
                    return self._json(400, {"error": "not json"})
                if urlsplit(self.path).path != PLAN_PATH:
                    return self._json(404, {"error": "no such route"})
                with server._lock:
                    server.requests.append(payload)
                    server.authorizations.append(self.headers.get("authorization"))
                try:
                    plan, recipes = server.policy(payload)
                except PlanRefused as exc:
                    return self._json(exc.status, {"error": exc.detail})
                decision_id = plan.get("decision_id") if isinstance(plan, Mapping) else None
                if isinstance(decision_id, str):
                    with server._lock:
                        server.served[decision_id] = (plan, recipes)
                self._json(200, {"plan": plan, "recipes": dict(recipes)})

            def do_GET(self) -> None:
                path = urlsplit(self.path).path
                if not path.startswith(PLAN_PATH + "/"):
                    return self._json(404, {"error": "no such route"})
                with server._lock:
                    hit = server.served.get(path[len(PLAN_PATH) + 1 :])
                if hit is None:
                    return self._json(404, {"error": "no plan under that id"})
                self._json(200, {"plan": hit[0], "recipes": dict(hit[1])})

        self._http = ThreadingHTTPServer((host, port), Handler)
        self._thread = threading.Thread(target=self._http.serve_forever, daemon=True)

    @property
    def url(self) -> str:
        host, port = self._http.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> PlanServer:
        self._thread.start()
        return self

    def serve_forever(self) -> None:
        """Block until :meth:`stop` (or the process ends). For the CLI."""
        self._thread.join()

    def stop(self) -> None:
        self._http.shutdown()
        self._http.server_close()
