"""The control half: applying a plan on Claude Code, as two components and one contract.

The observe plugin in ``plugin/`` promises in its manifest that it *never routes,
never blocks, never injects context*, and its shim points stdout at /dev/null so
the promise holds by construction. Control is the opposite of that promise, so
it is a second plugin (``plugin-control/``) rather than a mode of the first: a
reader of the observe plugin's manifest keeps getting a true statement, and the
CI smoke job that pins its invisibility keeps meaning something.

Two components carry one plan, exactly as ``docs/design/control-plane.md`` §2.4
lays out and RFC 0009 §4.2 requires:

* :mod:`smart_gateway.control.hook` is the **in-harness component**. On
  ``UserPromptSubmit`` it requests a plan, validates it against the package's
  capability descriptor with :func:`vicaria_contracts.client.decide`, and — where the plan
  changes the prompt — *stages* its contribution: the recipe text travels inside
  a machine-readable block in ``additionalContext``, together with the staging
  confirmation, and nothing is applied. On ``cannot_execute`` it blocks the
  prompt, which is how "zero provider requests" is reached from inside the
  harness.

* :mod:`smart_gateway.control.commit_point` is the **commit point**: a reverse
  proxy the harness reaches through ``ANTHROPIC_BASE_URL``. It reads the block
  off the request, re-fetches the plan by id, runs the same ``decide`` and then
  :func:`vicaria_contracts.client.resolve`, and materializes everything — model, effort,
  and the staged prompt — or nothing. A fallback dispatches the reference only
  after the same admission every dispatch passes, and a request that cannot be
  admitted is answered with an error and reaches no provider.

Both components validate the same plan against the same descriptor, and the
commit point verifies the hook's assumed baseline against the request it
actually receives. Where they disagree the request is refused as a stale
baseline and recorded; nothing is inferred.

The whole seam is driven end to end, against the real ``claude`` binary, by
:mod:`smart_gateway.conformance.claude_code`.
"""
