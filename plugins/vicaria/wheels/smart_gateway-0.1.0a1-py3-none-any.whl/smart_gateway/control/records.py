"""Where control records go, and the privacy line they keep.

``sg.control.v1`` lines land in ``raw/control/YYYY-MM-DD.jsonl`` next to the
observe plugin's ``raw/hooks``. Each line is one of a few kinds — ``stage`` from
the hook, ``dispatch`` and ``request`` from the commit point, ``assignment``
from whichever component minted it — and every kind carries the ids the other
kinds join on: ``session_id``, ``prompt_id`` and ``decision_id``.

The same discipline as ``raw/hooks``: prompt text, recipe text and message
content never reach a record. A record carries the recipe *id*, the prompt's
*length*, the model and effort that were dispatched, and the contract's own
typed records (:class:`vicaria_contracts.client.EpisodeRecords`), which name
configurations and refusals and nothing a user typed.

The shape is the client core's (``vicaria_client.records``, vicaria-docs RFC 0065
§3.7); what is this machine's --- the shard under the data directory, the
benchmark launch a record is stamped with --- is here.
"""

from __future__ import annotations

import os
from collections.abc import Iterator, Mapping
from pathlib import Path
from typing import Any

from smart_gateway import __version__
from smart_gateway.ids import utc_now_iso
from smart_gateway.rawlog import append_line, iter_lines, shard_path
from vicaria_client import records as shape
from vicaria_client.records import CONTROL_RECORD_SCHEMA, ENVELOPE_KEYS

KINDS = ("stage", "dispatch", "request", "assignment", "usage", "error")

#: A benchmark runs one agent per task and grades per task; this plane records
#: per *prompt*. Without a shared id the two corpora cannot be joined, and
#: "which recommendation ran on which benchmark task" is unanswerable — so an
#: episode carries the benchmark's own task id in this variable and the
#: in-harness components stamp it on what they record.
#:
#: Read by the components that run *inside* one episode (the Claude Code hook,
#: the OpenCode bridge). The commit point is a long-lived server shared by every
#: episode, so it does not read this: its records join through ``decision_id``.
TASK_ID_ENV = "VICARIA_TASK_ID"


def task_id(environ: Mapping[str, str] | None = None) -> str | None:
    env = os.environ if environ is None else environ
    value = env.get(TASK_ID_ENV)
    return value if isinstance(value, str) and value and len(value) <= 256 else None


#: A benchmark launch is one trial of one arm running one complete configuration.
#: The launcher sets these once, before the harness starts, and every component
#: that writes a record under that launch stamps them — the hook, the bridge and
#: the commit point alike, because under a benchmark the commit point is started
#: per trial with the trial's environment. A shared development server has no
#: trial id and stamps nothing, which is how the two deployments are told apart.
TRIAL_ID_ENV = "VICARIA_TRIAL_ID"
ARM_ENV = "VICARIA_ARM"
CONFIG_LABEL_ENV = "VICARIA_CONFIG_LABEL"
ARMS = ("reference", "fixed", "policy")


def launch_identity(environ: Mapping[str, str] | None = None) -> dict[str, str | None] | None:
    """Task, trial, arm and configuration label of the launch this process runs under.

    ``None`` when no trial id is set: a record from a shared server carries no
    launch, rather than a fabricated one. An arm outside :data:`ARMS` is refused
    at the first record rather than filed under a name no analysis expects.
    """
    env = os.environ if environ is None else environ
    trial = env.get(TRIAL_ID_ENV)
    if not isinstance(trial, str) or not trial:
        return None
    arm = env.get(ARM_ENV)
    if arm not in ARMS:
        raise ValueError(f"{ARM_ENV} must be one of {ARMS}, got {arm!r}")
    label = env.get(CONFIG_LABEL_ENV)
    return {
        "task_id": task_id(env),
        "trial_id": trial,
        "arm": arm,
        "config_label": label if isinstance(label, str) and label else None,
    }


def write_record(data_dir: Path, kind: str, fields: Mapping[str, Any]) -> Path:
    if kind not in KINDS:
        raise ValueError(f"unknown control record kind {kind!r}")
    shape.refuse_envelope_clash(kind, fields)
    launch = launch_identity()
    path = shard_path(data_dir / "raw", "control")
    append_line(
        path,
        {**envelope(kind), **({"launch": launch} if launch is not None else {}), **fields},
    )
    return path


def envelope(kind: str) -> dict[str, Any]:
    """What every control record opens with, on disk and on the wire alike."""
    return shape.envelope(kind, version=__version__, recorded_at=utc_now_iso())


def iter_records(data_dir: Path) -> Iterator[dict[str, Any]]:
    control_dir = data_dir / "raw" / "control"
    if not control_dir.exists():
        return
    for path in sorted(control_dir.glob("*.jsonl")):
        for _line_no, obj in iter_lines(path):
            if isinstance(obj, dict) and obj.get("schema") == CONTROL_RECORD_SCHEMA:
                yield obj


__all__ = [
    "ARMS",
    "ARM_ENV",
    "CONFIG_LABEL_ENV",
    "CONTROL_RECORD_SCHEMA",
    "ENVELOPE_KEYS",
    "KINDS",
    "TASK_ID_ENV",
    "TRIAL_ID_ENV",
    "envelope",
    "iter_records",
    "launch_identity",
    "task_id",
    "write_record",
]
