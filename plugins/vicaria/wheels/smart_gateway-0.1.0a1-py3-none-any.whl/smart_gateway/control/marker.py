"""The in-band block: how a staged contribution and its confirmation ride the request.

Claude Code's ``UserPromptSubmit`` hook can add ``additionalContext``; it cannot
add a header, set an environment variable for the request, or touch the body
any other way. So the confirmation RFC 0009 §4.2 requires *on the request*
travels the only way it can: inside the text Claude Code injects, wrapped in
delimiters the commit point can find exactly.

Verified at the wire: the injected text arrives as its own ``text`` block in the
last user message, wrapped in a ``<system-reminder>`` that names the hook. The
commit point replaces that whole block with the materialized recipe, or drops
it, and never has to edit around it.

The block carries the recipe *text* as the staged payload. That is what makes
the contribution stageable rather than applied — the harness has put the text
in the request, but the commit point decides whether the provider ever sees
it, and a fallback strips it before forwarding. A hook that injected the recipe
as plain context would have applied it, and "forward unmodified" would then run
the recipe against the reference model, which is the defect §4.2 exists to
prevent.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

BLOCK_OPEN = "<vicaria-staging>"
BLOCK_CLOSE = "</vicaria-staging>"
BLOCK_VERSION = 1
_BLOCK_RE = re.compile(re.escape(BLOCK_OPEN) + r"(.*?)" + re.escape(BLOCK_CLOSE), re.DOTALL)


class MarkerError(ValueError):
    """A block that is present and not readable — refused, never guessed at."""


@dataclass(frozen=True, slots=True)
class StagingBlock:
    """What the in-harness component tells the commit point.

    Only ``decision_id`` is *trusted* to identify anything, and only insofar as
    the commit point re-fetches the plan it names from the plan source. The
    staged contribution and confirmation are verified by the commit point's own
    ``commit``; ``origin``, ``unavailable_reason`` and ``assignment`` are carried
    for the record and the record says who wrote them.
    """

    decision_id: str
    episode_id: str
    request_revision: str
    origin: str  # served | local | unavailable
    unavailable_reason: str | None
    staged: Mapping[str, Any] | None
    confirmation: Mapping[str, Any] | None
    payload: Mapping[str, Any] | None  # {"recipe": id, "text": ...} when the prompt is staged
    assignment: Mapping[str, Any] | None
    validation: Mapping[str, Any] | None

    def encode(self) -> str:
        body = {
            "v": BLOCK_VERSION,
            "decision_id": self.decision_id,
            "episode_id": self.episode_id,
            "request_revision": self.request_revision,
            "origin": self.origin,
            "unavailable_reason": self.unavailable_reason,
            "staged": dict(self.staged) if self.staged else None,
            "confirmation": dict(self.confirmation) if self.confirmation else None,
            "payload": dict(self.payload) if self.payload else None,
            "assignment": dict(self.assignment) if self.assignment else None,
            "validation": dict(self.validation) if self.validation else None,
        }
        return BLOCK_OPEN + json.dumps(body, sort_keys=True, separators=(",", ":")) + BLOCK_CLOSE

    @classmethod
    def decode(cls, text: str) -> StagingBlock | None:
        """The block inside ``text``, or ``None`` when there is none.

        Two blocks in one text is refused: the second could only be an attempt
        to have the commit point read one and materialize the other.
        """
        found = _BLOCK_RE.findall(text)
        if not found:
            return None
        if len(found) > 1:
            raise MarkerError("more than one staging block in one text block")
        try:
            obj = json.loads(found[0])
        except json.JSONDecodeError as exc:
            raise MarkerError(f"staging block is not JSON: {exc}") from None
        if not isinstance(obj, dict) or obj.get("v") != BLOCK_VERSION:
            raise MarkerError("staging block has no recognizable version")
        for key in ("decision_id", "episode_id", "request_revision", "origin"):
            if not isinstance(obj.get(key), str) or not obj[key]:
                raise MarkerError(f"staging block: {key} must be a nonempty string")
        for key in ("staged", "confirmation", "payload", "assignment", "validation"):
            if obj.get(key) is not None and not isinstance(obj[key], dict):
                raise MarkerError(f"staging block: {key} must be an object or null")
        reason = obj.get("unavailable_reason")
        if reason is not None and not isinstance(reason, str):
            raise MarkerError("staging block: unavailable_reason must be a string or null")
        return cls(
            decision_id=obj["decision_id"],
            episode_id=obj["episode_id"],
            request_revision=obj["request_revision"],
            origin=obj["origin"],
            unavailable_reason=reason,
            staged=obj.get("staged"),
            confirmation=obj.get("confirmation"),
            payload=obj.get("payload"),
            assignment=obj.get("assignment"),
            validation=obj.get("validation"),
        )


#: The whole reminder Claude Code wraps a hook's context in, when it holds only
#: our block. Replaced as a unit so a fallback leaves no empty reminder behind.
_REMINDER_RE = re.compile(
    r"<system-reminder>\s*(?:[^\n<]*hook additional context:\s*)?"
    + re.escape(BLOCK_OPEN)
    + r".*?"
    + re.escape(BLOCK_CLOSE)
    + r"\s*</system-reminder>",
    re.DOTALL,
)

Location = tuple[str, int, int]  # ("messages" | "system", message_index, block_index)


def is_prompt_message(message: Mapping[str, Any]) -> bool:
    """Whether a ``role: "user"`` message is the user's prompt, not a tool result.

    In the Messages API a tool result comes back as a *user* message whose
    content is ``tool_result`` blocks. A turn is therefore not one user message
    but a user prompt followed by any number of tool-result user messages, and
    the staging block lives with the prompt. Stopping at the first user message
    from the end would stop at the last tool result, miss the turn's block, and
    dispatch the reference for every request after the first tool call — with
    the historical block still in the request. Observed on the wire against
    Claude Code 2.1.237 before this predicate existed.
    """
    if message.get("role") != "user":
        return False
    content = message.get("content")
    if isinstance(content, list):
        return not any(
            isinstance(part, dict) and part.get("type") == "tool_result" for part in content
        )
    return True


def strip_all_blocks(body: dict[str, Any]) -> int:
    """Remove every staging block anywhere in the request; returns how many.

    Run after the current turn's block has been materialized or stripped, so
    that no *earlier* turn's block — kept by the harness as conversation
    history — reaches the provider. A transport marker is never model input.
    """
    removed = 0
    messages = body.get("messages")
    if isinstance(messages, list):
        for message in messages:
            if not isinstance(message, dict):
                continue
            content = message.get("content")
            if isinstance(content, str):
                if _BLOCK_RE.search(content):
                    message["content"] = _splice(content, None).strip() or " "
                    removed += 1
            elif isinstance(content, list):
                kept: list[Any] = []
                for part in content:
                    if isinstance(part, dict) and part.get("type") == "text":
                        text = part.get("text") or ""
                        if _BLOCK_RE.search(text):
                            removed += 1
                            text = _splice(text, None)
                            if not text.strip():
                                continue  # a block that was alone in its text block
                            part = {**part, "text": text}
                    kept.append(part)
                message["content"] = kept or [{"type": "text", "text": " "}]
    system = body.get("system")
    if isinstance(system, str) and _BLOCK_RE.search(system):
        body["system"] = _splice(system, None).strip() or " "
        removed += 1
    elif isinstance(system, list):
        kept_system: list[Any] = []
        for part in system:
            if isinstance(part, dict) and part.get("type") == "text":
                text = part.get("text") or ""
                if _BLOCK_RE.search(text):
                    removed += 1
                    text = _splice(text, None)
                    if not text.strip():
                        continue
                    part = {**part, "text": text}
            kept_system.append(part)
        body["system"] = kept_system or [{"type": "text", "text": " "}]
    return removed


def find_block(body: Mapping[str, Any]) -> tuple[StagingBlock | None, Location | None]:
    """Locate this turn's block in a Messages request.

    Where Claude Code puts a hook's ``additionalContext`` depends on the model:
    observed as text blocks inside the user turn (``claude-sonnet-4-5``) and as
    one coalesced ``role: "system"`` message appended *after* the user turn
    (``claude-opus-5``), with the block near the end of a 7 kB reminder. So the
    search runs from the end of ``messages`` over every role, and **stops once
    the last user turn has been scanned**: an earlier turn's block belongs to a
    decision that was already committed, and reading it would re-apply a plan
    nobody re-validated for this prompt. The top-level ``system`` array is the
    last resort.
    """
    messages = body.get("messages")
    if isinstance(messages, list):
        for m_index in range(len(messages) - 1, -1, -1):
            message = messages[m_index]
            if not isinstance(message, dict):
                continue
            content = message.get("content")
            if isinstance(content, str):
                block = StagingBlock.decode(content)
                if block is not None:
                    return block, ("messages", m_index, -1)
            elif isinstance(content, list):
                for b_index in range(len(content) - 1, -1, -1):
                    part = content[b_index]
                    if isinstance(part, dict) and part.get("type") == "text":
                        block = StagingBlock.decode(part.get("text") or "")
                        if block is not None:
                            return block, ("messages", m_index, b_index)
            if is_prompt_message(message):
                break  # this turn ends here; anything earlier is another decision
    system = body.get("system")
    if isinstance(system, list):
        for s_index in range(len(system) - 1, -1, -1):
            part = system[s_index]
            if isinstance(part, dict) and part.get("type") == "text":
                block = StagingBlock.decode(part.get("text") or "")
                if block is not None:
                    return block, ("system", s_index, -1)
    elif isinstance(system, str):
        block = StagingBlock.decode(system)
        if block is not None:
            return block, ("system", -1, -1)
    return None, None


def _splice(text: str, replacement: str | None) -> str:
    """Replace our block — and the reminder around it when that reminder holds
    nothing else — leaving every other reminder in the text untouched."""
    new = replacement or ""
    if _REMINDER_RE.search(text):
        return _REMINDER_RE.sub(lambda _m: new, text, count=1)
    return _BLOCK_RE.sub(lambda _m: new, text, count=1)


def rewrite_block(body: dict[str, Any], location: Location, replacement: str | None) -> None:
    """Materialize the block in place (``replacement``) or strip it (``None``).

    Spliced within the text block that carried it, never by dropping the block:
    Claude Code coalesces several reminders into one text block, and the rest
    of that block — the environment, the user's own context — is not ours to
    remove. A text block left empty is dropped when siblings remain.
    """
    container, index, b_index = location
    if container == "system":
        system = body.get("system")
        if isinstance(system, str):
            body["system"] = _splice(system, replacement).strip() or " "
        elif isinstance(system, list) and 0 <= index < len(system):
            part = system[index]
            part["text"] = _splice(part.get("text") or "", replacement)
            if not part["text"].strip():
                if len(system) > 1:
                    del system[index]
                else:
                    part["text"] = " "
        return
    message = body["messages"][index]
    content = message.get("content")
    if b_index == -1 or isinstance(content, str):
        message["content"] = (
            _splice(content if isinstance(content, str) else "", replacement).strip() or " "
        )
        return
    part = content[b_index]
    part["text"] = _splice(part.get("text") or "", replacement)
    if not part["text"].strip():
        if len(content) > 1:
            del content[b_index]
        else:
            part["text"] = " "


def materialized_text(recipe: str, text: str) -> str:
    """How a materialized prompt contribution reads to the model."""
    return f"<system-reminder>\nVicaria prompt recipe {recipe}:\n{text}\n</system-reminder>"
