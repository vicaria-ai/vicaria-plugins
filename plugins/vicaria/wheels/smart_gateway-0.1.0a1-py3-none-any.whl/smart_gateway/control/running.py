"""What the session is running, read from where Claude Code actually says it.

The hook used to take the model from ``SessionStart``'s payload. Claude Code
sends none there (2.1.285, a new session and a resumed one alike), so the hook
fell through to ``control.json``'s default and reported that as the active
configuration: a session on one model was judged, and admitted or refused by
the organization's policy, as another. The version it reported was
``control.json``'s too.

Claude Code does say all of it, in two places a hook can read:

- **The environment.** ``AI_AGENT`` names the harness and its version to every
  hook (``claude-code_2-1-285_harness``); no payload does.
- **The transcript.** Once the first request of a session has been built it
  holds a ``model`` attachment (``identity.modelId``), the model on every
  assistant row, and a ``prompt_snapshot`` attachment whose ``tools`` are the
  tools sent on the wire. It does not exist at the first ``UserPromptSubmit``,
  which is why the first prompt of a session can only be *believed*, and why the
  hook reports what ran when the turn ends (``hook._observed``).

The transcript names **two** models, and they are not the same thing. The
``model`` attachment is the model Claude Code is configured with: the one its
requests ask for, written from its own settings. An assistant row's
``message.model`` is the model that *answered* --- which, behind the commit
point, is the model a plan applied. The first is the session's configuration
(``Seen.model_id``); the second is what was served (``Seen.served_id``). A first
build read the second as the first, so a session configured for Opus and served
Haiku by a plan told the service on its next prompt that it was configured for
Haiku, and the commit point refused the turn as a baseline mismatch (found in
review).

``tests/fixtures/claude_code_2_1_285`` holds what one real session produced, and
this module is written against that and nothing else.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

#: ``claude-code_2-1-285_harness`` in a session, ``…_agent`` in a subagent's.
AGENT_VERSION = re.compile(r"^claude-code_(\d+(?:-\d+){1,3})(?:_|$)")
#: A release's date stamp, and the context-window marker a model id can carry.
#: A policy's ``allowed_models`` and the registry name a model without either.
_STAMP = re.compile(r"(?:-\d{8})?(?:\[[^\]]*\])?$")
#: Not a model: the id Claude Code gives a row it wrote itself.
SYNTHETIC = "<synthetic>"

#: Where a reported value came from, most trustworthy first.
TRANSCRIPT = "transcript"  # what the harness recorded it ran
HARNESS = "harness"  # what the harness told this hook
ENVIRONMENT = "environment"  # what the launch asked for
CONFIGURED = "configured"  # control.json
CONFIGURED_DEFAULT = "configured_default"  # control.json's default: a belief, not a reading


def harness_version(environ: Mapping[str, Any]) -> str | None:
    """The running Claude Code's version, or None where the harness named none."""
    matched = AGENT_VERSION.match(str(environ.get("AI_AGENT") or ""))
    return matched.group(1).replace("-", ".") if matched else None


def canonical(model_id: str) -> str:
    """The model as a policy and the registry name it: without its date stamp."""
    return _STAMP.sub("", model_id) or model_id


@dataclass(frozen=True, slots=True)
class Seen:
    """What one read of the transcript found, and how far it read."""

    #: The configured model: the ``model`` attachment's id.
    model_id: str | None
    tools: tuple[str, ...] | None
    offset: int
    #: The model that answered, from the assistant rows read: what was served.
    served_id: str | None = None


def read(path: str | Path | None, *, offset: int = 0) -> Seen:
    """The model and the tools the transcript names after ``offset``.

    The last of each wins: a model switched mid-session is the model of the
    next turn. Only whole lines are consumed, so a row Claude Code is still
    writing is read by the next call instead of being lost to this one, and the
    offset returned is where that call should start --- a long session's
    transcript is megabytes, and each prompt reads only what the last turn added.
    """
    model_id: str | None = None
    served_id: str | None = None
    tools: tuple[str, ...] | None = None
    if not path:
        return Seen(None, None, offset)
    try:
        fh = open(path, "rb")  # noqa: SIM115 - closed below, on every path
    except OSError:
        return Seen(None, None, offset)
    with fh:
        fh.seek(offset)
        for line in fh:
            if not line.endswith(b"\n"):
                break
            offset += len(line)
            if b'"model' not in line and b"prompt_snapshot" not in line:
                continue
            try:
                row = json.loads(line)
            except (json.JSONDecodeError, UnicodeDecodeError):
                continue
            if not isinstance(row, dict) or row.get("isSidechain") is True:
                continue  # a subagent's rows are its own session's, not this one's
            found_model, found_served, found_tools = _of(row)
            model_id = found_model or model_id
            served_id = found_served or served_id
            tools = found_tools if found_tools is not None else tools
    return Seen(model_id, tools, offset, served_id)


def _of(row: Mapping[str, Any]) -> tuple[str | None, str | None, tuple[str, ...] | None]:
    """(configured model, served model, tools) a row names; each None where it does not."""
    kind = row.get("type")
    if kind == "assistant":
        message = row.get("message")
        return None, _model(message.get("model") if isinstance(message, Mapping) else None), None
    attachment = row.get("attachment")
    if kind != "attachment" or not isinstance(attachment, Mapping):
        return None, None, None
    if attachment.get("type") == "model":
        identity = attachment.get("identity")
        named = identity.get("modelId") if isinstance(identity, Mapping) else None
        return _model(named), None, None
    if attachment.get("type") == "prompt_snapshot" and isinstance(attachment.get("tools"), list):
        names = [t.get("name") for t in attachment["tools"] if isinstance(t, Mapping)]
        return None, None, tuple(n for n in names if isinstance(n, str) and n)
    return None, None, None


def _model(value: Any) -> str | None:
    ok = isinstance(value, str) and 0 < len(value) <= 256 and value.isprintable()
    return value if ok and value != SYNTHETIC else None


__all__ = [
    "CONFIGURED",
    "CONFIGURED_DEFAULT",
    "ENVIRONMENT",
    "HARNESS",
    "TRANSCRIPT",
    "Seen",
    "canonical",
    "harness_version",
    "read",
]
