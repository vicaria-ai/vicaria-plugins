"""The commit point: an Anthropic Messages reverse proxy that materializes everything or nothing.

Claude Code reaches it through ``ANTHROPIC_BASE_URL``. On every ``POST
/v1/messages`` it:

1. Reads the request's :class:`~smart_gateway.control.marker.StagingBlock` off
   the last user turn — or notes that there is none.
2. Derives the **reference** from the request itself: the model and
   ``output_config.effort`` the harness actually sent. This is what the plan's
   ``base_config_digest`` is checked against, so a hook that assumed the wrong
   baseline is refused here, dimension by dimension, rather than trusted.
3. Re-fetches the plan named by the block from the plan source and runs the
   same :func:`vicaria_contracts.client.decide` the hook ran.
4. Runs :func:`vicaria_contracts.client.resolve` — which is
   :func:`vicaria_contracts.staging.commit` with the client core's own fallbacks around it
   — with the staged contribution and confirmation the block carried and the
   manifest of components the plan needs.
5. Acts on the dispatch: **materialize** (rewrite ``model`` and
   ``output_config.effort``, replace the block with the recipe text), **surface**
   or **reference** (strip the block, forward unchanged), or **cannot_execute**
   (answer the harness with an error and forward nothing).
6. Records :class:`vicaria_contracts.client.EpisodeRecords` for the episode, with what
   was actually forwarded.

Every other path is forwarded as-is.

COUNTED AT THE WIRE MEANS NOT HERE

This proxy keeps a request log, and the conformance driver does not read it to
count provider requests. A commit point's own account of what it forwarded is
the adapter's log; the check is against the provider's. The driver reads the
mock provider's log instead, which is the difference between "the gateway says
it sent nothing" and "nothing arrived".
"""

from __future__ import annotations

import contextlib
import http.client
import json
import ssl
import threading
import uuid
from collections.abc import Callable, Mapping
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from vicaria_contracts.capability import Dimension
from vicaria_contracts.client import (
    Decided,
    Dispatch,
    Episode,
    decide,
    executed,
    no_decision,
    not_executed,
    resolve,
)
from vicaria_contracts.decision import UnavailableReason
from vicaria_contracts.plan import Configuration
from vicaria_contracts.staging import (
    Admission,
    CommitAction,
    CommitRefusal,
    StagedContribution,
    StagingConfirmation,
    contribution_digest,
    reference_or_stop,
)

from smart_gateway.control.config import EFFORT_UNSET, TOOLS_HARNESS, ControlConfig
from smart_gateway.control.marker import (
    MarkerError,
    StagingBlock,
    find_block,
    materialized_text,
    rewrite_block,
    strip_all_blocks,
)
from smart_gateway.control.plans import PlanClient, PlanUnavailable
from smart_gateway.control.records import write_record

HOP_BY_HOP = frozenset(
    {
        "connection",
        "keep-alive",
        "transfer-encoding",
        "te",
        "trailer",
        "upgrade",
        "host",
        "content-length",
        "accept-encoding",
        "proxy-authorization",
        "proxy-connection",
    }
)
PLUGIN = "plugin"


def _session_of(body: Mapping[str, Any]) -> str | None:
    """Claude Code puts its session id in ``metadata.user_id`` as JSON text."""
    raw = (
        (body.get("metadata") or {}).get("user_id")
        if isinstance(body.get("metadata"), dict)
        else None
    )
    if not isinstance(raw, str):
        return None
    try:
        obj = json.loads(raw)
    except json.JSONDecodeError:
        return None
    sid = obj.get("session_id") if isinstance(obj, dict) else None
    return sid if isinstance(sid, str) and sid else None


def _reference_of(control: ControlConfig, body: Mapping[str, Any]) -> Configuration:
    output_config = body.get("output_config") if isinstance(body.get("output_config"), dict) else {}
    effort = output_config.get("effort") if isinstance(output_config, dict) else None
    return control.active_configuration(
        str(body.get("model") or control.default_model),
        effort if isinstance(effort, str) and effort else EFFORT_UNSET,
    )


def _apply_to_body(
    body: dict[str, Any], effective: Configuration, control: ControlConfig
) -> list[str] | None:
    """Rewrite what the commit point applies: model, effort, and the tool set.

    Returns the names of tools removed by narrowing, or ``None`` when the plan
    kept the harness's own tool set. Narrowing is a removal from the request's
    ``tools`` array: a tool the model is not offered is a tool it cannot call,
    on this request and on every later request of the same turn (each carries
    the block, each is narrowed). There is no second line and none is needed.
    """
    body["model"] = effective.model
    if effective.effort != EFFORT_UNSET:
        output_config = body.get("output_config")
        if not isinstance(output_config, dict):
            output_config = {}
            body["output_config"] = output_config
        output_config["effort"] = effective.effort
    elif isinstance(body.get("output_config"), dict):
        body["output_config"].pop("effort", None)
    if effective.tools == TOOLS_HARNESS:
        return None
    allowed = control.narrowed_tools(effective.tools)  # raises for an unmapped profile
    assert allowed is not None
    tools = body.get("tools")
    if not isinstance(tools, list):
        return []
    removed = [
        str(t.get("name")) for t in tools if isinstance(t, dict) and t.get("name") not in allowed
    ]
    body["tools"] = [t for t in tools if isinstance(t, dict) and t.get("name") in allowed]
    return removed


class CommitPoint:
    """The decision half, separate from the HTTP half so it can be tested in-process."""

    def __init__(self, control: ControlConfig, data_dir: Path) -> None:
        self.control = control
        self.data_dir = data_dir
        self.descriptor = control.descriptor()
        self.plans = (
            PlanClient(control.plan_source, control.plan_timeout_s, control.plan_token)
            if control.plan_source
            else None
        )

    def admit(self, config: Configuration) -> Admission:
        return self.control.admission(config)

    def decide_request(self, body: dict[str, Any]) -> tuple[Dispatch, dict[str, Any]]:
        """Resolve one Messages request into a dispatch and a record of how."""
        reference = _reference_of(self.control, body)
        session_id = _session_of(body) or "unknown-session"
        try:
            block, location = find_block(body)
        except MarkerError as exc:
            block, location = None, None
            marker_error: str | None = str(exc)
        else:
            marker_error = None

        note: dict[str, Any] = {"session_id": session_id, "marker_error": marker_error}
        if block is None:
            # No decision reached this request: the component that should have
            # staged one did not. The reference runs, after admission (§4.3).
            episode = Episode(
                episode_id=session_id,
                descriptor=self.descriptor,
                active_config=reference,
                request_revision="unknown-prompt",
            )
            decided = no_decision(
                episode, UnavailableReason.UNREACHABLE, decision_id=f"{session_id}:none"
            )
            note["detail"] = (
                "no staging block on the request; the in-harness component staged nothing"
            )
            dispatch = resolve(decided, admit=self.admit)
            return dispatch, {**note, "location": None, "block": None}

        assigned = None
        if (
            isinstance(block.assignment, dict)
            and block.assignment.get("assignment") == "randomized"
        ):
            assigned = block.assignment.get("config_label")
        episode = Episode(
            episode_id=block.episode_id,
            descriptor=self.descriptor,
            active_config=reference,
            request_revision=block.request_revision,
            assigned_policy=assigned if isinstance(assigned, str) and assigned else None,
        )

        if block.origin == "unavailable":
            try:
                reason = UnavailableReason(block.unavailable_reason or "")
            except ValueError:
                reason = UnavailableReason.REFUSED
            decided = no_decision(episode, reason, decision_id=block.decision_id)
            return resolve(decided, admit=self.admit), {
                **note,
                "location": location,
                "block": block,
            }

        # A served or local decision: re-read the plan the source actually served.
        decided = self._refetch(episode, block, note)
        staged: list[StagedContribution] = []
        confirmation: StagingConfirmation | None = None
        try:
            if block.staged is not None:
                staged.append(StagedContribution.from_dict(block.staged))
            if block.confirmation is not None:
                confirmation = StagingConfirmation.from_dict(block.confirmation)
        except ValueError as exc:
            note["detail"] = f"unreadable contribution: {exc}"
            staged, confirmation = [], None

        expected: list[str] = []
        if decided.plan is not None and decided.plan.effective_config is not None:
            changed = decided.plan.effective_config.changed_from(reference)
            if Dimension.PROMPT in changed:
                expected.append(PLUGIN)
                # The recipe that will be spliced is the plan source's, re-read by
                # decision id — never the block's payload. The block's payload is
                # untrusted transport: it is verified against that recipe here and
                # then ignored. A staged contribution whose digest is not the
                # recipe's is not this plan's contribution, and a payload attached
                # to a plan that changes no prompt is never spliced at all.
                recipe = decided.plan.effective_config.prompt
                text = (note.get("recipes") or {}).get(recipe)
                if not isinstance(text, str) or not text:
                    note["detail"] = f"the plan names recipe {recipe!r} but the source has no text"
                    staged = []  # nothing verifiable was staged → missing contribution
                else:
                    expected_digest = contribution_digest(
                        [Dimension.PROMPT], {"recipe": recipe, "text": text}
                    )
                    if staged and staged[0].digest != expected_digest:
                        note["detail"] = (
                            "the staged contribution's digest is not the plan's recipe: "
                            "the block was tampered with or staged a different text"
                        )
                        staged = []
                    else:
                        note["recipe"] = {"recipe": recipe, "text": text}
        dispatch = resolve(
            decided, staged, confirmation, admit=self.admit, expected_components=expected
        )
        if dispatch.outcome.action is CommitAction.MATERIALIZE:
            # Defence in depth (§4.2.1 turned around): the configuration about to
            # be *materialized* passes the same admission the reference must. The
            # descriptor already omits denied models, so a plan naming one is
            # refused at validation; this catches a re-read plan that differs.
            assert dispatch.config is not None
            admission = self.admit(dispatch.config)
            if not admission.admitted:
                note["detail"] = f"effective configuration inadmissible: {admission.reason}"
                dispatch = Dispatch(
                    decided,
                    reference_or_stop(
                        staged,
                        reference,
                        self.admit,
                        CommitRefusal.PLAN_REFUSED,
                        f"the plan's effective configuration is inadmissible "
                        f"({admission.reason}); the reference runs if it may",
                    ),
                )
        return dispatch, {**note, "location": location, "block": block}

    def _refetch(self, episode: Episode, block: StagingBlock, note: dict[str, Any]) -> Decided:
        if self.plans is None:
            note["detail"] = "no plan source configured; the block's decision cannot be re-read"
            return no_decision(
                episode, UnavailableReason.UNREACHABLE, decision_id=block.decision_id
            )
        try:
            response = self.plans.fetch(block.decision_id)
        except PlanUnavailable as exc:
            note["detail"] = f"plan re-read failed: {exc.detail}"
            return no_decision(episode, exc.reason, decision_id=block.decision_id)
        if response is None:
            note["detail"] = "the plan source served no plan under this decision id"
            return no_decision(episode, UnavailableReason.REFUSED, decision_id=block.decision_id)
        note["recipes"] = response.recipes
        return decide(
            episode,
            response.plan,
            policy_bundle_id=block.assignment.get("policy_bundle_id")
            if isinstance(block.assignment, dict)
            else None,
        )

    def shape_request(
        self, body: dict[str, Any], dispatch: Dispatch, note: Mapping[str, Any]
    ) -> None:
        """Rewrite the body for the dispatch decided. Nothing else is touched."""
        location = note.get("location")
        recipe = note.get("recipe")  # verified against the re-read plan, or absent
        if dispatch.outcome.action is CommitAction.MATERIALIZE:
            assert dispatch.config is not None
            note["narrowed_tools"] = _apply_to_body(body, dispatch.config, self.control)
            if location is not None:
                if recipe is not None:
                    rewrite_block(
                        body, location, materialized_text(recipe["recipe"], recipe["text"])
                    )
                else:
                    rewrite_block(body, location, None)
        elif location is not None:
            rewrite_block(body, location, None)  # a fallback forwards no staged text
        # Whatever the dispatch, no transport marker reaches the provider — not
        # this turn's, and not an earlier turn's kept as conversation history.
        note["stripped_history_blocks"] = strip_all_blocks(body)

    def record(
        self,
        dispatch: Dispatch,
        note: Mapping[str, Any],
        *,
        upstream_status: int | None,
        forwarded: Configuration | None,
    ) -> None:
        if not dispatch.dispatches:
            records = not_executed(dispatch)
        elif upstream_status is not None and 200 <= upstream_status < 300:
            records = executed(dispatch)
        else:
            records = not_executed(dispatch, f"upstream answered {upstream_status}")
        write_record(
            self.data_dir,
            "dispatch",
            {
                "session_id": note.get("session_id"),
                "decision_id": dispatch.decided.decision_id,
                "prompt_id": dispatch.decided.episode.request_revision,
                "action": dispatch.outcome.action.value,
                "detail": note.get("detail"),
                "marker_error": note.get("marker_error"),
                "narrowed_tools": note.get("narrowed_tools"),
                "stripped_history_blocks": note.get("stripped_history_blocks"),
                "upstream_status": upstream_status,
                "forwarded": {"model": forwarded.model, "effort": forwarded.effort}
                if forwarded
                else None,
                "records": records.to_dict(),
            },
        )


_TOKEN_KEYS = (
    "input_tokens",
    "output_tokens",
    "cache_read_input_tokens",
    "cache_creation_input_tokens",
)


def _take_usage(into: dict[str, Any], usage: Any) -> None:
    """Copy every integer token category ``usage`` carries; a later event overrides an earlier."""
    if not isinstance(usage, dict):
        return
    for key in _TOKEN_KEYS:
        value = usage.get(key)
        if isinstance(value, int) and not isinstance(value, bool):
            into[key] = value


def _usage_of(content_type: str, reply: bytes) -> dict[str, Any]:
    """What the provider's own reply says ran, and whether it finished saying it.

    Persisted because RFC 0009 §6 check 7 asks that usage *survive a full run*
    — a number in the harness's ephemeral result is not evidence anyone can
    read back later. Three rules: a category the reply did not carry is absent,
    never 0; the ``reported`` block is the reply's own identity and stop reason
    (RFC 0010 §6.4), never the request's, and is absent when the reply named
    none; and ``completed`` is whether the reply reached its end
    (``message_stop``, or a parsed non-streamed message), because an
    interrupted stream's counts are an observation of what arrived, not a
    bill. ``usage_complete`` says every token category was present. A frame
    that cannot be parsed ends what can be learned, not what was learned:
    everything parsed before it is kept, ``completed`` is false, and
    ``malformed`` says so.
    """
    found: dict[str, Any] = {}
    reported: dict[str, Any] = {}
    completed = False
    malformed = False
    if "text/event-stream" in content_type:
        for line in reply.decode("utf-8", errors="replace").splitlines():
            if not line.startswith("data:"):
                continue
            try:
                event = json.loads(line[5:].strip() or "{}")
            except ValueError:
                malformed = True
                break
            if not isinstance(event, dict):
                continue
            kind = event.get("type")
            if kind == "message_start":
                message = event.get("message") or {}
                if not isinstance(message, dict):
                    continue
                if isinstance(message.get("model"), str):
                    reported["model"] = message["model"]
                if isinstance(message.get("id"), str):
                    reported["message_id"] = message["id"]
                _take_usage(found, message.get("usage"))
            elif kind == "message_delta":
                delta = event.get("delta") or {}
                if isinstance(delta, dict) and isinstance(delta.get("stop_reason"), str):
                    reported["stop_reason"] = delta["stop_reason"]
                _take_usage(found, event.get("usage"))
            elif kind == "message_stop":
                completed = True
    else:
        try:
            obj = json.loads(reply or b"{}")
        except ValueError:
            return {"completed": False, "usage_complete": False, "malformed": True}
        if isinstance(obj, dict) and obj.get("type") != "error":
            if isinstance(obj.get("model"), str):
                reported["model"] = obj["model"]
            if isinstance(obj.get("id"), str):
                reported["message_id"] = obj["id"]
            if isinstance(obj.get("stop_reason"), str):
                reported["stop_reason"] = obj["stop_reason"]
            _take_usage(found, obj.get("usage"))
            completed = "usage" in obj or "model" in obj
    if reported:
        found["reported"] = reported
    if malformed:
        found["malformed"] = True
        completed = False
    found["completed"] = completed
    found["usage_complete"] = all(key in found for key in _TOKEN_KEYS)
    return found


class _Upstream:
    def __init__(self, url: str) -> None:
        parts = urlsplit(url)
        self.scheme = parts.scheme or "https"
        self.host = parts.hostname or "api.anthropic.com"
        self.port = parts.port or (443 if self.scheme == "https" else 80)
        self.prefix = parts.path.rstrip("/")

    def connect(self) -> http.client.HTTPConnection:
        if self.scheme == "https":
            return http.client.HTTPSConnection(
                self.host, self.port, timeout=600, context=ssl.create_default_context()
            )
        return http.client.HTTPConnection(self.host, self.port, timeout=600)


def serve(
    control: ControlConfig, data_dir: Path, *, host: str | None = None, port: int | None = None
) -> ThreadingHTTPServer:
    """Build the HTTP server. The caller starts it (``serve_forever``) or runs it in a thread."""
    point = CommitPoint(control, data_dir)
    upstream = _Upstream(control.upstream)
    lock = threading.Lock()

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"

        def log_message(self, *args: Any) -> None:
            pass

        def _read_body(self) -> bytes:
            length = int(self.headers.get("content-length") or 0)
            raw = self.rfile.read(length) if length else b""
            if self.headers.get("content-encoding", "").lower() == "gzip":
                import gzip

                raw = gzip.decompress(raw)
            return raw

        def _reply(self, status: int, obj: Mapping[str, Any]) -> None:
            data = json.dumps(obj).encode("utf-8")
            self.send_response(status)
            self.send_header("content-type", "application/json")
            self.send_header("content-length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _forward(
            self,
            body: bytes,
            on_status: Callable[[int], None],
            on_complete: Callable[..., None] | None = None,
        ) -> int:
            """Relay one request. ``on_status`` runs once the upstream status is
            known and before any byte of the reply is sent, so what is recorded
            is durable before the harness can see the answer. ``on_complete``
            runs after the last byte with the whole reply, for what can only be
            known at the end — the usage the provider reported. When the
            upstream breaks mid-reply it still runs, with the bytes that
            arrived and ``error`` naming the break, so an interrupted call
            leaves a receipt that says it did not complete rather than none."""
            collected = bytearray()
            conn = upstream.connect()
            headers = {
                k: v
                for k, v in self.headers.items()
                if k.lower() not in HOP_BY_HOP and k.lower() != "content-encoding"
            }
            headers["content-length"] = str(len(body))
            headers["accept-encoding"] = "identity"
            try:
                try:
                    conn.request("POST", upstream.prefix + self.path, body=body, headers=headers)
                    resp = conn.getresponse()
                except OSError as exc:
                    on_status(502)
                    self._reply(
                        502,
                        {
                            "type": "error",
                            "error": {"type": "api_error", "message": f"upstream: {exc}"},
                        },
                    )
                    return 502
                on_status(resp.status)
                self.send_response(resp.status)
                length = resp.getheader("content-length")
                for key, value in resp.getheaders():
                    if key.lower() in HOP_BY_HOP or key.lower() == "content-length":
                        continue
                    self.send_header(key, value)
                error: str | None = None
                try:
                    if length is not None:
                        self.send_header("content-length", length)
                        self.end_headers()
                        remaining = int(length)
                        while remaining > 0:
                            chunk = resp.read(min(65536, remaining))
                            if not chunk:
                                break
                            collected += chunk
                            self.wfile.write(chunk)
                            remaining -= len(chunk)
                        if remaining > 0:
                            error = f"upstream closed with {remaining} byte(s) outstanding"
                    else:
                        self.send_header("transfer-encoding", "chunked")
                        self.end_headers()
                        while True:
                            chunk = resp.read(65536)
                            if not chunk:
                                break
                            collected += chunk
                            self.wfile.write(f"{len(chunk):x}\r\n".encode() + chunk + b"\r\n")
                        self.wfile.write(b"0\r\n\r\n")
                    self.wfile.flush()
                except (http.client.HTTPException, OSError) as exc:
                    # IncompleteRead, a reset, a broken pipe: the reply is cut. What
                    # arrived is still an observation, so the receipt is written with
                    # it, including the bytes http.client had read before the cut
                    # (IncompleteRead.partial: for a chunked reply, whole chunks that
                    # arrived before the broken one); the client connection is closed
                    # so the harness sees the cut rather than waiting on a terminator
                    # that will never come.
                    partial = exc.partial if isinstance(exc, http.client.IncompleteRead) else b""
                    if partial:
                        collected += partial
                        with contextlib.suppress(OSError):
                            if length is not None:
                                self.wfile.write(partial)
                            else:
                                self.wfile.write(
                                    f"{len(partial):x}\r\n".encode() + partial + b"\r\n"
                                )
                    error = f"{type(exc).__name__}: {exc}"
                    self.close_connection = True
                if on_complete is not None:
                    on_complete(
                        resp.status,
                        resp.getheader("content-type") or "",
                        bytes(collected),
                        error=error,
                    )
                return resp.status
            finally:
                conn.close()

        def do_POST(self) -> None:
            raw = self._read_body()
            route = urlsplit(self.path).path.rstrip("/")
            if not route.endswith("/v1/messages"):

                def _record_undecided(status: int) -> None:
                    with lock:
                        write_record(
                            data_dir,
                            "request",
                            {"path": route, "upstream_status": status, "decided": False},
                        )

                self._forward(raw, _record_undecided)
                return
            try:
                body = json.loads(raw)
                if not isinstance(body, dict):
                    raise ValueError("body is not an object")
            except ValueError as exc:
                return self._reply(
                    400,
                    {
                        "type": "error",
                        "error": {"type": "invalid_request_error", "message": str(exc)},
                    },
                )

            dispatch, note = point.decide_request(body)
            if not dispatch.dispatches:
                point.record(dispatch, note, upstream_status=None, forwarded=None)
                return self._reply(
                    403,
                    {
                        "type": "error",
                        "error": {
                            "type": "permission_error",
                            "message": f"vicaria: cannot_execute — {dispatch.outcome.detail}"
                            + (
                                f" ({dispatch.outcome.admission_reason})"
                                if dispatch.outcome.admission_reason
                                else ""
                            ),
                        },
                    },
                )
            point.shape_request(body, dispatch, note)
            forwarded = _reference_of(control, body)
            call_id = uuid.uuid4().hex[:16]

            def _record_decided(status: int) -> None:
                with lock:
                    point.record(dispatch, note, upstream_status=status, forwarded=forwarded)
                    write_record(
                        data_dir,
                        "request",
                        {
                            "path": route,
                            "upstream_status": status,
                            "decided": True,
                            "call_id": call_id,
                            "session_id": note.get("session_id"),
                            "decision_id": dispatch.decided.decision_id,
                            "model": forwarded.model,
                            "effort": forwarded.effort,
                            "tools_offered": sorted(
                                str(t.get("name"))
                                for t in (body.get("tools") or [])
                                if isinstance(t, dict) and t.get("name")
                            ),
                        },
                    )

            def _record_usage(
                status: int, content_type: str, reply: bytes, *, error: str | None = None
            ) -> None:
                usage = _usage_of(content_type, reply)
                if error is not None:
                    usage["completed"] = False
                    usage["upstream_error"] = error
                with lock:
                    write_record(
                        data_dir,
                        "usage",
                        {
                            "call_id": call_id,
                            "session_id": note.get("session_id"),
                            "decision_id": dispatch.decided.decision_id,
                            "prompt_id": dispatch.decided.episode.request_revision,
                            "upstream_status": status,
                            # `model` is the requested model, kept under its old key for
                            # existing readers; `requested_model` and the `reported` block
                            # spread from `usage` are the fact split in two (RFC 0010 §6.4).
                            "model": forwarded.model,
                            "requested_model": forwarded.model,
                            "upstream": control.upstream,
                            **usage,
                        },
                    )

            self._forward(json.dumps(body).encode("utf-8"), _record_decided, _record_usage)

        def do_GET(self) -> None:
            self._reply(
                404, {"type": "error", "error": {"type": "not_found_error", "message": self.path}}
            )

    return ThreadingHTTPServer(
        (host or control.listen_host, control.listen_port if port is None else port), Handler
    )
