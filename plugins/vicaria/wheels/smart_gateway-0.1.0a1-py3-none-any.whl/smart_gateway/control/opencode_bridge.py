"""The contract, spoken to an OpenCode plugin over stdin/stdout.

OpenCode's control boundary is not Claude Code's. There is no separate commit
point on ``ANTHROPIC_BASE_URL``: the plugin runs in-process and *is* the point
of application — ``chat.message`` mutates the parts sent to the model,
``chat.params`` sets the request options, ``tool.execute.before`` denies a
tool. So the two-phase staging protocol collapses to one phase, and what would
be a staging block riding the request is instead a JSON *application* the
plugin performs directly.

Everything upstream of that is :class:`smart_gateway.control.adapter.AdapterCore`,
the same code the Claude Code hook runs — session state, explicit feedback,
prompt features, the assignment, the plan request, ``vicaria_contracts.client.decide`` —
and the dispatch gate is the commit point's own too: the decision goes through
``vicaria_contracts.client.resolve`` with no staged contributions (there is only one
component) but the *same* re-admission of the reference before it is dispatched
(§2.4.2). A reference the organization does not permit stops here rather than
running because nobody could tell us to change it. The descriptor
(``config.descriptor("opencode")``) differs where the harness differs:
``model`` is ``suggest``, because OpenCode picks the model before any hook runs
and exposes no in-process switch. This module is a thin translator: in an
OpenCode event, out an application the JavaScript shim can carry out.

It writes the same ``sg.control.v1`` records as the Claude Code hook, so the
evidence has one shape across harnesses; and it keeps the same privacy line —
prompt text and recipe text, and anything derived from them, never reach a
record or the session state. The previous prompt the similarity feature needs
is the plugin's to hold in memory and send with the next one.

WHY THE RECORD HAS TWO PHASES

The bridge decides; the plugin applies. On a commit-point adapter those are the
same process and one record can state the outcome. Here they are not, so a
single record written at decision time would claim a materialization that the
plugin may never have managed. The bridge therefore writes ``phase: "decided"``,
and the plugin reports back what it actually did (``phase: "applied"``). A
record that says "materialized" is then a record of something that happened.

For the same reason the *decision* about what to do when an application cannot
be carried out belongs here, not in the plugin: only this side knows whether the
reference is admissible. ``on_failure`` carries it — fall back to the reference,
or stop, with the refusal named.

WHEN THIS BRIDGE ITSELF FAILS

The plugin cannot run Python's admission check, but it can hold the answer: every
reply carries ``policy`` (the denied models), and the plugin admits the reference
locally from the last policy it saw when a bridge call times out, crashes, or
answers ``unavailable`` — which is what this side says when it could not load
its configuration and so holds no policy at all. A reply is proof of admission
only when the policy behind it was loaded; a readable JSON envelope is not. With
the policy loaded, an internal error emits a *stop* rather than the reference
when the turn's model is denied — a configuration does not become permissible
because the thing that was supposed to judge it broke.

THE MODEL IS THE HARNESS'S TO REPORT

OpenCode resolves the model that is about to run into the user message before
``chat.message`` fires, and the plugin sends that. A prompt that arrives without
it is stopped: there is no configuration to validate a plan against and nothing
to admit, and a configured default is not a substitute for the truth.

INDUCED FAULTS

``VICARIA_INDUCE`` makes this component misbehave in the ways RFC 0009 §6
check 6 requires the *applying* component to survive. On a single-component
adapter the failure is not "staging succeeded, confirmation failed" — there is
no second component — but the property the check protects is the same, and it
still has teeth: a decision is made, the plugin then cannot apply it faithfully,
and what must not happen is the contribution running against the reference
configuration.

``fail_before_applying`` decides and then says nothing, so the plugin applies
nothing. ``corrupt_application`` returns an application whose recipe carries no
text: the plugin must apply *none* of it — not the recipe, not the effort
beside it — and run the reference. ``contribution_class=neither`` marks that
same application irreversible, and then the plugin may not fall back either: it
must stop, reaching no provider at all. They exist for the conformance driver,
are named in every record they touch, and a deployment never sets the variable.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

from vicaria_contracts.capability import Dimension
from vicaria_contracts.client import Dispatch, Episode, resolve
from vicaria_contracts.plan import summarize
from vicaria_contracts.staging import CommitAction, CommitOutcome, CommitRefusal, reference_or_stop

from smart_gateway.config import ensure_data_dir, resolve_data_dir
from smart_gateway.control.adapter import (
    AdapterCore,
    Decision,
    ident,
    induced,
    log_error,
)
from smart_gateway.control.config import (
    EFFORT_UNSET,
    HARNESSES,
    ControlConfig,
    ControlConfigError,
    load_control,
)
from smart_gateway.control.records import task_id as _task_id
from smart_gateway.control.records import write_record

HARNESS = "opencode"
COMPONENT = HARNESSES[HARNESS].component

#: OpenCode event names → the signal kinds the shape-only recorder understands.
#: The plugin forwards these; the mapping keeps the vocabulary the same as
#: Claude Code's so a mixed-harness corpus joins.
_SIGNAL_EVENTS = {
    "turn_complete": "Stop",
    "session_end": "SessionEnd",
    "tool_failure": "PostToolUseFailure",
    "permission_denied": "PermissionDenied",
    "error": "StopFailure",
    "compaction": "PreCompact",
}

#: The usage fields the plugin forwards from OpenCode's ``step-finish`` part.
_USAGE_FIELDS = (
    "input_tokens",
    "output_tokens",
    "reasoning_tokens",
    "cache_read_tokens",
    "cache_write_tokens",
    "cost",
)


def _emit(obj: dict[str, Any], control: ControlConfig | None) -> None:
    if control is not None:
        obj = {**obj, "policy": _policy(control)}
    sys.stdout.write(json.dumps(obj))
    sys.stdout.flush()


def _read() -> dict[str, Any]:
    try:
        obj = json.loads(sys.stdin.read() or "{}")
    except json.JSONDecodeError:
        return {}
    return obj if isinstance(obj, dict) else {}


def _policy(control: ControlConfig) -> dict[str, Any]:
    """What the plugin needs to admit the reference on its own when this bridge
    cannot answer: the organization's denials, as this deployment holds them."""
    return {"denied_models": sorted(control.denied_models)}


def _reference() -> dict[str, Any]:
    """What the plugin does when there is no decision to apply: nothing."""
    return {
        "action": "reference",
        "apply": _empty_apply(),
        "block": None,
        "message": None,
        "on_failure": {"action": "reference", "reason": None, "refusal": None},
    }


def _empty_apply() -> dict[str, Any]:
    return {"prompt_recipe": None, "effort": None, "allowed_tools": None, "model_suggestion": None}


def _block(reason: str, *, feedback: bool, decision_id: str | None = None) -> dict[str, Any]:
    return {
        "action": "block",
        "apply": _empty_apply(),
        "block": {"reason": reason, "feedback": feedback},
        "message": None,
        "on_failure": {"action": "stop", "reason": None, "refusal": None},
        "decision_id": decision_id,
    }


# --- events ---------------------------------------------------------------------------


def _session_start(core: AdapterCore, payload: dict[str, Any]) -> None:
    session_id = ident(payload.get("session_id"))
    if session_id:
        core.session_start(
            session_id,
            model=ident(payload.get("model")),
            effort=ident(payload.get("effort")),
            source=ident(payload.get("source")) or "opencode",
            parent_session_id=ident(payload.get("parent_session_id")),
        )
    _emit(_reference(), core.control)


def _chat_message(core: AdapterCore, payload: dict[str, Any]) -> None:
    session_id = ident(payload.get("session_id"))
    prompt_id = ident(payload.get("prompt_id"))
    prompt = payload.get("prompt")
    if not session_id or not prompt_id or not isinstance(prompt, str):
        _emit(_reference(), core.control)
        return

    feedback = core.explicit_feedback(session_id, prompt)
    if feedback is not None:
        mark = "up" if feedback.to_record().get("score", 0) > 0 else "down"
        _emit(
            _block(f"Vicaria: feedback recorded ({mark}). No tokens spent.", feedback=True),
            core.control,
        )
        return

    # The model about to run is the harness's to report (OpenCode resolves it
    # into the message before this hook fires). Without it nothing can be
    # admitted — and a configured default is not a substitute for the truth.
    model = ident(payload.get("model"))
    if not model:
        _unknown_model(core, session_id, prompt_id)
        return

    # The previous prompt, for the similarity feature, is the plugin's to
    # remember in memory; it is compared here and dropped, never persisted.
    previous = payload.get("previous_prompt")
    observed = core.observe_prompt(
        session_id,
        prompt_id,
        prompt,
        previous_prompt=previous if isinstance(previous, str) and previous else None,
    )
    decision = core.decide(session_id, prompt_id, prompt, observed, model=model)
    induce = induced()
    application, dispatch = _apply_of(core, decision, induce)
    _record_dispatch(core, session_id, prompt_id, decision, application, observed, induce, dispatch)
    core.remember(session_id, observed, prompt, prompt_id)
    if "fail_before_applying" in induce:
        # Decided, recorded, and then silent: the plugin must apply nothing.
        return
    _emit(application, core.control)


_UNKNOWN_MODEL = (
    "the harness did not report the model about to run; no configuration can be admitted"
)


def _unknown_model(core: AdapterCore, session_id: str, prompt_id: str) -> None:
    """Stop, and record why: identity unknown is not a configuration, so there
    is nothing to validate a plan against and nothing to admit."""
    outcome = CommitOutcome(
        action=CommitAction.CANNOT_EXECUTE,
        refusal=CommitRefusal.NOT_APPLICABLE,
        detail=_UNKNOWN_MODEL,
    )
    decision_id = f"{session_id}:{prompt_id}"
    write_record(
        core.data_dir,
        "dispatch",
        {
            "session_id": session_id,
            "prompt_id": prompt_id,
            "decision_id": decision_id,
            "component": COMPONENT,
            "phase": "decided",
            "origin": None,
            "action": "block",
            "task_id": _task_id(),
            "commit": outcome.to_dict(),
        },
    )
    _emit(
        _block(
            f"Vicaria: cannot_execute — {_UNKNOWN_MODEL}", feedback=False, decision_id=decision_id
        ),
        core.control,
    )


def _apply_of(
    core: AdapterCore, decision: Decision, induce: frozenset[str] = frozenset()
) -> tuple[dict[str, Any], Dispatch]:
    """The application the plugin should perform, decided through the shared gate.

    ``resolve`` is the commit point's own function. This adapter stages nothing
    (one component), so the staging gate is a no-op — but the reference still
    passes admission before it is dispatched, and a plan that stops still stops.
    """
    control, decided, episode, response = (
        core.control,
        decision.decided,
        decision.episode,
        decision.response,
    )
    dispatch = resolve(decided, admit=core.admit)
    apply = _empty_apply()
    changed: frozenset[Dimension] = frozenset()

    if dispatch.outcome.action is CommitAction.MATERIALIZE:
        effective = dispatch.config
        assert effective is not None
        changed = effective.changed_from(episode.active_config)
        if Dimension.PROMPT in changed:
            recipe = effective.prompt
            text = (response.recipes.get(recipe) if response else None) or ""
            if not text:
                raise ValueError(f"plan names recipe {recipe!r} but the source supplied no text")
            apply["prompt_recipe"] = {"recipe": recipe, "text": text}
        if Dimension.EFFORT in changed and effective.effort != EFFORT_UNSET:
            apply["effort"] = effective.effort
        if Dimension.TOOLS in changed:
            try:
                narrowed = control.narrowed_tools(effective.tools)
            except ControlConfigError as exc:
                # A profile this deployment cannot enforce. The descriptor no
                # longer offers one, so a validated plan should never name it;
                # if one does, the plan is not applicable here, and "not
                # applicable" is decided like every other failure to apply:
                # the reference after admission, or a stop. Never a silent
                # allow-all under a record that says the tools were narrowed.
                dispatch = Dispatch(
                    decided,
                    reference_or_stop(
                        [],
                        episode.active_config,
                        core.admit,
                        CommitRefusal.NOT_APPLICABLE,
                        f"{exc}; nothing applied",
                    ),
                )
                apply = _empty_apply()
                changed = frozenset()
            else:
                apply["allowed_tools"] = sorted(narrowed) if narrowed is not None else None
        if "corrupt_application" in induce and apply["prompt_recipe"]:
            # An application the plugin cannot carry out faithfully.
            apply["prompt_recipe"] = {"recipe": apply["prompt_recipe"]["recipe"], "text": ""}

    action = dispatch.outcome.action
    if action is CommitAction.CANNOT_EXECUTE:
        detail = dispatch.outcome.detail or "the plan cannot be executed"
        reason = dispatch.outcome.admission_reason
        return (
            _block(
                f"Vicaria: cannot_execute — {detail}" + (f" ({reason})" if reason else ""),
                feedback=False,
                decision_id=decided.decision_id,
            ),
            dispatch,
        )

    if action is CommitAction.SURFACE:
        proposal = dispatch.surfaced
        assert proposal is not None
        proposed = proposal.changed_from(episode.active_config)
        changes = ", ".join(
            f"{d.value}: {episode.active_config.value(d)} → {proposal.value(d)}"
            for d in sorted(proposed, key=lambda d: d.value)
        )
        return (
            {
                "action": "surface",
                "apply": {
                    **_empty_apply(),
                    "model_suggestion": proposal.model if Dimension.MODEL in proposed else None,
                },
                "block": None,
                "message": f"Vicaria recommends {changes} (not applied).",
                "on_failure": {"action": "reference", "reason": None, "refusal": None},
                "decision_id": decided.decision_id,
            },
            dispatch,
        )

    if action is CommitAction.MATERIALIZE and changed:
        return (
            {
                "action": "materialize",
                "apply": apply,
                "block": None,
                "message": None,
                "on_failure": _on_failure(
                    core, episode, irreversible="contribution_class=neither" in induce
                ),
                "decision_id": decided.decision_id,
            },
            dispatch,
        )
    return {**_reference(), "decision_id": decided.decision_id}, dispatch


def _on_failure(core: AdapterCore, episode: Episode, *, irreversible: bool) -> dict[str, Any]:
    """What the plugin must do if it cannot carry the application out.

    The plugin cannot decide this: falling back means dispatching the reference,
    and whether the reference may be dispatched is an admission question this
    side owns (RFC 0009 §2.4.2). A reference the organization denies does not
    become permissible because the thing meant to replace it failed.
    """
    if irreversible:
        return {
            "action": "stop",
            "reason": "the contribution can be neither staged nor restored",
            "refusal": "unstageable_contribution",
        }
    admission = core.admit(episode.active_config)
    if not admission.admitted:
        return {
            "action": "stop",
            "reason": admission.reason,
            "refusal": "reference_inadmissible",
        }
    return {"action": "reference", "reason": None, "refusal": None}


def _record_dispatch(
    core: AdapterCore,
    session_id: str,
    prompt_id: str,
    decision: Decision,
    application: dict[str, Any],
    observed: Any,
    induce: frozenset[str],
    dispatch: Dispatch,
) -> None:
    decided = decision.decided
    plan = decided.plan
    apply = application.get("apply") or {}
    write_record(
        core.data_dir,
        "dispatch",
        {
            "session_id": session_id,
            "prompt_id": prompt_id,
            "decision_id": decision.decision_id,
            "component": COMPONENT,
            "phase": "decided",
            "origin": decided.origin.value,
            "action": application["action"],
            "disposition": plan.disposition.value if plan else None,
            "applied": {
                "recipe": (apply.get("prompt_recipe") or {}).get("recipe"),
                "effort": apply.get("effort"),
                "narrowed_tools": bool(apply.get("allowed_tools")),
                "model_suggestion": apply.get("model_suggestion"),
            },
            "unavailable_reason": (
                decided.unavailable_reason.value if decided.unavailable_reason else None
            ),
            "prompt_features": observed.features.to_record(),
            "task_id": _task_id(),
            "induced": sorted(induce),
            "validation": summarize(decided.validation) if decided.validation else None,
            "commit": dispatch.outcome.to_dict(),
        },
    )


def _applied(core: AdapterCore, payload: dict[str, Any]) -> None:
    """What the plugin actually did. Written as its own record, because a
    decision is not an outcome (see the module docstring)."""
    outcome = ident(payload.get("outcome")) or "unknown"
    refusal = ident(payload.get("refusal"))
    reason = ident(payload.get("reason"))
    write_record(
        core.data_dir,
        "dispatch",
        {
            "session_id": ident(payload.get("session_id")),
            "prompt_id": ident(payload.get("prompt_id")),
            "decision_id": ident(payload.get("decision_id")),
            "component": COMPONENT,
            "phase": "applied",
            "action": outcome,
            "task_id": _task_id(),
            "commit": {"refusal": refusal, "detail": reason} if refusal else None,
        },
    )
    _emit(_reference(), core.control)


def _usage(core: AdapterCore, payload: dict[str, Any]) -> None:
    """A model step's cost, as OpenCode reports it to the plugin (``step-finish``).

    Joined to the session's last prompt, which is the one that was running.
    """
    session_id = ident(payload.get("session_id"))
    if session_id:
        fields = {
            k: (payload.get(k) if isinstance(payload.get(k), int | float) else None)
            for k in _USAGE_FIELDS
        }
        fields["message_id"] = ident(payload.get("message_id"))
        core.usage(session_id, prompt_id=None, fields=fields)
    _emit(_reference(), core.control)


def _signal(core: AdapterCore, payload: dict[str, Any]) -> None:
    name = payload.get("name")
    event = _SIGNAL_EVENTS.get(name if isinstance(name, str) else "")
    if event is not None:
        core.signal(event, payload)
    _emit(_reference(), core.control)


def _unavailable(reason: str) -> dict[str, Any]:
    """This bridge could not load its configuration, so it holds no policy and
    has admitted nothing. Not a reference: the plugin must judge locally, from
    the last policy it was given, exactly as it does when no reply comes."""
    return {
        "action": "unavailable",
        "reason": reason,
        "apply": _empty_apply(),
        "block": None,
        "message": None,
        "on_failure": {"action": "stop", "reason": reason, "refusal": None},
    }


def _failed_open(control: ControlConfig, event: str, payload: dict[str, Any]) -> dict[str, Any]:
    """The application when this bridge failed mid-event, with its policy loaded.

    For a prompt, failing open means the reference runs — which is a dispatch,
    and every dispatch passes admission (RFC 0009 §2.4.2): the turn's model is
    admitted here, and an unknown model admits nothing.
    """
    if event != "chat.message":
        return _reference()
    model = ident(payload.get("model"))
    if not model:
        return _block(f"Vicaria: cannot_execute — {_UNKNOWN_MODEL}", feedback=False)
    admission = control.admission(control.active_configuration(model, control.default_effort))
    if admission.admitted:
        return _reference()
    return {
        **_block(
            f"Vicaria: cannot_execute — the adapter failed and the reference is inadmissible "
            f"({admission.reason})",
            feedback=False,
        ),
        "on_failure": {
            "action": "stop",
            "reason": admission.reason,
            "refusal": "reference_inadmissible",
        },
    }


def main(argv: list[str] | None = None) -> int:
    # The event first: whatever fails next, the reply must know what was asked.
    payload = _read()
    event = ident(payload.get("event")) or "unknown"
    data_dir: Path | None = None
    try:
        data_dir = ensure_data_dir(resolve_data_dir())
        control = load_control(data_dir)
    except Exception as exc:  # no policy loaded: admitted nothing, and says so
        if data_dir is not None:
            log_error(data_dir, event, exc)
        _emit(_unavailable(f"{type(exc).__name__}: {exc}"), None)
        return 0
    try:
        core = AdapterCore(data_dir, control, harness=HARNESS)
        if event == "session_start":
            _session_start(core, payload)
        elif event == "chat.message":
            _chat_message(core, payload)
        elif event == "applied":
            _applied(core, payload)
        elif event == "usage":
            _usage(core, payload)
        elif event == "signal":
            _signal(core, payload)
        else:
            _emit(_reference(), control)  # includes "policy": what the plugin caches
    except Exception as exc:  # fail open — through admission, never around it
        log_error(data_dir, event, exc)
        _emit(_failed_open(control, event, payload), control)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
