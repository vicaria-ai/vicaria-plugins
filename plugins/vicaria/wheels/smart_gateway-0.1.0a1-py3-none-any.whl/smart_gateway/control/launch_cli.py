"""Register the optional benchmark launcher without importing its implementation."""

from __future__ import annotations

import argparse
import importlib
import sys

from smart_gateway.control.config import EFFORT_UNSET
from smart_gateway.control.config import HARNESSES as REGISTERED_HARNESSES

HARNESSES = tuple(sorted(REGISTERED_HARNESSES))


def cmd_control_launch(args: argparse.Namespace) -> int:
    try:
        implementation = importlib.import_module("gateway_bench.launch")
    except ModuleNotFoundError as exc:
        if exc.name not in {"gateway_bench", "gateway_bench.launch"}:
            raise
        print(
            "sg control launch requires smart-gateway-bench; install it to run benchmarks.",
            file=sys.stderr,
        )
        return 1
    return implementation.cmd_control_launch(args)


def add_launch_parser(sub: argparse._SubParsersAction) -> None:
    q = sub.add_parser(
        "launch",
        help="run a harness with control attached (a benchmark's agent step)",
        description=(
            "Attach the control adapter and run the harness command. Everything after "
            "`--` is the command. Example: sg control launch --harness claude-code "
            "--task-id t1 -- claude -p 'fix it' --plugin-dir ./plugin-control"
        ),
    )
    q.add_argument("--harness", choices=HARNESSES, required=True)
    q.add_argument("--data-dir", help="records and state go here (default: $SG_DATA_DIR)")
    q.add_argument("--control", metavar="FILE", help="a control.json to install first")
    q.add_argument("--plan-source", help="recommendation service URL (absent: reference only)")
    q.add_argument("--upstream", default="https://api.anthropic.com", help="claude-code only")
    q.add_argument("--model", help="the model the harness runs (control.json default_model)")
    q.add_argument("--effort", default=EFFORT_UNSET)
    q.add_argument("--harness-version", default="unknown")
    q.add_argument("--task-id", help="benchmark task id (default: $VICARIA_TASK_ID)")
    q.add_argument("--port", type=int, help="commit point port (claude-code; default 8790)")
    q.add_argument("command", nargs=argparse.REMAINDER, help="the harness command, after --")
    q.set_defaults(func=cmd_control_launch)
