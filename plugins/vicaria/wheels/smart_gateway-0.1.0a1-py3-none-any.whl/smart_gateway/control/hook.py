"""The in-harness component: ``python3 -m smart_gateway.control.hook <Event>``.

The harness-neutral half of every event — session state, explicit feedback,
prompt features, the assignment, the plan request, ``vicaria_contracts.client.decide`` —
is :class:`smart_gateway.control.adapter.AdapterCore`. This module is the Claude
Code translator around it: what each hook event carries in, and the one thing
this harness's application point needs out — a staging block for the commit
point on ``ANTHROPIC_BASE_URL``.

What it does on each event, and the contract each step keeps:

``SessionStart``
    Remembers what the session is running — the model Claude Code reports, or
    ``ANTHROPIC_MODEL``, or the configured default; the effort from
    ``CLAUDE_CODE_EFFORT_LEVEL`` or the configured default. This is the
    package's belief about the active configuration, and the commit point
    verifies it against the request it actually receives (RFC 0009 §4.1).

``UserPromptSubmit``
    1. If the prompt is explicit feedback (``/vicaria-control:feedback up``),
       record it against the previous prompt and block the prompt: feedback
       costs no tokens and the model never sees it.
    2. Compute the prompt's features and mint the assignment for this episode
       (:mod:`smart_gateway.randomize`), deterministic per session.
    3. Ask the plan source for a plan, sending the descriptor, the active
       configuration, the assignment, and — only under the capture policy —
       the prompt itself. No plan is a typed outcome
       (:func:`vicaria_contracts.client.no_decision`), never a fabricated one.
    4. :func:`vicaria_contracts.client.decide`. A ``cannot_execute`` plan **blocks the
       prompt**: zero provider requests, reached from inside the harness.
    5. Otherwise emit ``additionalContext`` carrying a
       :class:`~smart_gateway.control.marker.StagingBlock` — the decision, and
       where the plan changes the prompt, the staged recipe text and its
       confirmation. A suggestion also carries a ``systemMessage`` so the user
       sees it. Nothing is applied: the commit point decides.

``PostToolUseFailure``, ``PermissionDenied``, ``Stop``, ``StopFailure``,
``PreCompact``, ``SessionEnd``, ``SubagentStart``, ``SubagentStop``
    Signals, recorded by shape. The subagent pair is the parent/child boundary
    RFC 0009 §6 check 7 asks for.

Tools are not narrowed here. The commit point removes from the request's
``tools`` array everything the plan's profile does not allow, and a tool the
model is never offered is a tool it cannot call — there is no second line to
hold, so no ``PreToolUse`` hook and no subprocess per tool call.

INDUCED FAULTS

``VICARIA_INDUCE`` makes this component misbehave in the exact ways RFC 0009 §6
check 6 requires the commit point to survive: ``fail_before_staging`` exits
without staging; ``corrupt_confirmation`` stages with a confirmation naming
another plan; ``contribution_class=neither`` declares its contribution
irreversible. They exist for the conformance driver and are named in every
record they touch; a deployment never sets the variable.

FAILING OPEN, VISIBLY

Any internal error is logged to ``raw/control_errors.log`` and the hook exits 0
with **no output**: the prompt proceeds, the request reaches the commit point
without a block, and the commit point dispatches the reference after admission
and records that no decision arrived. That is the behaviour §2.4 of the control
plane design accepts for hook transport failures — permitted to let execution
continue — made legible rather than silent.

PRIVACY

Prompt text reaches no record and no session state, and neither does anything
derived from it: the similarity feature reads the previous prompt from Claude
Code's own transcript at the moment it is needed and keeps nothing, and the
plan request carries the text only when the capture policy says so (opt-in).
"""

from __future__ import annotations

import json
import os
import sys
from typing import Any

from vicaria_contracts.capability import Dimension
from vicaria_contracts.plan import Disposition, summarize
from vicaria_contracts.staging import (
    ContributionClass,
    StagedContribution,
    StagingConfirmation,
    contribution_digest,
)

from smart_gateway.config import ensure_data_dir, resolve_data_dir
from smart_gateway.control.adapter import (
    AdapterCore,
    Decision,
    advisor_sentence,
    ident,
    induced,
    log_error,
)
from smart_gateway.control.config import HARNESSES, load_control
from smart_gateway.control.marker import StagingBlock
from smart_gateway.control.records import task_id as _task_id
from smart_gateway.control.records import write_record

HARNESS = "claude-code"
COMPONENT = HARNESSES[HARNESS].component
STDIN_LIMIT = 1 << 20


def _emit(obj: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(obj))
    sys.stdout.flush()


# --- SessionStart -------------------------------------------------------------


def _session_start(core: AdapterCore, payload: dict[str, Any]) -> None:
    session_id = ident(payload.get("session_id"))
    if not session_id:
        return
    core.session_start(
        session_id,
        model=ident(payload.get("model")) or ident(os.environ.get("ANTHROPIC_MODEL")),
        effort=ident(os.environ.get("CLAUDE_CODE_EFFORT_LEVEL")),
        source=ident(payload.get("source")),
    )


# --- UserPromptSubmit ---------------------------------------------------------


def _stage(
    decision: Decision, induce: frozenset[str]
) -> tuple[StagedContribution | None, StagingConfirmation | None, dict[str, Any] | None]:
    """The plugin's contribution, staged. ``None`` triple when it contributes nothing."""
    decided, response = decision.decided, decision.response
    plan = decided.plan
    if plan is None or not decided.proceeds or plan.disposition is not Disposition.APPLY:
        return None, None, None
    assert plan.effective_config is not None
    changed = plan.effective_config.changed_from(decided.episode.active_config)
    if Dimension.PROMPT not in changed:
        return None, None, None
    recipe = plan.effective_config.prompt
    text = (response.recipes.get(recipe) if response else None) or ""
    if not text:
        # The plan names a recipe the source did not supply. Staging an empty
        # contribution would materialize nothing while confirming something.
        raise ValueError(f"plan names recipe {recipe!r} but the plan source supplied no text")
    payload = {"recipe": recipe, "text": text}
    digest = contribution_digest([Dimension.PROMPT], payload)
    cls = ContributionClass.STAGEABLE
    restore: bool | None = None
    if "contribution_class=neither" in induce:
        cls = ContributionClass.NEITHER
    staged = StagedContribution(
        component=COMPONENT,
        dimensions=frozenset({Dimension.PROMPT}),
        contribution_class=cls,
        digest=digest,
        restore_confirmed=restore,
    )
    confirmation = StagingConfirmation(
        component=COMPONENT,
        decision_id="dec-corrupt" if "corrupt_confirmation" in induce else plan.decision_id,
        base_config_digest=plan.base_config_digest,
        contribution_digest=digest,
    )
    return staged, confirmation, payload


#: How much of the transcript's tail is read for the previous prompt. Prompts
#: are small and recent; tool output between them can be large. Reading the
#: whole file every prompt would grow with the session, and this runs in the
#: hook's own time budget.
_TRANSCRIPT_TAIL = 4 << 20


def _previous_prompt(payload: dict[str, Any]) -> str | None:
    """The user's previous prompt, from the transcript Claude Code names in the
    hook input. That file is Claude Code's own record of the conversation and
    already holds every prompt; reading it adds no disclosure, and it means this
    package never has to keep a prompt, or anything derived from one, itself.

    At ``UserPromptSubmit`` the transcript does not yet contain the prompt being
    submitted (verified against 2.1.269), so its last prompt entry is the
    previous one. A prompt entry is a ``type: "user"`` line on the main chain
    whose message content is a string, or text blocks only — tool results are
    ``user`` lines too, with ``tool_result`` blocks, and are not prompts. Read
    from the tail, newest line first, and only as far as the last prompt.
    """
    path = payload.get("transcript_path")
    if not isinstance(path, str) or not path:
        return None
    try:
        with open(path, "rb") as fh:
            fh.seek(0, os.SEEK_END)
            size = fh.tell()
            fh.seek(max(0, size - _TRANSCRIPT_TAIL))
            tail = fh.read()
    except OSError:
        return None
    lines = tail.split(b"\n")
    if size > _TRANSCRIPT_TAIL:
        lines = lines[1:]  # the first piece is a partial line
    for raw in reversed(lines):
        if b'"type":"user"' not in raw and b'"type": "user"' not in raw:
            continue
        try:
            entry = json.loads(raw)
        except (json.JSONDecodeError, UnicodeDecodeError):
            continue
        if not isinstance(entry, dict) or entry.get("type") != "user" or entry.get("isSidechain"):
            continue
        content = (entry.get("message") or {}).get("content")
        if isinstance(content, str):
            text = content
        elif isinstance(content, list) and content:
            if any(isinstance(b, dict) and b.get("type") != "text" for b in content):
                continue  # a tool result, not a prompt
            text = " ".join(b.get("text", "") for b in content if isinstance(b, dict)).strip()
        else:
            continue
        if text:
            return text[:4000]
    return None


def _block(reason: str) -> dict[str, Any]:
    return {
        "decision": "block",
        "reason": reason,
        "hookSpecificOutput": {"hookEventName": "UserPromptSubmit"},
    }


def _user_prompt_submit(core: AdapterCore, payload: dict[str, Any]) -> None:
    session_id = ident(payload.get("session_id"))
    prompt_id = ident(payload.get("prompt_id"))
    prompt = payload.get("prompt")
    if not session_id or not prompt_id or not isinstance(prompt, str):
        return
    induce = induced()

    # 1. Explicit feedback never reaches the model.
    feedback = core.explicit_feedback(session_id, prompt)
    if feedback is not None:
        mark = "👍" if feedback.to_record().get("score", 0) > 0 else "👎"
        _emit(_block(f"Vicaria: feedback recorded ({mark})."))
        return

    # 2. Features and the turn count. The previous prompt for the similarity
    #    feature comes from Claude Code's own transcript, read now and dropped.
    observed = core.observe_prompt(
        session_id, prompt_id, prompt, previous_prompt=_previous_prompt(payload)
    )

    if "fail_before_staging" in induce:
        # The component died before it could stage — the gateway must see a
        # request with no block and run the reference.
        write_record(
            core.data_dir,
            "stage",
            {
                "session_id": session_id,
                "prompt_id": prompt_id,
                "induced": sorted(induce),
                "staged": None,
            },
        )
        core.remember(session_id, observed, prompt, prompt_id)
        return

    # 3. Assign and ask, 4. decide.
    decision = core.decide(session_id, prompt_id, prompt, observed)
    decided, episode = decision.decided, decision.episode

    if decided.validation is not None and decided.validation.stop:
        write_record(
            core.data_dir,
            "stage",
            {
                "session_id": session_id,
                "prompt_id": prompt_id,
                "decision_id": decision.decision_id,
                "origin": decided.origin.value,
                "validation": summarize(decided.validation),
                "blocked": True,
            },
        )
        core.remember(session_id, observed, prompt, prompt_id)
        _emit(_block(f"Vicaria: cannot_execute — {decided.validation.detail}"))
        return

    # 5. Stage and hand the decision to the commit point.
    staged, confirmation, staged_payload = _stage(decision, induce)
    block = StagingBlock(
        decision_id=decision.decision_id,
        episode_id=session_id,
        request_revision=prompt_id,
        origin=decided.origin.value,
        unavailable_reason=decided.unavailable_reason.value if decided.unavailable_reason else None,
        staged=staged.to_dict() if staged else None,
        confirmation=confirmation.to_dict() if confirmation else None,
        payload=staged_payload,
        assignment=decision.assignment.to_json(),
        validation=summarize(decided.validation) if decided.validation else None,
    )
    output: dict[str, Any] = {
        "hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": block.encode(),
        }
    }
    plan = decided.plan
    if plan is not None and decided.proceeds and plan.disposition is Disposition.SUGGEST:
        assert plan.effective_config is not None
        changes = ", ".join(
            f"{d.value}: {episode.active_config.value(d)} → {plan.effective_config.value(d)}"
            for d in sorted(
                plan.effective_config.changed_from(episode.active_config), key=lambda d: d.value
            )
        )
        why = advisor_sentence(plan.reason)
        output["systemMessage"] = f"Vicaria recommends {changes} (not applied)." + (
            f" {why}" if why else ""
        )
    write_record(
        core.data_dir,
        "stage",
        {
            "session_id": session_id,
            "prompt_id": prompt_id,
            "decision_id": decision.decision_id,
            "origin": decided.origin.value,
            "unavailable_reason": block.unavailable_reason,
            "validation": block.validation,
            "disposition": plan.disposition.value if plan else None,
            "staged": staged.to_dict() if staged else None,
            "recipe": staged_payload["recipe"] if staged_payload else None,
            "surfaced": "systemMessage" in output,
            "induced": sorted(induce),
            "assigned_policy": episode.assigned_policy,
            "prompt_features": observed.features.to_record(),
            "task_id": _task_id(),
        },
    )
    core.remember(session_id, observed, prompt, prompt_id)
    _emit(output)


# --- entry ------------------------------------------------------------------------


def _read_payload() -> dict[str, Any]:
    raw = sys.stdin.buffer.read(STDIN_LIMIT) if not sys.stdin.isatty() else b""
    try:
        obj = json.loads(raw) if raw else {}
    except json.JSONDecodeError:
        obj = {}
    return obj if isinstance(obj, dict) else {}


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    data_dir = None
    event = argv[0] if argv else "unknown"
    try:
        data_dir = ensure_data_dir(resolve_data_dir())
        core = AdapterCore(data_dir, load_control(data_dir), harness=HARNESS)
        payload = _read_payload()
        event = ident(payload.get("hook_event_name")) or event
        if event == "SessionStart":
            _session_start(core, payload)
        elif event == "UserPromptSubmit":
            _user_prompt_submit(core, payload)
        else:
            core.signal(event, payload)
    except Exception as exc:  # fail open, visibly: no output, the reference runs
        if data_dir is not None:
            log_error(data_dir, event, exc)
    return 0


if __name__ == "__main__":
    sys.exit(main())
