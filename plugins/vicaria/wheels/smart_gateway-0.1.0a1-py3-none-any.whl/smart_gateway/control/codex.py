"""Codex: the plan for a prompt, shown and never applied.

The Vicaria plugin for Codex asks at ``UserPromptSubmit``
(:func:`smart_gateway.capture.codex_plugin.advice`). With a control
configuration (``$SG_DATA_DIR/control.json`` naming a plan source), it asks
about the prompt through the same :class:`AdapterCore` every harness uses, and
the hook shows what the plan recommends. A plugin hook cannot change the model
or effort a Codex turn runs on, so model and effort are ``suggest`` here
(:data:`config.SUGGEST_ONLY_HARNESSES`): an ``apply`` plan is served as a
suggestion by the service, and a suggestion is all the developer is shown.

The plugin supplies the active configuration: the hook's model, and the effort
the turn's own ``turn_context`` names, or the effort meaning none (``default``)
with the reason it is not recorded, as ``effort_source`` (smart-gateway#96).
Only a direct caller that names neither falls back to Codex's ``config.toml``
(``model``, ``model_reasoning_effort``), then the control configuration's
defaults, each labelled ``configured_default``. The prompt id is Codex's turn
id, the one the captured prompt's event id is derived from, so a materialized
Codex turn joins its decision the way Claude Code's and OpenCode's do.

Nothing here can fail a run: no configuration, no plan source, or any error on
the way means no advice, and the error is written where ``sg doctor`` reads it.
"""

from __future__ import annotations

import os
import time
import tomllib
import uuid
from collections.abc import Mapping
from pathlib import Path

from smart_gateway.config import ensure_data_dir, resolve_data_dir
from smart_gateway.control import recommendations, running
from smart_gateway.control.adapter import (
    ident,
    log_error,
    reading,
)
from smart_gateway.control.config import (
    EFFORT_UNSET,
    ControlConfigError,
    load_control,
)
from smart_gateway.control.plans import PlanClient
from smart_gateway.control.recommendations import Advice
from smart_gateway.control.recommendations import device_control as _device_control
from smart_gateway.control.records import envelope, write_record

HARNESS = "codex"


def codex_configuration(environ: Mapping[str, str] | None = None) -> tuple[str | None, str | None]:
    """The model and reasoning effort Codex's ``config.toml`` names, where it names them."""
    env = os.environ if environ is None else environ
    home = Path(env.get("CODEX_HOME") or Path(env.get("HOME", "~")) / ".codex").expanduser()
    try:
        with open(home / "config.toml", "rb") as fh:
            doc = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError):
        return None, None
    return ident(doc.get("model")), ident(doc.get("model_reasoning_effort"))


def advise(
    session_id: str,
    prompt: str,
    *,
    prompt_id: str | None = None,
    environ: Mapping[str, str] | None = None,
    device: Mapping[str, str] | None = None,
    model: str | None = None,
    effort: str | None = None,
    model_source: str | None = None,
    effort_source: str | None = None,
    harness_version: str | None = None,
    budget_s: float = 5.0,
) -> Advice:
    """Ask the plan source about one prompt, when one is configured.

    ``prompt_id`` is the harness's own id for the prompt (Codex's turn id);
    one is minted when there is none.
    """
    prompt_id = prompt_id or uuid.uuid4().hex
    # Read before anything is created: a machine with no control configuration
    # gets no advice and no new directory.
    configured_model, configured_effort = codex_configuration(environ)
    # Where each was learnt (``running``), before a missing one is filled in:
    # the plugin says (the hook, the turn's own record, or why there is none);
    # a direct caller that names neither gets config.toml's, as a belief.
    if effort_source is not None and not reading(effort):
        # The plugin's path: it names where the effort came from, or why there
        # is none. A value the contract refuses, or a blank one, is no reading,
        # never config.toml's under the plugin's label; config.toml stays a
        # direct caller's fallback alone (smart-gateway#100 review).
        effort, effort_source = EFFORT_UNSET, "not_found"
    model_source = model_source or (running.HARNESS if ident(model) else running.CONFIGURED_DEFAULT)
    effort_source = effort_source or (
        running.HARNESS if reading(effort) else running.CONFIGURED_DEFAULT
    )
    model, effort = ident(model) or configured_model, reading(effort) or configured_effort
    return recommendations.advise(
        session_id,
        prompt,
        prompt_id=prompt_id,
        environ=environ,
        device=device,
        model=model,
        effort=effort,
        model_source=model_source,
        effort_source=effort_source,
        harness_version=harness_version,
        budget_s=budget_s,
    )


__all__ = ["HARNESS", "Advice", "advise", "codex_configuration"]


#: How long the end-of-turn report may wait on the service: a turn has ended,
#: and Codex waits on its ``Stop`` hook.
REPORT_TIMEOUT_S = 3.0


def observe(
    session_id: str,
    turn_id: str,
    *,
    model: str | None,
    effort: str | None,
    effort_unrecorded: str | None,
    from_turn_record: bool,
    harness_version: str | None = None,
    environ: Mapping[str, str] | None = None,
    device: Mapping[str, str] | None = None,
    budget_s: float = REPORT_TIMEOUT_S,
) -> bool:
    """Record, and tell the plan source, what a Codex turn ran (smart-gateway#95).

    Codex's ``Stop`` hook names the model and never the effort; the turn's own
    ``turn_context`` names both, as the turn started (a change partway through
    a turn is in no record). The report is the stage record Claude Code sends
    at the end of a turn (``hook._observed``), ``phase: observed``, for the
    decision this turn's prompt asked for (``<session>:<turn id>``):

    - ``effort`` only from the turn's record; else none, and
      ``effort_unrecorded`` says why (``absent``, ``disagree``, ``not_found``).
      Never ``config.toml``'s.
    - ``observed_from: codex_turn_context`` when the turn's record was read;
      a model the hook named stands alone, without it.

    Sent where the decision went: ``control.json``'s plan source, else the
    device's workspace. Written to disk either way. Never fails the turn:
    False when there is nowhere to send it or the service did not take it.
    """
    # One deadline for everything this report does: the device's configuration
    # and the delivery share what the hook has left, never spend it twice.
    deadline = time.monotonic() + max(0.0, budget_s)
    data_dir = resolve_data_dir(environ)
    control = None
    try:
        control = load_control(data_dir, environ)
        if device is not None:
            return False  # the explicit control path reported before capture
    except (ControlConfigError, OSError):
        if device is None:
            return False
        from smart_gateway.control.config import control_path

        if control_path(data_dir, environ).exists() or not model:
            return False
        try:
            ensure_data_dir(data_dir)
            control, _ = _device_control(
                device, model, effort, harness_version, environ, deadline - time.monotonic()
            )
        except Exception as exc:
            # No configuration, so nowhere to send it: kept on disk below.
            log_error(data_dir, "codex-device-observed", exc)
            control = None
    decision_id = f"{session_id}:{turn_id}"
    fields = {
        "session_id": session_id,
        "prompt_id": turn_id,
        "decision_id": decision_id,
        # One report per decision: a retry is the same row at the intake, and
        # a second, different report is refused rather than laid over the
        # first. The device door keys reports the same way, by the service.
        "event_id": f"observed:{decision_id}",
        "phase": "observed",
        "model": model,
        "effort": effort,
        "effort_unrecorded": None if effort else (effort_unrecorded or "not_found"),
        "observed_from": "codex_turn_context" if from_turn_record else None,
        "harness_version": harness_version or (control.harness_version if control else None),
    }
    reported = False
    remaining = deadline - time.monotonic()
    if control is not None and control.plan_source is not None and remaining > 0:
        try:
            client = PlanClient(
                control.plan_source,
                timeout_s=min(REPORT_TIMEOUT_S, remaining),
                token=control.plan_token,
            )
            line = {**envelope("stage"), **{k: v for k, v in fields.items() if v is not None}}
            reported = client.records([line])
        except Exception as exc:  # fail open: a turn is never stopped by its report
            log_error(data_dir, "codex-observed", exc)
            reported = False
    try:
        # Kept whatever happened to the delivery: the local copy matters most
        # when the report did not go out.
        ensure_data_dir(data_dir)
        write_record(data_dir, "stage", {**fields, "reported": reported})
    except Exception as exc:
        log_error(data_dir, "codex-observed-record", exc)
    return reported
