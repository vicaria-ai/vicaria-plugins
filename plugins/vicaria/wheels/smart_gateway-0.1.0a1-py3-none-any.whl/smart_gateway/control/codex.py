"""Codex: the plan for a prompt, shown and never applied.

The Vicaria plugin for Codex asks at ``UserPromptSubmit``
(:func:`smart_gateway.capture.codex_plugin.advice`). With a control
configuration (``$SG_DATA_DIR/control.json`` naming a plan source), it asks
about the prompt through the same :class:`AdapterCore` every harness uses, and
the hook shows what the plan recommends. A plugin hook cannot change the model
or effort a Codex turn runs on, so model and effort are ``suggest`` here
(:data:`config.SUGGEST_ONLY_HARNESSES`): an ``apply`` plan is served as a
suggestion by the service, and a suggestion is all the developer is shown.

What is known of the active configuration is what Codex's own ``config.toml``
says (``model``, ``model_reasoning_effort``), else the control configuration's
defaults. The prompt id is Codex's turn id, the one the captured prompt's event
id is derived from, so a materialized Codex turn joins its decision the way
Claude Code's and OpenCode's do.

Nothing here can fail a run: no configuration, no plan source, or any error on
the way means no advice, and the error is written where ``sg doctor`` reads it.
"""

from __future__ import annotations

import os
import tomllib
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

from vicaria_contracts.plan import Disposition

from smart_gateway.config import ensure_data_dir, resolve_data_dir
from smart_gateway.control.adapter import (
    AdapterCore,
    Decision,
    advisor_sentence,
    ident,
    log_error,
)
from smart_gateway.control.config import ControlConfigError, load_control
from smart_gateway.control.records import write_record

HARNESS = "codex"


@dataclass(frozen=True, slots=True)
class Advice:
    """What the plan said about one prompt: the prompt's id, and what to show."""

    prompt_id: str
    decision_id: str | None = None
    message: str | None = None


def codex_configuration(environ: Mapping[str, str] | None = None) -> tuple[str | None, str | None]:
    """The model and reasoning effort Codex's ``config.toml`` names, where it names them."""
    env = os.environ if environ is None else environ
    home = Path(env.get("CODEX_HOME") or Path(env.get("HOME", "~")) / ".codex").expanduser()
    try:
        with open(home / "config.toml", "rb") as fh:
            doc = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError):
        return None, None
    return ident(doc.get("model")), ident(doc.get("model_reasoning_effort"))


def advise(
    session_id: str,
    prompt: str,
    *,
    prompt_id: str | None = None,
    environ: Mapping[str, str] | None = None,
) -> Advice:
    """Ask the plan source about one prompt, when one is configured.

    ``prompt_id`` is the harness's own id for the prompt (Codex's turn id);
    one is minted when there is none.
    """
    prompt_id = prompt_id or uuid.uuid4().hex
    # Read before anything is created: a machine with no control configuration
    # gets no advice and no new directory.
    try:
        data_dir = resolve_data_dir(environ)
        control = load_control(data_dir, environ)
    except (ControlConfigError, OSError):
        return Advice(prompt_id)
    if control.plan_source is None:
        return Advice(prompt_id)
    try:
        ensure_data_dir(data_dir)
        core = AdapterCore(data_dir, control, harness=HARNESS)
        model, effort = codex_configuration(environ)
        core.session_start(session_id, model=model, effort=effort, source="plugin")
        observed = core.observe_prompt(session_id, prompt_id, prompt)
        decision = core.decide(session_id, prompt_id, prompt, observed, model=model)
        message = _message(decision)
        plan = decision.decided.plan
        write_record(
            data_dir,
            "stage",
            {
                "session_id": session_id,
                "prompt_id": prompt_id,
                "decision_id": decision.decision_id,
                "origin": decision.decided.origin.value,
                "disposition": plan.disposition.value if plan else None,
                "surfaced": message is not None,
                "prompt_features": observed.features.to_record(),
            },
        )
        core.remember(session_id, observed, prompt, prompt_id)
    except Exception as exc:  # fail open: a run is never stopped by its advice
        log_error(data_dir, "codex", exc)
        return Advice(prompt_id)
    return Advice(prompt_id, decision.decision_id, message)


def _message(decision: Decision) -> str | None:
    """The recommendation as the developer reads it, or ``None`` when there is none."""
    decided = decision.decided
    plan = decided.plan
    if (
        plan is None
        or not decided.proceeds
        or plan.disposition not in (Disposition.SUGGEST, Disposition.APPLY)
        or plan.effective_config is None
    ):
        return None
    active = decided.episode.active_config
    changed = sorted(plan.effective_config.changed_from(active), key=lambda d: d.value)
    if not changed:
        return None
    changes = ", ".join(
        f"{d.value}: {active.value(d)} → {plan.effective_config.value(d)}" for d in changed
    )
    why = advisor_sentence(plan.reason)
    return f"vicaria recommends {changes} (not applied)." + (f" {why}" if why else "")


__all__ = ["HARNESS", "Advice", "advise", "codex_configuration"]
