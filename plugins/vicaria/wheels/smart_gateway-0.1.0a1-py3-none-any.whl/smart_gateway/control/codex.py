"""Codex: the plan for a prompt, shown and never applied.

The Vicaria plugin for Codex asks at ``UserPromptSubmit``
(:func:`smart_gateway.capture.codex_plugin.advice`). With a control
configuration (``$SG_DATA_DIR/control.json`` naming a plan source), it asks
about the prompt through the same :class:`AdapterCore` every harness uses, and
the hook shows what the plan recommends. A plugin hook cannot change the model
or effort a Codex turn runs on, so model and effort are ``suggest`` here
(:data:`config.SUGGEST_ONLY_HARNESSES`): an ``apply`` plan is served as a
suggestion by the service, and a suggestion is all the developer is shown.

What is known of the active configuration is what Codex's own ``config.toml``
says (``model``, ``model_reasoning_effort``), else the control configuration's
defaults. The prompt id is Codex's turn id, the one the captured prompt's event
id is derived from, so a materialized Codex turn joins its decision the way
Claude Code's and OpenCode's do.

Nothing here can fail a run: no configuration, no plan source, or any error on
the way means no advice, and the error is written where ``sg doctor`` reads it.
"""

from __future__ import annotations

import os
import time
import tomllib
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path

from vicaria_contracts.plan import Disposition

from smart_gateway.config import ensure_data_dir, resolve_data_dir
from smart_gateway.control.adapter import (
    AdapterCore,
    Decision,
    advisor_sentence,
    ident,
    log_error,
)
from smart_gateway.control.config import ControlConfigError, load_control, parse_control
from smart_gateway.control.records import write_record

HARNESS = "codex"


@dataclass(frozen=True, slots=True)
class Advice:
    """What the plan said about one prompt: the prompt's id, and what to show."""

    prompt_id: str
    decision_id: str | None = None
    message: str | None = None


def codex_configuration(environ: Mapping[str, str] | None = None) -> tuple[str | None, str | None]:
    """The model and reasoning effort Codex's ``config.toml`` names, where it names them."""
    env = os.environ if environ is None else environ
    home = Path(env.get("CODEX_HOME") or Path(env.get("HOME", "~")) / ".codex").expanduser()
    try:
        with open(home / "config.toml", "rb") as fh:
            doc = tomllib.load(fh)
    except (OSError, tomllib.TOMLDecodeError):
        return None, None
    return ident(doc.get("model")), ident(doc.get("model_reasoning_effort"))


def advise(
    session_id: str,
    prompt: str,
    *,
    prompt_id: str | None = None,
    environ: Mapping[str, str] | None = None,
    device: Mapping[str, str] | None = None,
    model: str | None = None,
    effort: str | None = None,
    harness_version: str | None = None,
    budget_s: float = 5.0,
) -> Advice:
    """Ask the plan source about one prompt, when one is configured.

    ``prompt_id`` is the harness's own id for the prompt (Codex's turn id);
    one is minted when there is none.
    """
    prompt_id = prompt_id or uuid.uuid4().hex
    # Read before anything is created: a machine with no control configuration
    # gets no advice and no new directory.
    data_dir = resolve_data_dir(environ)
    capture_policy = None
    configured_model, configured_effort = codex_configuration(environ)
    model, effort = ident(model) or configured_model, ident(effort) or configured_effort
    try:
        control = load_control(data_dir, environ)
        if device is not None:
            # The explicit control path was already asked before capture.
            return Advice(prompt_id)
    except (ControlConfigError, OSError):
        if device is None:
            return Advice(prompt_id)
        # An invalid explicit configuration must not silently change the
        # authority the person selected to their device's workspace.
        from smart_gateway.control.config import control_path

        if control_path(data_dir, environ).exists() or not model:
            return Advice(prompt_id)
        try:
            ensure_data_dir(data_dir)
            control, capture_policy = _device_control(
                device, model, effort, harness_version, environ, budget_s
            )
        except Exception as exc:
            log_error(data_dir, "codex-device-advice", exc)
            return Advice(prompt_id)
    if control.plan_source is None:
        return Advice(prompt_id)
    try:
        ensure_data_dir(data_dir)
        core = AdapterCore(data_dir, control, harness=HARNESS, harness_version=harness_version,
                           capture_policy=capture_policy)
        core.session_start(session_id, model=model, effort=effort, source="plugin")
        observed = core.observe_prompt(session_id, prompt_id, prompt)
        decision = core.decide(session_id, prompt_id, prompt, observed, model=model)
        message = _message(decision)
        plan = decision.decided.plan
        write_record(
            data_dir,
            "stage",
            {
                "session_id": session_id,
                "prompt_id": prompt_id,
                "decision_id": decision.decision_id,
                "origin": decision.decided.origin.value,
                "disposition": plan.disposition.value if plan else None,
                "surfaced": message is not None,
                "prompt_features": observed.features.to_record(),
            },
        )
        core.remember(session_id, observed, prompt, prompt_id)
    except Exception as exc:  # fail open: a run is never stopped by its advice
        log_error(data_dir, "codex", exc)
        return Advice(prompt_id)
    return Advice(prompt_id, decision.decision_id, message)


def _device_control(device, model, effort, harness_version, environ, budget_s):
    """Use the linked device and current server policy, without saving its token."""
    from smart_gateway.capture.api import CaptureApi
    from smart_gateway.control.plans import carries_a_credential_safely

    server = device["server"].rstrip("/")
    if not carries_a_credential_safely(server):
        raise ControlConfigError("device advice requires HTTPS or a loopback server")
    if budget_s < 0.25:
        raise ControlConfigError("no time remains for device advice in this hook")
    deadline = time.monotonic() + budget_s
    api = CaptureApi(server, device["token"], timeout_s=min(2.0, budget_s / 2))
    outcome = api._request("GET", "/device/advice-config", None)
    if not outcome.ok or not isinstance(outcome.value, dict):
        raise ControlConfigError(f"device advice configuration unavailable ({outcome.status})")
    control = parse_control({
        "schema": "sg.control.v1",
        "plan_source": server + "/device",
        "plan_token": device["token"],
        "plan_timeout_s": max(0.05, min(3.0, deadline - time.monotonic())),
        "models": [model],
        "default_model": model,
        "default_effort": effort or "default",
        "efforts": sorted({"low", "medium", "high", "xhigh", "max", effort or "default"}),
        "harness_version": harness_version or "unknown",
    }, environ)
    capture = outcome.value.get("capture")
    if not isinstance(capture, dict) or not isinstance(capture.get("prompt_text"), bool):
        raise ControlConfigError("device advice configuration has no prompt policy")
    return control, capture


def _message(decision: Decision) -> str | None:
    """The recommendation as the developer reads it, or ``None`` when there is none."""
    decided = decision.decided
    plan = decided.plan
    if (
        plan is None
        or not decided.proceeds
        or plan.disposition not in (Disposition.SUGGEST, Disposition.APPLY)
        or plan.effective_config is None
    ):
        return None
    active = decided.episode.active_config
    changed = sorted(plan.effective_config.changed_from(active), key=lambda d: d.value)
    if not changed:
        return None
    changes = ", ".join(
        f"{d.value}: {active.value(d)} → {plan.effective_config.value(d)}" for d in changed
    )
    why = advisor_sentence(plan.reason)
    return f"vicaria recommends {changes} (not applied)." + (f" {why}" if why else "")


__all__ = ["HARNESS", "Advice", "advise", "codex_configuration"]
