"""Private next-session suggestions, separate from text-free capture/control logs.

The local apply flow needs the exact lesson returned with the plan. These files
are local application state, never raw telemetry. They contain no user prompt,
device token or complete response. Reading a suggestion does not authorize apply.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

from smart_gateway.rawlog import append_line, iter_lines, shard_path

SCHEMA = "sg.recommendation.v1"


def write_recommendation(data_dir: Path, record: dict[str, Any]) -> None:
    append_line(shard_path(data_dir, "recommendations"), record)


def latest_recommendation(data_dir: Path, harness: str) -> dict[str, Any] | None:
    """Latest saved suggestion for this harness; apply must validate it and consent."""
    latest = None
    for path in sorted((data_dir / "recommendations").glob("*.jsonl")):
        for _line, record in iter_lines(path):
            if record.get("schema") == SCHEMA and record.get("harness") == harness:
                latest = record
    return latest
