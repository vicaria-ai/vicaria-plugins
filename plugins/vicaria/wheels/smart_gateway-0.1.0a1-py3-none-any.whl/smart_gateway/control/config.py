"""Control configuration and the package's capability descriptor.

Kept apart from ``config.json`` (``sg.config.v1``) on purpose. That file is
validated against an allowlist that every observe-side test pins, and the
control plugin is optional: a team running the observe plugin alone should not
find control keys in the schema it has to understand. ``control.json`` sits next
to it in the data directory and is read only by the control components.

THE DESCRIPTOR IS BUILT, NOT WRITTEN

RFC 0009 §3 says an adapter never claims a control it has not exercised on this
harness version. The levels here are the measured ones (``docs/design/
control-plane.md`` §1.2, and the conformance driver's own wire evidence):

* ``model`` and ``effort`` are ``apply`` **at the commit point** — the request
  body carries ``model`` and ``output_config.effort``, and the proxy rewrites
  them. No hook can request a model switch, so the plugin alone would hold
  ``suggest``; the descriptor describes the package's reach, not one
  mechanism's.
* ``prompt`` is ``apply`` and ``additive``: ``UserPromptSubmit`` injects
  ``additionalContext`` alongside the prompt and cannot replace it.
* ``tools`` is ``apply`` by **narrowing**: a plan names a profile from
  ``tool_profiles``, the commit point removes every tool the profile does not
  allow from the request, and ``PreToolUse`` denies any call to one. The values
  are exactly the mapped profiles — an unmapped profile is undeclared, so a plan
  naming it is refused rather than recorded as applied.
* ``workflow`` is ``observe``.

``levels`` in ``control.json`` can lower any of these — never raise them. The
conformance driver uses that to check that a lowered level is honored (§6
check 3); a deployment uses it when an administrator narrows what the package
may do (§3.2).
"""

from __future__ import annotations

import json
import os
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from vicaria_contracts.capability import (
    CapabilityDescriptor,
    Control,
    ControlLevel,
    Dimension,
    PromptShape,
    ValueSupport,
)
from vicaria_contracts.plan import Configuration
from vicaria_contracts.staging import Admission

from smart_gateway import __version__
from smart_gateway.control.plans import carries_a_credential_safely

CONTROL_SCHEMA = "sg.control.v1"
CONTROL_FILE = "control.json"
CONTROL_CONFIG_ENV = "VICARIA_CONTROL_CONFIG"
#: The organization token, under the name the OpenCode plugin already reads,
#: so one credential serves both harnesses.
PLAN_TOKEN_ENV = "VICARIA_TOKEN"

#: The dimensions this package cannot change on Claude Code get fixed labels so a
#: Configuration still resolves every one of them (RFC 0009 §4.0).
PROMPT_NONE = "recipe:none@v0"
TOOLS_HARNESS = "profile:harness-default@v1"
WORKFLOW_DEFAULT = "workflow:default@v1"
EFFORT_UNSET = "default"  # the request carried no output_config.effort

#: What the package holds before any administrative narrowing, on Claude Code:
#: model, effort and tools at the commit point (tools by removing from the
#: request's ``tools`` array everything a mapped profile does not allow), prompt
#: additively at the hook, workflow observed.
_MEASURED_LEVELS: dict[Dimension, ControlLevel] = {
    Dimension.MODEL: ControlLevel.APPLY,
    Dimension.EFFORT: ControlLevel.APPLY,
    Dimension.PROMPT: ControlLevel.APPLY,
    Dimension.TOOLS: ControlLevel.APPLY,
    Dimension.WORKFLOW: ControlLevel.OBSERVE,
}

#: What the package holds on OpenCode, which is a different boundary and so a
#: different descriptor — the whole point of RFC 0009 §3. OpenCode selects the
#: model before any plugin hook runs and exposes no in-process model switch, so
#: `model` is `suggest`: the plan can recommend a model, and only a human or a
#: re-launch applies it. `effort` is `apply` (a ``chat.params`` option reaches
#: the wire as ``reasoning_effort``, verified), `prompt` is `apply` and additive
#: (a ``chat.message`` part rides beside the prompt), `tools` is `apply` by
#: narrowing (``tool.execute.before`` denies) and MCP registration.
_OPENCODE_MEASURED_LEVELS: dict[Dimension, ControlLevel] = {
    Dimension.MODEL: ControlLevel.SUGGEST,
    Dimension.EFFORT: ControlLevel.APPLY,
    Dimension.PROMPT: ControlLevel.APPLY,
    Dimension.TOOLS: ControlLevel.APPLY,
    Dimension.WORKFLOW: ControlLevel.OBSERVE,
}


@dataclass(frozen=True, slots=True)
class Harness:
    """One harness this package has an adapter for, and what was measured on it.

    The registry below is the single place a harness is named: the descriptor,
    the CLI's choices, and each adapter's component name come from here, so
    adding a harness is one entry plus its translator (``control/adapter.py``).
    """

    name: str
    #: What the applying component calls itself in confirmations and records.
    component: str
    #: ``commit-point`` — two components, the hook stages and ``ANTHROPIC_BASE_URL``
    #: applies; ``in-process`` — one component, the plugin is the application point.
    application: str
    measured_levels: Mapping[Dimension, ControlLevel]


#: The harnesses this package builds a descriptor for, and the measured levels
#: each was verified at. A harness is a key here only once its levels are the
#: result of a conformance run against it, never a hope carried over.
HARNESSES: Mapping[str, Harness] = {
    "claude-code": Harness(
        "claude-code",
        component="plugin",
        application="commit-point",
        measured_levels=_MEASURED_LEVELS,
    ),
    "opencode": Harness(
        "opencode",
        component="opencode-plugin",
        application="in-process",
        measured_levels=_OPENCODE_MEASURED_LEVELS,
    ),
}
MEASURED_LEVELS: Mapping[str, Mapping[Dimension, ControlLevel]] = {
    name: harness.measured_levels for name, harness in HARNESSES.items()
}
#: Harnesses reached through a wrapper that shows a plan and applies nothing.
#: ``suggest`` on model and effort is exactly what printing the recommendation
#: beside the run achieves, and nothing more is claimed: the wrapper never
#: rewrites the developer's command line (``control/codex.py``). The other three
#: are ``observe``: the wrapper adds no recipe, narrows no tools and changes no
#: workflow, so it knows each one's baseline, which a plan must be able to verify.
#: Kept apart from :data:`HARNESSES`, whose keys are the conformance and launch
#: commands' choices, because no conformance driver runs against a wrapped
#: harness yet.
SUGGEST_ONLY_HARNESSES: Mapping[str, Harness] = {
    "codex": Harness(
        "codex",
        component="codex-wrapper",
        application="none",
        measured_levels={
            Dimension.MODEL: ControlLevel.SUGGEST,
            Dimension.EFFORT: ControlLevel.SUGGEST,
            Dimension.PROMPT: ControlLevel.OBSERVE,
            Dimension.TOOLS: ControlLevel.OBSERVE,
            Dimension.WORKFLOW: ControlLevel.OBSERVE,
        },
    ),
}
_RANK = {
    ControlLevel.UNKNOWN: 0,
    ControlLevel.OBSERVE: 1,
    ControlLevel.SUGGEST: 2,
    ControlLevel.APPLY: 3,
}

DEFAULT_CONTROL: dict[str, Any] = {
    "schema": CONTROL_SCHEMA,
    "plan_source": None,  # URL of the recommendation service; None = no decisions
    "upstream": "https://api.anthropic.com",
    "listen": {"host": "127.0.0.1", "port": 8790},
    "models": ["claude-opus-5", "claude-sonnet-4-5", "claude-haiku-4-5"],
    "efforts": ["low", "medium", "high", "xhigh", "max"],
    "tools": ["mcp:vicaria_probe"],
    "tool_profiles": {},  # profile id -> concrete tool names an adapter can narrow to (OpenCode)
    "levels": {},
    "default_model": "claude-opus-5",
    "default_effort": EFFORT_UNSET,
    "denied_models": [],
    "experiment": None,
    "harness_version": "unknown",
    "adapter_version": __version__,
    "plan_timeout_s": 3.0,
    "plan_token": None,
}


class ControlConfigError(Exception):
    exit_code = 2


@dataclass(frozen=True, slots=True)
class ControlConfig:
    plan_source: str | None
    upstream: str
    listen_host: str
    listen_port: int
    models: tuple[str, ...]
    efforts: tuple[str, ...]
    tools: tuple[str, ...]
    tool_profiles: Mapping[str, Any]
    levels: Mapping[Dimension, ControlLevel]
    default_model: str
    default_effort: str
    denied_models: frozenset[str]
    experiment: Mapping[str, Any] | None
    harness_version: str
    adapter_version: str
    plan_timeout_s: float
    #: ``repr=False`` because this is a credential. Nothing prints a
    #: ``ControlConfig`` today, but a traceback that renders locals, a
    #: structured log, or pytest's assertion introspection on a failing test
    #: all would — and a secret in a log is a secret that has left.
    plan_token: str | None = field(repr=False)

    def descriptor(self, harness: str = "claude-code") -> CapabilityDescriptor:
        """The package's descriptor for one harness, with any administrative narrowing applied.

        The measured levels differ by harness (``MEASURED_LEVELS``) because the
        integration boundary does — this is the descriptor RFC 0009 §3 requires,
        one that describes *this* harness's reach and not a hope carried over
        from another.
        """
        registered = HARNESSES.get(harness) or SUGGEST_ONLY_HARNESSES.get(harness)
        if registered is None:
            raise ControlConfigError(
                f"no adapter is registered for harness {harness!r} (known: {sorted(HARNESSES)})"
            )
        measured_levels = registered.measured_levels
        controls: dict[Dimension, Control] = {}
        for dimension, measured in measured_levels.items():
            level = self.levels.get(dimension, measured)
            if _RANK[level] > _RANK[measured]:
                raise ControlConfigError(
                    f"levels.{dimension.value}={level.value!r} claims more than this package "
                    f"has exercised on {harness} ({measured.value}); a level can be lowered "
                    "by an administrator, never raised by configuration (RFC 0009 §3)"
                )
            controls[dimension] = Control(level, values=self._values(dimension))
        prompt_declares_change = (
            _RANK[controls[Dimension.PROMPT].level] >= _RANK[ControlLevel.SUGGEST]
        )
        return CapabilityDescriptor(
            harness=harness,
            harness_version=self.harness_version,
            adapter_version=self.adapter_version,
            controls=controls,
            prompt_shape=PromptShape.ADDITIVE if prompt_declares_change else None,
        )

    def _values(self, dimension: Dimension) -> frozenset[str] | ValueSupport:
        if dimension is Dimension.MODEL:
            # A denied model is not a value this deployment can reach. Declaring
            # it and refusing it later would let a served plan name it and be
            # validated; excluding it here makes such a plan an undeclared value,
            # refused before anything is staged. The commit point re-admits the
            # effective configuration anyway, as defence in depth.
            return frozenset(self.models) - self.denied_models
        if dimension is Dimension.EFFORT:
            return frozenset(self.efforts) | {EFFORT_UNSET}
        if dimension is Dimension.PROMPT:
            return ValueSupport.UNRESTRICTED  # recipe ids are unbounded
        if dimension is Dimension.TOOLS:
            # Only profiles this deployment can actually enforce: the ones
            # `tool_profiles` maps to concrete tool names, plus the harness's
            # own default. `tools` (the registry of tool ids) is not a value set;
            # advertising an unmapped profile let a plan be recorded as applied
            # while nothing narrowed.
            return frozenset(self.tool_profiles) | {TOOLS_HARNESS}
        return ValueSupport.UNKNOWN  # workflow: observed, never set, nothing to enumerate

    def narrowed_tools(self, profile: str) -> frozenset[str] | None:
        """The concrete tool names a profile allows, or ``None`` for the harness default."""
        if profile == TOOLS_HARNESS:
            return None
        names = self.tool_profiles.get(profile)
        if not isinstance(names, list):
            raise ControlConfigError(
                f"tool profile {profile!r} is not mapped in control.json tool_profiles"
            )
        return frozenset(names)

    def admission(self, config: Configuration) -> Admission:
        """Whether the organization permits ``config`` to run at all (RFC 0009 §2.4.2).

        Asked of every configuration before dispatch — the plan's and the
        reference's alike. One implementation, so the commit point and the
        single-component adapters cannot drift on what "denied" means.
        """
        if config.model in self.denied_models:
            return Admission(
                admitted=False, reason=f"model {config.model} is denied for this organization"
            )
        return Admission(admitted=True)

    def active_configuration(self, model: str, effort: str | None) -> Configuration:
        """The configuration the harness is running, as this package can see it."""
        return Configuration(
            model=model,
            effort=effort or EFFORT_UNSET,
            prompt=PROMPT_NONE,
            tools=TOOLS_HARNESS,
            workflow=WORKFLOW_DEFAULT,
        )


def label_of(config: Configuration) -> str:
    """The config label the gate compares: model and effort, the two levers here."""
    return f"{config.model}@{config.effort}"


def _str_list(obj: Mapping[str, Any], key: str) -> tuple[str, ...]:
    value = obj.get(key)
    if not isinstance(value, list) or not all(isinstance(v, str) and v for v in value):
        raise ControlConfigError(f"control.json: {key} must be a list of nonempty strings")
    return tuple(value)


def parse_control(obj: Any, environ: Mapping[str, str] | None = None) -> ControlConfig:
    if not isinstance(obj, Mapping):
        raise ControlConfigError("control.json must be a JSON object")
    if obj.get("schema") != CONTROL_SCHEMA:
        raise ControlConfigError(f"control.json: schema must be {CONTROL_SCHEMA!r}")
    merged: dict[str, Any] = {**DEFAULT_CONTROL, **obj}
    unknown = set(merged) - set(DEFAULT_CONTROL)
    if unknown:
        raise ControlConfigError(f"control.json: unknown keys {sorted(unknown)}")

    levels: dict[Dimension, ControlLevel] = {}
    raw_levels = merged.get("levels") or {}
    if not isinstance(raw_levels, Mapping):
        raise ControlConfigError("control.json: levels must be an object")
    for name, level in raw_levels.items():
        try:
            levels[Dimension(name)] = ControlLevel(level)
        except ValueError:
            raise ControlConfigError(
                f"control.json: levels.{name}={level!r} is not a dimension/level pair"
            ) from None

    listen = merged.get("listen") or {}
    if not isinstance(listen, Mapping):
        raise ControlConfigError("control.json: listen must be an object")
    port = listen.get("port", 8790)
    if isinstance(port, bool) or not isinstance(port, int) or not 0 <= port <= 65535:
        raise ControlConfigError("control.json: listen.port must be a port number")

    plan_source = merged.get("plan_source")
    if plan_source is not None and (not isinstance(plan_source, str) or not plan_source):
        raise ControlConfigError("control.json: plan_source must be a URL or null")
    upstream = merged.get("upstream")
    if not isinstance(upstream, str) or not upstream:
        raise ControlConfigError("control.json: upstream must be a URL")
    timeout = merged.get("plan_timeout_s")
    if isinstance(timeout, bool) or not isinstance(timeout, int | float) or timeout <= 0:
        raise ControlConfigError("control.json: plan_timeout_s must be a positive number")
    #: The organization token the plan source authenticates with. Without it the
    #: service answers 401 before reading the body, so a control package
    #: configured with a plan_source and no token reaches nothing. Read from
    #: control.json or from VICARIA_TOKEN, the name the OpenCode plugin already
    #: uses, so one credential serves both harnesses.
    plan_token = merged.get("plan_token")
    if plan_token is not None and (not isinstance(plan_token, str) or not plan_token.strip()):
        raise ControlConfigError("control.json: plan_token must be a non-empty string or null")
    if plan_token is None:
        from_env = (os.environ if environ is None else environ).get(PLAN_TOKEN_ENV, "").strip()
        plan_token = from_env or None

    #: A token and a plaintext plan_source together would put an organization's
    #: credential on the wire in clear text. Refused here as well as in the
    #: client, because a configuration error should surface when the file is
    #: read rather than on the first plan request, where it would arrive as a
    #: refusal and read like the service's answer.
    if (
        plan_token is not None
        and plan_source is not None
        and not carries_a_credential_safely(plan_source)
    ):
        raise ControlConfigError(
            f"control.json: plan_source {plan_source!r} is not https and is not a "
            "loopback address, so an organization token cannot be sent to it in "
            "clear text. Use https, or remove the token."
        )

    experiment = merged.get("experiment")
    if experiment is not None and not isinstance(experiment, Mapping):
        raise ControlConfigError("control.json: experiment must be an object or null")
    tool_profiles = merged.get("tool_profiles") or {}
    if not isinstance(tool_profiles, Mapping) or not all(
        isinstance(v, list) and all(isinstance(t, str) for t in v) for v in tool_profiles.values()
    ):
        raise ControlConfigError(
            "control.json: tool_profiles must map profile ids to tool-name lists"
        )

    return ControlConfig(
        plan_source=plan_source,
        upstream=upstream,
        listen_host=str(listen.get("host", "127.0.0.1")),
        listen_port=port,
        models=_str_list(merged, "models"),
        efforts=_str_list(merged, "efforts"),
        tools=_str_list(merged, "tools"),
        tool_profiles=dict(tool_profiles),
        levels=levels,
        default_model=str(merged["default_model"]),
        default_effort=str(merged["default_effort"]),
        denied_models=frozenset(_str_list(merged, "denied_models")),
        experiment=experiment,
        harness_version=str(merged["harness_version"]),
        adapter_version=str(merged["adapter_version"]),
        plan_timeout_s=float(timeout),
        plan_token=plan_token,
    )


def control_path(data_dir: Path, environ: Mapping[str, str] | None = None) -> Path:
    env = os.environ if environ is None else environ
    override = env.get(CONTROL_CONFIG_ENV)
    return Path(override) if override else data_dir / CONTROL_FILE


def load_control(data_dir: Path, environ: Mapping[str, str] | None = None) -> ControlConfig:
    path = control_path(data_dir, environ)
    try:
        with open(path, encoding="utf-8") as fh:
            return parse_control(json.load(fh), environ)
    except FileNotFoundError:
        raise ControlConfigError(f"no control configuration at {path}") from None
    except json.JSONDecodeError as exc:
        raise ControlConfigError(f"{path}: not valid JSON ({exc})") from None


def write_control(path: Path, obj: Mapping[str, Any]) -> ControlConfig:
    """Validate, then write. Returns the parsed configuration."""
    config = parse_control({**obj, "schema": CONTROL_SCHEMA})
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({**obj, "schema": CONTROL_SCHEMA}, indent=2, sort_keys=True) + "\n")
    return config
