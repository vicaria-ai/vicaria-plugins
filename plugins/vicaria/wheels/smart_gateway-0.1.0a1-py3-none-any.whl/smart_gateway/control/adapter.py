"""The harness-neutral half of every adapter: from a prompt arriving to a decision made.

Two adapters exist (Claude Code, OpenCode) and they differ only at the edges —
what event shapes arrive, and how a decision is carried out. Everything in
between is the same on every harness, and was once duplicated between them:
session state, explicit feedback, prompt features and the prompt signal, the
assignment, the plan request, and ``vicaria_contracts.client.decide``. This module is that
middle, so a third harness costs one thin translator (an event in, an
application out) and nothing else.

WHAT A TRANSLATOR OWES

1. Call :meth:`AdapterCore.session_start` when the harness opens a session.
2. On a prompt: :meth:`explicit_feedback` first (feedback never reaches a model);
   then :meth:`observe_prompt`; then :meth:`decide`; then :meth:`remember`.
3. Forward the harness's lifecycle and failure events through :meth:`signal`.

What the translator keeps for itself is the harness-specific part of applying:
on Claude Code, staging a contribution for the commit point; on OpenCode,
producing the application the plugin performs. The core does not know which.

PRIVACY

Nothing here writes prompt text — or anything derived from it — to a record or
to session state. The similarity feature compares the prompt with the previous
one in memory, from the harness's own conversation record, and the plan request
carries the prompt only under the capture policy (:meth:`captures`).
"""

from __future__ import annotations

import dataclasses
import json
import os
import time
from collections.abc import Mapping
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from vicaria_contracts.capability import Dimension
from vicaria_contracts.client import Decided, Episode, decide, no_decision
from vicaria_contracts.decision import UnavailableReason
from vicaria_contracts.plan import Configuration
from vicaria_contracts.staging import Admission

from smart_gateway.assignment import Assignment, AssignmentKind
from smart_gateway.control import running
from smart_gateway.control.config import ControlConfig, ControlConfigError, label_of
from smart_gateway.control.plans import PlanClient, PlanResponse, PlanUnavailable
from smart_gateway.control.records import launch_identity, task_id, write_record
from smart_gateway.control.signals import (
    PromptFeatures,
    Signal,
    event_signal,
    parse_explicit,
    prompt_features,
)
from smart_gateway.ids import utc_now_iso
from smart_gateway.randomize import Experiment, Unenrolled, assign
from smart_gateway.rawlog import atomic_write

INDUCE_ENV = "VICARIA_INDUCE"
ERROR_LOG = "control_errors.log"


def ident(value: Any) -> str | None:
    """A printable identifier, or ``None`` — never a coerced one."""
    return (
        value if isinstance(value, str) and 0 < len(value) <= 256 and value.isprintable() else None
    )


def advisor_sentence(reason: Any) -> str | None:
    """The advisor's sentence a plan's reason carries, if any.

    The service appends it once, to the answer that first carries it:
    ``advisor(<code>): <sentence>``. Each translator shows it beside the
    recommendation it explains, so a developer reads what a suggestion rests on.
    """
    head, sep, sentence = str(reason or "").partition("): ")
    sentence = sentence.strip()
    return sentence if sep and head.startswith("advisor(") and sentence else None


def induced() -> frozenset[str]:
    """The faults ``VICARIA_INDUCE`` asks for. Empty in any real session."""
    return frozenset(
        part.strip() for part in (os.environ.get(INDUCE_ENV) or "").split(",") if part.strip()
    )


def log_error(data_dir: Path, event: str, exc: BaseException) -> None:
    """Fail open, visibly: the error is written where a doctor can find it."""
    try:
        with open(data_dir / "raw" / ERROR_LOG, "a", encoding="utf-8") as fh:
            fh.write(f"{utc_now_iso()} {event} {type(exc).__name__}: {exc}\n")
    except OSError:
        pass


@dataclass(frozen=True, slots=True)
class Observed:
    """A prompt seen: its measured shape, and the session state it updated."""

    state: dict[str, Any]
    features: PromptFeatures
    now: float


@dataclass(frozen=True, slots=True)
class Decision:
    """A prompt decided: everything a translator needs to stage or apply."""

    decision_id: str
    episode: Episode
    assignment: Assignment
    decided: Decided
    response: PlanResponse | None  # the plan source's answer, with recipe text; None if none came


class AdapterCore:
    def __init__(
        self,
        data_dir: Path,
        control: ControlConfig,
        *,
        harness: str,
        harness_version: str | None = None,
        capture_policy: Mapping[str, Any] | None = None,
    ) -> None:
        self.data_dir = data_dir
        self.capture_policy = capture_policy
        #: ``harness_version`` is the version the harness itself named, where it
        #: named one (``running.harness_version``). It replaces the configured
        #: one, which is a line someone typed into ``control.json`` once and
        #: which every request then carried whatever was installed.
        self.control = (
            dataclasses.replace(control, harness_version=harness_version)
            if harness_version
            else control
        )
        self.harness_version_source = running.HARNESS if harness_version else running.CONFIGURED
        self.harness = harness

    # --- session state -----------------------------------------------------------

    def state_path(self, session_id: str) -> Path:
        return self.data_dir / "state" / "control" / f"{session_id}.json"

    def load_state(self, session_id: str) -> dict[str, Any]:
        try:
            return json.loads(self.state_path(session_id).read_text())
        except (FileNotFoundError, json.JSONDecodeError):
            return {}

    def save_state(self, session_id: str, state: dict[str, Any]) -> None:
        path = self.state_path(session_id)
        path.parent.mkdir(parents=True, exist_ok=True)
        atomic_write(path, json.dumps(state, sort_keys=True))

    def session_start(
        self,
        session_id: str,
        *,
        model: str | None,
        effort: str | None,
        source: str | None,
        parent_session_id: str | None = None,
        model_source: str = running.HARNESS,
        effort_source: str = running.ENVIRONMENT,
    ) -> dict[str, Any]:
        """Open (or reopen) a session: remember what it runs, and record the signal.

        A child session (a subagent's) names its parent, so its usage can be
        joined to the episode that spawned it.

        What it runs is remembered **with where that was learnt**. A default is
        a belief, and every reader downstream --- the organization's admission,
        the advisor's evidence, the operator's page --- treated it as a reading
        until the request said which it was.
        """
        state = self.load_state(session_id)
        if model:
            state["model"], state["model_source"] = model, model_source
            state.pop("model_id", None)
        elif not state.get("model"):
            state["model"] = self.control.default_model
            state["model_source"] = running.CONFIGURED_DEFAULT
        if effort:
            state["effort"], state["effort_source"] = effort, effort_source
        elif not state.get("effort"):
            state["effort"] = self.control.default_effort
            state["effort_source"] = running.CONFIGURED_DEFAULT
        state.update(
            {
                "source": source or state.get("source"),
                "parent_session_id": parent_session_id or state.get("parent_session_id"),
                "turns": state.get("turns", 0),
                "signals": state.get("signals", []),
            }
        )
        signal = event_signal(
            "SessionStart",
            {
                "session_id": session_id,
                "source": state["source"],
                "model": state["model"],
                "parent_session_id": state["parent_session_id"],
            },
        )
        if signal is not None:
            self._record_signal(signal, state)
        self.save_state(session_id, state)
        return state

    def read_transcript(self, session_id: str, path: Any) -> running.Seen:
        """Take what the harness's transcript says the session ran, and keep it.

        A reading outranks everything the session was believed to run: it is the
        harness's own record of the requests it made. Only what was appended
        since the last read is read.
        """
        state = self.load_state(session_id)
        offset = state.get("transcript_offset")
        seen = running.read(
            path if isinstance(path, str) else None,
            offset=offset if isinstance(offset, int) and not isinstance(offset, bool) else 0,
        )
        if seen.model_id:
            state["model"] = running.canonical(seen.model_id)
            state["model_id"] = seen.model_id
            state["model_source"] = running.TRANSCRIPT
        if seen.served_id:
            # What answered since the last read: the turn's own evidence, and
            # never the configuration (``running``). Cleared when a decision is
            # made, so a turn is reported on what was written for it.
            state["served"] = seen.served_id
        if seen.tools is not None:
            state["tools"] = list(seen.tools)
        state["transcript_offset"] = seen.offset
        self.save_state(session_id, state)
        return seen

    # --- the prompt ------------------------------------------------------------------

    def explicit_feedback(self, session_id: str, prompt: str) -> Signal | None:
        """Record explicit feedback about the previous prompt, if this prompt is that.

        The comment's *length* is recorded; the comment itself goes nowhere but
        the plan source (and only if the caller sends it there).
        """
        feedback = parse_explicit(prompt)
        if feedback is None:
            return None
        state = self.load_state(session_id)
        signal = Signal(
            "explicit_feedback",
            session_id,
            state.get("last_prompt_id"),
            {**feedback.to_record(), "about_prompt_id": state.get("last_prompt_id")},
        )
        self._record_signal(signal, state)
        self.save_state(session_id, state)
        return signal

    def observe_prompt(
        self,
        session_id: str,
        prompt_id: str,
        prompt: str,
        *,
        previous_prompt: str | None = None,
    ) -> Observed:
        """Measure the prompt's shape, record it as a signal, and count the turn.

        ``previous_prompt`` is the translator's to supply, from the harness's
        own record of the conversation, in memory; the core keeps nothing it
        could compare against, by design (see :meth:`remember`).
        """
        state = self.load_state(session_id)
        now = time.time()
        features = prompt_features(
            prompt,
            previous=previous_prompt,
            seconds_since_previous=(now - state["last_prompt_at"])
            if "last_prompt_at" in state
            else None,
        )
        self._record_signal(Signal("prompt", session_id, prompt_id, features.to_record()), state)
        state["turns"] = state.get("turns", 0) + 1
        return Observed(state=state, features=features, now=now)

    def decide(
        self,
        session_id: str,
        prompt_id: str,
        prompt: str,
        observed: Observed,
        *,
        model: str | None = None,
    ) -> Decision:
        """Assign, describe, ask the plan source, and validate what it said."""
        state = observed.state
        active = self.control.active_configuration(
            model or state.get("model") or self.control.default_model,
            state.get("effort") or self.control.default_effort,
        )
        decision_id = f"{session_id}:{prompt_id}"
        if model:
            # The translator read it off the harness for this very prompt.
            state["model"], state["model_source"] = model, running.HARNESS
            state.pop("model_id", None)
        # What this decision was made on, for the end of the turn to compare
        # with what the turn then ran (the hook's ``observed`` record).
        state["believed"] = {
            "prompt_id": prompt_id,
            "model": active.value(Dimension.MODEL),
            "source": state.get("model_source") or running.CONFIGURED_DEFAULT,
        }
        # Nothing has answered this prompt yet: whatever answered the last one
        # is not this turn's evidence.
        state.pop("served", None)
        assignment = self._assignment(decision_id, session_id, label_of(active))
        write_record(
            self.data_dir,
            "assignment",
            {
                "session_id": session_id,
                "prompt_id": prompt_id,
                "task_id": task_id(),
                "assignment": assignment.to_json(),
            },
        )
        episode = Episode(
            episode_id=session_id,
            descriptor=self.control.descriptor(self.harness),
            active_config=active,
            request_revision=prompt_id,
            assigned_policy=assignment.config_label if assignment.comparable else None,
        )
        decided, response = self._request_plan(episode, decision_id, assignment, prompt, state)
        return Decision(
            decision_id=decision_id,
            episode=episode,
            assignment=assignment,
            decided=decided,
            response=response,
        )

    def remember(self, session_id: str, observed: Observed, prompt: str, prompt_id: str) -> None:
        """Note which prompt was last and when — and nothing derived from its text.

        Three earlier forms of "something to compare the next prompt against"
        were each shown to give up short prompts to a reader with the state:
        the first 2,000 characters; an unkeyed CRC32 per character 4-gram
        (invertible outright); a keyed, truncated bottom-k sketch (overlapping
        grams plus the recorded length pin a short prompt down even with a
        thousand candidates per value). The conclusion is not a better
        representation but none: the previous prompt comes from the harness's
        own conversation record when the next prompt arrives, in memory
        (:meth:`observe_prompt`), and this state holds only an id and a time.
        Any of the earlier forms found on disk is dropped on sight.
        """
        state = observed.state
        for stale in ("last_prompt_text", "last_prompt_fingerprint", "last_prompt_sketch"):
            state.pop(stale, None)
        stale_key = self.data_dir / "state" / "control" / "fingerprint.key"
        if stale_key.exists():
            stale_key.unlink()
        state["last_prompt_id"] = prompt_id
        state["last_prompt_at"] = observed.now
        self.save_state(session_id, state)

    # --- other events --------------------------------------------------------------

    def usage(
        self, session_id: str, *, prompt_id: str | None, fields: Mapping[str, Any]
    ) -> dict[str, Any]:
        """Persist what a model step cost, joined to the prompt it served.

        A ``usage`` record, not a signal: tokens are the measurement a
        recommendation is later judged by (RFC 0009 §6 check 7), and they must
        survive the run on disk whether or not any server is reachable. The
        commit point writes the same kind from the provider's reply; this is
        the path for a harness that reports usage to its plugin instead.
        """
        prompt = prompt_id or self.load_state(session_id).get("last_prompt_id")
        record = {
            "session_id": session_id,
            "prompt_id": prompt,
            "decision_id": f"{session_id}:{prompt}" if prompt else None,
            "source": self.harness,
            **{k: v for k, v in fields.items() if isinstance(v, int | float | str) or v is None},
        }
        write_record(self.data_dir, "usage", record)
        return record

    def admit(self, config: Configuration) -> Admission:
        """The organization's answer for ``config``: the config's own, not a copy."""
        return self.control.admission(config)

    def signal(self, event: str, payload: dict[str, Any]) -> Signal | None:
        """Record a lifecycle or failure event by its shape alone."""
        signal = event_signal(event, payload)
        if signal is None:
            return None
        state = self.load_state(signal.session_id) if signal.session_id else {}
        self._record_signal(signal, state)
        if signal.session_id:
            self.save_state(signal.session_id, state)
        return signal

    # --- the capture policy ----------------------------------------------------------

    def captures(self, what: str) -> bool:
        """Whether ``what`` (e.g. ``prompt_text``) may leave the machine.

        The policy lives with the control config so a team can see in one file
        what leaves; an environment override exists for a single session.

        This answer is the machine's own and nothing else's. Unlike the OpenCode
        plugin, whose ``capturesText`` reads the capture policy the service
        delivers with the client config, this adapter fetches no client
        configuration at all: its only channel is ``POST /v1/plan``, and a plan
        response carries a plan, not a policy. The bearer token on that request
        (``control.plan_token``, ``plans.py``) closed the authentication half of
        the gap and none of this half — RFC 0011 §4's service-backed Claude Code
        adapter, the one that would read a delivered capture policy, still does
        not exist. So an organization that revokes prompt capture centrally does
        not revoke it here — a machine whose ``control.json`` still says capture
        keeps sending the text until that file, or that environment variable,
        changes. Closing that gap is a change to what this adapter reads from
        the service and is not made here.
        """
        if self.capture_policy is not None:
            return bool(self.capture_policy.get(what, False))
        capture = self.control.experiment.get("capture") if self.control.experiment else None
        if isinstance(capture, dict):
            return bool(capture.get(what, False))
        # Opt-in. Absent policy means nothing leaves; the environment variable is
        # the single-session override, and its absence is "no".
        return os.environ.get(f"VICARIA_CAPTURE_{what.upper()}", "0") == "1"

    # --- internals ---------------------------------------------------------------------

    def _record_signal(self, signal: Signal, state: dict[str, Any]) -> None:
        write_record(
            self.data_dir, "stage", {"session_id": signal.session_id, "signal": signal.to_record()}
        )
        state.setdefault("signals", []).append(signal.to_record())

    def _assignment(self, decision_id: str, session_id: str, active_label: str) -> Assignment:
        # Under a benchmark launch the arm is a launch fact, not a draw: a matched
        # design runs every arm on every task, so the record says which arm this
        # trial is (policy or reference) and which complete configuration it ran,
        # and carries no propensity. A randomized experiment is a different design
        # with its own record; configuring both at once would let the launch say
        # "reference" while the server draws an alternative, so it is refused here,
        # loudly, rather than resolved by precedence.
        launch = launch_identity()
        if launch is not None and self.control.experiment:
            raise ControlConfigError(
                "a matched-launch arm (VICARIA_ARM) and a randomized experiment "
                "(control.json experiment) cannot both be configured"
            )
        experiment = None
        if self.control.experiment:
            experiment = Experiment(
                experiment_id=str(self.control.experiment.get("experiment_id", "")),
                config_labels=tuple(self.control.experiment.get("config_labels") or ()),
                enrollment=float(self.control.experiment.get("enrollment", 1.0)),
            )
        unenrolled = Unenrolled(kind=AssignmentKind.REFERENCE, config_label=active_label)
        if launch is not None:
            unenrolled = Unenrolled(
                kind=AssignmentKind.REFERENCE
                if launch["arm"] == "reference"
                else AssignmentKind.POLICY,
                config_label=launch["config_label"] or active_label,
            )
        return assign(
            decision_id=decision_id,
            episode_id=session_id,
            experiment=experiment,
            unenrolled=unenrolled,
        )

    def _request_plan(
        self,
        episode: Episode,
        decision_id: str,
        assignment: Assignment,
        prompt: str,
        state: dict[str, Any],
    ) -> tuple[Decided, PlanResponse | None]:
        control = self.control
        if control.plan_source is None:
            return no_decision(
                episode, UnavailableReason.UNREACHABLE, decision_id=decision_id
            ), None
        client = PlanClient(
            control.plan_source,
            timeout_s=control.plan_timeout_s,
            token=control.plan_token,
        )
        context: dict[str, Any] = {
            "harness": self.harness,
            "prompt_length": len(prompt),
            "turn_index": state.get("turns", 0),
            "session_source": state.get("source"),
            "signals": state.get("signals", [])[-20:],
            # Where each part of the active configuration was learnt, so the
            # service can tell a reading from a belief (``running``).
            "model_source": state.get("model_source") or running.CONFIGURED_DEFAULT,
            "effort_source": state.get("effort_source") or running.CONFIGURED_DEFAULT,
            "harness_version_source": self.harness_version_source,
        }
        if state.get("model_id"):
            context["model_id"] = state["model_id"]
        if isinstance(state.get("tools"), list):
            # The tools the harness sent on the wire last turn. A first prompt
            # has none to name yet, and names none rather than guessing.
            context["tools_loaded"] = list(state["tools"])
            context["tools_source"] = running.TRANSCRIPT
        if self.captures("prompt_text"):
            # ``text`` is the key the plan request carries the prompt under
            # (RFC 0009's contract, and the name the service reads as
            # ``context.text``); under any other name the consented text never
            # arrives at the plan source that was meant to receive it. Which
            # plan source that is, is the operator's choice: an RFC 0009 server
            # of their own, or the v1 service, which this client now reaches
            # when ``control.plan_token`` is set and answers ``401`` when it is
            # not. The service-side ``text_sent`` is recorded only for a
            # request that got past that check, so it says nothing about a
            # tokenless install — and under the wrong key it would be ``false``
            # for a tokened one too, which is the defect this line closes.
            context["text"] = prompt
        try:
            response = client.request(
                {
                    "decision_id": decision_id,
                    "episode_id": episode.episode_id,
                    "request_revision": episode.request_revision,
                    "descriptor": episode.descriptor.to_dict(),
                    "active_config": {d.value: episode.active_config.value(d) for d in Dimension},
                    "assignment": assignment.to_json(),
                    "context": context,
                }
            )
        except PlanUnavailable as exc:
            return no_decision(episode, exc.reason, decision_id=decision_id), None
        if response.plan.decision_id != decision_id:
            # A plan answering a different decision is not this decision's plan.
            # Treated as a refusal rather than adopted under either id.
            return no_decision(episode, UnavailableReason.REFUSED, decision_id=decision_id), None
        return decide(episode, response.plan), response


__all__ = [
    "ERROR_LOG",
    "INDUCE_ENV",
    "AdapterCore",
    "Decision",
    "Observed",
    "ident",
    "induced",
    "log_error",
]
