"""A plan source that answers by assigned arm: the smallest recommendation service that is real.

The adapters mint a randomized assignment per episode (``control.json`` names
the experiment and its labels) and send it with every plan request. Something
has to answer *according to that assignment*, or the randomization decides
nothing. This module is that something: an **arms file** declares what each
label means as a configuration change, and :class:`ArmsPolicy` turns a plan
request into the plan for the label the request was assigned — bound to the
request's own decision id, revision and baseline, exactly as the contract
requires — so a validated experiment runs on real work and the gate can judge
it from the records the build joins.

It is deliberately not clever. It has no evidence and no ranking; it does what
the experiment's designer wrote down, for every prompt, and refuses when the
request names a label or an experiment it does not know rather than guessing.

The file::

    {
      "schema": "sg.arms.v1",
      "experiment_id": "exp-2026-09",
      "arms": {
        "reference": {"disposition": "retain"},
        "brief-low": {
          "model": "claude-haiku-4-5",
          "effort": "low",
          "prompt": {"recipe": "recipe:brief@v1", "text": "Prefer the shortest correct answer."},
          "tools": "profile:read-only@v1"
        }
      }
    }

An arm names the dimensions it changes; anything it does not name is the
active configuration, resolved per request (a plan must be complete, RFC 0009
§4.0). ``disposition`` is ``apply`` (the default for an arm with changes),
``suggest`` (the same change shown, never applied) or ``retain`` (no changes
allowed). Values must be ones the adapter's descriptor offers — that is the
operator's ``control.json`` — or the adapter refuses the plan by name.
"""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from vicaria_contracts.capability import Dimension, PromptShape
from vicaria_contracts.plan import Configuration, Disposition, Plan

from smart_gateway.control.plans import PlanRefused

ARMS_SCHEMA = "sg.arms.v1"
_DISPOSITIONS = {
    "apply": Disposition.APPLY,
    "suggest": Disposition.SUGGEST,
    "retain": Disposition.RETAIN,
}
_SCALAR_DIMENSIONS = {
    "model": Dimension.MODEL,
    "effort": Dimension.EFFORT,
    "tools": Dimension.TOOLS,
}


class ArmsError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Arm:
    label: str
    disposition: Disposition
    changes: Mapping[Dimension, str] = field(default_factory=dict)
    recipe_text: str | None = None


@dataclass(frozen=True, slots=True)
class Arms:
    experiment_id: str
    arms: Mapping[str, Arm]

    @classmethod
    def from_dict(cls, obj: Any) -> Arms:
        if not isinstance(obj, dict):
            raise ArmsError("arms file must be a JSON object")
        if obj.get("schema") != ARMS_SCHEMA:
            raise ArmsError(f"arms file schema must be {ARMS_SCHEMA!r}")
        experiment_id = obj.get("experiment_id")
        if not isinstance(experiment_id, str) or not experiment_id:
            raise ArmsError("arms file needs a non-empty experiment_id")
        raw_arms = obj.get("arms")
        if not isinstance(raw_arms, dict) or not raw_arms:
            raise ArmsError("arms file needs at least one arm under 'arms'")
        arms = {label: _arm(label, spec) for label, spec in raw_arms.items()}
        return cls(experiment_id=experiment_id, arms=arms)


def _arm(label: str, spec: Any) -> Arm:
    if not isinstance(label, str) or not label:
        raise ArmsError("arm labels must be non-empty strings")
    if not isinstance(spec, dict):
        raise ArmsError(f"arm {label!r} must be an object")
    unknown = set(spec) - {"disposition", "model", "effort", "tools", "prompt"}
    if unknown:
        raise ArmsError(f"arm {label!r}: unknown keys {sorted(unknown)}")
    changes: dict[Dimension, str] = {}
    for key, dimension in _SCALAR_DIMENSIONS.items():
        if key in spec:
            value = spec[key]
            if not isinstance(value, str) or not value:
                raise ArmsError(f"arm {label!r}: {key} must be a non-empty string")
            changes[dimension] = value
    recipe_text: str | None = None
    if "prompt" in spec:
        prompt = spec["prompt"]
        if (
            not isinstance(prompt, dict)
            or not isinstance(prompt.get("recipe"), str)
            or not prompt["recipe"]
            or not isinstance(prompt.get("text"), str)
            or not prompt["text"]
        ):
            raise ArmsError(f"arm {label!r}: prompt must be {{'recipe': id, 'text': text}}")
        changes[Dimension.PROMPT] = prompt["recipe"]
        recipe_text = prompt["text"]
    disposition_name = spec.get("disposition", "retain" if not changes else "apply")
    disposition = _DISPOSITIONS.get(disposition_name)
    if disposition is None:
        raise ArmsError(f"arm {label!r}: disposition must be one of {sorted(_DISPOSITIONS)}")
    if disposition is Disposition.RETAIN and changes:
        raise ArmsError(
            f"arm {label!r}: a retain arm changes nothing; "
            f"it names {sorted(k.value for k in changes)}"
        )
    if disposition is not Disposition.RETAIN and not changes:
        raise ArmsError(f"arm {label!r}: {disposition_name} needs at least one change")
    return Arm(label=label, disposition=disposition, changes=changes, recipe_text=recipe_text)


def load_arms(path: Path) -> Arms:
    try:
        obj = json.loads(Path(path).read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ArmsError(f"{path}: not valid JSON ({exc})") from None
    return Arms.from_dict(obj)


class ArmsPolicy:
    """The plan for the arm a request was assigned; a refusal for anything else."""

    def __init__(self, arms: Arms) -> None:
        self.arms = arms

    def __call__(self, request: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
        try:
            active = Configuration.from_dict(request["active_config"])
            decision_id = str(request["decision_id"])
            revision = str(request["request_revision"])
        except (KeyError, TypeError, ValueError) as exc:
            raise PlanRefused(400, f"malformed plan request: {exc}") from None
        assignment = request.get("assignment")
        if not isinstance(assignment, Mapping):
            raise PlanRefused(400, "plan request carries no assignment")
        if assignment.get("assignment") == "randomized":
            experiment = assignment.get("experiment")
            if experiment != self.arms.experiment_id:
                raise PlanRefused(
                    422,
                    f"assignment is for experiment {experiment!r}; this plan source serves "
                    f"{self.arms.experiment_id!r}",
                )
            label = assignment.get("config_label")
            arm = self.arms.arms.get(label) if isinstance(label, str) else None
            if arm is None:
                raise PlanRefused(
                    422, f"no arm {label!r} in the arms for {self.arms.experiment_id!r}"
                )
        else:
            # Unenrolled, or not randomized at all: the reference runs, as a plan
            # that says so — recorded as served, not as the source being absent.
            arm = Arm(label="reference", disposition=Disposition.RETAIN)
        effective = Configuration(
            **{d.value: arm.changes.get(d, active.value(d)) for d in Dimension}
        )
        plan = Plan(
            decision_id=decision_id,
            request_revision=revision,
            base_config_digest=active.digest(),
            disposition=arm.disposition,
            effective_config=effective,
            prompt_shape=PromptShape.ADDITIVE if Dimension.PROMPT in arm.changes else None,
            evidence_ref=f"arms:{self.arms.experiment_id}:{arm.label}",
            reason=None,
        )
        recipes = (
            {arm.changes[Dimension.PROMPT]: arm.recipe_text}
            if Dimension.PROMPT in arm.changes and arm.recipe_text
            else {}
        )
        return plan.to_dict(), recipes


__all__ = ["ARMS_SCHEMA", "Arm", "Arms", "ArmsError", "ArmsPolicy", "load_arms"]
