"""Signals: what the user's behaviour says about the work, captured where it happens.

RFC 0009 §2 lists the adapter's fourth responsibility — *collect signals:
outcomes, tool activity, usage, errors, retries, user corrections, explicit
feedback* — and the recommendation service lists "relevant conversation
context" and user signals among its inputs. This module is the plugin's side of
that: it turns hook events into typed signal records and cheap, deterministic
features, and it ships them to the plan source with the next request.

WHAT IS COMPUTED HERE, AND WHAT IS NOT

Features that a 10-second hook on a developer's machine can compute without a
model: prompt length, correction markers ("no", "wrong", "undo", "not what I
asked"), how much a prompt resembles the previous one (a re-ask is a
correction), shouting and exclamation density, and time since the last prompt.
Explicit feedback is parsed from a plugin command the user types.

*Classification* — is this user frustrated, is this a re-ask or a refinement,
what is the intent — is not done here. The server classifies (that is where
the model, the evidence and the organization's consent policy live), and it
classifies from the features plus, where the capture policy permits, the text.
A classifier inside the hook would be a second, unversioned opinion formed
under a time budget, and it would disagree with the server's exactly when it
mattered.

WHAT NEVER REACHES A RECORD

The text. Records carry counts, ratios, ids and enum-typed event kinds. The
prompt itself goes to the plan source only under ``capture.prompt_text``, and
then in the request, never in ``raw/control``.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any

SIGNAL_SCHEMA = "sg.signal.v1"

#: Words that, in a follow-up prompt, most often mean the previous turn missed.
_CORRECTION_MARKERS = (
    r"\bno\b",
    r"\bnot\b",
    r"\bwrong\b",
    r"\bundo\b",
    r"\brevert\b",
    r"\bagain\b",
    r"\bstop\b",
    r"\bdon'?t\b",
    r"\bnot what i (?:asked|meant|wanted)\b",
    r"\bthat'?s not\b",
    r"\bstill (?:broken|failing|wrong)\b",
)
_CORRECTION_RE = re.compile("|".join(_CORRECTION_MARKERS), re.IGNORECASE)
_FEEDBACK_RE = re.compile(
    r"^\s*(?:/(?:[\w-]+:)?feedback|feedback:)\s*(?P<score>up|down|\+1|-1|👍|👎)\s*(?P<comment>.*)$",
    re.IGNORECASE | re.DOTALL,
)
_EMOJI_ONLY_RE = re.compile(r"^\s*(?P<score>👍|👎)\s*$")

#: The event kinds a hook can turn into a signal without interpreting anything.
EVENT_SIGNALS: Mapping[str, str] = {
    "SessionStart": "session_start",
    "Stop": "turn_complete",
    "PostToolUseFailure": "tool_failure",
    "PermissionDenied": "permission_denied",
    "StopFailure": "stop_failure",
    "SessionEnd": "session_end",
    "PreCompact": "compaction",
    # Parent/child boundaries (RFC 0009 §6 check 7): a subagent is a child
    # episode of the session that spawned it, and both ends are recorded.
    "SubagentStart": "subagent_start",
    "SubagentStop": "subagent_stop",
}


@dataclass(frozen=True, slots=True)
class ExplicitFeedback:
    score: int  # +1 or -1
    comment_length: int
    comment: str  # shipped to the plan source under the capture policy; never recorded

    def to_record(self) -> dict[str, Any]:
        return {"score": self.score, "comment_length": self.comment_length}


def parse_explicit(prompt: str) -> ExplicitFeedback | None:
    """``/vicaria-control:feedback up|down [comment]``, ``feedback: down ...``, or a bare 👍/👎."""
    match = _FEEDBACK_RE.match(prompt) or _EMOJI_ONLY_RE.match(prompt)
    if not match:
        return None
    raw = match.group("score").lower()
    score = 1 if raw in ("up", "+1", "👍") else -1
    comment = (match.groupdict().get("comment") or "").strip()
    return ExplicitFeedback(score=score, comment_length=len(comment), comment=comment)


@dataclass(frozen=True, slots=True)
class PromptFeatures:
    """Deterministic features of one submitted prompt, relative to the previous one."""

    length: int
    words: int
    correction_markers: int
    caps_ratio: float
    exclamations: int
    questions: int
    similarity_to_previous: float | None
    seconds_since_previous: float | None
    likely_correction: bool

    def to_record(self) -> dict[str, Any]:
        return {
            "length": self.length,
            "words": self.words,
            "correction_markers": self.correction_markers,
            "caps_ratio": round(self.caps_ratio, 3),
            "exclamations": self.exclamations,
            "questions": self.questions,
            "similarity_to_previous": (
                None
                if self.similarity_to_previous is None
                else round(self.similarity_to_previous, 3)
            ),
            "seconds_since_previous": (
                None
                if self.seconds_since_previous is None
                else round(self.seconds_since_previous, 1)
            ),
            "likely_correction": self.likely_correction,
        }


#: How much of each prompt the similarity feature reads. A retyped prompt is
#: recognized from its head; the window bounds the cost, because this runs in
#: the adapter's own budget (the OpenCode plugin gives the bridge five seconds)
#: and a recommendation lost to a slow feature is a recommendation lost.
SIMILARITY_WINDOW = 8000


def _grams(text: str) -> set[str]:
    lowered = text[:SIMILARITY_WINDOW].lower()  # normalized once, then sliced
    return {lowered[i : i + 4] for i in range(max(0, len(lowered) - 3))}


def similarity(a: str, b: str) -> float:
    """How much two prompts overlap: Jaccard over lowercased character 4-grams.

    Computed from two texts that are both in memory and both discarded
    afterwards. Nothing derived from either is written anywhere — the earlier
    designs that persisted a per-gram representation of the previous prompt
    (first its text, then an unkeyed CRC32 per gram, then a keyed, truncated
    sketch) were each shown to let a reader with the state reconstruct short
    prompts, because overlapping grams and the recorded length constrain the
    text far more than any per-gram ambiguity protects it. The previous prompt
    now comes from the harness's own record of the conversation (Claude Code's
    transcript, the OpenCode plugin's memory), read at the moment it is needed.

    Linear in the window: each text is normalized once and read once. The
    first version lowercased the whole string inside the per-character loop —
    quadratic — and a 120,000-character prompt repeated took the OpenCode
    bridge past its five-second budget, losing the turn's recommendation.
    """
    ga, gb = _grams(a), _grams(b)
    if not ga or not gb:
        return 0.0
    return len(ga & gb) / len(ga | gb)


def prompt_features(
    prompt: str,
    previous: str | None = None,
    seconds_since_previous: float | None = None,
) -> PromptFeatures:
    letters = [c for c in prompt if c.isalpha()]
    caps = sum(1 for c in letters if c.isupper()) / len(letters) if letters else 0.0
    markers = len(_CORRECTION_RE.findall(prompt))
    sim = similarity(previous, prompt) if isinstance(previous, str) and previous else None
    words = len(prompt.split())
    # A short follow-up with a correction marker, or a near-repeat of the last
    # prompt, is the shape of "that was not it". Flagged, not concluded: the
    # server decides what to make of it.
    likely = (markers > 0 and words <= 40) or (sim is not None and sim >= 0.75)
    return PromptFeatures(
        length=len(prompt),
        words=words,
        correction_markers=markers,
        caps_ratio=caps,
        exclamations=prompt.count("!"),
        questions=prompt.count("?"),
        similarity_to_previous=sim,
        seconds_since_previous=seconds_since_previous,
        likely_correction=likely,
    )


#: The signal names this client writes, and the closed set the coverage document
#: publishes.  Derived from :data:`EVENT_SIGNALS` rather than retyped beside it,
#: because retyping is how the published list came to have no overlap at all
#: with what is written: it named five shape FIELDS and four categories --
#: ``tool_count``, ``session_age_s``, ``subagent_depth``, ``retry_index`` --
#: that exist nowhere in this system.  The contract asks for the names the
#: client writes and warns they are not the server's derived predicates; what
#: was published was neither.
SIGNAL_NAMES: tuple[str, ...] = tuple(sorted(set(EVENT_SIGNALS.values())))


@dataclass(frozen=True, slots=True)
class Signal:
    """One typed signal, bound to the session and — where there is one — the prompt."""

    kind: str
    session_id: str | None
    prompt_id: str | None
    fields: Mapping[str, Any] = field(default_factory=dict)

    def to_record(self) -> dict[str, Any]:
        return {
            "schema": SIGNAL_SCHEMA,
            "signal": self.kind,
            "session_id": self.session_id,
            "prompt_id": self.prompt_id,
            **dict(self.fields),
        }


def event_signal(event: str, payload: Mapping[str, Any]) -> Signal | None:
    """The signal an event carries by its shape alone, or ``None``."""
    kind = EVENT_SIGNALS.get(event)
    if kind is None:
        return None
    fields: dict[str, Any] = {}
    if event == "SessionStart":
        fields["source"] = _ident(payload.get("source"))
        fields["model"] = _ident(payload.get("model"))
        # A child session names its parent (OpenCode's ``parentID``); a root
        # session has none. The link is what makes a subagent's usage the
        # parent episode's cost.
        fields["parent_session_id"] = _ident(payload.get("parent_session_id"))
    elif event in ("SubagentStart", "SubagentStop"):
        fields["agent_id"] = _ident(payload.get("agent_id"))
        fields["agent_type"] = _ident(payload.get("agent_type"))
    elif event == "Stop":
        message = payload.get("last_assistant_message")
        fields["last_message_length"] = len(message) if isinstance(message, str) else None
        effort = payload.get("effort")
        fields["effort"] = _ident(effort.get("level")) if isinstance(effort, dict) else None
    elif event == "PostToolUseFailure" or event == "PermissionDenied":
        fields["tool_name"] = _ident(payload.get("tool_name"))
    elif event == "StopFailure":
        fields["error_type"] = _ident(payload.get("error_type"))
    elif event == "SessionEnd":
        fields["reason"] = _ident(payload.get("reason"))
    elif event == "PreCompact":
        fields["trigger"] = _ident(payload.get("trigger"))
    return Signal(
        kind=kind,
        session_id=_ident(payload.get("session_id")),
        prompt_id=_ident(payload.get("prompt_id")),
        fields=fields,
    )


def _ident(value: Any) -> str | None:
    return (
        value if isinstance(value, str) and 0 < len(value) <= 256 and value.isprintable() else None
    )
