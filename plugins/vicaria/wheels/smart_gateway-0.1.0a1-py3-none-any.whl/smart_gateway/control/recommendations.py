"""Shared plugin-only recommendation path for Claude Code and Codex.

Model, effort and lessons are suggestions for a later session, never a claim
that a capture hook changed the current provider request. Explicit control
configuration remains authoritative and is never replaced by device fallback.
"""

from __future__ import annotations

import time
import uuid
from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlsplit, urlunsplit

from vicaria_contracts.plan import Disposition

from smart_gateway.config import ensure_data_dir, resolve_data_dir
from smart_gateway.control.adapter import AdapterCore, Decision, advisor_sentence, log_error
from smart_gateway.control.config import ControlConfigError, load_control, parse_control
from smart_gateway.control.recommendation_records import SCHEMA, write_recommendation
from smart_gateway.control.records import write_record
from smart_gateway.ids import utc_now_iso


@dataclass(frozen=True, slots=True)
class Advice:
    """What the plan said about one prompt: the prompt's id, and what to show."""

    prompt_id: str
    decision_id: str | None = None
    message: str | None = None
    recommendation: dict[str, Any] | None = None


def advise(
    session_id: str,
    prompt: str,
    *,
    prompt_id: str | None = None,
    environ: Mapping[str, str] | None = None,
    device: Mapping[str, str] | None = None,
    model: str | None = None,
    effort: str | None = None,
    model_source: str | None = None,
    effort_source: str | None = None,
    harness_version: str | None = None,
    budget_s: float = 5.0,
    harness: str = "codex",
) -> Advice:
    """Ask for a suggestion; this path never applies a configuration."""
    prompt_id = prompt_id or uuid.uuid4().hex
    if harness not in {"codex", "claude-code"}:
        raise ValueError("unsupported recommendation harness")
    data_dir = resolve_data_dir(environ)
    capture_policy = None
    try:
        control = load_control(data_dir, environ)
        if device is not None:
            # The explicit control path was already asked before capture.
            return Advice(prompt_id)
    except (ControlConfigError, OSError):
        if device is None:
            return Advice(prompt_id)
        # An invalid explicit configuration must not silently change the
        # authority the person selected to their device's workspace.
        from smart_gateway.control.config import control_path

        if control_path(data_dir, environ).exists() or not model:
            return Advice(prompt_id)
        try:
            ensure_data_dir(data_dir)
            control, capture_policy = device_control(
                device, model, effort, harness_version, environ, budget_s, require_models=True
            )
        except Exception as exc:
            log_error(data_dir, f"{harness}-device-advice", exc)
            return Advice(prompt_id)
    if control.plan_source is None:
        return Advice(prompt_id)
    try:
        ensure_data_dir(data_dir)
        core = AdapterCore(
            data_dir,
            control,
            harness=harness,
            harness_version=harness_version,
            capture_policy=capture_policy,
            suggest_only=True,
        )
        core.session_start(
            session_id,
            model=model,
            effort=effort,
            source="plugin",
            model_source=model_source,
            effort_source=effort_source,
        )
        observed = core.observe_prompt(session_id, prompt_id, prompt)
        decision = core.decide(session_id, prompt_id, prompt, observed)
        message = message_of(decision, control.models)
        recommendation = recommendation_of(
            decision, harness, session_id, prompt_id, control.plan_source
        )
        if recommendation is not None:
            write_recommendation(data_dir, recommendation)
        plan = decision.decided.plan
        write_record(
            data_dir,
            "stage",
            {
                "session_id": session_id,
                "prompt_id": prompt_id,
                "decision_id": decision.decision_id,
                "origin": decision.decided.origin.value,
                "disposition": plan.disposition.value if plan else None,
                "surfaced": message is not None,
                "prompt_features": observed.features.to_record(),
            },
        )
        core.remember(session_id, observed, prompt, prompt_id)
    except Exception as exc:  # fail open: a run is never stopped by its advice
        log_error(data_dir, harness, exc)
        return Advice(prompt_id)
    return Advice(prompt_id, decision.decision_id, message, recommendation)


def device_control(
    device, model, effort, harness_version, environ, budget_s, *, require_models=False
):
    """Use the linked device and current server policy, without saving its token."""
    from smart_gateway.capture.api import CaptureApi
    from smart_gateway.control.plans import carries_a_credential_safely

    server = device["server"].rstrip("/")
    if not carries_a_credential_safely(server):
        raise ControlConfigError("device advice requires HTTPS or a loopback server")
    if budget_s < 0.25:
        raise ControlConfigError("no time remains for device advice in this hook")
    deadline = time.monotonic() + budget_s
    api = CaptureApi(server, device["token"], timeout_s=min(2.0, budget_s / 2))
    outcome = api._request("GET", "/device/advice-config", None)
    if not outcome.ok or not isinstance(outcome.value, dict):
        raise ControlConfigError(f"device advice configuration unavailable ({outcome.status})")
    allowed = outcome.value.get("allowed_models")
    if require_models:
        if (
            not isinstance(allowed, list)
            or not allowed
            or any(not isinstance(item, str) or not item.strip() for item in allowed)
            or len(set(allowed)) != len(allowed)
        ):
            raise ControlConfigError("device advice configuration has no valid allowed_models")
    else:
        # End-of-turn reporting must also work with older servers. This fallback
        # is never used to advertise recommendation candidates.
        allowed = [model]
    control = parse_control(
        {
            "schema": "sg.control.v1",
            "plan_source": server + "/device",
            "plan_token": device["token"],
            "plan_timeout_s": max(0.05, min(3.0, deadline - time.monotonic())),
            "models": allowed,
            "default_model": model,
            "default_effort": effort or "default",
            "efforts": sorted({"low", "medium", "high", "xhigh", "max", effort or "default"}),
            "harness_version": harness_version or "unknown",
        },
        environ,
    )
    capture = outcome.value.get("capture")
    if not isinstance(capture, dict) or not isinstance(capture.get("prompt_text"), bool):
        raise ControlConfigError("device advice configuration has no prompt policy")
    return control, capture


def recommendation_of(
    decision: Decision,
    harness: str,
    session_id: str,
    prompt_id: str,
    server: str,
) -> dict[str, Any] | None:
    """Persist only an admissible, complete suggestion that actually changes something."""
    decided = decision.decided
    plan = decided.plan
    if (
        plan is None
        or not decided.proceeds
        or plan.disposition not in (Disposition.SUGGEST, Disposition.APPLY)
        or plan.effective_config is None
    ):
        return None
    active = decided.episode.active_config
    changed = sorted(plan.effective_config.changed_from(active), key=lambda d: d.value)
    if not changed:
        return None
    lesson = None
    if any(d.value == "prompt" for d in changed):
        recipe = plan.effective_config.prompt
        text = decision.response.recipes.get(recipe) if decision.response else None
        if not text:
            return None
        lesson = {"recipe": recipe, "text": text}
    # Retain the endpoint's identity, never userinfo/query/fragment credentials.
    endpoint = urlsplit(server)
    authority = endpoint.netloc.rsplit("@", 1)[-1]
    safe_server = urlunsplit((endpoint.scheme, authority, endpoint.path, "", ""))
    return {
        "schema": SCHEMA,
        "harness": harness,
        "session_id": session_id,
        "prompt_id": prompt_id,
        "decision_id": decision.decision_id,
        "label": (
            "configured" if (plan.evidence_ref or "").startswith("declared:") else "recommended"
        ),
        "base": {"model": active.model, "effort": active.effort},
        "suggested": {d.value: plan.effective_config.value(d) for d in changed},
        "lesson": lesson,
        "reason": plan.reason,
        "evidence_ref": plan.evidence_ref,
        "policy_version": decision.response.bundle_id if decision.response else None,
        "server": safe_server,
        "recorded_at": utc_now_iso(),
    }


def message_of(decision: Decision, allowed_models=()) -> str | None:
    """The recommendation as the developer reads it, or ``None`` when there is none."""
    decided = decision.decided
    plan = decided.plan
    if plan is not None and plan.disposition is Disposition.CANNOT_EXECUTE:
        reasons = []
        effort_refused = False
        for reason in (plan.reason or "").split("; "):
            for dimension in ("model", "effort"):
                prefix = dimension + "_not_allowed("
                if reason.startswith(prefix) and reason.endswith(")"):
                    denied = reason[len(prefix) : -1]
                    reasons.append(f"this workspace's policy doesn't allow {dimension} {denied}")
                    effort_refused |= dimension == "effort"
                    break
            else:
                reasons.append(f"no recommendation available ({reason})")
        allowed = ", ".join(sorted(allowed_models)) or "none declared"
        effort_hint = " Choose an effort allowed by the workspace policy." if effort_refused else ""
        return (
            "vicaria: " + "; ".join(reasons) + ". "
            f"Allowed model values: {allowed}." + effort_hint + " Nothing was changed."
        )
    if (
        plan is None
        or not decided.proceeds
        or plan.disposition not in (Disposition.SUGGEST, Disposition.APPLY)
        or plan.effective_config is None
    ):
        return None
    active = decided.episode.active_config
    changed = sorted(plan.effective_config.changed_from(active), key=lambda d: d.value)
    if not changed:
        return None
    prefix = "vicaria recommends"
    if (plan.evidence_ref or "").startswith("declared:"):
        prefix = "vicaria configured arm"
    lesson = ""
    if any(d.value == "prompt" for d in changed):
        text = (
            decision.response.recipes.get(plan.effective_config.prompt)
            if decision.response
            else None
        )
        if not text:
            return "vicaria: the suggested lesson is unavailable. Nothing was applied."
        lesson = f" Lesson: {text}"
    changes = (
        ", ".join(
            f"{d.value}: {active.value(d)} → {plan.effective_config.value(d)}"
            for d in changed
            if d.value != "prompt"
        )
        or "lesson update"
    )
    why = advisor_sentence(plan.reason)
    return f"{prefix} {changes} (not applied)." + lesson + (f" {why}" if why else "")
