"""Append-only JSON Lines storage (spec section 8).

Hooks from concurrent sessions append to the same shard, so every line is one locked
os.write; readers skip and count corrupt lines instead of raising, because a torn line
must never make a whole week of raw data unreadable.
"""

from __future__ import annotations

import contextlib
import fcntl
import json
import os
import tempfile
from collections.abc import Iterator
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

__all__ = [
    "LineStats",
    "append_line",
    "atomic_write",
    "encode_line",
    "iter_lines",
    "shard_path",
    "utc_date",
]

_DIR_MODE = 0o700
_FILE_MODE = 0o600


def encode_line(obj: object) -> bytes:
    """The one canonical JSON Lines encoding used for every raw and derived file."""
    return (json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n").encode("utf-8")


def utc_date(now: datetime | None = None) -> str:
    """The recorder's UTC date, YYYY-MM-DD, which names the shard a line lands in."""
    now = datetime.now(UTC) if now is None else now.astimezone(UTC)
    return now.strftime("%Y-%m-%d")


def shard_path(raw_dir: Path, kind: str, now: datetime | None = None) -> Path:
    """`<raw_dir>/<kind>/YYYY-MM-DD.jsonl`; ordering is by content, never by shard."""
    return raw_dir / kind / f"{utc_date(now)}.jsonl"


def _mkdir_private(path: Path) -> None:
    if path.is_dir():
        return
    _mkdir_private(path.parent)
    try:
        path.mkdir(mode=_DIR_MODE)
    except FileExistsError:
        return
    path.chmod(_DIR_MODE)


def append_line(path: Path, obj: object) -> None:
    """Append one line under an exclusive lock with a single write; no fsync per line."""
    data = encode_line(obj)
    _mkdir_private(path.parent)
    fd = os.open(path, os.O_WRONLY | os.O_APPEND | os.O_CREAT, _FILE_MODE)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX)
        try:
            written = os.write(fd, data)
        finally:
            fcntl.flock(fd, fcntl.LOCK_UN)
    finally:
        os.close(fd)
    if written != len(data):
        raise OSError(f"short write: {written} of {len(data)} bytes")


@dataclass(slots=True)
class LineStats:
    """Per-file read counts that iter_lines fills in, later copied into build.json."""

    lines: int = 0
    corrupt_lines: int = 0
    corrupt_line_nos: list[int] = field(default_factory=list)


def iter_lines(path: Path, stats: LineStats | None = None) -> Iterator[tuple[int, dict]]:
    """Yield (1-based line_no, object) for every intact JSON-object line; never raises.

    A missing file yields nothing. Blank, undecodable, non-JSON and non-object lines are
    skipped and recorded in `stats` so the build can report them.
    """
    try:
        raw = path.read_bytes()
    except FileNotFoundError:
        return
    parts = raw.split(b"\n")
    if parts and parts[-1] == b"":
        parts.pop()  # the empty tail after the final newline is not a line
    for line_no, line in enumerate(parts, start=1):
        if stats is not None:
            stats.lines += 1
        try:
            obj = json.loads(line.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            obj = None
        if not isinstance(obj, dict):
            if stats is not None:
                stats.corrupt_lines += 1
                stats.corrupt_line_nos.append(line_no)
            continue
        yield line_no, obj


def atomic_write(path: Path, data: bytes | str) -> None:
    """Write via a same-directory temp file and os.replace so readers never see a partial file."""
    if isinstance(data, str):
        data = data.encode("utf-8")
    _mkdir_private(path.parent)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        os.fchmod(fd, _FILE_MODE)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp)
        raise
