"""Compatibility imports for smart-gateway-bench."""
