"""Compatibility import; install smart-gateway-bench for offline tools."""

import importlib
import sys

sys.modules[__name__] = importlib.import_module("gateway_bench.harbor")
