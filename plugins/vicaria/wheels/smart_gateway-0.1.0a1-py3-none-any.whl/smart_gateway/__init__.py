"""Smart Gateway: measures what coding-agent work costs, reconciled to billing.

The plugin observes and records; it never routes, blocks or injects context.
"""

__version__ = "0.1.0a1"

# Every record schema (spec section 5 + config), mapped to where such records live
# relative to the data dir. docs/schema.md must name each of these (test T28).
SCHEMAS: dict[str, str] = {
    "sg.config.v1": "config.json",
    "sg.hook.v1": "raw/hooks/YYYY-MM-DD.jsonl",
    "sg.otel.v1": "raw/otel/YYYY-MM-DD.jsonl",
    "sg.transcript.v1": "raw/transcript/YYYY-MM-DD.jsonl",
    "sg.billing.v1": "raw/billing/<fetch_id>.jsonl",
    "sg.task.v1": "raw/tasks/YYYY-MM-DD.jsonl",
    "sg.api_call.v1": "derived/api_calls.jsonl",
    "sg.attempt.v1": "derived/attempts.jsonl",
    "sg.task.derived.v1": "derived/tasks.jsonl",
    "sg.reconcile.v1": "derived/reconciliation.jsonl",
    "sg.build.v1": "derived/build.json",
    "sg.decision.v1": "reports/gate-<current>-vs-<candidate>-<build_id[:8]>.json",
}
