"""Usage-only transcript extraction with per-file cursors (spec section 6.3).

Claude Code's transcript is private and its format is unstable, but it is the only local
source of the cache TTL split, thinking tokens and the model the API actually answered
with. Only identifiers, counts and usage numbers leave a line: message text, tool input,
tool output, paths and branch names never do (the last two become salted hashes).
"""

from __future__ import annotations

import fcntl
import json
import os
import re
import time
from collections.abc import Callable
from dataclasses import dataclass, field, fields
from datetime import datetime
from pathlib import Path

from smart_gateway import __version__
from smart_gateway.config import ensure_data_dir, load_config, resolve_data_dir
from smart_gateway.ids import extract_task_ref, load_or_create_salt, salted_hash, utc_now_iso
from smart_gateway.rawlog import append_line, atomic_write, shard_path

__all__ = [
    "CURSORS_FILE",
    "CURSORS_LOCK",
    "KINDS",
    "SCHEMA",
    "TRANSCRIPTS_FILE",
    "TRIGGERS",
    "ExtractContext",
    "IngestStats",
    "TranscriptFile",
    "TranscriptRecord",
    "Usage",
    "default_projects_dir",
    "discover",
    "extract_line",
    "ingest",
    "known_sessions",
]

SCHEMA = "sg.transcript.v1"
KIND_MAIN = "main"
KIND_SUBAGENT = "subagent"
KIND_WORKFLOW = "workflow"
KINDS = frozenset({KIND_MAIN, KIND_SUBAGENT, KIND_WORKFLOW})
TRIGGERS = frozenset({"hook", "cli"})
CURSORS_FILE = "cursors.json"
CURSORS_LOCK = "cursors.lock"
TRANSCRIPTS_FILE = "transcripts.json"

# Session and agent ids are used to build file names, so they are restricted to a
# path-safe alphabet before any glob or open happens.
_SESSION_ID_RE = re.compile(r"[A-Za-z0-9_-]{1,128}")
_AGENT_ID_RE = re.compile(r"[A-Za-z0-9_-]{1,64}")
_AGENT_FILE_RE = re.compile(r"agent-([A-Za-z0-9_-]{1,64})\.jsonl")
# Line-type names are copied into state and stats as counter keys: identifier-like only.
_TYPE_KEY_RE = re.compile(r"[A-Za-z0-9_-]{1,40}")
_TOOL_NAME_RE = re.compile(r"\S{1,120}")
_CHUNK = 1 << 20
_LOCK_POLL_S = 0.02
_RECORDER_COMPONENT = "transcript"


def default_projects_dir() -> Path:
    """Where Claude Code keeps transcripts: ~/.claude/projects/<project>/<session>.jsonl."""
    return Path.home() / ".claude" / "projects"


@dataclass(frozen=True, slots=True)
class TranscriptFile:
    """One transcript file found for a session; `agent_id` comes from the file name."""

    path: Path
    kind: str
    agent_id: str | None


@dataclass(frozen=True, slots=True)
class Usage:
    """`message.usage` flattened; each field is null when the line does not carry it."""

    input_tokens: int | None
    cache_creation_input_tokens: int | None
    cache_read_input_tokens: int | None
    output_tokens: int | None
    thinking_tokens: int | None
    cache_creation_5m: int | None
    cache_creation_1h: int | None
    service_tier: str | None
    inference_geo: str | None
    speed: str | None
    web_search_requests: int | None
    web_fetch_requests: int | None
    n_iterations: int | None

    def to_json(self) -> dict[str, object]:
        return {f.name: getattr(self, f.name) for f in fields(self)}

    @classmethod
    def from_json(cls, obj: object) -> Usage:
        names = [f.name for f in fields(cls)]
        if not isinstance(obj, dict) or set(obj) != set(names):
            raise ValueError("usage on disk carries exactly the sg.transcript.v1 usage keys")
        return cls(**{name: obj[name] for name in names})


@dataclass(frozen=True, slots=True)
class TranscriptRecord:
    """One `sg.transcript.v1` line: a `user` or `assistant` transcript line minus its text."""

    recorded_at: str
    recorder_version: str
    trigger: str
    session_id: str
    agent_id: str | None
    agent_type: str | None
    spawn_depth: int | None
    transcript_kind: str
    line_type: str
    uuid: str
    parent_uuid: str | None
    timestamp: str | None
    claude_version: str | None
    entrypoint: str | None
    cwd_hash: str | None
    branch_hash: str | None
    branch_task_ref: str | None
    is_sidechain: bool
    # assistant lines (null / empty on user lines)
    request_id: str | None
    message_id: str | None
    api_block_index: int | None
    model: str | None
    effort: str | None
    stop_reason: str | None
    attribution_agent: str | None
    usage: Usage | None
    n_tool_use_blocks: int
    tool_names: tuple[str, ...]
    # user lines (null / zero on assistant lines)
    prompt_id: str | None
    permission_mode: str | None
    n_tool_result_blocks: int
    n_tool_result_errors: int

    def to_json(self) -> dict[str, object]:
        out: dict[str, object] = {"schema": SCHEMA}
        for f in fields(self):
            if f.name in ("recorder_version", "trigger"):
                continue
            out[f.name] = getattr(self, f.name)
        out["recorder"] = {
            "component": _RECORDER_COMPONENT,
            "version": self.recorder_version,
            "trigger": self.trigger,
        }
        out["usage"] = None if self.usage is None else self.usage.to_json()
        out["tool_names"] = list(self.tool_names)
        return out

    @classmethod
    def from_json(cls, obj: object) -> TranscriptRecord:
        names = [f.name for f in fields(cls) if f.name not in ("recorder_version", "trigger")]
        expected = {*names, "schema", "recorder"}
        if not isinstance(obj, dict) or set(obj) != expected:
            raise ValueError(
                "a transcript record on disk carries exactly the sg.transcript.v1 keys"
            )
        if obj["schema"] != SCHEMA:
            raise ValueError(f"expected schema {SCHEMA}")
        recorder = obj["recorder"]
        if (
            not isinstance(recorder, dict)
            or recorder.get("component") != _RECORDER_COMPONENT
            or recorder.get("trigger") not in TRIGGERS
            or not isinstance(recorder.get("version"), str)
        ):
            raise ValueError("transcript recorder must be {component, version, trigger}")
        kwargs: dict[str, object] = {name: obj[name] for name in names}
        kwargs["usage"] = None if obj["usage"] is None else Usage.from_json(obj["usage"])
        if not isinstance(obj["tool_names"], list):
            raise ValueError("tool_names must be a list")
        kwargs["tool_names"] = tuple(obj["tool_names"])
        kwargs["recorder_version"] = recorder["version"]
        kwargs["trigger"] = recorder["trigger"]
        return cls(**kwargs)


@dataclass(frozen=True, slots=True)
class ExtractContext:
    """Everything extract_line needs besides the line itself, fixed per ingested file."""

    salt: bytes
    task_id_branch_regex: re.Pattern[str]
    protected_branches: frozenset[str]
    recorded_at: str
    trigger: str
    recorder_version: str
    session_id: str
    agent_id: str | None
    agent_type: str | None
    spawn_depth: int | None


@dataclass(slots=True)
class IngestStats:
    """What one ingest() call did; `other_line_types` counts lines it saw and did not emit."""

    files_seen: int = 0
    files_restarted: int = 0
    lines_read: int = 0
    records_emitted: int = 0
    other_line_types: dict[str, int] = field(default_factory=dict)
    stopped_by_deadline: bool = False
    elapsed_ms: int = 0

    def to_json(self) -> dict[str, object]:
        return {f.name: getattr(self, f.name) for f in fields(self)}


# --- pure extraction -----------------------------------------------------------------


def _str(v: object) -> str | None:
    return v if isinstance(v, str) and v else None


def _int(v: object) -> int | None:
    return v if isinstance(v, int) and not isinstance(v, bool) else None


def _dict(v: object) -> dict:
    return v if isinstance(v, dict) else {}


def _usage(msg: dict) -> Usage | None:
    u = msg.get("usage")
    if not isinstance(u, dict):
        return None
    details = _dict(u.get("output_tokens_details"))
    creation = _dict(u.get("cache_creation"))
    server = _dict(u.get("server_tool_use"))
    iterations = u.get("iterations")
    return Usage(
        input_tokens=_int(u.get("input_tokens")),
        cache_creation_input_tokens=_int(u.get("cache_creation_input_tokens")),
        cache_read_input_tokens=_int(u.get("cache_read_input_tokens")),
        output_tokens=_int(u.get("output_tokens")),
        thinking_tokens=_int(details.get("thinking_tokens")),
        cache_creation_5m=_int(creation.get("ephemeral_5m_input_tokens")),
        cache_creation_1h=_int(creation.get("ephemeral_1h_input_tokens")),
        service_tier=_str(u.get("service_tier")),
        inference_geo=_str(u.get("inference_geo")),
        speed=_str(u.get("speed")),
        web_search_requests=_int(server.get("web_search_requests")),
        web_fetch_requests=_int(server.get("web_fetch_requests")),
        n_iterations=len(iterations) if isinstance(iterations, list) else None,
    )


def _tool_name(v: object) -> str:
    # Tool names are structural identifiers; anything that does not look like one is
    # replaced so free text cannot ride along in a "name".
    return v if isinstance(v, str) and _TOOL_NAME_RE.fullmatch(v) else "invalid_tool_name"


def extract_line(obj: object, kind: str, ctx: ExtractContext) -> TranscriptRecord | None:
    """Reduce one transcript line to a TranscriptRecord; None for every other line type.

    Pure: the same (obj, kind, ctx) always yields the same record. A `user`/`assistant`
    line without a string `uuid` cannot be deduplicated at build and is not emitted.
    """
    if kind not in KINDS:
        raise ValueError("transcript_kind must be main, subagent or workflow")
    if not isinstance(obj, dict):
        return None
    line_type = obj.get("type")
    if line_type not in ("user", "assistant"):
        return None
    uuid = _str(obj.get("uuid"))
    if uuid is None:
        return None
    msg = _dict(obj.get("message"))
    content = msg.get("content")
    blocks = [b for b in content if isinstance(b, dict)] if isinstance(content, list) else []
    cwd = _str(obj.get("cwd"))
    branch = _str(obj.get("gitBranch"))
    is_assistant = line_type == "assistant"
    tool_uses = [b for b in blocks if b.get("type") == "tool_use"] if is_assistant else []
    results = [b for b in blocks if b.get("type") == "tool_result"] if not is_assistant else []
    return TranscriptRecord(
        recorded_at=ctx.recorded_at,
        recorder_version=ctx.recorder_version,
        trigger=ctx.trigger,
        session_id=_str(obj.get("sessionId")) or ctx.session_id,
        agent_id=_str(obj.get("agentId")) or ctx.agent_id,
        agent_type=ctx.agent_type,
        spawn_depth=ctx.spawn_depth,
        transcript_kind=kind,
        line_type=line_type,
        uuid=uuid,
        parent_uuid=_str(obj.get("parentUuid")),
        timestamp=_str(obj.get("timestamp")),
        claude_version=_str(obj.get("version")),
        entrypoint=_str(obj.get("entrypoint")),
        cwd_hash=None if cwd is None else salted_hash(ctx.salt, cwd),
        branch_hash=None if branch is None else salted_hash(ctx.salt, branch),
        branch_task_ref=extract_task_ref(branch, ctx.task_id_branch_regex, ctx.protected_branches),
        is_sidechain=obj.get("isSidechain") is True,
        request_id=_str(obj.get("requestId")) if is_assistant else None,
        message_id=_str(msg.get("id")) if is_assistant else None,
        api_block_index=_int(obj.get("apiBlockIndex")) if is_assistant else None,
        model=_str(msg.get("model")) if is_assistant else None,
        effort=_str(obj.get("effort")) if is_assistant else None,
        stop_reason=_str(msg.get("stop_reason")) if is_assistant else None,
        attribution_agent=_str(obj.get("attributionAgent")) if is_assistant else None,
        usage=_usage(msg) if is_assistant else None,
        n_tool_use_blocks=len(tool_uses),
        tool_names=tuple(_tool_name(b.get("name")) for b in tool_uses),
        prompt_id=_str(obj.get("promptId")) if not is_assistant else None,
        permission_mode=_str(obj.get("permissionMode")) if not is_assistant else None,
        n_tool_result_blocks=len(results),
        n_tool_result_errors=sum(1 for b in results if b.get("is_error") is True),
    )


def _other_type(obj: object) -> str:
    """Counter key for a line extract_line did not emit."""
    if not isinstance(obj, dict):
        return "malformed"
    t = obj.get("type")
    if t in ("user", "assistant"):
        return "malformed"  # a user/assistant line without a usable uuid
    return t if isinstance(t, str) and _TYPE_KEY_RE.fullmatch(t) else "unknown"


# --- discovery -----------------------------------------------------------------------


def _check_session_id(session_id: object) -> str:
    if not isinstance(session_id, str) or not _SESSION_ID_RE.fullmatch(session_id):
        raise ValueError("session id must match [A-Za-z0-9_-]{1,128}")
    return session_id


def discover(
    session_id: str, projects_dir: Path | None = None, *, main_path: Path | None = None
) -> list[TranscriptFile]:
    """Every transcript file of a session: main first, then subagents, then workflows.

    `main_path` (from state/transcripts.json) is trusted when it exists; discovery under
    `projects_dir/*/` finds the rest, including subagent trees of a session whose main
    file was never recorded by a hook.
    """
    _check_session_id(session_id)
    projects_dir = default_projects_dir() if projects_dir is None else Path(projects_dir)
    out: list[TranscriptFile] = []
    dirs: list[Path] = []
    if main_path is not None and Path(main_path).is_file():
        main = Path(main_path).resolve()
        out.append(TranscriptFile(main, KIND_MAIN, None))
        dirs.append(main.parent)
    try:
        children = sorted(p for p in projects_dir.iterdir() if p.is_dir())
    except OSError:
        children = []
    for child in children:
        if (child / f"{session_id}.jsonl").is_file() or (child / session_id).is_dir():
            dirs.append(child.resolve())
    seen = {f.path for f in out}
    for d in sorted(set(dirs), key=str):
        main = d / f"{session_id}.jsonl"
        if main.is_file() and main not in seen:
            out.append(TranscriptFile(main, KIND_MAIN, None))
            seen.add(main)
        subagents = d / session_id / "subagents"
        for pattern, kind in (
            ("agent-*.jsonl", KIND_SUBAGENT),
            ("workflows/*/agent-*.jsonl", KIND_WORKFLOW),
        ):
            for f in sorted(subagents.glob(pattern)):
                m = _AGENT_FILE_RE.fullmatch(f.name)
                if m is None or not f.is_file() or f in seen:
                    continue
                out.append(TranscriptFile(f, kind, m.group(1)))
                seen.add(f)
    return out


def _known_main_path(state_dir: Path, session_id: str) -> Path | None:
    """The transcript path SessionStart recorded for this session, if any."""
    try:
        obj = json.loads((state_dir / TRANSCRIPTS_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    value = obj.get(session_id) if isinstance(obj, dict) else None
    return Path(value) if isinstance(value, str) and value else None


def known_sessions(data_dir: Path, projects_dir: Path | None = None) -> list[str]:
    """Session ids from state/transcripts.json plus every `*/<id>.jsonl` under projects_dir."""
    ids: set[str] = set()
    try:
        obj = json.loads((data_dir / "state" / TRANSCRIPTS_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        obj = {}
    if isinstance(obj, dict):
        ids.update(k for k in obj if isinstance(k, str) and _SESSION_ID_RE.fullmatch(k))
    projects_dir = default_projects_dir() if projects_dir is None else Path(projects_dir)
    try:
        children = [p for p in projects_dir.iterdir() if p.is_dir()]
    except OSError:
        children = []
    for child in children:
        for f in child.glob("*.jsonl"):
            if f.is_file() and _SESSION_ID_RE.fullmatch(f.stem):
                ids.add(f.stem)
    return sorted(ids)


def _read_meta(tf: TranscriptFile) -> tuple[str | None, int | None]:
    """(agentType, spawnDepth) from the sidecar agent-<id>.meta.json; both optional."""
    if tf.kind == KIND_MAIN:
        return None, None
    meta_path = tf.path.with_name(tf.path.name[: -len(".jsonl")] + ".meta.json")
    try:
        obj = json.loads(meta_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None, None
    if not isinstance(obj, dict):
        return None, None
    return _str(obj.get("agentType")), _int(obj.get("spawnDepth"))


# --- cursors and ingest --------------------------------------------------------------


def _load_cursors(state_dir: Path) -> dict:
    """state/cursors.json, or a fresh structure when it is missing or unreadable (restarting
    a file only re-emits lines the build deduplicates)."""
    try:
        obj = json.loads((state_dir / CURSORS_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        obj = None
    if not isinstance(obj, dict) or not isinstance(obj.get("files"), dict):
        return {"files": {}}
    return obj


def _fresh_cursor(tf: TranscriptFile, session_id: str, inode: int) -> dict:
    return {
        "offset": 0,
        "inode": inode,
        "size": 0,
        "kind": tf.kind,
        "session_id": session_id,
        "agent_id": tf.agent_id,
        "restarts": 0,
        "lines_read": 0,
        "records_emitted": 0,
        "other_line_types": {},
        "updated_at": None,
    }


def _cursor_for(cursors: dict, tf: TranscriptFile, session_id: str, st: os.stat_result) -> dict:
    """The file's cursor, restarted at 0 when the file was replaced or truncated."""
    key = str(tf.path)
    cur = cursors["files"].get(key)
    if not isinstance(cur, dict) or not all(
        isinstance(cur.get(k), int) and not isinstance(cur.get(k), bool)
        for k in ("offset", "inode", "size", "restarts", "lines_read", "records_emitted")
    ):
        cur = _fresh_cursor(tf, session_id, st.st_ino)
    elif cur["inode"] != st.st_ino or st.st_size < cur["offset"]:
        restarts = cur["restarts"] + 1
        cur = _fresh_cursor(tf, session_id, st.st_ino)
        cur["restarts"] = restarts
        cur["restarted"] = True
    if not isinstance(cur.get("other_line_types"), dict):
        cur["other_line_types"] = {}
    cursors["files"][key] = cur
    return cur


def _lock(fd: int, deadline: float, clock: Callable[[], float]) -> bool:
    """flock with a deadline: a hook must never hang on a sibling ingest."""
    while True:
        try:
            fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            return True
        except BlockingIOError:
            if clock() >= deadline:
                return False
            time.sleep(_LOCK_POLL_S)


def _count(counter: dict, key: str) -> None:
    counter[key] = counter.get(key, 0) + 1


def _ingest_file(
    tf: TranscriptFile,
    cur: dict,
    ctx: ExtractContext,
    shard: Path,
    stats: IngestStats,
    deadline: float,
    clock: Callable[[], float],
) -> bool:
    """Read from the cursor to EOF, emitting records; False when the deadline stopped it.

    A trailing line without a newline is still being written by Claude Code and is left
    for the next pass; the cursor only ever advances past complete lines.
    """
    st = os.stat(tf.path)
    offset = cur["offset"]
    finished = True
    with tf.path.open("rb") as fh:
        fh.seek(offset)
        rest = b""
        while finished:
            chunk = fh.read(_CHUNK)
            if not chunk:
                break
            parts = (rest + chunk).split(b"\n")
            rest = parts.pop()
            for line in parts:
                if clock() >= deadline:
                    finished = False
                    break
                offset += len(line) + 1
                stats.lines_read += 1
                cur["lines_read"] += 1
                if not line.strip():
                    _count(stats.other_line_types, "blank")
                    _count(cur["other_line_types"], "blank")
                    continue
                try:
                    obj = json.loads(line.decode("utf-8"))
                except (UnicodeDecodeError, ValueError):
                    obj = None
                rec = extract_line(obj, tf.kind, ctx)
                if rec is None:
                    kind = _other_type(obj)
                    _count(stats.other_line_types, kind)
                    _count(cur["other_line_types"], kind)
                    continue
                append_line(shard, rec.to_json())
                stats.records_emitted += 1
                cur["records_emitted"] += 1
    cur["offset"] = offset
    cur["inode"] = st.st_ino
    cur["size"] = st.st_size
    cur["updated_at"] = ctx.recorded_at
    return finished


def ingest(
    session_id: str,
    deadline_s: float,
    only_agent: str | None = None,
    trigger: str = "hook",
    *,
    data_dir: Path | None = None,
    projects_dir: Path | None = None,
    now: datetime | None = None,
    clock: Callable[[], float] = time.monotonic,
) -> IngestStats:
    """Incrementally extract one session's transcripts into raw/transcript/<date>.jsonl.

    Each file is processed under state/cursors.lock, from its cursor to EOF, so two
    concurrent ingests (Stop and SubagentStop fire together) emit every line exactly
    once. `deadline_s` bounds wall time; whatever is left is picked up next time.
    """
    t0 = clock()
    _check_session_id(session_id)
    if only_agent is not None and not _AGENT_ID_RE.fullmatch(only_agent):
        raise ValueError("agent id must match [A-Za-z0-9_-]{1,64}")
    if trigger not in TRIGGERS:
        raise ValueError("trigger must be 'hook' or 'cli'")
    if isinstance(deadline_s, bool) or not isinstance(deadline_s, int | float) or deadline_s < 0:
        raise ValueError("deadline_s must be a non-negative number")
    deadline = t0 + deadline_s

    data_dir = ensure_data_dir(resolve_data_dir() if data_dir is None else Path(data_dir))
    salt = load_or_create_salt(data_dir)
    config = load_config(data_dir, missing_ok=True)
    regex = re.compile(config["task_id_branch_regex"])
    protected = frozenset(config["protected_branches"])
    recorded_at = utc_now_iso(now)
    shard = shard_path(data_dir / "raw", "transcript", now)
    state_dir = data_dir / "state"

    files = discover(session_id, projects_dir, main_path=_known_main_path(state_dir, session_id))
    if only_agent is not None:
        files = [f for f in files if f.agent_id == only_agent]
    stats = IngestStats(files_seen=len(files))

    lock_fd = os.open(state_dir / CURSORS_LOCK, os.O_RDWR | os.O_CREAT, 0o600)
    try:
        for tf in files:
            if clock() >= deadline or not _lock(lock_fd, deadline, clock):
                stats.stopped_by_deadline = True
                break
            try:
                try:
                    st = os.stat(tf.path)
                except OSError:
                    continue  # vanished between discovery and now; nothing to read
                cursors = _load_cursors(state_dir)
                cur = _cursor_for(cursors, tf, session_id, st)
                if cur.pop("restarted", False):
                    stats.files_restarted += 1
                agent_type, spawn_depth = _read_meta(tf)
                ctx = ExtractContext(
                    salt=salt,
                    task_id_branch_regex=regex,
                    protected_branches=protected,
                    recorded_at=recorded_at,
                    trigger=trigger,
                    recorder_version=__version__,
                    session_id=session_id,
                    agent_id=tf.agent_id,
                    agent_type=agent_type,
                    spawn_depth=spawn_depth,
                )
                finished = _ingest_file(tf, cur, ctx, shard, stats, deadline, clock)
                atomic_write(
                    state_dir / CURSORS_FILE, json.dumps(cursors, sort_keys=True, indent=1) + "\n"
                )
            finally:
                fcntl.flock(lock_fd, fcntl.LOCK_UN)
            if not finished:
                stats.stopped_by_deadline = True
                break
    finally:
        os.close(lock_fd)
    stats.elapsed_ms = int((clock() - t0) * 1000)
    return stats
