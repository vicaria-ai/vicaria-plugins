"""`sg doctor`, `sg privacy-audit` and `sg export` (spec section 15).

The doctor only reports what it can observe: a check is green because of evidence on
disk, on the wire or in the environment (a synthetic OTLP POST that lands as a raw
line, an `env` block read from the settings files Claude Code loads), never because a
process claims to be healthy. The privacy audit is the last line of defence before a
bundle leaves the machine, so it is deliberately dumb: it scans bytes and key names and
knows nothing about which module wrote a file. `export` refuses unless that audit is
clean, and never packs `state/` or the salt.
"""

from __future__ import annotations

import contextlib
import http.client
import json
import os
import re
import secrets
import statistics
import subprocess
import tarfile
import tempfile
import time
from collections.abc import Iterator, Mapping
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from pathlib import Path
from urllib.parse import urlsplit

from smart_gateway.config import DEFAULT_CONFIG, ConfigError, load_config
from smart_gateway.ids import utc_now_iso
from smart_gateway.rawlog import atomic_write, iter_lines

__all__ = [
    "AUDIT_DIRS",
    "BENCH_FILE",
    "BILLING_MAX_AGE_DAYS",
    "BUILD_MAX_AGE_DAYS",
    "CHECK_NAMES",
    "FORBIDDEN_KEYS",
    "MAX_STRING_LEN",
    "REQUIRED_SETTINGS_ENV",
    "UNBOUND_SHARE_MAX",
    "WINDOW_DAYS",
    "Check",
    "ExportRefused",
    "ExportResult",
    "Finding",
    "bench_hook",
    "doctor",
    "export",
    "privacy_audit",
    "settings_env",
]

WINDOW_DAYS = 7  # "last 7 d" in every doctor line
BILLING_MAX_AGE_DAYS = 8  # weekly cadence plus a day of slack
BUILD_MAX_AGE_DAYS = 8
UNBOUND_SHARE_MAX = 0.5  # more than half the recent attempts unbound = the conventions failed
BENCH_RUNS = 20
BENCH_P95_MAX_MS = 1000  # a sync hook has 5 s; the shim alone must be far below that
BENCH_FILE = "bench.json"  # state/bench.json {p50_ms, p95_ms, measured_at}
PROBE_MODEL = "sg.doctor.probe"  # the synthetic api_refusal line is recognisable in raw/otel
CHECK_NAMES = (
    "data_dir_writable",
    "config_valid",
    "salt_present",
    "last_session_start",
    "sessions_without_hooks",
    "otel_settings",
    "receiver",
    "transcript_cursors",
    "hook_errors",
    "unbound_share",
    "admin_key",
    "billing_fetch",
    "last_build",
)
# What `sg init` writes and the receiver needs; the endpoint is checked separately
# against config.otel.port.
REQUIRED_SETTINGS_ENV = {
    "CLAUDE_CODE_ENABLE_TELEMETRY": "1",
    "OTEL_LOGS_EXPORTER": "otlp",
    "OTEL_EXPORTER_OTLP_PROTOCOL": "http/json",
}
_ADMIN_KEY_ENV = "SG_ADMIN_API_KEY"
_ADMIN_KEY_PREFIX = "sk-ant-admin"
_INGEST_EVENTS = frozenset({"Stop", "SubagentStop", "SessionEnd"})
_SALT_RE = re.compile(r"[0-9a-f]{64}")

AUDIT_DIRS = ("raw", "derived", "reports")
MAX_STRING_LEN = 200
# Key names under which Claude Code (or a careless recorder) would carry free text.
FORBIDDEN_KEYS = frozenset(
    {
        "prompt",
        "last_assistant_message",
        "tool_input",
        "tool_response",
        "cwd",
        "transcript_path",
        "git_branch",
        "gitBranch",
        "error",
        "custom_instructions",
        "content",
        "text",
        "thinking",
        "response",
        "tool_parameters",
        "email",
    }
)
_DECISION_SCHEMA = "sg.decision.v1"
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_PATH_RE = re.compile(r"/.+/")
_MEASURE_KEYS = ({"value", "source"}, {"unknown"})
_EXPORT_PREFIX = "sg-export"


# -- doctor


@dataclass(frozen=True, slots=True)
class Check:
    """One red/green line of `sg doctor`; `detail` says what was observed or what to run."""

    name: str
    ok: bool
    detail: str

    def to_json(self) -> dict[str, object]:
        return {"name": self.name, "ok": self.ok, "detail": self.detail}


def doctor(
    data_dir: Path,
    bench_hook: bool = False,
    *,
    now: datetime | None = None,
    environ: Mapping[str, str] | None = None,
    home: Path | None = None,
    cwd: Path | None = None,
) -> tuple[list[Check], int]:
    """Run every section-15 check against `data_dir`; exit code 1 when any is red.

    `now`, `environ`, `home` and `cwd` are seams for tests; the defaults are the real
    clock, process environment, `Path.home()` and the current directory.
    """
    data_dir = Path(data_dir)
    now = datetime.now(UTC) if now is None else now.astimezone(UTC)
    env = os.environ if environ is None else environ
    home = Path.home() if home is None else Path(home)
    cwd = Path.cwd() if cwd is None else Path(cwd)
    window_start = utc_now_iso(now - timedelta(days=WINDOW_DAYS))

    checks: list[Check] = [_check_writable(data_dir)]
    config, config_check = _check_config(data_dir)
    checks.append(config_check)
    checks.append(_check_salt(data_dir))
    hooks = list(_records(data_dir / "raw" / "hooks"))
    checks.append(_check_last_session_start(hooks, now))
    checks.append(_check_sessions_without_hooks(data_dir, hooks, window_start))
    external = config["otel"]["mode"] == "external"
    port = int(config["otel"]["port"])
    checks.append(_check_settings(home, cwd, port, external))
    checks.append(_check_receiver(data_dir, port, external))
    checks.append(_check_cursors(data_dir, hooks, window_start))
    checks.append(_check_hook_errors(data_dir, window_start))
    checks.append(_check_unbound_share(data_dir, window_start))
    checks.append(_check_admin_key(env))
    checks.append(_check_billing_fetch(data_dir, now))
    checks.append(_check_last_build(data_dir, now))
    if bench_hook:
        checks.append(_check_bench(data_dir, now))
    return checks, (0 if all(c.ok for c in checks) else 1)


def _check_writable(data_dir: Path) -> Check:
    if not data_dir.is_dir():
        return Check("data_dir_writable", False, "data dir does not exist (run sg init)")
    probe = data_dir / f".sg-doctor-{secrets.token_hex(4)}"
    try:
        fd = os.open(probe, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        os.close(fd)
        probe.unlink()
    except OSError as e:
        return Check("data_dir_writable", False, f"cannot create a file: {e.__class__.__name__}")
    return Check("data_dir_writable", True, "data dir exists and accepts new files")


def _check_config(data_dir: Path) -> tuple[dict, Check]:
    """The validated config, or the defaults with a red check when config.json is unusable."""
    try:
        config = load_config(data_dir)
    except ConfigError as e:
        return dict(DEFAULT_CONFIG), Check("config_valid", False, f"config.json: {e}")
    otel = config["otel"]
    detail = f"config.json valid (otel.mode {otel['mode']}, port {otel['port']})"
    return config, Check("config_valid", True, detail)


def _check_salt(data_dir: Path) -> Check:
    try:
        text = (data_dir / "salt").read_text(encoding="ascii").strip()
    except (OSError, UnicodeDecodeError) as e:
        return Check("salt_present", False, f"salt unreadable: {e.__class__.__name__}")
    if not _SALT_RE.fullmatch(text):
        return Check("salt_present", False, "salt is not 64 hex characters")
    return Check("salt_present", True, "salt present (64 hex)")


def _check_last_session_start(hooks: list[dict], now: datetime) -> Check:
    starts = [r["recorded_at"] for r in hooks if r.get("event") == "SessionStart"]
    if not starts:
        return Check(
            "last_session_start",
            False,
            "no SessionStart hook line yet (start claude with --plugin-dir <repo>/plugin)",
        )
    age = _age_s(max(starts), now)
    ok = age is not None and age <= WINDOW_DAYS * 86400
    return Check("last_session_start", ok, f"last SessionStart {_age_text(age)} ago")


def _check_sessions_without_hooks(data_dir: Path, hooks: list[dict], since: str) -> Check:
    hooked = {r["session_id"] for r in hooks if isinstance(r.get("session_id"), str)}
    seen: set[str] = set()
    for kind in ("otel", "transcript"):
        for rec in _records(data_dir / "raw" / kind):
            sid = rec.get("session_id")
            if isinstance(sid, str) and rec["recorded_at"] >= since:
                seen.add(sid)
    missing = sorted(seen - hooked)
    if missing:
        shown = ", ".join(missing[:3]) + (", ..." if len(missing) > 3 else "")
        detail = (
            f"{len(missing)} session(s) in the last {WINDOW_DAYS} d have OTEL/transcript "
            f"lines but no hook lines (plugin not loaded?): {shown}"
        )
        return Check("sessions_without_hooks", False, detail)
    detail = f"every OTEL/transcript session of the last {WINDOW_DAYS} d has hook lines"
    return Check("sessions_without_hooks", True, detail)


def settings_env(home: Path, cwd: Path) -> tuple[dict[str, str], list[str]]:
    """The effective `env` block of user + project settings (project wins), and the
    files that contributed one. Unreadable or non-object files contribute nothing."""
    env: dict[str, str] = {}
    files: list[str] = []
    for label, path in (
        ("user", home / ".claude" / "settings.json"),
        ("project", cwd / ".claude" / "settings.json"),
    ):
        try:
            obj = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        block = obj.get("env") if isinstance(obj, dict) else None
        if not isinstance(block, dict):
            continue
        files.append(label)
        env.update({k: str(v) for k, v in block.items() if isinstance(k, str)})
    return env, files


def _check_settings(home: Path, cwd: Path, port: int, external: bool) -> Check:
    if external:
        detail = "otel.mode is external: settings are not managed; collection is transcript-only"
        return Check("otel_settings", True, detail)
    env, files = settings_env(home, cwd)
    if not files:
        detail = (
            "no `env` block in ~/.claude/settings.json or ./.claude/settings.json (run sg init)"
        )
        return Check("otel_settings", False, detail)
    problems = [
        f"{key}={env[key]!r} (need {want!r})" if key in env else f"{key} missing (need {want!r})"
        for key, want in REQUIRED_SETTINGS_ENV.items()
        if env.get(key) != want
    ]
    endpoint = env.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    if endpoint is None:
        problems.append(f"OTEL_EXPORTER_OTLP_ENDPOINT missing (need http://127.0.0.1:{port})")
    else:
        parts = urlsplit(endpoint)
        try:
            ep_port = parts.port
        except ValueError:
            ep_port = None
        if parts.hostname not in ("127.0.0.1", "localhost") or ep_port != port:
            problems.append(f"OTEL_EXPORTER_OTLP_ENDPOINT is not http://127.0.0.1:{port}")
    where = "+".join(files) + " settings"
    if problems:
        return Check("otel_settings", False, f"{where}: " + "; ".join(problems))
    notes = ""
    if env.get("OTEL_METRICS_INCLUDE_VERSION") != "true":
        notes = " (OTEL_METRICS_INCLUDE_VERSION=true absent: harness version stays not_reported)"
    return Check("otel_settings", True, f"{where}: OTEL env present, protocol http/json{notes}")


def _probe_payload(probe_id: str) -> bytes:
    """One allowlisted `api_refusal` record with no session id: merge ignores the event and
    the build creates no session for it, so the probe is visible only as a raw line."""
    attrs = [
        {"key": "event.name", "value": {"stringValue": "claude_code.api_refusal"}},
        {"key": "model", "value": {"stringValue": PROBE_MODEL}},
        {"key": "request_id", "value": {"stringValue": probe_id}},
    ]
    record = {
        "timeUnixNano": str(time.time_ns()),
        "body": {"stringValue": "claude_code.api_refusal"},
        "attributes": attrs,
    }
    payload = {
        "resourceLogs": [
            {
                "resource": {"attributes": []},
                "scopeLogs": [{"scope": {"name": "sg.doctor"}, "logRecords": [record]}],
            }
        ]
    }
    return json.dumps(payload).encode("utf-8")


def _check_receiver(data_dir: Path, port: int, external: bool) -> Check:
    if external:
        detail = "otel.mode is external: no local receiver expected (transcript-only)"
        return Check("receiver", True, detail)
    probe_id = f"sg-doctor-{secrets.token_hex(8)}"
    body = _probe_payload(probe_id)
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=2.0)
    try:
        conn.request("POST", "/v1/logs", body=body, headers={"Content-Type": "application/json"})
        status = conn.getresponse().status
    except ConnectionRefusedError:
        detail = (
            f"nothing listens on 127.0.0.1:{port} (the next SessionStart spawns the "
            "receiver, or run `sg otel serve`)"
        )
        return Check("receiver", False, detail)
    except OSError as e:
        return Check("receiver", False, f"127.0.0.1:{port}: {e.__class__.__name__}")
    finally:
        conn.close()
    if status != 200:
        hint = " (not the sg receiver? it expects OTLP http/json)" if status == 415 else ""
        return Check("receiver", False, f"POST /v1/logs on 127.0.0.1:{port} -> {status}{hint}")
    if _probe_landed(data_dir, probe_id):
        detail = f"receiver on 127.0.0.1:{port} answered 200 and the probe landed in raw/otel"
        return Check("receiver", True, detail)
    detail = (
        f"127.0.0.1:{port} answered 200 but the probe is not in raw/otel (another process "
        "on the port, or a receiver on a different data dir)"
    )
    return Check("receiver", False, detail)


def _probe_landed(data_dir: Path, probe_id: str) -> bool:
    otel_dir = data_dir / "raw" / "otel"
    for shard in sorted(otel_dir.glob("*.jsonl"), reverse=True):
        for _, rec in iter_lines(shard):
            attrs = rec.get("attrs")
            if isinstance(attrs, dict) and attrs.get("request_id") == probe_id:
                return True
    return False


def _check_cursors(data_dir: Path, hooks: list[dict], since: str) -> Check:
    triggers = [
        r["recorded_at"]
        for r in hooks
        if r.get("event") in _INGEST_EVENTS and r["recorded_at"] >= since
    ]
    if not triggers:
        detail = f"no Stop/SubagentStop/SessionEnd hook line in the last {WINDOW_DAYS} d"
        return Check("transcript_cursors", True, detail)
    last = max(triggers)
    try:
        obj = json.loads((data_dir / "state" / "cursors.json").read_text(encoding="utf-8"))
        files = obj["files"]
        updated = [
            f["updated_at"]
            for f in files.values()
            if isinstance(f, dict) and isinstance(f.get("updated_at"), str)
        ]
    except (OSError, ValueError, KeyError, AttributeError, TypeError):
        detail = "state/cursors.json missing or unreadable while Stop hooks exist (ingest failing?)"
        return Check("transcript_cursors", False, detail)
    if not updated or max(updated) < last:
        detail = (
            f"cursors last updated {max(updated) if updated else 'never'}, before the last "
            f"ingest hook at {last} (no transcript found? see raw/hook_errors.log)"
        )
        return Check("transcript_cursors", False, detail)
    return Check("transcript_cursors", True, f"{len(files)} cursor(s), fresh as of {max(updated)}")


def _check_hook_errors(data_dir: Path, since: str) -> Check:
    try:
        lines = (data_dir / "raw" / "hook_errors.log").read_text(encoding="utf-8").splitlines()
    except FileNotFoundError:
        return Check("hook_errors", True, "no raw/hook_errors.log")
    except (OSError, UnicodeDecodeError) as e:
        return Check("hook_errors", False, f"hook_errors.log unreadable: {e.__class__.__name__}")
    recent = sum(1 for line in lines if line.split(" ", 1)[0] >= since)
    detail = f"{recent} hook error line(s) in the last {WINDOW_DAYS} d ({len(lines)} total)"
    return Check("hook_errors", recent == 0, detail)


def _check_unbound_share(data_dir: Path, since: str) -> Check:
    path = data_dir / "derived" / "attempts.jsonl"
    if not path.is_file():
        return Check("unbound_share", False, "no derived/attempts.jsonl (run sg build)")
    total = unbound = 0
    for _, rec in iter_lines(path):
        span = rec.get("span")
        started = span.get("started_at") if isinstance(span, dict) else None
        if not isinstance(started, str) or started < since:
            continue
        total += 1
        task = rec.get("task_id")
        if not isinstance(task, dict) or "unknown" in task:
            unbound += 1
    if total == 0:
        return Check("unbound_share", True, f"no attempts started in the last {WINDOW_DAYS} d")
    share = unbound / total
    detail = f"{unbound}/{total} attempts of the last {WINDOW_DAYS} d unbound ({share:.0%})"
    if share > UNBOUND_SHARE_MAX:
        detail += " (see `sg task list --unbound` for bind commands)"
    return Check("unbound_share", share <= UNBOUND_SHARE_MAX, detail)


def _check_admin_key(env: Mapping[str, str]) -> Check:
    key = env.get(_ADMIN_KEY_ENV, "")
    if not key:
        detail = f"{_ADMIN_KEY_ENV} not set (billing fetch refused; cost_billed stays unknown)"
        return Check("admin_key", False, detail)
    if not key.startswith(_ADMIN_KEY_PREFIX):
        return Check("admin_key", False, f"{_ADMIN_KEY_ENV} is not an admin key (sk-ant-admin...)")
    return Check("admin_key", True, f"{_ADMIN_KEY_ENV} present")


def _check_billing_fetch(data_dir: Path, now: datetime) -> Check:
    fetched: list[str] = []
    for shard in sorted((data_dir / "raw" / "billing").glob("*.jsonl")):
        for _, rec in iter_lines(shard):
            if isinstance(rec.get("fetched_at"), str):
                fetched.append(rec["fetched_at"])
            break  # every row of one fetch shares fetched_at
    if not fetched:
        return Check("billing_fetch", False, "no billing fetch yet (run sg billing fetch)")
    age = _age_s(max(fetched), now)
    ok = age is not None and age <= BILLING_MAX_AGE_DAYS * 86400
    return Check("billing_fetch", ok, f"last billing fetch {_age_text(age)} ago")


def _check_last_build(data_dir: Path, now: datetime) -> Check:
    try:
        obj = json.loads((data_dir / "derived" / "build.json").read_text(encoding="utf-8"))
        built_at = obj["built_at"]
    except (OSError, ValueError, KeyError, TypeError):
        return Check("last_build", False, "no derived/build.json (run sg build)")
    age = _age_s(built_at, now) if isinstance(built_at, str) else None
    ok = age is not None and age <= BUILD_MAX_AGE_DAYS * 86400
    return Check("last_build", ok, f"last build {_age_text(age)} ago")


def _check_bench(data_dir: Path, now: datetime) -> Check:
    result = bench_hook()
    if result is None:
        detail = "plugin/bin/sg-hook not found next to the package (not a repo checkout)"
        return Check("hook_bench", False, detail)
    result["measured_at"] = utc_now_iso(now)
    atomic_write(
        data_dir / "state" / BENCH_FILE, json.dumps(result, indent=2, sort_keys=True) + "\n"
    )
    detail = f"shim wall time p50 {result['p50_ms']} ms, p95 {result['p95_ms']} ms"
    return Check("hook_bench", result["p95_ms"] <= BENCH_P95_MAX_MS, detail)


def bench_hook(runs: int = BENCH_RUNS, *, shim: Path | None = None) -> dict[str, int] | None:
    """Wall time of the shim (interpreter start-up included) over `runs` invocations.

    Runs against a throwaway SG_DATA_DIR so the benchmark never lands in the user's raw
    files; the payload is a SubagentStart with no cwd, the event with the least extra work.
    None when the shim is not on disk (a pip install without the repo).
    """
    if shim is None:
        shim = Path(__file__).resolve().parents[2] / "plugin" / "bin" / "sg-hook"
    if not shim.is_file():
        return None
    payload = json.dumps(
        {
            "hook_event_name": "SubagentStart",
            "session_id": "00000000-0000-4000-8000-00000000bench",
            "agent_id": "bench",
            "agent_type": "bench",
        }
    ).encode("utf-8")
    samples: list[float] = []
    with tempfile.TemporaryDirectory(prefix="sg-bench-") as tmp:
        env = {**os.environ, "SG_DATA_DIR": tmp}
        for _ in range(runs):
            t0 = time.perf_counter()
            subprocess.run(
                ["sh", str(shim), "SubagentStart"],
                input=payload,
                env=env,
                capture_output=True,
                timeout=30,
                check=False,
            )
            samples.append((time.perf_counter() - t0) * 1000)
    samples.sort()
    p95 = samples[max(0, -(-95 * len(samples) // 100) - 1)]  # nearest-rank
    return {"p50_ms": int(statistics.median(samples)), "p95_ms": int(p95)}


def _records(shard_dir: Path) -> Iterator[dict]:
    """Every intact record of a raw kind that carries a str recorded_at, in shard order."""
    for shard in sorted(shard_dir.glob("*.jsonl")):
        for _, rec in iter_lines(shard):
            if isinstance(rec.get("recorded_at"), str):
                yield rec


def _age_s(iso: str, now: datetime) -> float | None:
    try:
        then = datetime.fromisoformat(iso)
    except ValueError:
        return None
    if then.tzinfo is None:
        then = then.replace(tzinfo=UTC)
    return max(0.0, (now - then).total_seconds())


def _age_text(age: float | None) -> str:
    if age is None:
        return "an unparsable time"
    if age < 3600:
        return f"{age / 60:.0f} min"
    if age < 2 * 86400:
        return f"{age / 3600:.1f} h"
    return f"{age / 86400:.1f} d"


# -- privacy audit


@dataclass(frozen=True, slots=True)
class Finding:
    """One audit hit. `detail` describes the hit without repeating the offending value,
    so printing findings cannot itself leak what they found."""

    file: str  # relative to the audited data dir
    line: int | None  # 1-based for JSONL/text files; None for whole-file JSON
    location: str  # JSON pointer-ish key path, "" for text lines
    rule: str  # forbidden_key | email | path | long_string
    detail: str

    def to_json(self) -> dict[str, object]:
        return {
            "file": self.file,
            "line": self.line,
            "location": self.location,
            "rule": self.rule,
            "detail": self.detail,
        }

    def __str__(self) -> str:
        where = self.file if self.line is None else f"{self.file}:{self.line}"
        loc = f" {self.location}" if self.location else ""
        return f"{where}{loc}: {self.rule} ({self.detail})"


def privacy_audit(path: Path) -> list[Finding]:
    """Scan raw/, derived/ and reports/ under `path` for anything that looks like text.

    JSON and JSON Lines files are walked structurally (forbidden keys, e-mail-shaped and
    absolute-path-shaped strings, strings over 200 chars); torn lines and other text
    files are scanned line by line for e-mails and paths. Empty list = clean.
    """
    root = Path(path)
    findings: list[Finding] = []
    for sub in AUDIT_DIRS:
        base = root / sub
        if not base.is_dir():
            continue
        for file in sorted(p for p in base.rglob("*") if p.is_file()):
            rel = file.relative_to(root).as_posix()
            findings.extend(_audit_file(file, rel))
    return findings


def _audit_file(file: Path, rel: str) -> list[Finding]:
    out: list[Finding] = []
    data = file.read_bytes()
    if file.suffix == ".json":
        try:
            obj = json.loads(data.decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            _audit_text_lines(data, rel, out)
        else:
            _walk(obj, "", rel, None, out)
        return out
    structured = file.suffix == ".jsonl"
    for line_no, raw in enumerate(data.split(b"\n"), start=1):
        if not raw.strip():
            continue
        obj: object = None
        if structured:
            with contextlib.suppress(UnicodeDecodeError, ValueError):
                obj = json.loads(raw.decode("utf-8"))
        if structured and obj is not None:
            _walk(obj, "", rel, line_no, out)
        else:
            _audit_text(raw.decode("utf-8", errors="replace"), rel, line_no, out)
    return out


def _audit_text_lines(data: bytes, rel: str, out: list[Finding]) -> None:
    for line_no, raw in enumerate(data.split(b"\n"), start=1):
        if raw.strip():
            _audit_text(raw.decode("utf-8", errors="replace"), rel, line_no, out)


def _audit_text(line: str, rel: str, line_no: int, out: list[Finding]) -> None:
    """Unstructured lines: only the shape rules apply (a markdown paragraph is long)."""
    if _EMAIL_RE.search(line):
        out.append(Finding(rel, line_no, "", "email", "e-mail-shaped string"))
    if any(_PATH_RE.match(tok) for tok in line.split()):
        out.append(Finding(rel, line_no, "", "path", "absolute-path-shaped string"))


def _is_numeric_measure(value: object) -> bool:
    """A Measure carrying a number/bool (e.g. `tokens.thinking`) is a count, not text."""
    if not isinstance(value, dict) or set(value) not in _MEASURE_KEYS:
        return False
    v = value.get("value")
    return v is None or isinstance(v, int | float | bool)


def _walk(value: object, loc: str, rel: str, line: int | None, out: list[Finding]) -> None:
    if isinstance(value, dict):
        # The decision record's `text` is a sentence gate.py composes from config labels
        # and numbers (never harness data); it is the one string allowed to be long.
        decision = value.get("schema") == _DECISION_SCHEMA
        for key, child in value.items():
            child_loc = f"{loc}/{key}"
            if decision and key == "text" and isinstance(child, str):
                _check_string(child, child_loc, rel, line, out, length=False)
                continue
            if key in FORBIDDEN_KEYS and not _is_numeric_measure(child):
                out.append(Finding(rel, line, child_loc, "forbidden_key", f"key {key!r}"))
            _walk(child, child_loc, rel, line, out)
    elif isinstance(value, list):
        for i, child in enumerate(value):
            _walk(child, f"{loc}[{i}]", rel, line, out)
    elif isinstance(value, str):
        _check_string(value, loc, rel, line, out)


def _check_string(
    s: str, loc: str, rel: str, line: int | None, out: list[Finding], *, length: bool = True
) -> None:
    if _EMAIL_RE.search(s):
        out.append(Finding(rel, line, loc, "email", "e-mail-shaped string"))
    if _PATH_RE.match(s):
        out.append(Finding(rel, line, loc, "path", "absolute-path-shaped string"))
    if length and len(s) > MAX_STRING_LEN:
        out.append(Finding(rel, line, loc, "long_string", f"{len(s)} chars"))


# -- export


class ExportRefused(Exception):
    """The privacy audit found something; nothing was written. CLI exit code 2 (refused)."""

    exit_code = 2

    def __init__(self, findings: list[Finding]) -> None:
        self.findings = findings
        super().__init__(f"privacy audit found {len(findings)} issue(s); export refused")


@dataclass(frozen=True, slots=True)
class ExportResult:
    path: Path
    members: tuple[str, ...]  # archive member names, in archive order
    size_bytes: int

    def to_json(self) -> dict[str, object]:
        return {
            "path": str(self.path),
            "members": list(self.members),
            "size_bytes": self.size_bytes,
        }


def export(data_dir: Path, out: Path, with_reports: bool = False) -> ExportResult:
    """Pack raw/ + config.json + derived/build.json (+ reports/) into `out` (tar.gz).

    Refuses with ExportRefused when the privacy audit is not clean. `state/`, the salt
    and the other derived files are never packed: state holds transcript paths, the salt
    would let a recipient test guesses against the hashes, and derived files are
    rebuilt from raw by the recipient's own `sg build --raw-dir`.
    """
    data_dir = Path(data_dir)
    out = Path(out)
    findings = privacy_audit(data_dir)
    if findings:
        raise ExportRefused(findings)
    files: list[Path] = sorted(p for p in (data_dir / "raw").rglob("*") if p.is_file())
    for extra in (data_dir / "config.json", data_dir / "derived" / "build.json"):
        if extra.is_file():
            files.append(extra)
    if with_reports:
        files.extend(sorted(p for p in (data_dir / "reports").rglob("*") if p.is_file()))
    members: list[str] = []
    out.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=out.parent, prefix=f".{out.name}.", suffix=".tmp")
    try:
        os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as fobj, tarfile.open(fileobj=fobj, mode="w:gz") as tar:
            for file in files:
                name = f"{_EXPORT_PREFIX}/{file.relative_to(data_dir).as_posix()}"
                info = tar.gettarinfo(str(file), arcname=name)
                info.uid = info.gid = 0
                info.uname = info.gname = ""
                info.mode = 0o600
                with file.open("rb") as src:
                    tar.addfile(info, src)
                members.append(name)
        os.replace(tmp, out)
    except BaseException:
        with contextlib.suppress(FileNotFoundError):
            os.unlink(tmp)
        raise
    return ExportResult(out, tuple(members), out.stat().st_size)
