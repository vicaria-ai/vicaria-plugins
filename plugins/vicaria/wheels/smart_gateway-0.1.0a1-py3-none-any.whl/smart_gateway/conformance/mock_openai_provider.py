"""A scripted OpenAI chat-completions provider that records every request at the wire.

The Anthropic-format twin of ``mock_provider.py``, for harnesses that speak
OpenAI (OpenCode, Codex). Each ``POST /v1/chat/completions`` consumes the next
step of a script — ``{"text": ...}`` ends the turn, ``{"tool_call": {"name_prefix":
..., "arguments": {...}}}`` asks for the first offered tool whose name starts
with the prefix — and the last step repeats. Replies stream as SSE because
OpenCode streams.

AUXILIARY CALLS ARE COUNTED SEPARATELY

OpenCode makes a second, unrelated model call per run to generate a thread
title. It is a real provider request and is recorded, but it is not the user's
turn, and a check asserting "one provider request for this prompt" must not
trip over it. ``main_requests`` excludes it (by its own system prompt);
``requests`` keeps everything, so a zero-request assertion is zero of *both*.

What is recorded is what a check needs and no more: the model, the
``reasoning_effort``, how many messages and tool results, which tools were
offered, whether a staging marker leaked through, and which ``VICARIA-*``
sentinels appeared. Message text itself is never kept.
"""

from __future__ import annotations

import json
import re
import threading
from collections.abc import Mapping, Sequence
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlsplit

from smart_gateway.control.marker import BLOCK_OPEN

_SENTINEL_RE = re.compile(r"VICARIA-[A-Z0-9-]+")

#: How OpenCode's title-generation call identifies itself. Matched on the system
#: prompt rather than a header, because that is what the harness actually sends.
_AUX_SYSTEM_PREFIX = "You are a title generator"


def _texts(messages: Sequence[Mapping[str, Any]]) -> list[str]:
    out: list[str] = []
    for message in messages:
        content = message.get("content")
        if isinstance(content, str):
            out.append(content)
        elif isinstance(content, list):
            out += [p.get("text") or "" for p in content if isinstance(p, dict)]
    return out


class MockOpenAIProvider:
    def __init__(self, script: Sequence[Mapping[str, Any]] | None = None) -> None:
        self.script: list[Mapping[str, Any]] = list(script or [{"text": "ok"}])
        self.requests: list[dict[str, Any]] = []
        self._turn = 0
        self._lock = threading.Lock()
        provider = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args: Any) -> None:
                pass

            def _json(self, status: int, obj: Mapping[str, Any]) -> None:
                data = json.dumps(obj).encode("utf-8")
                self.send_response(status)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def _sse(self, chunks: Sequence[Mapping[str, Any]]) -> None:
                payload = (
                    "".join(f"data: {json.dumps(c)}\n\n" for c in chunks) + "data: [DONE]\n\n"
                ).encode("utf-8")
                self.send_response(200)
                self.send_header("content-type", "text/event-stream")
                self.send_header("content-length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def do_GET(self) -> None:
                if urlsplit(self.path).path.endswith("/models"):
                    return self._json(
                        200,
                        {"object": "list", "data": [{"id": "tiny", "object": "model"}]},
                    )
                self._json(404, {"error": {"message": self.path}})

            def do_POST(self) -> None:
                length = int(self.headers.get("content-length") or 0)
                raw = self.rfile.read(length) if length else b""
                try:
                    body = json.loads(raw) if raw else {}
                except json.JSONDecodeError:
                    body = {}
                if not isinstance(body, dict):
                    body = {}
                messages = body.get("messages") if isinstance(body.get("messages"), list) else []
                texts = _texts(messages)
                system = next(
                    (
                        m.get("content")
                        for m in messages
                        if isinstance(m, dict) and m.get("role") == "system"
                    ),
                    "",
                )
                tool_results = [
                    m for m in messages if isinstance(m, dict) and m.get("role") == "tool"
                ]
                offered = [
                    (t.get("function") or {}).get("name")
                    for t in body.get("tools") or []
                    if isinstance(t, dict)
                ]
                provider._record(
                    {
                        "path": urlsplit(self.path).path,
                        "auxiliary": str(system).startswith(_AUX_SYSTEM_PREFIX),
                        "model": body.get("model"),
                        "effort": body.get("reasoning_effort"),
                        "n_messages": len(messages),
                        "n_tool_results": len(tool_results),
                        "last_tool_result": (
                            str(tool_results[-1].get("content"))[:300] if tool_results else None
                        ),
                        "tools": offered,
                        "has_staging_block": any(BLOCK_OPEN in t for t in texts),
                        "sentinels": sorted({s for t in texts for s in _SENTINEL_RE.findall(t)}),
                    }
                )
                if not urlsplit(self.path).path.endswith("/chat/completions"):
                    return self._json(404, {"error": {"message": self.path}})
                model = body.get("model")
                base = {
                    "id": "chatcmpl-mock",
                    "object": "chat.completion.chunk",
                    "created": 0,
                    "model": model,
                }
                usage = {"prompt_tokens": 10, "completion_tokens": 2, "total_tokens": 12}
                if str(system).startswith(_AUX_SYSTEM_PREFIX):
                    # The title call is not part of the script: answering it from
                    # the script would consume a step the user's turn needs.
                    return self._sse(
                        [
                            {
                                **base,
                                "choices": [
                                    {
                                        "index": 0,
                                        "delta": {"content": "title"},
                                        "finish_reason": None,
                                    }
                                ],
                            },
                            {
                                **base,
                                "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                                "usage": usage,
                            },
                        ]
                    )
                step = provider._next_step()
                if "tool_call" in step:
                    spec = step["tool_call"]
                    name = next(
                        (
                            n
                            for n in offered
                            if isinstance(n, str) and n.startswith(spec.get("name_prefix", ""))
                        ),
                        spec.get("name_prefix", "unknown"),
                    )
                    return self._sse(
                        [
                            {
                                **base,
                                "choices": [
                                    {
                                        "index": 0,
                                        "delta": {
                                            "role": "assistant",
                                            "tool_calls": [
                                                {
                                                    "index": 0,
                                                    "id": "call_mock_1",
                                                    "type": "function",
                                                    "function": {
                                                        "name": name,
                                                        "arguments": json.dumps(
                                                            dict(spec.get("arguments") or {})
                                                        ),
                                                    },
                                                }
                                            ],
                                        },
                                        "finish_reason": None,
                                    }
                                ],
                            },
                            {
                                **base,
                                "choices": [
                                    {"index": 0, "delta": {}, "finish_reason": "tool_calls"}
                                ],
                                "usage": usage,
                            },
                        ]
                    )
                self._sse(
                    [
                        {
                            **base,
                            "choices": [
                                {
                                    "index": 0,
                                    "delta": {
                                        "role": "assistant",
                                        "content": str(step.get("text", "ok")),
                                    },
                                    "finish_reason": None,
                                }
                            ],
                        },
                        {
                            **base,
                            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                            "usage": usage,
                        },
                    ]
                )

        self._http = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._http.serve_forever, daemon=True)

    def _next_step(self) -> Mapping[str, Any]:
        with self._lock:
            step = self.script[min(self._turn, len(self.script) - 1)]
            self._turn += 1
            return step

    def _record(self, entry: dict[str, Any]) -> None:
        with self._lock:
            self.requests.append(entry)

    @property
    def main_requests(self) -> list[dict[str, Any]]:
        """The user's turn, without OpenCode's own title-generation call."""
        with self._lock:
            return [r for r in self.requests if not r["auxiliary"]]

    @property
    def url(self) -> str:
        host, port = self._http.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> MockOpenAIProvider:
        self._thread.start()
        return self

    def stop(self) -> None:
        self._http.shutdown()
        self._http.server_close()
