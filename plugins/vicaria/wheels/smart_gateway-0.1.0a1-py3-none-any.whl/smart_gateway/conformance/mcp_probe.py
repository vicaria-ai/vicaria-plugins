"""A stdio MCP server exposing one tool, logging every method it is asked for.

    python3 -m smart_gateway.conformance.mcp_probe <log.jsonl>

Registered with Claude Code through ``--mcp-config``. When the scripted
provider asks for ``mcp__vicaria__vicaria_probe``, the harness calls
``tools/call`` here, and the reply — ``PROBE-EXECUTED:<echo>`` — is what the
next provider request's ``tool_result`` must carry for §6 check 5 to pass.
Newline-delimited JSON-RPC 2.0, the subset a tool server needs.
"""

from __future__ import annotations

import json
import sys
from typing import Any

TOOL = {
    "name": "vicaria_probe",
    "description": "Returns a fixed probe token so tool execution can be observed at the wire.",
    "inputSchema": {"type": "object", "properties": {"echo": {"type": "string"}}, "required": []},
}


def _reply(obj: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(obj) + "\n")
    sys.stdout.flush()


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    log_path = argv[0] if argv else None

    def log(entry: dict[str, Any]) -> None:
        if log_path:
            with open(log_path, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(entry) + "\n")

    for line in sys.stdin:
        line = line.strip()
        if not line:
            continue
        try:
            req = json.loads(line)
        except json.JSONDecodeError:
            continue
        method, rid, params = req.get("method"), req.get("id"), req.get("params") or {}
        log({"method": method, "params": params if method == "tools/call" else None})
        if method == "initialize":
            _reply(
                {
                    "jsonrpc": "2.0",
                    "id": rid,
                    "result": {
                        "protocolVersion": params.get("protocolVersion", "2025-06-18"),
                        "capabilities": {"tools": {}},
                        "serverInfo": {"name": "vicaria", "version": "0.0.1"},
                    },
                }
            )
        elif method == "tools/list":
            _reply({"jsonrpc": "2.0", "id": rid, "result": {"tools": [TOOL]}})
        elif method == "tools/call":
            echo = (params.get("arguments") or {}).get("echo", "")
            _reply(
                {
                    "jsonrpc": "2.0",
                    "id": rid,
                    "result": {
                        "content": [{"type": "text", "text": f"PROBE-EXECUTED:{echo}"}],
                        "isError": False,
                    },
                }
            )
        elif method == "ping":
            _reply({"jsonrpc": "2.0", "id": rid, "result": {}})
        elif rid is not None:
            _reply(
                {
                    "jsonrpc": "2.0",
                    "id": rid,
                    "error": {"code": -32601, "message": f"unknown method {method}"},
                }
            )
    return 0


if __name__ == "__main__":
    sys.exit(main())
