"""A mock OpenRouter for the end-to-end suite: records everything, answers a script.

The gateway forwards to ``<base>/chat/completions`` and ``<base>/models``; this
server answers both at ``/api/v1``, streams the reply the way OpenRouter does
(SSE chunks that carry ``model`` and ``provider``, the last one with ``usage``
and ``cost`` when the request asked for ``usage.include``), and keeps every
request's headers and body so a test can assert what reached the provider:
the rewritten model, effort and tools, the organization's own key, and no
Vicaria header.
"""

from __future__ import annotations

import json
import threading
from collections.abc import Mapping, Sequence
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlsplit

from smart_gateway.conformance.mock_openai_provider import _AUX_SYSTEM_PREFIX

PROVIDER_NAME = "MockProvider"


class MockOpenRouter:
    def __init__(self, script: Sequence[Mapping[str, Any]] | None = None) -> None:
        self.script: list[Mapping[str, Any]] = list(script or [{"text": "ok"}])
        self.requests: list[dict[str, Any]] = []
        self._turn = 0
        self._lock = threading.Lock()
        provider = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args: Any) -> None:
                pass

            def _json(self, status: int, obj: Mapping[str, Any]) -> None:
                data = json.dumps(obj).encode("utf-8")
                self.send_response(status)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def _sse(self, chunks: Sequence[Mapping[str, Any]]) -> None:
                payload = (
                    ": OPENROUTER PROCESSING\n\n"
                    + "".join(f"data: {json.dumps(c)}\n\n" for c in chunks)
                    + "data: [DONE]\n\n"
                ).encode("utf-8")
                self.send_response(200)
                self.send_header("content-type", "text/event-stream")
                self.send_header("content-length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def do_GET(self) -> None:
                provider._record(
                    {
                        "path": urlsplit(self.path).path,
                        "headers": _headers(self.headers),
                        "body": None,
                        "auxiliary": False,
                    }
                )
                if urlsplit(self.path).path.endswith("/models"):
                    return self._json(
                        200,
                        {
                            "data": [
                                {"id": "anthropic/claude-haiku-4.5"},
                                {"id": "anthropic/claude-sonnet-4.5"},
                            ]
                        },
                    )
                self._json(404, {"error": {"message": self.path}})

            def do_POST(self) -> None:
                length = int(self.headers.get("content-length") or 0)
                raw = self.rfile.read(length) if length else b""
                try:
                    body = json.loads(raw) if raw else {}
                except json.JSONDecodeError:
                    body = {}
                if not isinstance(body, dict):
                    body = {}
                messages = body.get("messages") if isinstance(body.get("messages"), list) else []
                system = next(
                    (
                        _text(m.get("content"))
                        for m in messages
                        if isinstance(m, dict) and m.get("role") == "system"
                    ),
                    "",
                )
                auxiliary = system.startswith(_AUX_SYSTEM_PREFIX)
                provider._record(
                    {
                        "path": urlsplit(self.path).path,
                        "headers": _headers(self.headers),
                        "body": body,
                        "auxiliary": auxiliary,
                    }
                )
                if not urlsplit(self.path).path.endswith("/chat/completions"):
                    return self._json(404, {"error": {"message": self.path}})
                model = body.get("model")
                base = {
                    "id": "gen-mock",
                    "object": "chat.completion.chunk",
                    "created": 0,
                    "model": model,
                    "provider": PROVIDER_NAME,
                }
                usage: dict[str, Any] = {
                    "prompt_tokens": 10,
                    "completion_tokens": 2,
                    "total_tokens": 12,
                }
                if isinstance(body.get("usage"), dict) and body["usage"].get("include"):
                    usage["cost"] = 0.00042
                step = {} if auxiliary else provider._next_step()
                if "tool_call" in step:
                    # A scripted tool call: the first offered tool whose name
                    # starts with the prefix, else the prefix itself — so a
                    # call to a tool the plan removed can still be scripted.
                    spec = step["tool_call"]
                    offered = [
                        (t.get("function") or {}).get("name")
                        for t in body.get("tools") or []
                        if isinstance(t, dict)
                    ]
                    prefix = str(spec.get("name_prefix", ""))
                    name = next(
                        (n for n in offered if isinstance(n, str) and n.startswith(prefix)),
                        prefix,
                    )
                    chunks = [
                        {
                            **base,
                            "choices": [
                                {
                                    "index": 0,
                                    "delta": {
                                        "role": "assistant",
                                        "tool_calls": [
                                            {
                                                "index": 0,
                                                "id": "call_mock_1",
                                                "type": "function",
                                                "function": {
                                                    "name": name,
                                                    "arguments": json.dumps(
                                                        dict(spec.get("arguments") or {})
                                                    ),
                                                },
                                            }
                                        ],
                                    },
                                    "finish_reason": None,
                                }
                            ],
                        },
                        {
                            **base,
                            "choices": [{"index": 0, "delta": {}, "finish_reason": "tool_calls"}],
                            "usage": usage,
                        },
                    ]
                    return self._sse(chunks)
                text = "title" if auxiliary else str(step.get("text", "ok"))
                chunks = [
                    {
                        **base,
                        "choices": [
                            {
                                "index": 0,
                                "delta": {"role": "assistant", "content": text},
                                "finish_reason": None,
                            }
                        ],
                    },
                    {
                        **base,
                        "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
                        "usage": usage,
                    },
                ]
                if body.get("stream"):
                    return self._sse(chunks)
                self._json(
                    200,
                    {
                        **base,
                        "object": "chat.completion",
                        "choices": [
                            {
                                "index": 0,
                                "message": {"role": "assistant", "content": text},
                                "finish_reason": "stop",
                            }
                        ],
                        "usage": usage,
                    },
                )

        self._http = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._http.serve_forever, daemon=True)

    def _next_step(self) -> Mapping[str, Any]:
        with self._lock:
            step = self.script[min(self._turn, len(self.script) - 1)]
            self._turn += 1
            return step

    def _record(self, entry: dict[str, Any]) -> None:
        with self._lock:
            self.requests.append(entry)

    @property
    def main_requests(self) -> list[dict[str, Any]]:
        """The user's turns: chat completions that are not OpenCode's title call."""
        with self._lock:
            return [r for r in self.requests if r["body"] is not None and not r["auxiliary"]]

    @property
    def url(self) -> str:
        host, port = self._http.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> MockOpenRouter:
        self._thread.start()
        return self

    def stop(self) -> None:
        self._http.shutdown()
        self._http.server_close()


def _text(content: Any) -> str:
    """A message's text whether it came as a string or as a list of parts."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join(str(part.get("text", "")) for part in content if isinstance(part, dict))
    return ""


def offered_tools(body: Mapping[str, Any]) -> list[str]:
    """The tool names a chat-completions body offers, in order."""
    return [
        str((t.get("function") or {}).get("name"))
        for t in body.get("tools") or []
        if isinstance(t, dict) and isinstance((t.get("function") or {}).get("name"), str)
    ]


def last_tool_result(body: Mapping[str, Any]) -> str | None:
    """The text of the last tool result in the conversation, or None."""
    messages = body.get("messages") if isinstance(body.get("messages"), list) else []
    results = [m for m in messages if isinstance(m, dict) and m.get("role") == "tool"]
    return _text(results[-1].get("content")) if results else None


def user_text(body: Mapping[str, Any]) -> str:
    """Every user message's text in a chat-completions body, joined."""
    messages = body.get("messages") if isinstance(body.get("messages"), list) else []
    return "\n".join(
        _text(m.get("content")) for m in messages if isinstance(m, dict) and m.get("role") == "user"
    )


def _headers(headers: Any) -> dict[str, str]:
    return {k.lower(): v for k, v in headers.items()}


__all__ = ["PROVIDER_NAME", "MockOpenRouter", "last_tool_result", "offered_tools", "user_text"]
