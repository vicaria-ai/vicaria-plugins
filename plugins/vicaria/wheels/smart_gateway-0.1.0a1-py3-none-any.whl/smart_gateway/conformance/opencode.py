"""The OpenCode conformance driver: RFC 0009 §6, against the real ``opencode`` binary.

The Claude Code driver proved the contract on one harness. This one exists to
prove the *suite* generalizes to a harness with a different boundary — because
ten checks that only ever ran against a commit-point adapter are ten checks
about that adapter, not about the contract.

WHAT IS DIFFERENT, AND WHY IT IS STILL THE SAME CHECK

OpenCode has one component: the plugin runs in-process and is itself the point
of application. Two checks therefore read differently, and both say so in their
detail rather than quietly asserting something weaker:

* **Check 2 (declared mutations)** confirms the mutations *this descriptor
  declares at apply level* — effort, prompt and tools. It does not assert a
  model change, because the OpenCode descriptor says ``model: suggest``: OpenCode
  picks the model before any hook runs. Asserting a mutation the adapter never
  claimed would be testing a different adapter.
* **Check 6 (cross-component atomicity)** cannot induce "staging succeeded,
  confirmation failed" — there is no second component to fail between. The
  property it protects is induced instead at the point that does exist: a
  decision is made, the plugin then cannot apply it faithfully, and what must
  not happen is the contribution running against the reference configuration.
  All three of its scenarios still turn on evidence the adapter cannot fake.

WHAT COUNTS

* **Provider requests** are the scripted provider's own log. OpenCode makes a
  second, unrelated call per run to title the thread; ``main_requests`` excludes
  it, and the zero-request checks (6c, 9, 10) require zero of *both*.
* **Receipts** are the provider's record of the request body: the model, the
  ``reasoning_effort``, whether the recipe text was present, whether a marker
  leaked. A mutation is confirmed by what arrived, never by the absence of an
  error.
* **Records** are the bridge's ``sg.control.v1`` lines read back from the data
  directory.

Each run gets a fresh ``HOME``, data directory and working directory, so no
session state reaches the next and none from the developer's machine reaches
any of them. What is shared is OpenCode's package cache (its config and cache
directories, where it npm-installs its plugin SDK at startup): one
Vicaria-owned directory per OpenCode version, so only the first run installs
(:func:`package_cache`). Installing on every run's fresh ``HOME`` put a
network fetch with no timeout in front of every scenario, and a stalled one
hung the run before its first event (found on a loaded machine: the log ended
at loading config, the ``node_modules`` half written). Runs on a cache not yet
installed take turns (:func:`install_lock`). A run is bounded by its timeout,
and what it started is stopped when it ends (:func:`run_contained`). Without
the binary every check is ``NOT_RUN`` — a skip is not a pass.
"""

from __future__ import annotations

import contextlib
import fcntl
import json
import os
import re
import shutil
import signal
import subprocess
import tempfile
import threading
import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import IO, Any

from vicaria_contracts.conformance import CheckId, CheckResult, CheckStatus

from smart_gateway.conformance.claude_code import (
    RECIPE_ID,
    apply,
    cannot_execute,
    retain,
    stale_baseline,
    stale_revision,
    suggest,
)
from smart_gateway.conformance.mock_openai_provider import MockOpenAIProvider
from smart_gateway.control.config import CONTROL_SCHEMA, EFFORT_UNSET, write_control
from smart_gateway.control.plans import PlanServer, Policy
from smart_gateway.control.records import iter_records

REPO = Path(__file__).resolve().parents[3]
PLUGIN = REPO / "plugin-control-opencode" / "vicaria.js"

PROVIDER_ID = "vicaria-mock"
MODEL = "tiny"
CANDIDATE_MODEL = "tiny-pro"
NARROW_PROFILE = "profile:narrow@v1"
NARROWED_TOOLS = ["read", "grep"]
PROBE_TOOL = "vicaria_vicaria_probe"  # <mcp server id>_<tool name>, as OpenCode names it
DECLARED_ONLY_TOOL = "vicaria_vicaria_declared_only"
TASK_TOOL = "task"  # OpenCode's subagent tool: a child session with a parentID
_CLOSED_PORT_URL = "http://127.0.0.1:1"


@dataclass(frozen=True, slots=True)
class Scenario:
    prompt: str = "reply with exactly: ok"
    policy: Policy | None = field(default_factory=retain)  # None: the plan source is down
    script: Sequence[Mapping[str, Any]] = ({"text": "ok"},)
    induce: str | None = None
    levels: Mapping[str, str] = field(default_factory=dict)
    denied_models: Sequence[str] = ()
    mcp: bool = False
    tools: Sequence[str] = ("mcp:vicaria_probe", NARROW_PROFILE)
    #: What a benchmark would set, so the episode is attributable to its task.
    task_id: str | None = None
    timeout_s: float = 120.0


@dataclass(slots=True)
class Evidence:
    exit_code: int
    events: list[dict[str, Any]]
    wire: list[dict[str, Any]]  # the user's turn only
    all_wire: list[dict[str, Any]]  # including OpenCode's own title call
    control: list[dict[str, Any]]
    plan_requests: list[dict[str, Any]]
    mcp_calls: list[dict[str, Any]]
    errors: str
    stdout: str

    def decided(self) -> dict[str, Any] | None:
        """What the bridge decided (``phase: "decided"``)."""
        rows = [r for r in self.control if r["kind"] == "dispatch" and r.get("phase") == "decided"]
        return rows[-1] if rows else None

    def applied(self) -> dict[str, Any] | None:
        """What the plugin reported actually doing (``phase: "applied"``).

        Separate from :meth:`decided` on purpose: a decision is not an outcome,
        and on this adapter they are made in different processes.
        """
        rows = [r for r in self.control if r["kind"] == "dispatch" and r.get("phase") == "applied"]
        return rows[-1] if rows else None

    def signals(self) -> list[dict[str, Any]]:
        return [r["signal"] for r in self.control if r["kind"] == "stage" and "signal" in r]

    def usage(self) -> list[dict[str, Any]]:
        """What each model step cost, as the plugin forwarded it from ``step-finish``."""
        return [r for r in self.control if r["kind"] == "usage"]

    def text(self) -> str:
        """Everything the harness printed (stdout and stderr), for a check that
        needs the user-visible reason or recommendation."""
        return self.stdout


class OpenCodeDriver:
    """Implements ``vicaria_contracts.conformance.ConformanceDriver`` for OpenCode."""

    def __init__(
        self,
        *,
        opencode_bin: str = "opencode",
        python_bin: str | None = None,
        timeout_s: float = 120.0,
        keep_dir: Path | None = None,
        cache_dir: Path | None = None,
    ) -> None:
        self.opencode_bin = shutil.which(opencode_bin) or opencode_bin
        #: Where OpenCode's packages are kept between runs; see
        #: :meth:`package_cache`.
        self.cache_dir = cache_dir
        self.python_bin = python_bin or os.environ.get("VICARIA_PYTHON") or "python3"
        self.timeout_s = timeout_s
        self.keep_dir = keep_dir
        self.available = Path(self.opencode_bin).exists() or shutil.which(opencode_bin) is not None
        self._version: str | None = None

    # --- identity --------------------------------------------------------------

    def harness_identity(self) -> tuple[str, str, str]:
        from smart_gateway import __version__

        if not self.available:
            return ("opencode", "not-installed", __version__)
        if self._version is None:
            self._version = opencode_version(self.opencode_bin)
        return ("opencode", self._version, __version__)

    def package_cache(self) -> dict[str, str]:
        """This binary's shared package cache; see :func:`package_cache`."""
        return package_cache(self.harness_identity()[1], self.cache_dir)

    # --- one run -------------------------------------------------------------

    def run(self, scenario: Scenario) -> Evidence:
        if not self.available:
            raise RuntimeError(f"{self.opencode_bin} is not installed")
        root = Path(tempfile.mkdtemp(prefix="vicaria-opencode-"))
        provider = MockOpenAIProvider(scenario.script).start()
        plan_server = PlanServer(scenario.policy).start() if scenario.policy is not None else None
        try:
            data_dir = root / "sg-data"
            for sub in ("raw", "state", "derived", "reports"):
                (data_dir / sub).mkdir(parents=True, exist_ok=True)
            home, work = root / "home", root / "work"
            home.mkdir()
            work.mkdir()
            write_control(
                data_dir / "control.json",
                {
                    "schema": CONTROL_SCHEMA,
                    "plan_source": plan_server.url if plan_server else _CLOSED_PORT_URL,
                    "upstream": provider.url,  # unused by this adapter; the harness calls out
                    "models": [MODEL, CANDIDATE_MODEL],
                    "efforts": ["low", "medium", "high"],
                    "tools": list(scenario.tools),
                    "tool_profiles": {NARROW_PROFILE: NARROWED_TOOLS},
                    "levels": dict(scenario.levels),
                    "default_model": MODEL,
                    "default_effort": EFFORT_UNSET,
                    "denied_models": list(scenario.denied_models),
                    "harness_version": self.harness_identity()[1],
                    "plan_timeout_s": 5.0,
                },
            )

            mcp_log = root / "mcp.jsonl"
            config: dict[str, Any] = {
                "plugin": [str(PLUGIN)],
                "permission": "allow",
                "provider": {
                    PROVIDER_ID: {
                        "npm": "@ai-sdk/openai-compatible",
                        "name": PROVIDER_ID,
                        "options": {"baseURL": provider.url + "/v1", "apiKey": "conformance"},
                        "models": {MODEL: {"name": MODEL}},
                    }
                },
            }
            if scenario.mcp:
                config["mcp"] = {
                    "vicaria": {
                        "type": "local",
                        "command": [
                            self.python_bin,
                            "-m",
                            "smart_gateway.conformance.mcp_probe",
                            str(mcp_log),
                        ],
                        "environment": {"PYTHONPATH": _pythonpath()},
                    }
                }

            cache = self.package_cache()
            env = {
                "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
                "HOME": str(home),
                "TERM": "dumb",
                "PYTHONPATH": _pythonpath(),
                "VICARIA_PYTHON": self.python_bin,
                "SG_DATA_DIR": str(data_dir),
                "OPENCODE_CONFIG_CONTENT": json.dumps(config),
                "OPENCODE_DISABLE_AUTOUPDATE": "1",
                **cache,
            }
            if scenario.induce:
                env["VICARIA_INDUCE"] = scenario.induce
            if scenario.task_id:
                env["VICARIA_TASK_ID"] = scenario.task_id

            argv = [
                self.opencode_bin,
                "run",
                "--format",
                "json",
                "-m",
                f"{PROVIDER_ID}/{MODEL}",
                scenario.prompt,
            ]
            with install_lock(cache):
                ran = run_contained(argv, cwd=work, env=env, timeout_s=scenario.timeout_s)
            exit_code, stdout = ran.returncode, ran.stdout + ran.stderr

            events: list[dict[str, Any]] = []
            for line in stdout.splitlines():
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(obj, dict):
                    events.append(obj)
            mcp_calls = (
                [json.loads(x) for x in mcp_log.read_text().splitlines() if x.strip()]
                if mcp_log.exists()
                else []
            )
            errors_path = data_dir / "raw" / "control_errors.log"
            return Evidence(
                exit_code=exit_code,
                events=events,
                wire=provider.main_requests,
                all_wire=list(provider.requests),
                control=list(iter_records(data_dir)),
                plan_requests=list(plan_server.requests) if plan_server else [],
                mcp_calls=mcp_calls,
                errors=errors_path.read_text() if errors_path.exists() else "",
                stdout=stdout,
            )
        finally:
            if plan_server is not None:
                plan_server.stop()
            provider.stop()
            if self.keep_dir is not None:
                shutil.copytree(root, self.keep_dir / root.name, dirs_exist_ok=True)
            shutil.rmtree(root, ignore_errors=True)

    # --- the ten checks ---------------------------------------------------------

    def _result(self, check: CheckId, ok: bool, detail: str) -> CheckResult:
        return CheckResult(check, CheckStatus.PASSED if ok else CheckStatus.FAILED, detail)

    def _not_run(self, check: CheckId) -> CheckResult:
        return CheckResult(check, CheckStatus.NOT_RUN, f"{self.opencode_bin} is not installed")

    def _reference_on_wire(self, ev: Evidence) -> bool:
        """The user's turn ran as it would have with no adapter at all."""
        return (
            len(ev.wire) >= 1
            and ev.wire[0]["model"] == MODEL
            and not ev.wire[0]["effort"]
            and "VICARIA-RECIPE-TEXT" not in ev.wire[0]["sentinels"]
            and not ev.wire[0]["has_staging_block"]
        )

    def check_interception(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.INTERCEPTION)
        task = "conformance/interception"
        ev = self.run(Scenario(task_id=task))
        decided, applied = ev.decided(), ev.applied()
        # The prompt was seen, and its measured shape is the prompt's own.
        saw_prompt = decided is not None and (decided.get("prompt_features") or {}).get(
            "length"
        ) == len("reply with exactly: ok")
        # It reached the plan source — interception that communicates nothing is
        # not interception. What reaches it by default is the prompt's shape
        # (its length here) under this decision's id; the text itself only
        # under an opt-in capture policy, which this run does not set. The key
        # the text would travel under is ``context.text`` — naming it is what
        # makes this a test and not a tautology — and ``context.prompt`` is
        # named too, so a revert to the old key cannot pass here either.
        request = ev.plan_requests[-1] if ev.plan_requests else {}
        reached_server = (
            (request.get("context") or {}).get("prompt_length") == len("reply with exactly: ok")
            and "text" not in (request.get("context") or {})
            and "prompt" not in (request.get("context") or {})
            and request.get("decision_id") == (decided or {}).get("decision_id")
        )
        # And the same decision came back through the application point.
        same_decision = (
            applied is not None
            and decided is not None
            and applied.get("decision_id") == decided.get("decision_id")
            and applied.get("session_id") == decided.get("session_id")
        )
        # And the episode is attributable to the task the harness was told to run —
        # without this a benchmark result and a recommendation cannot be joined.
        attributed = decided is not None and decided.get("task_id") == task
        # And the configuration the plan was bound to is the one that ran: the
        # model in the plan request is the model on the wire, read from the
        # message OpenCode resolved, not from a configured default.
        bound_to_what_ran = (
            bool(ev.wire)
            and (request.get("active_config") or {}).get("model") == ev.wire[0]["model"]
        )
        return self._result(
            CheckId.INTERCEPTION,
            saw_prompt
            and reached_server
            and same_decision
            and attributed
            and bound_to_what_ran
            and len(ev.wire) == 1,
            f"the adapter saw the submitted prompt ({saw_prompt}); its shape reached the plan "
            f"source under this decision, text withheld by the default capture policy "
            f"({reached_server}); the same decision came back through the application point "
            f"({same_decision}); the episode is attributed to the task ({attributed}); the plan "
            f"was bound to the model that ran ({bound_to_what_ran}); provider "
            f"requests for the turn: {len(ev.wire)} (plus "
            f"{len(ev.all_wire) - len(ev.wire)} the harness makes to title the thread)",
        )

    def check_declared_mutations(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.DECLARED_MUTATIONS)
        # (a) Effort and prompt, from one request's receipt.
        one = self.run(Scenario(policy=apply(effort="low", prompt=RECIPE_ID)))
        receipt = one.wire[0] if one.wire else {}
        effort_ok = receipt.get("effort") == "low"
        prompt_ok = "VICARIA-RECIPE-TEXT" in receipt.get("sentinels", [])
        clean = not receipt.get("has_staging_block", True)
        dispatch = one.decided() or {}
        one_ok = (
            len(one.wire) == 1
            and effort_ok
            and prompt_ok
            and clean
            and dispatch.get("action") == "materialize"
        )
        # (b) Tools. OpenCode offers a plugin no way to remove a tool from the
        # request, so narrowing is a denial at execution: the tool is still
        # offered on the wire, the model calls it, the plugin refuses, the MCP
        # server never runs it, and the refusal reaches the provider as the
        # tool's result on the next request.
        narrowed = self.run(
            Scenario(
                prompt="use the probe tool",
                policy=apply(tools=NARROW_PROFILE),
                script=[
                    {"tool_call": {"name_prefix": PROBE_TOOL, "arguments": {"echo": "hello"}}},
                    {"text": "tool done"},
                ],
                mcp=True,
            )
        )
        offered = narrowed.wire[0]["tools"] if narrowed.wire else []
        ran = any(c.get("method") == "tools/call" for c in narrowed.mcp_calls)
        denial_on_wire = len(narrowed.wire) >= 2 and "allowed set" in (
            narrowed.wire[1].get("last_tool_result") or ""
        )
        narrowed_ok = (
            PROBE_TOOL in offered
            and not ran
            and denial_on_wire
            and ((narrowed.decided() or {}).get("applied") or {}).get("narrowed_tools") is True
            and (narrowed.applied() or {}).get("action") == "materialized"
        )
        # (c) The same mutation across a tool loop: every request of the turn
        # carries the decided effort and the recipe, not only the first.
        loop = self.run(
            Scenario(
                prompt="use the probe tool",
                policy=apply(effort="low", prompt=RECIPE_ID),
                script=[
                    {"tool_call": {"name_prefix": PROBE_TOOL, "arguments": {"echo": "hello"}}},
                    {"text": "tool done"},
                ],
                mcp=True,
            )
        )
        loop_ok = len(loop.wire) == 2 and all(
            r.get("effort") == "low"
            and "VICARIA-RECIPE-TEXT" in r.get("sentinels", [])
            and not r.get("has_staging_block", True)
            for r in loop.wire
        )
        return self._result(
            CheckId.DECLARED_MUTATIONS,
            one_ok and narrowed_ok and loop_ok,
            f"one request: effort={receipt.get('effort')} recipe_present={prompt_ok} "
            f"marker_leaked={not clean}; action={dispatch.get('action')}; provider requests: "
            f"{len(one.wire)}. Tools: the narrowed-away tool was offered ({PROBE_TOOL in offered}"
            f"), never executed ({not ran}), and its denial reached the provider "
            f"({denial_on_wire}). Tool loop: {len(loop.wire)} requests, every one with the "
            f"effort and the recipe ({loop_ok}). Model is NOT asserted: this descriptor "
            "declares model=suggest, because OpenCode selects the model before any plugin "
            "hook runs",
        )

    def check_level_honored(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.LEVEL_HONORED)
        # model is natively suggest here — no administrative narrowing needed.
        refused = self.run(Scenario(policy=apply(model=CANDIDATE_MODEL)))
        served = self.run(Scenario(policy=suggest(model=CANDIDATE_MODEL)))
        undeclared = self.run(
            Scenario(policy=suggest(workflow="workflow:other@v1"), levels={"workflow": "unknown"})
        )
        r_refusal = ((refused.decided() or {}).get("validation") or {}).get("refusal")
        s_dispatch = served.decided() or {}
        u_refusal = ((undeclared.decided() or {}).get("validation") or {}).get("refusal")
        refused_ok = r_refusal == "insufficient_level" and self._reference_on_wire(refused)
        # A suggestion is served only if the user can see it: the plugin writes
        # it to stderr (and the TUI's toast when one is attached) and reports
        # "surfaced" — a record of something that happened, not of an intent.
        served_ok = (
            s_dispatch.get("action") == "surface"
            and (s_dispatch.get("applied") or {}).get("model_suggestion") == CANDIDATE_MODEL
            and (served.applied() or {}).get("action") == "surfaced"
            and "Vicaria recommends" in served.text()
            and CANDIDATE_MODEL in served.text()
            and self._reference_on_wire(served)
        )
        undeclared_ok = u_refusal == "insufficient_level" and self._reference_on_wire(undeclared)
        return self._result(
            CheckId.LEVEL_HONORED,
            refused_ok and served_ok and undeclared_ok,
            f"applying a model change on a suggest-level control refused as {r_refusal} "
            f"({refused_ok}); the same change served as a suggestion reached the user on "
            f"stderr and was reported surfaced ({served_ok}); an "
            f"undeclared control refused as {u_refusal} ({undeclared_ok}); the reference ran on "
            "the wire in every case",
        )

    def check_stale_baseline_refused(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.STALE_BASELINE_REFUSED)
        moved = self.run(Scenario(policy=stale_baseline(effort="low")))
        superseded = self.run(Scenario(policy=stale_revision(effort="low")))
        m = ((moved.decided() or {}).get("validation") or {}).get("refusal")
        s = ((superseded.decided() or {}).get("validation") or {}).get("refusal")
        return self._result(
            CheckId.STALE_BASELINE_REFUSED,
            m == "baseline_mismatch"
            and s == "stale_request_revision"
            and self._reference_on_wire(moved)
            and self._reference_on_wire(superseded),
            f"moved baseline refused as {m}; superseded revision refused as {s}; the reference "
            "ran on the wire in both cases",
        )

    def check_tool_execution(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.TOOL_EXECUTION)
        ev = self.run(
            Scenario(
                prompt="use the probe tool",
                script=[
                    {"tool_call": {"name_prefix": PROBE_TOOL, "arguments": {"echo": "hello"}}},
                    {"text": "tool done"},
                ],
                mcp=True,
            )
        )
        offered = ev.wire[0]["tools"] if ev.wire else []
        registered_ran = any(c.get("method") == "tools/call" for c in ev.mcp_calls)
        result_on_wire = len(ev.wire) >= 2 and "PROBE-EXECUTED:hello" in (
            ev.wire[1].get("last_tool_result") or ""
        )
        declared_only_absent = DECLARED_ONLY_TOOL not in offered
        return self._result(
            CheckId.TOOL_EXECUTION,
            PROBE_TOOL in offered and registered_ran and result_on_wire and declared_only_absent,
            f"registered tool offered ({PROBE_TOOL in offered}), called ({registered_ran}), its "
            f"result reached the provider ({result_on_wire}); declared-only tool not offered "
            f"({declared_only_absent}); provider requests: {len(ev.wire)}",
        )

    def check_cross_component_atomicity(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.CROSS_COMPONENT_ATOMICITY)
        plan = apply(effort="low", prompt=RECIPE_ID)
        before = self.run(Scenario(policy=plan, induce="fail_before_applying"))
        during = self.run(Scenario(policy=plan, induce="corrupt_application"))
        irreversible = self.run(
            Scenario(policy=plan, induce="corrupt_application,contribution_class=neither")
        )
        before_ok = self._reference_on_wire(before) and len(before.wire) == 1
        # The defect this catches: the recipe absent but its effort applied, i.e.
        # the contribution running against the reference configuration.
        during_receipt = during.wire[0] if during.wire else {}
        during_ok = (
            len(during.wire) == 1
            and self._reference_on_wire(during)
            and not during_receipt.get("effort")
        )
        irreversible_ok = (
            len(irreversible.all_wire) == 0
            and (irreversible.applied() or {}).get("action") == "stopped"
        )
        return self._result(
            CheckId.CROSS_COMPONENT_ATOMICITY,
            before_ok and during_ok and irreversible_ok,
            f"decided then silent → reference ran ({before_ok}); an unapplicable application → "
            f"NONE of it applied, reference ran with no recipe and no effort ({during_ok}); the "
            f"same marked irreversible → zero provider requests ({irreversible_ok}, saw "
            f"{len(irreversible.all_wire)}). Single-component adapter: the failure is induced "
            "between deciding and applying, the only seam that exists",
        )

    def check_event_completeness(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.EVENT_COMPLETENESS)
        ev = self.run(Scenario())
        kinds = {s.get("signal") for s in ev.signals()}
        decided = ev.decided() or {}
        sessions = {s.get("session_id") for s in ev.signals()} | {decided.get("session_id")}
        needed = {"session_start", "prompt", "turn_complete"}
        completed = any(e.get("type") == "step_finish" for e in ev.events)
        # Usage is a record on disk, joined to the prompt that was running —
        # forwarded by the plugin from OpenCode's step-finish part.
        usage = [
            u
            for u in ev.usage()
            if u.get("prompt_id") == decided.get("prompt_id")
            and isinstance(u.get("input_tokens"), int)
            and isinstance(u.get("output_tokens"), int)
        ]
        boundaries_ok = needed <= kinds and len(sessions - {None}) == 1 and completed
        # Parent/child: OpenCode's task tool runs a subagent in a child session
        # whose session.created names its parentID; the plugin forwards it, so
        # the child's start signal points at the parent.
        child = self.run(
            Scenario(
                prompt="delegate to a subagent",
                script=[
                    {
                        "tool_call": {
                            "name_prefix": TASK_TOOL,
                            "arguments": {
                                "description": "probe",
                                "prompt": "reply with exactly: ok",
                                "subagent_type": "general",
                            },
                        }
                    },
                    {"text": "ok"},
                    {"text": "done"},
                ],
            )
        )
        starts = [s for s in child.signals() if s.get("signal") == "session_start"]
        roots = [s for s in starts if not s.get("parent_session_id")]
        children = [
            s
            for s in starts
            if s.get("parent_session_id")
            and any(r.get("session_id") == s.get("parent_session_id") for r in roots)
        ]
        child_ok = len(roots) == 1 and len(children) == 1 and len(child.wire) >= 3
        return self._result(
            CheckId.EVENT_COMPLETENESS,
            boundaries_ok and bool(usage) and child_ok,
            f"signals recorded: {sorted(k for k in kinds if k)}; one session id "
            f"({len(sessions - {None})}); the turn completed ({completed}); usage persisted "
            f"for the prompt ({len(usage)} record(s)); a subagent's child session recorded "
            f"with its parent ({child_ok}: {len(roots)} root, {len(children)} child, "
            f"{len(child.wire)} provider requests)",
        )

    def check_server_unavailable_recovery(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.SERVER_UNAVAILABLE_RECOVERY)
        ev = self.run(Scenario(policy=None))
        dispatch = ev.decided() or {}
        kept_working = ev.exit_code == 0
        recorded = (
            dispatch.get("origin") == "unavailable"
            and dispatch.get("unavailable_reason") == "unreachable"
        )
        # "Events buffer": with the plan source unreachable for the whole run,
        # every record still lands on disk — boundaries, prompt, decision,
        # application, usage. The local records ARE the buffer. Not verified:
        # replaying them to a recovered server; this package has no uploader.
        kinds = {s.get("signal") for s in ev.signals()}
        needed = {"session_start", "prompt", "turn_complete"}
        buffered = needed <= kinds and bool(ev.usage()) and ev.applied() is not None
        return self._result(
            CheckId.SERVER_UNAVAILABLE_RECOVERY,
            kept_working
            and recorded
            and self._reference_on_wire(ev)
            and len(ev.wire) == 1
            and buffered,
            f"harness completed ({kept_working}); the adapter recorded an unavailable decision "
            f"({recorded}, reason={dispatch.get('unavailable_reason')}); the reference ran; "
            f"provider requests: {len(ev.wire)}; every record of the run landed locally while "
            f"the source was down ({buffered}: signals {sorted(k for k in kinds if k)}, "
            f"applied={ev.applied() is not None}, {len(ev.usage())} usage). Not verified: "
            "replay to a recovered server — this package has no uploader",
        )

    def check_cannot_execute_stops(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.CANNOT_EXECUTE_STOPS)
        ev = self.run(Scenario(policy=cannot_execute("reference provider prohibited")))
        applied = ev.applied() or {}
        blocked = applied.get("action") == "stopped"
        surfaced = "cannot_execute" in ev.text()
        return self._result(
            CheckId.CANNOT_EXECUTE_STOPS,
            len(ev.all_wire) == 0 and blocked and surfaced,
            f"provider requests: {len(ev.all_wire)} (including the harness's own title call); "
            f"the adapter blocked the turn ({blocked}) and the reason reached the user "
            f"({surfaced})",
        )

    def check_inadmissible_fallback_stops(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.INADMISSIBLE_FALLBACK_STOPS)
        # A valid plan the adapter cannot apply, whose reference is inadmissible:
        # falling back would run a configuration the organization denies.
        ev = self.run(
            Scenario(
                policy=apply(effort="low", prompt=RECIPE_ID),
                induce="corrupt_application",
                denied_models=[MODEL],
            )
        )
        decided = ev.decided() or {}
        applied = ev.applied() or {}
        commit = applied.get("commit") or {}
        validation = decided.get("validation") or {}
        return self._result(
            CheckId.INADMISSIBLE_FALLBACK_STOPS,
            validation.get("ok") is True
            and len(ev.all_wire) == 0
            and applied.get("action") == "stopped"
            and commit.get("refusal") == "reference_inadmissible"
            and bool(commit.get("detail")),
            f"the plan validated ({validation.get('ok')}); the application could not be carried "
            f"out and the reference was inadmissible; provider requests: {len(ev.all_wire)}; "
            f"refusal={commit.get('refusal')} with a reason ({bool(commit.get('detail'))})",
        )


# --- the binary, its packages, and what a run starts -----------------------------

#: What an install writes last, once it has installed: npm's lockfile, or
#: bun's for an OpenCode that installs with bun.
_INSTALL_LOCKFILES = ("package-lock.json", "bun.lock")
#: What OpenCode writes into its config directory when it installs its packages
#: there. 1.18.32 installs with npm: its manifest, lockfile and tree, and a
#: .gitignore; an OpenCode that installs with bun writes bun.lock. A file some
#: other version's install writes there needs adding here.
_PACKAGE_ENTRIES = frozenset({"package.json", "node_modules", ".gitignore", *_INSTALL_LOCKFILES})
#: What a version looks like: the shared cache is keyed by it, so nothing a
#: failed probe printed ("unknown", an error) can key one.
_VERSION = re.compile(r"\d+(\.\d+)+([.+-][0-9A-Za-z.+-]*)?")
#: How long a run waits for another to finish installing before it gives up.
INSTALL_WAIT_S = 300.0
#: How often a running harness's descendants are looked up: every half second
#: for its first five seconds, when a hang is most likely to be starting up,
#: then every two.
_SAMPLE_S = 0.5
_SAMPLE_FAST_FOR_S = 5.0
_SAMPLE_SLOW_S = 2.0
#: How long a stopped run's output is still read: what is already in the
#: pipes, not a pipe some process outside the stopped groups still holds.
_DRAIN_S = 5.0
#: Where the process list is read first (Linux's /proc), before ``ps``.
PROC_ROOT = "/proc"


def opencode_version(opencode_bin: str, *, timeout_s: float = 60) -> str:
    """The version ``opencode --version`` prints, bounded and contained like a run.

    A probe that fails, times out or prints no version raises ``RuntimeError``:
    the version keys the shared package cache, and every binary whose probe
    failed would otherwise share one keyed "unknown".
    """
    ran = run_contained([opencode_bin, "--version"], timeout_s=timeout_s)
    printed = (ran.stdout.split() or [""])[0]
    if ran.returncode != 0 or not _VERSION.fullmatch(printed):
        said = (ran.stdout + ran.stderr).strip()[-200:]
        raise RuntimeError(
            f"{opencode_bin} --version gave no version (exit {ran.returncode}): {said!r}"
        )
    return printed


def package_cache(version: str, cache_dir: Path | None = None) -> dict[str, str]:
    """OpenCode's config and cache directories, shared by the runs of ``version``.

    The root is ``cache_dir`` when given, else ``VICARIA_OPENCODE_CACHE``, else
    ``$XDG_CACHE_HOME/vicaria/opencode/<version>`` (``~/.cache`` where that is
    unset or not absolute); a relative root is taken from the working
    directory. The default root is keyed by version, as the packages OpenCode
    installs are its version's, so there a new binary gets its own (a root
    that ``cache_dir`` or ``VICARIA_OPENCODE_CACHE`` names is every version's),
    and a version that is not one (``RuntimeError``) keys nothing. The two
    directories are returned as a run's ``XDG_CONFIG_HOME`` and
    ``XDG_CACHE_HOME``; its ``XDG_DATA_HOME`` and ``XDG_STATE_HOME``
    (sessions, logs, OpenCode's own install lock) stay under the run's own
    ``HOME``.

    The config directory is where OpenCode reads its global configuration as
    well as where it installs: an ``opencode.json``, ``config.json`` or
    ``.npmrc`` left there would be every run's. So it may hold only what
    OpenCode installs there (``_PACKAGE_ENTRIES``), and a cache holding anything
    else is refused (``RuntimeError``) rather than cleaned.
    """
    if cache_dir is not None:
        root = Path(cache_dir)
    elif os.environ.get("VICARIA_OPENCODE_CACHE"):
        root = Path(os.environ["VICARIA_OPENCODE_CACHE"])
    else:
        if not _VERSION.fullmatch(version):
            raise RuntimeError(f"no OpenCode version to key the package cache by: {version!r}")
        xdg = Path(os.environ.get("XDG_CACHE_HOME") or ".")
        root = (xdg if xdg.is_absolute() else Path.home() / ".cache") / "vicaria" / "opencode"
        root = root / version
    root = root.absolute()
    dirs = {"XDG_CONFIG_HOME": root / "config", "XDG_CACHE_HOME": root / "cache"}
    for path in dirs.values():
        path.mkdir(parents=True, exist_ok=True)
    foreign = _foreign_config(dirs["XDG_CONFIG_HOME"])
    if foreign:
        raise RuntimeError(
            f"OpenCode {version}'s shared package cache {root} holds {', '.join(foreign)} in its "
            "config directory, which every run would read as its configuration. Remove them. "
            "Only a file an OpenCode's package install writes there belongs in "
            f"_PACKAGE_ENTRIES in {__name__}; never a configuration file (OpenCode writes a "
            "default opencode.jsonc there for a run without OPENCODE_CONFIG_CONTENT)"
        )
    return {name: str(path) for name, path in dirs.items()}


def _foreign_config(config: Path) -> list[str]:
    """What the shared config directory holds besides OpenCode's packages."""
    found = [entry.name for entry in config.iterdir() if entry.name != "opencode"]
    if (config / "opencode").is_dir():
        found += [
            f"opencode/{entry.name}"
            for entry in (config / "opencode").iterdir()
            if entry.name not in _PACKAGE_ENTRIES
        ]
    return sorted(found)


class InstallLock:
    """A run on a package cache OpenCode has not installed into yet installs alone.

    OpenCode's own install lock is in its state directory, under each run's
    own ``HOME``, so it keeps two runs sharing a cache from nothing: on a cold
    cache both would install into the one directory at once. So while the
    install's lockfile (``config/opencode/package-lock.json``, or ``bun.lock``
    from an OpenCode that installs with bun) is missing, a run takes
    ``<root>/.install.lock`` (an ``flock``), and holds it until a lockfile
    appears or the run ends, whichever is first; a run on an installed cache
    takes nothing. One that cannot take it within ``wait_s``
    raises ``RuntimeError`` rather than wait on a holder that hung.
    """

    def __init__(self, cache: Mapping[str, str], *, wait_s: float = INSTALL_WAIT_S) -> None:
        config = Path(cache["XDG_CONFIG_HOME"])
        self.lockfiles = [config / "opencode" / name for name in _INSTALL_LOCKFILES]
        self.path = config.parent / ".install.lock"
        self.wait_s = wait_s
        self._handle: IO[str] | None = None
        self._guard = threading.Lock()
        self._done = threading.Event()

    @property
    def held(self) -> bool:
        return self._handle is not None

    def installed(self) -> bool:
        return any(lockfile.exists() for lockfile in self.lockfiles)

    def acquire(self) -> None:
        if self.installed():
            return
        handle = open(self.path, "a")  # noqa: SIM115 - held past this call, closed by release
        deadline = time.monotonic() + self.wait_s
        while True:
            try:
                fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                if time.monotonic() >= deadline:
                    handle.close()
                    raise RuntimeError(
                        f"OpenCode's install lock {self.path} was held past {self.wait_s:.0f} s "
                        "by another run that has not finished installing"
                    ) from None
                time.sleep(0.1)
        self._handle = handle
        threading.Thread(target=self._release_once_installed, daemon=True).start()

    def _release_once_installed(self) -> None:
        while not self._done.wait(0.2):
            if self.installed():
                self.release()

    def release(self) -> None:
        self._done.set()
        with self._guard:
            if self._handle is not None:
                self._handle.close()  # which releases the flock
                self._handle = None

    def __enter__(self) -> InstallLock:
        self.acquire()
        return self

    def __exit__(self, *exc: object) -> None:
        self.release()


def install_lock(cache: Mapping[str, str], *, wait_s: float = INSTALL_WAIT_S) -> InstallLock:
    """The :class:`InstallLock` of what :func:`package_cache` returned, to use with ``with``."""
    return InstallLock(cache, wait_s=wait_s)


def _process_table(proc: str | None = None) -> dict[int, tuple[int, int]]:
    """Every process's parent and process group, by pid.

    From ``proc`` (:data:`PROC_ROOT`) where it can be read and is this pid
    namespace's (Linux), else from ``ps``. Where neither answers,
    ``RuntimeError``: what a run starts could not be found, and a run that
    cannot stop what it starts is not run as if it could.
    """
    proc = proc or PROC_ROOT
    table: dict[int, tuple[int, int]] = {}
    with contextlib.suppress(OSError):
        # A /proc of another pid namespace (unshare -p without its own mount)
        # names other processes by these pids: only one whose self is this
        # process is this namespace's.
        if os.readlink(Path(proc) / "self") != str(os.getpid()):
            raise OSError("not this pid namespace's /proc")
        for entry in os.listdir(proc):
            if not entry.isdigit():
                continue
            try:
                stat = (Path(proc) / entry / "stat").read_text()
            except OSError:
                continue  # gone since it was listed
            # The command is parenthesized and may hold anything; after the
            # last ")" come the state, the parent and the process group.
            fields = stat[stat.rfind(")") + 2 :].split()
            if len(fields) >= 3 and fields[1].isdigit() and fields[2].isdigit():
                table[int(entry)] = (int(fields[1]), int(fields[2]))
    if table:
        return table
    try:
        listing = subprocess.run(
            ["ps", "-A", "-o", "pid=,ppid=,pgid="], capture_output=True, text=True, timeout=10
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        raise RuntimeError(
            f"cannot list processes ({proc} unreadable, ps: {exc}): what a run starts cannot be "
            "found to be stopped"
        ) from exc
    for line in listing.stdout.splitlines():
        fields = line.split()
        if len(fields) == 3 and all(f.isdigit() for f in fields):
            table[int(fields[0])] = (int(fields[1]), int(fields[2]))
    if not table:
        raise RuntimeError(
            f"cannot list processes ({proc} unreadable, ps exit {listing.returncode}): what a "
            "run starts cannot be found to be stopped"
        )
    # ps reads a /proc too: one that does not show this process in its own
    # group lists another pid namespace's processes.
    if table.get(os.getpid(), (0, -1))[1] != os.getpgrp():
        raise RuntimeError(
            "cannot list processes: ps does not show this process as it is, so it lists another "
            "pid namespace's; what a run starts cannot be found to be stopped"
        )
    return table


def descendants(
    pid: int, proc: str | None = None, *, table: Mapping[int, tuple[int, int]] | None = None
) -> dict[int, int]:
    """``pid``'s descendants now (or in ``table``), each with its process group.

    Empty for a process that has exited: its children were given to init then,
    and nothing names them its own.
    """
    children: dict[int, list[tuple[int, int]]] = {}
    for child, (parent, group) in (table or _process_table(proc)).items():
        children.setdefault(parent, []).append((child, group))
    found: dict[int, int] = {}
    stack = [pid]
    while stack:
        for child, group in children.get(stack.pop(), []):
            if child not in found and child != pid:
                found[child] = group
                stack.append(child)
    return found


def descendant_groups(pid: int, proc: str | None = None) -> set[int]:
    """The process groups ``pid``'s descendants are in now."""
    return set(descendants(pid, proc).values())


def kill_groups(groups: set[int]) -> None:
    """SIGKILL every process in ``groups``, never this process's own group."""
    own = os.getpgrp()
    for group in groups:
        if group > 1 and group != own:
            with contextlib.suppress(ProcessLookupError, PermissionError):
                os.killpg(group, signal.SIGKILL)


def kill_seen(
    seen: Mapping[int, int],
    proc: str | None = None,
    *,
    table: Mapping[int, tuple[int, int]] | None = None,
) -> None:
    """Kill the groups of the processes in ``seen`` (pid: its group, when looked up).

    Only a group one of them is still in (now, or in ``table``): a group none
    of them is in any more may have ended, and its id been given to someone
    else's.
    """
    table = table or _process_table(proc)
    kill_groups({group for pid, group in seen.items() if table.get(pid, (0, -1))[1] == group})


def stop_started(
    pid: int, seen: Mapping[int, int], *, reaped: bool, proc: str | None = None
) -> None:
    """Kill what the harness ``pid`` started: every group a process in ``seen``
    (pid: its group, when looked up) is still in, and the harness's own group.

    While the harness is not reaped its pid, and its group's id, are its own,
    and its descendants are looked up once more. Once it is reaped its pid may
    be another process's: it is dropped from ``seen``, its descendants are not
    looked up, and its group is killed only while members remain and none of
    them has its pid (one that does was given it). Where no process list can
    be read, ``RuntimeError``, after killing the group of a harness not reaped.
    """
    try:
        table = _process_table(proc)
    except RuntimeError:
        if not reaped:
            kill_groups({pid})
        raise
    seen = dict(seen)
    if reaped:
        seen.pop(pid, None)
    else:
        seen.update(descendants(pid, table=table))
    kill_seen(seen, table=table)
    members = {member for member, (_, group) in table.items() if group == pid}
    if not reaped or (members and pid not in members):
        kill_groups({pid})


def run_contained(
    argv: Sequence[str],
    *,
    timeout_s: float,
    cwd: Path | None = None,
    env: Mapping[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    """Run a harness to its exit or its timeout, and stop what it leaves running.

    The harness gets a session, and so a process group, of its own. That group
    is not everything it starts: OpenCode starts its bash tool detached, in a
    group of its own. So while the harness runs its descendants are looked up
    (every half second for five seconds, then every two), and once more when
    it exits or its timeout passes (killing the binary alone left an ``opencode
    run`` orphaned for 23 minutes, found in review). Then every group one of
    those processes is still in is killed, the harness's included, and the
    output is read for at most five seconds more. A harness that exits while
    something it started still holds its output is not waited on past that.

    What is not guaranteed: a descendant that leaves the harness's tree and
    group between two looks (one that detaches and whose parent exits between
    them) is not found; if it holds the harness's output, the run still
    returns, five seconds later. Where no process list can be read (no /proc
    and no ``ps``), the run raises ``RuntimeError`` after killing the
    harness's group.

    A timed-out run's exit code is -1, and its output so far, stdout and
    stderr, is kept.
    """
    proc = subprocess.Popen(
        list(argv),
        cwd=cwd,
        env=None if env is None else dict(env),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        start_new_session=True,
    )
    seen = {proc.pid: proc.pid}
    started = time.monotonic()
    deadline = started + timeout_s
    timed_out = False
    out: str | None = None
    err: str | None = None
    try:
        while True:
            seen.update(descendants(proc.pid))
            now = time.monotonic()
            every = _SAMPLE_S if now - started < _SAMPLE_FAST_FOR_S else _SAMPLE_SLOW_S
            try:
                out, err = proc.communicate(timeout=max(0.0, min(every, deadline - now)))
                break
            except subprocess.TimeoutExpired:
                if proc.poll() is not None:
                    break  # the harness is gone; what holds its output is left over
                if time.monotonic() >= deadline:
                    timed_out = True
                    break
    finally:
        # Without a process list, the harness's own group is all that is known.
        with contextlib.suppress(RuntimeError):
            stop_started(proc.pid, seen, reaped=proc.poll() is not None)
        if proc.poll() is None:
            with contextlib.suppress(ProcessLookupError):
                proc.kill()
        if out is None:
            try:
                out, err = proc.communicate(timeout=_DRAIN_S)
            except subprocess.TimeoutExpired as exc:
                out, err = _text(exc.stdout), _text(exc.stderr)
                for pipe in (proc.stdout, proc.stderr):
                    if pipe is not None:
                        pipe.close()
                with contextlib.suppress(subprocess.TimeoutExpired):
                    proc.wait(timeout=_DRAIN_S)
    code = -1 if timed_out or proc.returncode is None else proc.returncode
    return subprocess.CompletedProcess(list(argv), code, out or "", err or "")


def _text(output: bytes | str | None) -> str:
    """What a pipe had given when a read timed out (bytes, even in text mode)."""
    if isinstance(output, bytes):
        return output.decode(errors="replace")
    return output or ""


def _pythonpath() -> str:
    """Where ``smart_gateway`` and ``traces`` come from for the bridge and MCP subprocesses."""
    import vicaria_contracts

    import smart_gateway

    roots = {
        str(Path(smart_gateway.__file__).resolve().parents[1]),
        str(Path(vicaria_contracts.__file__).resolve().parents[1]),
    }
    existing = os.environ.get("PYTHONPATH")
    return os.pathsep.join(sorted(roots) + ([existing] if existing else []))


__all__ = [
    "Evidence",
    "InstallLock",
    "OpenCodeDriver",
    "Scenario",
    "descendant_groups",
    "descendants",
    "install_lock",
    "kill_groups",
    "kill_seen",
    "opencode_version",
    "package_cache",
    "run_contained",
    "stop_started",
]
