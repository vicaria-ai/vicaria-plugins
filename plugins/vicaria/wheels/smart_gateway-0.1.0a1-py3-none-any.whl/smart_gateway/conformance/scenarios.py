"""Compatibility import: moved to ``vicaria_client.scenarios`` (vicaria-docs RFC 0065 §3.6)."""

import importlib
import sys

sys.modules[__name__] = importlib.import_module("vicaria_client.scenarios")
