"""Plan policies every conformance driver runs: what the plan source answers, per check.

A *policy* is what :class:`smart_gateway.control.plans.PlanServer` answers a
plan request with. These are the answers RFC 0009 §6 needs — retain, apply,
suggest, a moved baseline, a superseded revision, ``cannot_execute``, a server
error — written once, against the request's own active configuration, so
every harness driver asks the same questions and differs only in how it reads
the answers off its harness.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from vicaria_contracts.capability import Dimension, PromptShape
from vicaria_contracts.plan import Configuration, Disposition, Plan

from smart_gateway.control.plans import PlanRefused, Policy

RECIPE_ID = "recipe:conformance@v1"
RECIPE_TEXT = "VICARIA-RECIPE-TEXT Prefer the shortest correct answer."


def _variant(base: Configuration, **changes: str) -> Configuration:
    return Configuration(**{d.value: changes.get(d.value, base.value(d)) for d in Dimension})


def _plan(
    request: Mapping[str, Any],
    *,
    disposition: Disposition = Disposition.APPLY,
    changes: Mapping[str, str] | None = None,
    base_digest: str | None = None,
    revision: str | None = None,
    reason: str | None = None,
) -> tuple[dict[str, Any], dict[str, str]]:
    active = Configuration.from_dict(request["active_config"])
    changes = dict(changes or {})
    effective = None if disposition is Disposition.CANNOT_EXECUTE else _variant(active, **changes)
    plan = Plan(
        decision_id=request["decision_id"],
        request_revision=revision or request["request_revision"],
        base_config_digest=base_digest or active.digest(),
        disposition=disposition,
        effective_config=effective,
        prompt_shape=PromptShape.ADDITIVE if "prompt" in changes else None,
        evidence_ref="report:conformance",
        reason=reason,
    )
    recipes = {RECIPE_ID: RECIPE_TEXT} if changes.get("prompt") == RECIPE_ID else {}
    return plan.to_dict(), recipes


def retain() -> Policy:
    return lambda request: _plan(request, disposition=Disposition.RETAIN)


def apply(**changes: str) -> Policy:
    return lambda request: _plan(request, changes=changes)


def suggest(reason: str | None = None, **changes: str) -> Policy:
    return lambda request: _plan(
        request, disposition=Disposition.SUGGEST, changes=changes, reason=reason
    )


def stale_baseline(**changes: str) -> Policy:
    return lambda request: _plan(request, changes=changes, base_digest="sha256:" + "0" * 64)


def stale_revision(**changes: str) -> Policy:
    return lambda request: _plan(request, changes=changes, revision="req-superseded")


def cannot_execute(reason: str) -> Policy:
    return lambda request: _plan(request, disposition=Disposition.CANNOT_EXECUTE, reason=reason)


def server_error() -> Policy:
    def policy(_request: Mapping[str, Any]) -> tuple[dict[str, Any], dict[str, str]]:
        raise PlanRefused(500, "induced")

    return policy


__all__ = [
    "RECIPE_ID",
    "RECIPE_TEXT",
    "apply",
    "cannot_execute",
    "retain",
    "server_error",
    "stale_baseline",
    "stale_revision",
    "suggest",
]
