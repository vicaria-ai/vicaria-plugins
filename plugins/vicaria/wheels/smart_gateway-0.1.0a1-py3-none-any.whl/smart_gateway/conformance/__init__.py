"""Conformance drivers: RFC 0009 §6 run against a real harness, counted at the wire.

``vicaria_contracts.conformance`` delegates every check to a ``ConformanceDriver`` and
refuses to ship a fake one. This package holds the drivers, one per harness,
and the two pieces of infrastructure they share:

* :mod:`smart_gateway.conformance.mock_provider` — a scripted Anthropic
  Messages server that records every request. It is the **provider**, and its
  log is what "zero provider requests" is counted against. It is not a fake
  harness: the harness is the real ``claude`` binary, spawned per check.
* :mod:`smart_gateway.conformance.mcp_probe` — a stdio MCP server with one tool,
  so "a registered tool actually runs" can be observed as a ``tools/call`` on
  one side and a ``tool_result`` on the wire on the other.

The plan source the checks need is the reference :class:`~smart_gateway.control.plans.PlanServer`.
"""
