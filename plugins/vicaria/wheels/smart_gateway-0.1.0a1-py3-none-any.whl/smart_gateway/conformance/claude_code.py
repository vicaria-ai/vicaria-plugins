"""The Claude Code conformance driver: RFC 0009 §6, against the real ``claude`` binary.

Every check spawns ``claude -p`` with the control plugin loaded, the commit
point as ``ANTHROPIC_BASE_URL``, a scripted provider behind the commit point,
and a reference plan server standing in for the recommendation service. The
harness is real; the provider, the plan source and the induced faults are the
driver's. Nothing about Claude Code is simulated.

WHAT COUNTS

* **Provider requests** are the scripted provider's own log — what arrived —
  not the commit point's account of what it forwarded. Checks 6c, 9 and 10 pass
  on a count of zero from that log and nothing else.
* **Receipts** are the provider's record of the request body: the model and
  ``output_config.effort`` it carried, whether the recipe text was present,
  whether a staging block leaked through. A mutation is confirmed by what the
  provider received, never by the absence of an error.
* **Records** are the control plugin's and commit point's ``sg.control.v1``
  lines, read back from the data directory: what each component decided, and
  why.

WHAT IT REFUSES TO DO

Run without the binary. A missing ``claude`` is reported as every check
``NOT_RUN`` with the reason, which ``ConformanceReport.supported()`` counts as
not supported — a skip is not a pass (``scripts/control_conformance.py``).

Each run gets a fresh ``HOME``, a fresh data directory and a fresh working
directory, so no session state or settings file from one check reaches the
next, and none from the developer's machine reaches any of them.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
import threading
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from vicaria_contracts.conformance import CheckId, CheckResult, CheckStatus

from smart_gateway.conformance.mock_provider import MockProvider
from smart_gateway.control.commit_point import serve
from smart_gateway.control.config import (
    CONTROL_SCHEMA,
    EFFORT_UNSET,
    write_control,
)
from smart_gateway.control.plans import PlanServer, Policy
from smart_gateway.control.records import iter_records

REPO = Path(__file__).resolve().parents[3]
PLUGIN_CONTROL = REPO / "plugin-control"
PROBE_TOOL = "mcp__vicaria__vicaria_probe"
DECLARED_ONLY_TOOL = "mcp__vicaria__vicaria_declared_only"
NARROW_PROFILE = "profile:narrow@v1"
#: Tool names as Claude Code puts them on the wire. The profile keeps these; the
#: commit point removes everything else from the request's ``tools`` array.
NARROWED_TOOLS = ["Read", "Edit", "Write"]
AGENT_TOOL = "Agent"  # Claude Code's subagent tool: a child episode of the session
_CLOSED_PORT_URL = "http://127.0.0.1:1"  # nobody listens on port 1: connection refused, fast
# The plan policies are shared with every other driver (conformance/scenarios.py)
# and re-exported here, where the tests and the first driver learned to find them.
from smart_gateway.conformance.scenarios import (  # noqa: E402
    RECIPE_ID,
    RECIPE_TEXT,
    apply,
    cannot_execute,
    retain,
    server_error,
    stale_baseline,
    stale_revision,
    suggest,
)

# --- one run ------------------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Scenario:
    prompt: str = "reply with exactly: ok"
    policy: Policy | None = field(default_factory=retain)  # None: the plan source is down
    script: Sequence[Mapping[str, Any]] = ({"text": "ok"},)
    induce: str | None = None
    levels: Mapping[str, str] = field(default_factory=dict)
    denied_models: Sequence[str] = ()
    mcp: bool = False
    tools: Sequence[str] = ("mcp:vicaria_probe", "mcp:vicaria_declared_only", NARROW_PROFILE)
    max_turns: int = 3


@dataclass(slots=True)
class Evidence:
    exit_code: int
    events: list[dict[str, Any]]
    result: dict[str, Any] | None
    wire: list[dict[str, Any]]
    control: list[dict[str, Any]]
    plan_requests: list[dict[str, Any]]
    mcp_calls: list[dict[str, Any]]
    errors: str
    stderr: str
    last_wire_body: dict[str, Any] | None = None

    def stage(self) -> dict[str, Any] | None:
        stages = [r for r in self.control if r["kind"] == "stage" and r.get("prompt_id")]
        return stages[-1] if stages else None

    def dispatch(self) -> dict[str, Any] | None:
        dispatches = self.dispatches()
        return dispatches[-1] if dispatches else None

    def dispatches(self) -> list[dict[str, Any]]:
        """Every commit-point dispatch, one per provider request."""
        return [r for r in self.control if r["kind"] == "dispatch"]

    def usage(self) -> list[dict[str, Any]]:
        """What each dispatched request cost, as the commit point read it off the reply."""
        return [r for r in self.control if r["kind"] == "usage"]

    def signals(self) -> list[dict[str, Any]]:
        return [r["signal"] for r in self.control if r["kind"] == "stage" and "signal" in r]


class ClaudeCodeDriver:
    """Implements ``vicaria_contracts.conformance.ConformanceDriver`` for Claude Code."""

    def __init__(
        self,
        *,
        claude_bin: str = "claude",
        model: str = "claude-opus-5",
        effort: str = "high",
        candidate_model: str = "claude-haiku-4-5",
        candidate_effort: str = "low",
        timeout_s: float = 150.0,
        keep_dir: Path | None = None,
    ) -> None:
        self.claude_bin = shutil.which(claude_bin) or claude_bin
        self.model = model
        self.effort = effort
        self.candidate_model = candidate_model
        self.candidate_effort = candidate_effort
        self.timeout_s = timeout_s
        self.keep_dir = keep_dir
        self.available = shutil.which(claude_bin) is not None
        self._version: str | None = None

    # --- identity --------------------------------------------------------------

    def harness_identity(self) -> tuple[str, str, str]:
        from smart_gateway import __version__

        if not self.available:
            return ("claude-code", "not-installed", __version__)
        if self._version is None:
            out = subprocess.run(
                [self.claude_bin, "--version"], capture_output=True, text=True, timeout=30
            )
            self._version = (out.stdout.strip().split() or ["unknown"])[0]
        return ("claude-code", self._version, __version__)

    # --- the run -------------------------------------------------------------

    def run(self, scenario: Scenario) -> Evidence:
        if not self.available:
            raise RuntimeError(f"{self.claude_bin} is not installed")
        root = Path(tempfile.mkdtemp(prefix="vicaria-conformance-"))
        provider = MockProvider(scenario.script).start()
        plan_server = PlanServer(scenario.policy).start() if scenario.policy is not None else None
        commit_server = None
        try:
            data_dir = root / "sg-data"
            for sub in ("raw", "state", "derived", "reports"):
                (data_dir / sub).mkdir(parents=True, exist_ok=True)
            home, work = root / "home", root / "work"
            home.mkdir()
            work.mkdir()
            control = write_control(
                data_dir / "control.json",
                {
                    "schema": CONTROL_SCHEMA,
                    "plan_source": plan_server.url if plan_server else _CLOSED_PORT_URL,
                    "upstream": provider.url,
                    "models": sorted({self.model, self.candidate_model, "claude-sonnet-4-5"}),
                    "efforts": ["low", "medium", "high", "xhigh", "max"],
                    "tools": list(scenario.tools),
                    "tool_profiles": {NARROW_PROFILE: NARROWED_TOOLS},
                    "levels": dict(scenario.levels),
                    "default_model": self.model,
                    "default_effort": self.effort,
                    "denied_models": list(scenario.denied_models),
                    "harness_version": self.harness_identity()[1],
                    "plan_timeout_s": 3.0,
                },
            )
            commit_server = serve(control, data_dir, port=0)
            threading.Thread(target=commit_server.serve_forever, daemon=True).start()
            host, port = commit_server.server_address[:2]
            base_url = f"http://{host}:{port}"

            argv = [
                self.claude_bin,
                "-p",
                scenario.prompt,
                "--output-format",
                "stream-json",
                "--verbose",
                "--model",
                self.model,
                "--plugin-dir",
                str(PLUGIN_CONTROL),
                "--setting-sources",
                "",
                "--max-turns",
                str(scenario.max_turns),
            ]
            mcp_log = root / "mcp.jsonl"
            if scenario.mcp:
                mcp_config = root / "mcp.json"
                mcp_config.write_text(
                    json.dumps(
                        {
                            "mcpServers": {
                                "vicaria": {
                                    "command": "python3",
                                    "args": [
                                        "-m",
                                        "smart_gateway.conformance.mcp_probe",
                                        str(mcp_log),
                                    ],
                                    "env": {"PYTHONPATH": _pythonpath()},
                                }
                            }
                        }
                    )
                )
                argv += [
                    "--mcp-config",
                    str(mcp_config),
                    "--strict-mcp-config",
                    "--allowedTools",
                    PROBE_TOOL,
                    "--permission-mode",
                    "acceptEdits",
                ]

            env = {
                "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
                "HOME": str(home),
                "TERM": "dumb",
                "PYTHONPATH": _pythonpath(),
                "SG_DATA_DIR": str(data_dir),
                "ANTHROPIC_API_KEY": "sk-ant-conformance",
                "ANTHROPIC_BASE_URL": base_url,
                "CLAUDE_CODE_EFFORT_LEVEL": self.effort,
                "DISABLE_TELEMETRY": "1",
                "DISABLE_AUTOUPDATER": "1",
                "DISABLE_ERROR_REPORTING": "1",
                "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1",
            }
            if scenario.induce:
                env["VICARIA_INDUCE"] = scenario.induce
            try:
                proc = subprocess.run(
                    argv,
                    cwd=work,
                    env=env,
                    stdin=subprocess.DEVNULL,
                    capture_output=True,
                    text=True,
                    timeout=self.timeout_s,
                )
                exit_code, stdout, stderr = proc.returncode, proc.stdout, proc.stderr
            except subprocess.TimeoutExpired as exc:
                exit_code = -1
                stdout = (
                    (exc.stdout or b"").decode()
                    if isinstance(exc.stdout, bytes)
                    else (exc.stdout or "")
                )
                stderr = "timed out"

            events: list[dict[str, Any]] = []
            for line in stdout.splitlines():
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(obj, dict):
                    events.append(obj)
            results = [e for e in events if e.get("type") == "result"]
            mcp_calls: list[dict[str, Any]] = []
            if mcp_log.exists():
                mcp_calls = [
                    json.loads(line) for line in mcp_log.read_text().splitlines() if line.strip()
                ]
            errors_path = data_dir / "raw" / "control_errors.log"
            return Evidence(
                exit_code=exit_code,
                events=events,
                result=results[-1] if results else None,
                wire=provider.messages_requests,
                control=list(iter_records(data_dir)),
                plan_requests=list(plan_server.requests) if plan_server else [],
                mcp_calls=mcp_calls,
                errors=errors_path.read_text() if errors_path.exists() else "",
                stderr=stderr,
                last_wire_body=provider.last_body,
            )
        finally:
            if commit_server is not None:
                commit_server.shutdown()
                commit_server.server_close()
            if plan_server is not None:
                plan_server.stop()
            provider.stop()
            if self.keep_dir is not None:
                shutil.copytree(root, self.keep_dir / root.name, dirs_exist_ok=True)
            shutil.rmtree(root, ignore_errors=True)

    # --- the ten checks ---------------------------------------------------------

    def _result(self, check: CheckId, ok: bool, detail: str) -> CheckResult:
        return CheckResult(check, CheckStatus.PASSED if ok else CheckStatus.FAILED, detail)

    def _not_run(self, check: CheckId) -> CheckResult:
        return CheckResult(check, CheckStatus.NOT_RUN, f"{self.claude_bin} is not installed")

    def _reference_on_wire(self, ev: Evidence) -> bool:
        return (
            len(ev.wire) >= 1
            and ev.wire[0]["model"] == self.model
            and (ev.wire[0]["effort"] or EFFORT_UNSET) == self.effort
            and "VICARIA-RECIPE-TEXT" not in ev.wire[0]["sentinels"]
            and not ev.wire[0]["has_staging_block"]
        )

    def check_interception(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.INTERCEPTION)
        ev = self.run(Scenario())
        stage, dispatch = ev.stage(), ev.dispatch()
        saw_prompt = (
            stage is not None
            and (stage.get("prompt_features") or {}).get("length") == len("reply with exactly: ok")
            and bool(stage.get("prompt_id"))
        )
        saw_request = (
            dispatch is not None
            and stage is not None
            and dispatch.get("session_id") == stage.get("session_id")
            and dispatch.get("decision_id") == stage.get("decision_id")
        )
        return self._result(
            CheckId.INTERCEPTION,
            saw_prompt and saw_request and len(ev.wire) == 1,
            f"hook saw the submitted prompt ({saw_prompt}); the commit point saw the assembled "
            f"request for the same decision ({saw_request}); provider requests: {len(ev.wire)}",
        )

    def check_declared_mutations(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.DECLARED_MUTATIONS)
        # (a) Every control this descriptor declares at apply level — model,
        # effort, prompt, tools — confirmed from the provider's receipt of one
        # request. Tools: the request's tool list arrives narrowed to the
        # profile, and non-empty, so the harness still has tools to work with.
        one = self.run(
            Scenario(
                policy=apply(
                    model=self.candidate_model,
                    effort=self.candidate_effort,
                    prompt=RECIPE_ID,
                    tools=NARROW_PROFILE,
                )
            )
        )
        receipt = one.wire[0] if one.wire else {}
        model_ok = receipt.get("model") == self.candidate_model
        effort_ok = receipt.get("effort") == self.candidate_effort
        prompt_ok = "VICARIA-RECIPE-TEXT" in receipt.get("sentinels", [])
        clean = not receipt.get("has_staging_block", True)
        offered = receipt.get("tools") or []
        tools_ok = bool(offered) and set(offered) <= set(NARROWED_TOOLS)
        dispatch = one.dispatch() or {}
        removed = dispatch.get("narrowed_tools") or []
        one_ok = (
            len(one.wire) == 1
            and model_ok
            and effort_ok
            and prompt_ok
            and clean
            and tools_ok
            and bool(removed)
            and dispatch.get("action") == "materialize"
        )
        # (b) The same mutation across a tool loop: the second request of the
        # turn carries a tool result, not a prompt, and must still run the
        # decided configuration — the block is found past the tool result and
        # applied to every request of the turn, and stripped from every one.
        loop = self.run(
            Scenario(
                prompt="use the probe tool",
                policy=apply(
                    model=self.candidate_model, effort=self.candidate_effort, prompt=RECIPE_ID
                ),
                script=[
                    {"tool_use": {"name_prefix": PROBE_TOOL, "input": {"echo": "hello"}}},
                    {"text": "tool done"},
                ],
                mcp=True,
            )
        )
        loop_receipts_ok = len(loop.wire) == 2 and all(
            r.get("model") == self.candidate_model
            and r.get("effort") == self.candidate_effort
            and "VICARIA-RECIPE-TEXT" in r.get("sentinels", [])
            and not r.get("has_staging_block", True)
            for r in loop.wire
        )
        loop_dispatches = [d for d in loop.dispatches() if d.get("action") == "materialize"]
        loop_ok = (
            loop_receipts_ok
            and len(loop_dispatches) == 2
            and len({d.get("decision_id") for d in loop_dispatches}) == 1
            and any(c.get("method") == "tools/call" for c in loop.mcp_calls)
        )
        return self._result(
            CheckId.DECLARED_MUTATIONS,
            one_ok and loop_ok,
            f"one request: model={receipt.get('model')} effort={receipt.get('effort')} "
            f"recipe_present={prompt_ok} block_leaked={not clean} tools_narrowed_to="
            f"{sorted(offered)} (removed {len(removed)}); commit action="
            f"{dispatch.get('action')}; provider requests: {len(one.wire)}. Tool loop: "
            f"{len(loop.wire)} requests, every one on the decided configuration with the "
            f"recipe and no block ({loop_receipts_ok}); {len(loop_dispatches)} materializing "
            f"dispatches under one decision",
        )

    def check_level_honored(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.LEVEL_HONORED)
        narrowed = {"model": "suggest"}
        refused = self.run(Scenario(policy=apply(model=self.candidate_model), levels=narrowed))
        served = self.run(Scenario(policy=suggest(model=self.candidate_model), levels=narrowed))
        undeclared = self.run(
            Scenario(policy=suggest(workflow="workflow:other@v1"), levels={"workflow": "unknown"})
        )
        r_stage, s_stage, u_stage = (
            refused.stage() or {},
            served.stage() or {},
            undeclared.stage() or {},
        )
        refused_ok = (r_stage.get("validation") or {}).get(
            "refusal"
        ) == "insufficient_level" and self._reference_on_wire(refused)
        served_ok = (
            (s_stage.get("validation") or {}).get("ok") is True
            and s_stage.get("surfaced") is True
            and (served.dispatch() or {}).get("action") == "surface"
            and self._reference_on_wire(served)
        )
        undeclared_ok = (u_stage.get("validation") or {}).get(
            "refusal"
        ) == "insufficient_level" and self._reference_on_wire(undeclared)
        return self._result(
            CheckId.LEVEL_HONORED,
            refused_ok and served_ok and undeclared_ok,
            f"apply on a suggest-level control refused ({refused_ok}); the same change served as "
            f"a suggestion and surfaced ({served_ok}); an undeclared control refused "
            f"({undeclared_ok}); the reference ran on the wire in every case",
        )

    def check_stale_baseline_refused(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.STALE_BASELINE_REFUSED)
        moved = self.run(Scenario(policy=stale_baseline(model=self.candidate_model)))
        superseded = self.run(Scenario(policy=stale_revision(model=self.candidate_model)))
        m_refusal = ((moved.stage() or {}).get("validation") or {}).get("refusal")
        s_refusal = ((superseded.stage() or {}).get("validation") or {}).get("refusal")
        return self._result(
            CheckId.STALE_BASELINE_REFUSED,
            m_refusal == "baseline_mismatch"
            and s_refusal == "stale_request_revision"
            and self._reference_on_wire(moved)
            and self._reference_on_wire(superseded),
            f"moved baseline refused as {m_refusal}; superseded revision refused as {s_refusal}; "
            "the reference ran on the wire in both cases",
        )

    def check_tool_execution(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.TOOL_EXECUTION)
        ev = self.run(
            Scenario(
                prompt="use the probe tool",
                script=[
                    {"tool_use": {"name_prefix": PROBE_TOOL, "input": {"echo": "hello"}}},
                    {"text": "tool done"},
                ],
                mcp=True,
            )
        )
        offered = ev.wire[0]["tools"] if ev.wire else []
        registered_ran = any(c.get("method") == "tools/call" for c in ev.mcp_calls)
        result_on_wire = len(ev.wire) >= 2 and "PROBE-EXECUTED:hello" in (
            ev.wire[1].get("last_tool_result") or ""
        )
        declared_only_absent = DECLARED_ONLY_TOOL not in offered
        return self._result(
            CheckId.TOOL_EXECUTION,
            PROBE_TOOL in offered and registered_ran and result_on_wire and declared_only_absent,
            f"registered tool offered ({PROBE_TOOL in offered}), called ({registered_ran}), "
            f"its result reached the provider ({result_on_wire}); declared-only tool not offered "
            f"({declared_only_absent}); provider requests: {len(ev.wire)}",
        )

    def check_cross_component_atomicity(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.CROSS_COMPONENT_ATOMICITY)
        plan = apply(model=self.candidate_model, effort=self.candidate_effort, prompt=RECIPE_ID)
        before = self.run(Scenario(policy=plan, induce="fail_before_staging"))
        after = self.run(Scenario(policy=plan, induce="corrupt_confirmation"))
        irreversible = self.run(
            Scenario(policy=plan, induce="corrupt_confirmation,contribution_class=neither")
        )
        before_ok = self._reference_on_wire(before) and len(before.wire) == 1
        after_dispatch = after.dispatch() or {}
        after_ok = (
            self._reference_on_wire(after)
            and len(after.wire) == 1
            and after_dispatch.get("action") == "reference"
            and (after_dispatch.get("records") or {}).get("commit", {}).get("refusal")
            == "confirmation_mismatch"
        )
        irr_dispatch = irreversible.dispatch() or {}
        irreversible_ok = (
            len(irreversible.wire) == 0
            and irr_dispatch.get("action") == "cannot_execute"
            and (irr_dispatch.get("records") or {}).get("commit", {}).get("refusal")
            == "unstageable_contribution"
        )
        return self._result(
            CheckId.CROSS_COMPONENT_ATOMICITY,
            before_ok and after_ok and irreversible_ok,
            f"hook failed before staging → reference ran ({before_ok}); staging succeeded and "
            f"confirmation failed → reference ran with no staged text ({after_ok}); irreversible "
            f"contribution → zero provider requests ({irreversible_ok}, "
            f"saw {len(irreversible.wire)})",
        )

    def check_event_completeness(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.EVENT_COMPLETENESS)
        ev = self.run(Scenario())
        kinds = {s.get("signal") for s in ev.signals()}
        sessions = {s.get("session_id") for s in ev.signals()} | {
            (ev.stage() or {}).get("session_id")
        }
        stage = ev.stage() or {}
        prompt_bound = all(
            s.get("prompt_id") == stage.get("prompt_id")
            for s in ev.signals()
            if s.get("signal") in ("turn_complete", "session_end")
        )
        # Usage is a record on disk, joined to the decision — not the number the
        # harness printed on the way out, which nothing keeps.
        usage = [
            u
            for u in ev.usage()
            if u.get("decision_id") == stage.get("decision_id")
            and isinstance(u.get("input_tokens"), int)
            and isinstance(u.get("output_tokens"), int)
        ]
        needed = {"session_start", "prompt", "turn_complete", "session_end"}
        boundaries_ok = needed <= kinds and len(sessions - {None}) == 1 and prompt_bound
        # Parent/child: a subagent is a child episode of the session. Both of
        # its boundaries land on the parent's session with the child's id, and
        # its requests are dispatched (and their usage kept) like any other.
        child = self.run(
            Scenario(
                prompt="delegate to a subagent",
                script=[
                    {
                        "tool_use": {
                            "name_prefix": AGENT_TOOL,
                            "input": {
                                "description": "probe",
                                "prompt": "reply with exactly: ok",
                                "subagent_type": "general-purpose",
                            },
                        }
                    },
                    {"text": "ok"},
                    {"text": "done"},
                ],
                max_turns=4,
            )
        )
        starts = [s for s in child.signals() if s.get("signal") == "subagent_start"]
        stops = [s for s in child.signals() if s.get("signal") == "subagent_stop"]
        parent = (child.stage() or {}).get("session_id")
        child_ok = (
            len(starts) == 1
            and len(stops) == 1
            and bool(starts[0].get("agent_id"))
            and starts[0].get("agent_id") == stops[0].get("agent_id")
            and starts[0].get("session_id") == parent
            and len(child.wire) >= 3
            and len(child.usage()) >= 3
        )
        return self._result(
            CheckId.EVENT_COMPLETENESS,
            boundaries_ok and bool(usage) and child_ok,
            f"signals recorded: {sorted(k for k in kinds if k)}; one session id "
            f"({len(sessions - {None})}); turn and end bound to the prompt ({prompt_bound}); "
            f"usage persisted for the decision ({len(usage)} record(s)); a subagent's start "
            f"and stop recorded on the parent session with one agent id ({child_ok}: "
            f"{len(starts)} start, {len(stops)} stop, {len(child.wire)} provider requests, "
            f"{len(child.usage())} usage records)",
        )

    def check_server_unavailable_recovery(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.SERVER_UNAVAILABLE_RECOVERY)
        ev = self.run(Scenario(policy=None))
        stage, dispatch = ev.stage() or {}, ev.dispatch() or {}
        kept_working = ev.result is not None and ev.result.get("is_error") is False
        recorded = (
            stage.get("origin") == "unavailable"
            and stage.get("unavailable_reason") == "unreachable"
        )
        decision = (dispatch.get("records") or {}).get("decision") or {}
        # "Events buffer": with the plan source unreachable for the whole run,
        # every record of the run still lands on disk — the boundaries, the
        # prompt, the dispatch, the usage. The local records ARE the buffer.
        # What this does not verify: replaying them to a server once it is
        # back. This package has no uploader; that path belongs to the one
        # that does, and a pass here does not claim it.
        kinds = {s.get("signal") for s in ev.signals()}
        needed = {"session_start", "prompt", "turn_complete", "session_end"}
        buffered = needed <= kinds and bool(ev.usage()) and bool(dispatch)
        return self._result(
            CheckId.SERVER_UNAVAILABLE_RECOVERY,
            kept_working
            and recorded
            and self._reference_on_wire(ev)
            and decision.get("origin") == "unavailable"
            and buffered,
            f"harness completed ({kept_working}); the hook recorded an unavailable decision "
            f"({recorded}); the commit point dispatched the reference and recorded origin="
            f"{decision.get('origin')}; provider requests: {len(ev.wire)}; every record of "
            f"the run landed locally while the source was down ({buffered}: signals "
            f"{sorted(k for k in kinds if k)}, {len(ev.dispatches())} dispatch, "
            f"{len(ev.usage())} usage). Not verified: replay to a recovered server — this "
            "package has no uploader",
        )

    def check_cannot_execute_stops(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.CANNOT_EXECUTE_STOPS)
        ev = self.run(Scenario(policy=cannot_execute("reference provider prohibited")))
        stage = ev.stage() or {}
        blocked = stage.get("blocked") is True
        surfaced = "cannot_execute" in str((ev.result or {}).get("result", ""))
        return self._result(
            CheckId.CANNOT_EXECUTE_STOPS,
            len(ev.wire) == 0 and blocked and surfaced and (ev.result or {}).get("num_turns") == 0,
            f"provider requests: {len(ev.wire)}; the hook blocked the prompt ({blocked}) and the "
            f"reason reached the user ({surfaced})",
        )

    def check_inadmissible_fallback_stops(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.INADMISSIBLE_FALLBACK_STOPS)
        ev = self.run(
            Scenario(
                policy=apply(
                    model=self.candidate_model, effort=self.candidate_effort, prompt=RECIPE_ID
                ),
                induce="corrupt_confirmation",
                denied_models=[self.model],
            )
        )
        stage, dispatch = ev.stage() or {}, ev.dispatch() or {}
        plan_valid = (stage.get("validation") or {}).get("ok") is True
        commit = (dispatch.get("records") or {}).get("commit") or {}
        return self._result(
            CheckId.INADMISSIBLE_FALLBACK_STOPS,
            plan_valid
            and len(ev.wire) == 0
            and dispatch.get("action") == "cannot_execute"
            and commit.get("refusal") == "reference_inadmissible"
            and bool(commit.get("admission_reason"))
            and "confirmation" in str(commit.get("detail")),
            f"valid plan ({plan_valid}); staging failed; the reference was inadmissible; provider "
            f"requests: {len(ev.wire)}; refusal={commit.get('refusal')} with admission reason "
            f"({bool(commit.get('admission_reason'))}) and the staging failure in the detail",
        )


def _pythonpath() -> str:
    """Where ``smart_gateway`` and ``traces`` come from for the hook and MCP subprocesses."""
    import vicaria_contracts

    import smart_gateway

    roots = {
        str(Path(smart_gateway.__file__).resolve().parents[1]),
        str(Path(vicaria_contracts.__file__).resolve().parents[1]),
    }
    existing = os.environ.get("PYTHONPATH")
    return os.pathsep.join(sorted(roots) + ([existing] if existing else []))


__all__ = [
    "RECIPE_ID",
    "RECIPE_TEXT",
    "ClaudeCodeDriver",
    "Evidence",
    "Scenario",
    "apply",
    "cannot_execute",
    "retain",
    "server_error",
    "stale_baseline",
    "stale_revision",
    "suggest",
]
