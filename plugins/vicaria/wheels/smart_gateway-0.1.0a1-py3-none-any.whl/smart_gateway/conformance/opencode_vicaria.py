"""RFC 0009 §6 against the v1 product: OpenCode, @vicaria/opencode, the service, a mock OpenRouter.

The driver for ``sg control conformance --harness opencode-vicaria``. Every
check drives the real ``opencode`` binary with the TypeScript plugin
(``plugin-opencode/dist/index.js``), the v1 service from intelligent-tools
(``vicaria_server``, run in this process on a random port) and
:class:`~smart_gateway.conformance.mock_openrouter.MockOpenRouter` standing in
for OpenRouter behind the service's gateway. What each check reads is the
wire (what reached the provider), the plugin's local records, and the
service's journal — never the adapter's word for what it did.

Two things the pilot driver could induce from the outside are induced here at
the wire instead, because the product has no test hooks: a *faulty server* is
a small proxy between the plugin and the service that rewrites a plan
response (a moved baseline, a superseded revision, a missing recipe, a 500),
and a *service that is down* is a run with no service at all against a home
that cached the configuration in an earlier run. Both are the situations the
checks exist for, produced the way they would happen.

Runs share OpenCode's package cache and are contained as the pilot driver's
are (:func:`~smart_gateway.conformance.opencode.package_cache`,
:func:`~smart_gateway.conformance.opencode.run_contained`).
"""

from __future__ import annotations

import json
import os
import shutil
import socket
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.request
from collections import Counter
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from vicaria_contracts.conformance import CheckId, CheckResult, CheckStatus

from smart_gateway.conformance.mock_openrouter import (
    PROVIDER_NAME,
    MockOpenRouter,
    last_tool_result,
    offered_tools,
    user_text,
)
from smart_gateway.conformance.opencode import (
    install_lock,
    opencode_version,
    package_cache,
    run_contained,
)

REPO = Path(__file__).resolve().parents[3]
PLUGIN = REPO / "plugin-opencode" / "dist" / "index.js"
FIXTURE = REPO / "plugin-opencode" / "test" / "fixtures" / "plan_validation.json"

STRONG = "anthropic/claude-sonnet-4.5"
CHEAP = "anthropic/claude-haiku-4.5"
RECIPE_ID = "recipe:conformance@v1"
RECIPE_TEXT = "VICARIA-RECIPE-TEXT Prefer the shortest correct answer."
PROBE_TOOL = "vicaria_vicaria_probe"  # <mcp server id>_<tool name>, as OpenCode names it
NARROWED_TOOL = "glob"  # harmless if it ever ran; the plan removes it

#: What the gateway adds to every body it forwards, the reference included, so
#: the reference arm's cost is recorded too (``vicaria_server/gateway.py``,
#: rules 1 and 5). A routed turn carrying exactly this has still run unrouted
#: in everything the plan could have changed.
GATEWAY_USAGE = {"include": True}
TASK_TOOL = "task"  # OpenCode's subagent tool: a child session with a parentID
KEY = "sk-or-v1-conformance-THE-ORGS-OWN-KEY"
PROMPT = "reply with exactly: ok"

PlanMutation = Callable[[dict[str, Any]], dict[str, Any] | None]


# --- policies: what the organization declares, per check ------------------------------


def _policy(arm: Mapping[str, Any], *, allowed: Sequence[str] = (CHEAP, STRONG)) -> dict[str, Any]:
    return {
        "schema": "vicaria.policy.v1",
        "allowed_models": list(allowed),
        "protected_tools": ["read", "grep"],
        "capture": {"prompt_text": False, "recent_turns": 0, "store_text": False},
        "mode": "declared",
        "strata": [{"id": "first", "when": {"turn": "first"}}, {"id": "other", "when": {}}],
        "arms": {"reference": {}, "candidate": dict(arm)},
        "declared": {
            "first": {"arm": "candidate" if arm else "reference"},
            "other": {"arm": "candidate" if arm else "reference"},
        },
    }


def reference() -> dict[str, Any]:
    return _policy({})


def apply(**changes: Any) -> dict[str, Any]:
    arm: dict[str, Any] = {}
    if "model" in changes:
        arm["model"] = changes["model"]
    if "effort" in changes:
        arm["effort"] = changes["effort"]
    if changes.get("prompt"):
        arm["prompt"] = {"recipe": RECIPE_ID, "text": RECIPE_TEXT}
    if changes.get("remove"):
        arm["tools"] = {"remove": list(changes["remove"])}
    return _policy(arm)


def deny_reference(**changes: Any) -> dict[str, Any]:
    """The developer's own model is not allowed; an arm may or may not replace it."""
    policy = apply(**changes)
    policy["allowed_models"] = [STRONG]
    return policy


# --- plan mutations: a faulty server, at the wire ------------------------------------------


def moved_baseline(answer: dict[str, Any]) -> dict[str, Any]:
    answer["plan"]["base_config_digest"] = "sha256:" + "0" * 64
    return answer


def superseded_revision(answer: dict[str, Any]) -> dict[str, Any]:
    answer["plan"]["request_revision"] = "req-superseded"
    return answer


def missing_recipe(answer: dict[str, Any]) -> dict[str, Any]:
    answer["recipes"] = {}
    return answer


def silent(_answer: dict[str, Any]) -> None:
    return None  # the proxy answers 500


# --- scenarios and evidence ---------------------------------------------------------------


@dataclass(frozen=True, slots=True)
class Scenario:
    prompt: str = PROMPT
    policy: dict[str, Any] | None = field(default_factory=reference)  # None: no service runs
    script: Sequence[Mapping[str, Any]] = ({"text": "ok"},)
    mutate_plan: PlanMutation | None = None
    gateway_reachable: bool = True
    mcp: bool = False
    task_id: str | None = None
    #: Reuse an earlier run's home (its cached configuration) and organization.
    home: Path | None = None
    token: str | None = None
    timeout_s: float = 120.0


@dataclass(slots=True)
class Evidence:
    exit_code: int
    events: list[dict[str, Any]]
    wire: list[dict[str, Any]]  # the user's turn: every provider request carrying the prompt
    all_wire: list[dict[str, Any]]  # every chat completion, the title call included
    local: list[dict[str, Any]]  # the plugin's records
    decision: dict[str, Any] | None  # the service's journaled decision record for the turn
    service_records: list[dict[str, Any]]  # the service's records for the episode
    mcp_calls: list[dict[str, Any]]
    stdout: str
    home: Path
    token: str
    session_id: str | None

    def stages(self, phase: str) -> list[dict[str, Any]]:
        return [r for r in self.local if r["kind"] == "stage" and r.get("phase") == phase]

    def stage(self, phase: str) -> dict[str, Any] | None:
        rows = self.stages(phase)
        return rows[-1] if rows else None

    def signals(self) -> list[dict[str, Any]]:
        return [r for r in self.local if r["kind"] == "stage" and "signal" in r]

    def usage(self) -> list[dict[str, Any]]:
        return [r for r in self.local if r["kind"] == "usage"]

    def model_on_wire(self, index: int = 0) -> str | None:
        return self.wire[index]["body"].get("model") if len(self.wire) > index else None

    def effort_on_wire(self, index: int = 0) -> str | None:
        if len(self.wire) <= index:
            return None
        body = self.wire[index]["body"]
        reasoning = body.get("reasoning")
        if isinstance(reasoning, dict) and isinstance(reasoning.get("effort"), str):
            return reasoning["effort"]
        legacy = body.get("reasoning_effort")
        return legacy if isinstance(legacy, str) else None

    def recipe_on_wire(self, index: int = 0) -> bool:
        return len(self.wire) > index and RECIPE_TEXT in user_text(self.wire[index]["body"])

    def text(self) -> str:
        return self.stdout


class _PlanProxy:
    """Forwards the plugin's calls to the service; rewrites ``POST /v1/plan`` answers."""

    def __init__(self, upstream: str, mutate: PlanMutation) -> None:
        proxy = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args: Any) -> None:
                pass

            def _forward(self) -> None:
                length = int(self.headers.get("content-length") or 0)
                raw = self.rfile.read(length) if length else None
                headers = {
                    k: v
                    for k, v in self.headers.items()
                    if k.lower() not in ("host", "content-length", "connection")
                }
                req = urllib.request.Request(
                    upstream + self.path, data=raw, headers=headers, method=self.command
                )
                try:
                    with urllib.request.urlopen(req, timeout=10) as resp:
                        status, body = resp.status, resp.read()
                        ctype = resp.headers.get("content-type", "application/json")
                except urllib.error.HTTPError as exc:
                    status, body, ctype = exc.code, exc.read(), "application/json"
                if self.command == "POST" and self.path == "/v1/plan" and status == 200:
                    try:
                        answer = json.loads(body)
                    except json.JSONDecodeError:
                        answer = None
                    mutated = proxy.mutate(answer) if isinstance(answer, dict) else answer
                    if mutated is None:
                        status, body = 500, b'{"error": "induced"}'
                    else:
                        body = json.dumps(mutated).encode("utf-8")
                self.send_response(status)
                self.send_header("content-type", ctype)
                self.send_header("content-length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)

            do_GET = _forward
            do_POST = _forward

        self.mutate = mutate
        self._http = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self._thread = threading.Thread(target=self._http.serve_forever, daemon=True)

    @property
    def url(self) -> str:
        host, port = self._http.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> _PlanProxy:
        self._thread.start()
        return self

    def stop(self) -> None:
        self._http.shutdown()
        self._http.server_close()


class _Service:
    """vicaria_server in this process, on a fixed port, over a store that outlives restarts."""

    def __init__(self, db: Path, port: int) -> None:
        from vicaria_server.store import Store

        self.db = db
        self.port = port
        self.url = f"http://127.0.0.1:{port}"
        self.store = Store(db)
        self._server: Any = None
        self._thread: threading.Thread | None = None

    def start(self, *, upstream: str, public_url: str) -> None:
        import uvicorn
        from vicaria_server.app import create_app

        app = create_app(self.store, public_url=public_url, upstream_base_url=upstream)
        config = uvicorn.Config(app, host="127.0.0.1", port=self.port, log_level="warning")
        self._server = uvicorn.Server(config)
        self._thread = threading.Thread(target=self._server.run, daemon=True)
        self._thread.start()
        deadline = time.time() + 15
        while time.time() < deadline:
            if getattr(self._server, "started", False):
                return
            time.sleep(0.05)
        raise RuntimeError("the service did not start")

    def stop(self) -> None:
        if self._server is not None:
            self._server.should_exit = True
        if self._thread is not None:
            self._thread.join(timeout=10)
        self._server, self._thread = None, None

    def close(self) -> None:
        self.stop()
        self.store.close()


def _free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def _pythonpath() -> str:
    import vicaria_contracts

    import smart_gateway

    roots = {
        str(Path(smart_gateway.__file__).resolve().parents[1]),
        str(Path(vicaria_contracts.__file__).resolve().parents[1]),
    }
    existing = os.environ.get("PYTHONPATH")
    return os.pathsep.join(sorted(roots) + ([existing] if existing else []))


class VicariaOpenCodeDriver:
    """Conformance driver for the v1 OpenCode product."""

    def __init__(
        self,
        *,
        opencode_bin: str = "opencode",
        timeout_s: float = 120.0,
        keep_dir: Path | None = None,
    ) -> None:
        self.opencode_bin = shutil.which(opencode_bin) or opencode_bin
        self.timeout_s = timeout_s
        self.keep_dir = keep_dir
        self.port = _free_port()
        self.unavailable_reason = self._unavailable()
        self.available = self.unavailable_reason is None
        self._version: str | None = None
        self._service: _Service | None = None
        self._root = Path(tempfile.mkdtemp(prefix="vicaria-conformance-"))
        self._runs = 0

    def _unavailable(self) -> str | None:
        if not (Path(self.opencode_bin).exists() or shutil.which(self.opencode_bin)):
            return f"{self.opencode_bin} is not installed"
        if not PLUGIN.exists():
            return f"the plugin is not built ({PLUGIN}); run npm run build in plugin-opencode/"
        try:
            import starlette  # noqa: F401
            import uvicorn  # noqa: F401
            import vicaria_server.app  # noqa: F401
        except ImportError as exc:
            return f"the service is not importable ({exc}); install smart-gateway-server"
        return None

    # --- identity --------------------------------------------------------------------

    def harness_identity(self) -> tuple[str, str, str]:
        from smart_gateway import __version__

        if not self.available:
            return ("opencode", "not-installed", f"vicaria-opencode/{__version__}")
        if self._version is None:
            self._version = opencode_version(self.opencode_bin)
        return ("opencode", self._version, f"vicaria-opencode/{__version__}")

    # --- one run ----------------------------------------------------------------------

    def _service_for(self, scenario: Scenario) -> _Service:
        if self._service is None or scenario.token is None:
            if self._service is not None:
                self._service.close()
            self._runs += 1
            self._service = _Service(self._root / f"service-{self._runs}.db", self.port)
        return self._service

    def run(self, scenario: Scenario) -> Evidence:
        if not self.available:
            raise RuntimeError(self.unavailable_reason)
        self._runs += 1
        root = self._root / f"run-{self._runs}"
        home = scenario.home or (root / "home")
        work = root / "work"
        home.mkdir(parents=True, exist_ok=True)
        work.mkdir(parents=True, exist_ok=True)

        mock = MockOpenRouter(scenario.script).start()
        service = self._service_for(scenario)
        token = scenario.token
        proxy: _PlanProxy | None = None
        try:
            if scenario.policy is not None:
                if token is None:
                    organization, token = service.store.create_organization("conformance")
                    self._org_id = organization.org_id
                service.store.set_policy(self._org_id, scenario.policy)
                public_url = service.url if scenario.gateway_reachable else "http://127.0.0.1:1"
                service.start(upstream=mock.url + "/api/v1", public_url=public_url)
            server_url = service.url
            if scenario.mutate_plan is not None:
                proxy = _PlanProxy(service.url, scenario.mutate_plan).start()
                server_url = proxy.url
            assert token is not None, "a run without a service needs the token of an earlier run"

            mcp_log = root / "mcp.jsonl"
            config: dict[str, Any] = {
                "plugin": [str(PLUGIN)],
                "permission": "allow",
                "provider": {
                    "openrouter": {
                        "npm": "@ai-sdk/openai-compatible",
                        "name": "openrouter",
                        "options": {"baseURL": mock.url + "/api/v1", "apiKey": KEY},
                        # Only the developer's model is listed: a plan naming
                        # another one is "a model the client never listed".
                        "models": {CHEAP: {"name": "haiku"}},
                    }
                },
            }
            if scenario.mcp:
                config["mcp"] = {
                    "vicaria": {
                        "type": "local",
                        "command": [
                            sys.executable,
                            "-m",
                            "smart_gateway.conformance.mcp_probe",
                            str(mcp_log),
                        ],
                        "environment": {"PYTHONPATH": _pythonpath()},
                    }
                }
            cache = package_cache(self.harness_identity()[1])
            env = {
                "PATH": os.environ.get("PATH", "/usr/bin:/bin"),
                "HOME": str(home),
                "TERM": "dumb",
                "OPENCODE_CONFIG_CONTENT": json.dumps(config),
                "OPENCODE_DISABLE_AUTOUPDATE": "1",
                **cache,
                "VICARIA_SERVER": server_url,
                "VICARIA_TOKEN": token,
                "VICARIA_HOME": str(home / "vicaria"),
            }
            for key in (
                "HTTPS_PROXY",
                "HTTP_PROXY",
                "NO_PROXY",
                "SSL_CERT_FILE",
                "NODE_EXTRA_CA_CERTS",
                "VICARIA_DEBUG",
            ):
                if key in os.environ:
                    env[key] = os.environ[key]
            if scenario.task_id:
                env["VICARIA_TASK_ID"] = scenario.task_id

            # Records written before this run (a reused home) are not its evidence.
            started = _record_clock()
            argv = [
                self.opencode_bin,
                "run",
                # Where the plugin's user-facing notices actually are. `say`
                # writes stderr only under VICARIA_DEBUG, so the checks that ask
                # "did the reason reach the user" were reading a stream nothing
                # had written to since that change, and failing on turns where
                # the plugin had said exactly what it should. The durable
                # server log is a transport a developer can read, which the
                # debug variable is not, so it is what these checks read.
                "--print-logs",
                "--format",
                "json",
                "-m",
                f"openrouter/{CHEAP}",
                scenario.prompt,
            ]
            with install_lock(cache):
                ran = run_contained(argv, cwd=work, env=env, timeout_s=scenario.timeout_s)
            exit_code, stdout = ran.returncode, ran.stdout + ran.stderr

            events: list[dict[str, Any]] = []
            for line in stdout.splitlines():
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if isinstance(obj, dict):
                    events.append(obj)
            local = [r for r in _local_records(home) if str(r.get("recorded_at") or "") >= started]
            session_id = _root_session(local)
            decision = None
            service_records: list[dict[str, Any]] = []
            if scenario.policy is not None and session_id:
                rows = service.store.plans_of_episode(self._org_id, session_id)
                decision = rows[-1].decision if rows else None
                service_records = service.store.records_of_episode(self._org_id, session_id)
            mcp_calls = (
                [json.loads(x) for x in mcp_log.read_text().splitlines() if x.strip()]
                if mcp_log.exists()
                else []
            )
            all_wire = [r for r in mock.requests if r["body"] is not None]
            wire = [r for r in mock.main_requests if scenario.prompt in user_text(r["body"])]
            return Evidence(
                exit_code=exit_code,
                events=events,
                wire=wire,
                all_wire=all_wire,
                local=local,
                decision=decision,
                service_records=service_records,
                mcp_calls=mcp_calls,
                stdout=stdout,
                home=home,
                token=token,
                session_id=session_id,
            )
        finally:
            if proxy is not None:
                proxy.stop()
            service.stop()
            mock.stop()
            if self.keep_dir is not None:
                self.keep_dir.mkdir(parents=True, exist_ok=True)
                shutil.copytree(root, self.keep_dir / root.name, dirs_exist_ok=True)

    # --- the ten checks -----------------------------------------------------------------

    def _result(self, check: CheckId, ok: bool, detail: str) -> CheckResult:
        return CheckResult(check, CheckStatus.PASSED if ok else CheckStatus.FAILED, detail)

    def _not_run(self, check: CheckId) -> CheckResult:
        return CheckResult(check, CheckStatus.NOT_RUN, self.unavailable_reason or "not available")

    def _reference_on_wire(self, ev: Evidence) -> bool:
        """The user's turn ran as it would have with no adapter at all.

        Except for one key. Once the plugin routes the session, every request
        reaches the provider through the gateway, and the gateway asks for usage
        on every turn it forwards — rewritten or not — so that an experiment's
        reference arm records a cost and can be compared with the arms it is
        measured against (``vicaria_server/gateway.py``, rules 1 and 5). This
        check predates that by a day and read the added key as a mutation, which
        failed two checks on turns that had run unrouted in every respect that
        matters. Only the exact object the gateway writes is excused; a usage
        object with anything else in it is somebody else's change.
        """
        return (
            len(ev.wire) >= 1
            and ev.model_on_wire() == CHEAP
            and ev.effort_on_wire() is None
            and not ev.recipe_on_wire()
            and ev.wire[0]["body"].get("usage", GATEWAY_USAGE) == GATEWAY_USAGE
        )

    def check_interception(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.INTERCEPTION)
        task = "conformance/interception"
        ev = self.run(Scenario(task_id=task))
        retained = ev.stage("retained") or {}
        decision = ev.decision or {}
        inputs = decision.get("inputs") or {}
        # The prompt's shape reached the service under this decision's id; its
        # text did not, because the default capture policy withholds it.
        reached = (
            inputs.get("prompt_length") == len(PROMPT)
            and inputs.get("text_captured") is False
            and decision.get("decision_id") == retained.get("decision_id")
        )
        attributed = inputs.get("task_id") == task and retained.get("task_id") == task
        # The plan was bound to the model that ran: the baseline the service
        # pinned is the configuration on the wire.
        chosen = (decision.get("chosen") or {}).get("digest")
        bound = decision.get("baseline", {}).get("digest") == chosen and ev.model_on_wire() == CHEAP
        same = (
            retained.get("decision_id") is not None and retained.get("session_id") == ev.session_id
        )
        return self._result(
            CheckId.INTERCEPTION,
            reached and attributed and bound and same and len(ev.wire) == 1,
            f"the prompt's shape reached the service under the decision, text withheld by the "
            f"default capture policy ({reached}); the episode is attributed to the task on the "
            f"service and locally ({attributed}); the plan was bound to the model that ran "
            f"({bound}); the same decision was recorded locally ({same}); provider requests for "
            f"the turn: {len(ev.wire)} (plus {len(ev.all_wire) - len(ev.wire)} the harness makes "
            "to title the thread)",
        )

    def check_declared_mutations(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.DECLARED_MUTATIONS)
        # (a) Model, effort and prompt on one request's receipt. The model the
        # plan names is not in the client's own provider configuration.
        one = self.run(Scenario(policy=apply(model=STRONG, effort="low", prompt=True)))
        applied = one.stage("applied") or {}
        one_ok = (
            len(one.wire) == 1
            and one.model_on_wire() == STRONG
            and one.effort_on_wire() == "low"
            and one.recipe_on_wire()
            and one.wire[0]["body"].get("usage") == {"include": True}
            and one.wire[0]["headers"].get("authorization") == f"Bearer {KEY}"
            and not any(k.startswith("x-vicaria") for k in one.wire[0]["headers"])
            and applied.get("routed") is True
        )
        # (b) Tools: the removed tool is absent from the wire (the gateway
        # filters by name) and, if the model calls it anyway, the plugin
        # denies it in-process and the denial reaches the provider.
        narrowed = self.run(
            Scenario(
                prompt="use the glob tool",
                policy=apply(remove=[NARROWED_TOOL]),
                script=[
                    {"tool_call": {"name_prefix": NARROWED_TOOL, "arguments": {"pattern": "*"}}},
                    {"text": "tool done"},
                ],
            )
        )
        offered = offered_tools(narrowed.wire[0]["body"]) if narrowed.wire else []
        keep = ((narrowed.decision or {}).get("tools") or {}).get("keep") or []
        result = last_tool_result(narrowed.wire[1]["body"]) if len(narrowed.wire) >= 2 else None
        denied_locally = any(
            s.get("signal") == "tool_denied" and s.get("tool") == NARROWED_TOOL
            for s in narrowed.signals()
        )
        denial_on_wire = bool(result) and "not in the plan's tool set" in result
        narrowed_ok = (
            NARROWED_TOOL not in offered
            and "read" in offered
            and NARROWED_TOOL not in keep
            and ((narrowed.stage("applied") or {}).get("tools_removed") == 1)
            and denied_locally
            and denial_on_wire
        )
        # (c) Across a tool loop every request of the turn carries the effort
        # and the recipe, not only the first.
        loop = self.run(
            Scenario(
                prompt="use the probe tool",
                policy=apply(effort="low", prompt=True),
                script=[
                    {"tool_call": {"name_prefix": PROBE_TOOL, "arguments": {"echo": "hello"}}},
                    {"text": "tool done"},
                ],
                mcp=True,
            )
        )
        loop_ok = len(loop.wire) == 2 and all(
            loop.effort_on_wire(i) == "low" and loop.recipe_on_wire(i) for i in range(2)
        )
        return self._result(
            CheckId.DECLARED_MUTATIONS,
            one_ok and narrowed_ok and loop_ok,
            f"one request: model={one.model_on_wire()} effort={one.effort_on_wire()} "
            f"recipe_present={one.recipe_on_wire()} usage_requested="
            f"{one.wire[0]['body'].get('usage') if one.wire else None}, the organization's key "
            f"passed through and no Vicaria header ({one_ok}). Tools: {NARROWED_TOOL} absent "
            f"from the wire ({NARROWED_TOOL not in offered}), denied in-process when called "
            f"({denied_locally}), the denial reached the provider ({denial_on_wire}). Tool "
            f"loop: {len(loop.wire)} requests, every one with the effort and the recipe "
            f"({loop_ok})",
        )

    def check_level_honored(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.LEVEL_HONORED)
        # With the gateway unreachable the plugin declares model=suggest: the
        # same arm is served as a suggestion, surfaced, and nothing applied.
        ev = self.run(Scenario(policy=apply(model=STRONG), gateway_reachable=False))
        decision = ev.decision or {}
        exclusions = (decision.get("admission") or {}).get("exclusions") or []
        refused_ok = decision.get("disposition") == "suggest" and any(
            e.get("reason") == "level" for e in exclusions
        )
        suggested = ev.stage("suggested") or {}
        served_ok = (
            bool(suggested)
            and "vicaria suggests" in ev.text()
            and STRONG in ev.text()
            and self._reference_on_wire(ev)
        )
        # An undeclared control (a dimension the adapter holds at unknown) is
        # refused by the validator both sides run: the shared fixture file
        # carries the case, and the plugin's copy is the contracts' copy.
        fixture_ok = False
        try:
            cases = {c["name"]: c for c in json.loads(FIXTURE.read_text())["cases"]}
            fixture_ok = (
                cases["unverifiable_dimension"]["expect"]["refusal"] == "unverifiable_dimension"
                and cases["undeclared_value_support"]["expect"]["refusal"]
                == "undeclared_value_support"
            )
        except (OSError, KeyError, ValueError):
            fixture_ok = False
        return self._result(
            CheckId.LEVEL_HONORED,
            refused_ok and served_ok and fixture_ok,
            f"an apply on a suggest-level model control was served as a suggestion, with the "
            f"level exclusion in the decision record ({refused_ok}); the suggestion reached the "
            f"user and nothing was applied — the reference ran on the wire ({served_ok}); an "
            f"undeclared control is refused by the shared validation fixtures both validators "
            f"run ({fixture_ok})",
        )

    def check_stale_baseline_refused(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.STALE_BASELINE_REFUSED)
        moved = self.run(Scenario(policy=apply(effort="low"), mutate_plan=moved_baseline))
        superseded = self.run(Scenario(policy=apply(effort="low"), mutate_plan=superseded_revision))
        m = (moved.stage("refused") or {}).get("refusal")
        s = (superseded.stage("refused") or {}).get("refusal")
        return self._result(
            CheckId.STALE_BASELINE_REFUSED,
            m == "baseline_mismatch"
            and s == "stale_request_revision"
            and self._reference_on_wire(moved)
            and self._reference_on_wire(superseded),
            f"moved baseline refused as {m}; superseded revision refused as {s}; the reference "
            "ran on the wire in both cases, unrouted (no plan token was sent)",
        )

    def check_tool_execution(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.TOOL_EXECUTION)
        # A registered MCP tool, under a plan that removes another tool: the
        # probe is offered, called, and its result reaches the provider; the
        # removed tool is gone from the wire. The probe was not in the
        # inventory the plugin read (OpenCode's listing does not carry MCP
        # tools), and a tool the plan never saw is not the plan's to remove.
        ev = self.run(
            Scenario(
                prompt="use the probe tool",
                policy=apply(remove=[NARROWED_TOOL]),
                script=[
                    {"tool_call": {"name_prefix": PROBE_TOOL, "arguments": {"echo": "hello"}}},
                    {"text": "tool done"},
                ],
                mcp=True,
            )
        )
        offered = offered_tools(ev.wire[0]["body"]) if ev.wire else []
        ran = any(c.get("method") == "tools/call" for c in ev.mcp_calls)
        result = last_tool_result(ev.wire[1]["body"]) if len(ev.wire) >= 2 else None
        result_on_wire = bool(result) and "PROBE-EXECUTED:hello" in result
        removed = ((ev.decision or {}).get("tools") or {}).get("removed") or []
        return self._result(
            CheckId.TOOL_EXECUTION,
            PROBE_TOOL in offered
            and NARROWED_TOOL not in offered
            and removed == [NARROWED_TOOL]
            and ran
            and result_on_wire,
            f"registered tool offered under a plan that removes {NARROWED_TOOL} "
            f"({PROBE_TOOL in offered}; removed tool absent: {NARROWED_TOOL not in offered}; "
            f"the plan removed exactly {removed}), called ({ran}), its result reached the "
            f"provider ({result_on_wire}); provider requests: {len(ev.wire)}",
        )

    def check_cross_component_atomicity(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.CROSS_COMPONENT_ATOMICITY)
        # Decided then silent: the service answers nothing → the reference.
        before = self.run(Scenario(policy=apply(effort="low", prompt=True), mutate_plan=silent))
        before_ok = (
            self._reference_on_wire(before)
            and len(before.wire) == 1
            and (before.stage("decided") or {}).get("origin") == "unavailable"
        )
        # An application that cannot be carried out in full (the recipe text
        # is missing) → none of it: no effort, no recipe, no plan token.
        during = self.run(
            Scenario(policy=apply(effort="low", prompt=True), mutate_plan=missing_recipe)
        )
        during_ok = (
            len(during.wire) == 1
            and self._reference_on_wire(during)
            and (during.stage("refused") or {}).get("refusal") == "recipe_missing"
        )
        return self._result(
            CheckId.CROSS_COMPONENT_ATOMICITY,
            before_ok and during_ok,
            f"decided then silent → the reference ran, recorded unavailable ({before_ok}); an "
            f"application that could not be carried out in full → none of it applied, the "
            f"reference ran with no effort and no recipe ({during_ok}). In-process adapter: the "
            "recipe and the effort are staged from the same decision and the plan token goes "
            "out only with an applied decision, so there is no irreversible partial application "
            "to induce",
        )

    def check_event_completeness(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.EVENT_COMPLETENESS)
        ev = self.run(Scenario())
        kinds = {s.get("signal") for s in ev.signals()}
        sessions = {r.get("session_id") for r in ev.local}
        needed = {"session_start", "prompt", "turn_complete"}
        completed = any(e.get("type") == "step_finish" for e in ev.events)
        retained = ev.stage("retained") or {}
        usage = [
            u
            for u in ev.usage()
            if u.get("prompt_id") == retained.get("prompt_id")
            and isinstance(u.get("input_tokens"), int)
            and isinstance(u.get("output_tokens"), int)
        ]
        # The service holds both accounts of the same step: the gateway's
        # (provider-reported) and the plugin's (harness-counted), joined by
        # the decision.
        gateway_usage = [
            r
            for r in ev.service_records
            if r["kind"] == "usage" and r["record"].get("source") == "gateway"
        ]
        harness_usage = [
            r
            for r in ev.service_records
            if r["kind"] == "usage" and r["record"].get("source") != "gateway"
        ]
        joined = (
            bool(gateway_usage)
            and bool(harness_usage)
            and (
                gateway_usage[-1]["record"].get("decision_id") == retained.get("decision_id")
                and gateway_usage[-1]["record"].get("provider") == PROVIDER_NAME
            )
        )
        boundaries_ok = needed <= kinds and len(sessions - {None}) == 1 and completed
        # Parent/child: the task tool runs a subagent in a child session whose
        # session.created names its parentID.
        child = self.run(
            Scenario(
                prompt="delegate to a subagent",
                script=[
                    {
                        "tool_call": {
                            "name_prefix": TASK_TOOL,
                            "arguments": {
                                "description": "probe",
                                "prompt": PROMPT,
                                "subagent_type": "general",
                            },
                        }
                    },
                    {"text": "ok"},
                    {"text": "done"},
                ],
            )
        )
        starts = [s for s in child.signals() if s.get("signal") == "session_start"]
        roots = [s for s in starts if not s.get("parent_session_id")]
        children = [
            s
            for s in starts
            if s.get("parent_session_id")
            and any(r.get("session_id") == s.get("parent_session_id") for r in roots)
        ]
        child_ok = len(roots) == 1 and len(children) == 1 and len(child.all_wire) >= 3
        return self._result(
            CheckId.EVENT_COMPLETENESS,
            boundaries_ok and bool(usage) and joined and child_ok,
            f"signals recorded: {sorted(k for k in kinds if k)}; one session id "
            f"({len(sessions - {None})}); the turn completed ({completed}); usage persisted "
            f"locally for the prompt ({len(usage)} record(s)); the service holds the gateway's "
            f"provider-reported usage and the plugin's upload joined by the decision ({joined}); "
            f"a subagent's child session recorded with its parent ({child_ok}: {len(roots)} "
            f"root, {len(children)} child, {len(child.all_wire)} provider requests)",
        )

    def check_server_unavailable_recovery(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.SERVER_UNAVAILABLE_RECOVERY)
        # Run 1 registers and caches the configuration; run 2 has no service at
        # all; run 3 has it back, and the queue from run 2 reaches it.
        first = self.run(Scenario())
        down = self.run(Scenario(policy=None, home=first.home, token=first.token))
        decided = down.stage("decided") or {}
        kept_working = down.exit_code == 0
        recorded = (
            decided.get("origin") == "unavailable" and decided.get("reason") == "plan_unavailable"
        )
        admitted = decided.get("admitted_locally") is True
        # The outage session's own records, never an earlier session's from the reused home.
        outage = [r for r in down.local if r.get("session_id") == down.session_id]
        kinds = {r.get("signal") for r in outage if r.get("kind") == "stage" and "signal" in r}
        needed = {"session_start", "prompt", "turn_complete"}
        buffered = needed <= kinds and any(r.get("kind") == "usage" for r in outage)
        queued = bool(_pending_lines(down.home))
        back = self.run(Scenario(home=first.home, token=first.token))
        # Recovery is proven record by record: every record the outage session
        # queued is on the service under that session, as many times as it was
        # queued — not merely "some stage record exists" or "the queue is empty",
        # either of which an earlier session or a truncated queue could satisfy,
        # and not by a kind-session-time identity, which two records written in
        # the same millisecond share.
        expected = Counter(_canonical(r) for r in outage)
        reached = (
            Counter(
                _canonical(r["record"])
                for r in self._service.store.records_of_episode(self._org_id, down.session_id)
            )
            if self._service is not None and down.session_id is not None
            else Counter()
        )
        replayed = (
            bool(expected)
            and all(reached[record] >= count for record, count in expected.items())
            and not _pending_lines(down.home)
        )
        return self._result(
            CheckId.SERVER_UNAVAILABLE_RECOVERY,
            kept_working
            and recorded
            and admitted
            and self._reference_on_wire(down)
            and len(down.wire) == 1
            and buffered
            and queued
            and replayed
            and back.exit_code == 0,
            f"harness completed with the service down ({kept_working}); the plugin recorded an "
            f"unavailable decision ({recorded}, reason={decided.get('reason')}) and admitted the "
            f"reference from the cached configuration ({admitted}); the reference ran, unrouted; "
            f"provider requests: {len(down.wire)}; every record landed locally ({buffered}: "
            f"signals {sorted(k for k in kinds if k)}, {len(down.usage())} usage) and queued "
            f"({queued}); with the service back the queue reached it ({replayed})",
        )

    def check_cannot_execute_stops(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.CANNOT_EXECUTE_STOPS)
        # The developer's model is outside the organization's allowed models
        # and no arm replaces it: the service answers cannot_execute.
        ev = self.run(Scenario(policy=deny_reference()))
        stopped = ev.stage("stopped") or {}
        blocked = stopped.get("disposition") == "cannot_execute"
        surfaced = "cannot_execute" in ev.text() and "model_not_allowed" in ev.text()
        return self._result(
            CheckId.CANNOT_EXECUTE_STOPS,
            len(ev.all_wire) == 0 and blocked and surfaced,
            f"provider requests: {len(ev.all_wire)} (including the harness's own title call); "
            f"the plugin stopped the turn on the service's cannot_execute ({blocked}) and the "
            f"reason reached the user ({surfaced})",
        )

    def check_inadmissible_fallback_stops(self) -> CheckResult:
        if not self.available:
            return self._not_run(CheckId.INADMISSIBLE_FALLBACK_STOPS)
        # A valid plan (the arm replaces the prohibited model, with a recipe)
        # that cannot be applied (the recipe text is missing at the wire), whose
        # reference the cached admission inputs prohibit.
        ev = self.run(
            Scenario(
                policy=deny_reference(model=STRONG, prompt=True),
                mutate_plan=missing_recipe,
            )
        )
        refused = ev.stage("refused") or {}
        stopped = ev.stage("stopped") or {}
        validated = (ev.decision or {}).get("disposition") == "apply"
        return self._result(
            CheckId.INADMISSIBLE_FALLBACK_STOPS,
            validated
            and refused.get("refusal") == "recipe_missing"
            and stopped.get("reason") == "reference_inadmissible"
            and len(ev.all_wire) == 0
            and "not among the organization's allowed models" in ev.text(),
            f"the service served an apply plan ({validated}); the application could not be "
            f"carried out (refusal={refused.get('refusal')}) and the reference was inadmissible "
            f"(reason={stopped.get('reason')}); provider requests: {len(ev.all_wire)}",
        )


def _record_clock() -> str:
    """Now, in the plugin's own ``recorded_at`` format (milliseconds, ``Z``), comparable as text."""
    now = datetime.now(UTC)
    return now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"


def _root_session(local: list[dict[str, Any]]) -> str | None:
    """The session this run started: its root ``session_start`` (no parent), else the first id."""
    for record in local:
        if (
            record.get("kind") == "stage"
            and record.get("signal") == "session_start"
            and not record.get("parent_session_id")
            and record.get("session_id")
        ):
            return str(record["session_id"])
    return next((r.get("session_id") for r in local if r.get("session_id")), None)


def _canonical(record: Mapping[str, Any]) -> str:
    """One plugin record as the local log and the service both hold it.

    The service drops ``upload_probability`` from the line it stores (the
    batch's probability is kept beside the record), so it is dropped here too.
    """
    return json.dumps(
        {k: v for k, v in record.items() if k != "upload_probability"},
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )


def _pending_lines(home: Path) -> list[str]:
    """Unacknowledged queue entries; delivery receipts leave the journal intact."""
    import hashlib

    records = home / "vicaria" / "records"
    pending = records / "pending.jsonl"
    if not pending.exists():
        return []
    return [
        line
        for line in pending.read_text(encoding="utf-8").splitlines()
        if line.strip()
        and not (records / "receipts" / hashlib.sha256(line.encode()).hexdigest()).exists()
    ]


def _local_records(home: Path) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    records = home / "vicaria" / "records"
    if not records.exists():
        return out
    for path in sorted(records.glob("*.jsonl")):
        if path.name == "pending.jsonl":
            continue
        for line in path.read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return out


__all__ = ["Evidence", "Scenario", "VicariaOpenCodeDriver"]
