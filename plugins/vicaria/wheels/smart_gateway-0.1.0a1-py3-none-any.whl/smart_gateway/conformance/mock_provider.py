"""A scripted Anthropic Messages provider that records every request at the wire.

Each ``POST /v1/messages`` consumes the next step of a script — ``{"text":
...}`` ends the turn with that text; ``{"tool_use": {"name_prefix": ...,
"input": {...}}}`` asks the harness to run the first offered tool whose name
starts with the prefix — and the last step repeats. Responses are streamed as
SSE because Claude Code streams; ``count_tokens`` is answered; everything else
is a 404.

What is recorded per request is what a check needs and no more: the model and
effort the request carried, how many messages and tool results it held, which
tools were offered, whether a staging block leaked through, and which
``VICARIA-*`` sentinel tokens appeared in any text. Message text itself is not
kept.
"""

from __future__ import annotations

import json
import re
import threading
from collections.abc import Mapping, Sequence
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from typing import Any
from urllib.parse import urlsplit

from smart_gateway.control.marker import BLOCK_OPEN

_SENTINEL_RE = re.compile(r"VICARIA-[A-Z0-9-]+")


def _blocks(message: Mapping[str, Any]) -> list[dict[str, Any]]:
    content = message.get("content")
    if isinstance(content, list):
        return [b for b in content if isinstance(b, dict)]
    return [{"type": "text", "text": content}] if isinstance(content, str) else []


class MockProvider:
    def __init__(
        self,
        script: Sequence[Mapping[str, Any]] | None = None,
        *,
        host: str = "127.0.0.1",
        port: int = 0,
    ) -> None:
        self.script: list[Mapping[str, Any]] = list(script or [{"text": "ok"}])
        self.requests: list[dict[str, Any]] = []
        #: The last Messages body as parsed, text included. Test infrastructure
        #: only — the recorded ``requests`` are what a check reads.
        self.last_body: dict[str, Any] | None = None
        self._turn = 0
        self._lock = threading.Lock()
        provider = self

        class Handler(BaseHTTPRequestHandler):
            protocol_version = "HTTP/1.1"

            def log_message(self, *args: Any) -> None:
                pass

            def _body(self) -> dict[str, Any]:
                length = int(self.headers.get("content-length") or 0)
                raw = self.rfile.read(length) if length else b""
                if self.headers.get("content-encoding", "").lower() == "gzip":
                    import gzip

                    raw = gzip.decompress(raw)
                try:
                    obj = json.loads(raw) if raw else {}
                except json.JSONDecodeError:
                    obj = {}
                return obj if isinstance(obj, dict) else {}

            def _json(self, status: int, obj: Mapping[str, Any]) -> None:
                data = json.dumps(obj).encode("utf-8")
                self.send_response(status)
                self.send_header("content-type", "application/json")
                self.send_header("content-length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def _sse(self, events: Sequence[Mapping[str, Any]]) -> None:
                payload = "".join(
                    f"event: {e['type']}\ndata: {json.dumps(e)}\n\n" for e in events
                ).encode("utf-8")
                self.send_response(200)
                self.send_header("content-type", "text/event-stream")
                self.send_header("content-length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)

            def do_POST(self) -> None:
                body = self._body()
                route = urlsplit(self.path).path.rstrip("/")
                messages = body.get("messages") if isinstance(body.get("messages"), list) else []
                texts = [
                    b.get("text") or ""
                    for m in messages
                    for b in _blocks(m)
                    if b.get("type") == "text"
                ]
                tool_results = [
                    b for m in messages for b in _blocks(m) if b.get("type") == "tool_result"
                ]
                output_config = body.get("output_config")
                provider._record(
                    {
                        "path": route,
                        "model": body.get("model"),
                        "effort": (
                            output_config.get("effort") if isinstance(output_config, dict) else None
                        ),
                        "thinking": body.get("thinking"),
                        "stream": body.get("stream"),
                        "n_messages": len(messages),
                        "n_tool_results": len(tool_results),
                        "last_tool_result": (
                            json.dumps(tool_results[-1].get("content"))[:300]
                            if tool_results
                            else None
                        ),
                        "tools": [
                            t.get("name") for t in body.get("tools") or [] if isinstance(t, dict)
                        ],
                        "has_staging_block": any(BLOCK_OPEN in t for t in texts),
                        "sentinels": sorted({s for t in texts for s in _SENTINEL_RE.findall(t)}),
                    }
                )
                if route.endswith("/v1/messages/count_tokens"):
                    return self._json(200, {"input_tokens": 12})
                if not route.endswith("/v1/messages"):
                    return self._json(
                        404,
                        {"type": "error", "error": {"type": "not_found_error", "message": route}},
                    )
                with provider._lock:
                    provider.last_body = body
                step = provider._next_step()
                model = str(body.get("model") or "mock")
                if "tool_use" in step:
                    spec = step["tool_use"]
                    offered = [
                        t.get("name") for t in body.get("tools") or [] if isinstance(t, dict)
                    ]
                    name = next(
                        (
                            n
                            for n in offered
                            if isinstance(n, str) and n.startswith(spec.get("name_prefix", ""))
                        ),
                        spec.get("name", "unknown"),
                    )
                    return self._sse(provider._tool_events(model, name, spec.get("input", {})))
                self._sse(provider._text_events(model, str(step.get("text", "ok"))))

            def do_GET(self) -> None:
                self._json(
                    404,
                    {"type": "error", "error": {"type": "not_found_error", "message": self.path}},
                )

        self._http = ThreadingHTTPServer((host, port), Handler)
        self._thread = threading.Thread(target=self._http.serve_forever, daemon=True)

    # --- scripting ---------------------------------------------------------

    def reset(self, script: Sequence[Mapping[str, Any]] | None = None) -> None:
        with self._lock:
            if script is not None:
                self.script = list(script)
            self.requests = []
            self._turn = 0

    def _next_step(self) -> Mapping[str, Any]:
        with self._lock:
            step = self.script[min(self._turn, len(self.script) - 1)]
            self._turn += 1
            return step

    def _record(self, entry: dict[str, Any]) -> None:
        with self._lock:
            self.requests.append(entry)

    @property
    def messages_requests(self) -> list[dict[str, Any]]:
        """Provider requests that would have been billed: the Messages calls only."""
        with self._lock:
            return [r for r in self.requests if r["path"].endswith("/v1/messages")]

    # --- SSE shapes --------------------------------------------------------

    @staticmethod
    def _start(model: str) -> dict[str, Any]:
        return {
            "type": "message_start",
            "message": {
                "id": "msg_mock",
                "type": "message",
                "role": "assistant",
                "model": model,
                "content": [],
                "stop_reason": None,
                "stop_sequence": None,
                # Every category a real reply carries; a provider that served no cache
                # hit says 0, and a receipt without a category is incomplete, never 0.
                "usage": {
                    "input_tokens": 12,
                    "cache_read_input_tokens": 0,
                    "cache_creation_input_tokens": 0,
                    "output_tokens": 1,
                },
            },
        }

    def _text_events(self, model: str, text: str) -> list[dict[str, Any]]:
        return [
            self._start(model),
            {
                "type": "content_block_start",
                "index": 0,
                "content_block": {"type": "text", "text": ""},
            },
            {
                "type": "content_block_delta",
                "index": 0,
                "delta": {"type": "text_delta", "text": text},
            },
            {"type": "content_block_stop", "index": 0},
            {
                "type": "message_delta",
                "delta": {"stop_reason": "end_turn", "stop_sequence": None},
                "usage": {"output_tokens": 3},
            },
            {"type": "message_stop"},
        ]

    def _tool_events(
        self, model: str, name: str, arguments: Mapping[str, Any]
    ) -> list[dict[str, Any]]:
        return [
            self._start(model),
            {
                "type": "content_block_start",
                "index": 0,
                "content_block": {
                    "type": "tool_use",
                    "id": "toolu_mock_1",
                    "name": name,
                    "input": {},
                },
            },
            {
                "type": "content_block_delta",
                "index": 0,
                "delta": {"type": "input_json_delta", "partial_json": json.dumps(dict(arguments))},
            },
            {"type": "content_block_stop", "index": 0},
            {
                "type": "message_delta",
                "delta": {"stop_reason": "tool_use", "stop_sequence": None},
                "usage": {"output_tokens": 8},
            },
            {"type": "message_stop"},
        ]

    # --- lifecycle ---------------------------------------------------------

    @property
    def url(self) -> str:
        host, port = self._http.server_address[:2]
        return f"http://{host}:{port}"

    def start(self) -> MockProvider:
        self._thread.start()
        return self

    def stop(self) -> None:
        self._http.shutdown()
        self._http.server_close()
