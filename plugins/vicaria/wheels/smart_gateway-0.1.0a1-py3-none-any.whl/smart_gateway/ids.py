"""Identifiers and sanitizers (spec section 4).

Paths, branch names and OS users never reach disk: they are replaced by a salted hash
whose salt lives only on the recording machine, so raw files from several machines can be
concatenated without any of them revealing a directory layout or a user name.
"""

from __future__ import annotations

import hashlib
import os
import re
import secrets
from collections.abc import Iterable
from datetime import UTC, datetime
from pathlib import Path

__all__ = [
    "SALT_FILE",
    "TASK_ID_RE",
    "extract_task_ref",
    "load_or_create_salt",
    "salted_hash",
    "sanitize_task_id",
    "utc_now_iso",
]

SALT_FILE = "salt"
_SALT_BYTES = 32
_SALT_HEX_RE = re.compile(r"[0-9a-f]{64}")

TASK_ID_RE = re.compile(r"[A-Za-z0-9._:/-]{1,128}")


def load_or_create_salt(data_dir: Path) -> bytes:
    """The per-install salt (32 random bytes); created once with O_EXCL, so a race between
    two first hooks still leaves exactly one salt."""
    path = data_dir / SALT_FILE
    try:
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        pass
    else:
        with os.fdopen(fd, "w") as f:
            f.write(secrets.token_hex(_SALT_BYTES))
    text = path.read_text(encoding="ascii").strip()
    if not _SALT_HEX_RE.fullmatch(text):
        raise ValueError("salt file is not 64 hex characters")
    return bytes.fromhex(text)


def salted_hash(salt: bytes, value: str) -> str:
    """sha256(salt || value)[:16] hex — stable per install, unlinkable across installs."""
    if len(salt) != _SALT_BYTES:
        raise ValueError("salt must be 32 bytes")
    return hashlib.sha256(salt + value.encode("utf-8")).hexdigest()[:16]


def sanitize_task_id(value: str) -> str:
    """Accept exactly the task-id alphabet [A-Za-z0-9._:/-]{1,128}; never rewrite an id
    (a rewritten id could collide with a real one)."""
    if not isinstance(value, str):
        raise ValueError("task id must be a string")
    value = value.strip()
    if not TASK_ID_RE.fullmatch(value):
        raise ValueError("task id must match [A-Za-z0-9._:/-]{1,128}")
    return value


def extract_task_ref(
    branch: str | None, regex: str | re.Pattern[str], protected_branches: Iterable[str]
) -> str | None:
    """First capture group of `regex` in the branch name, or None.

    Protected branches never bind: work on `main` is not one task. Evaluated at hook time
    so the branch name itself is never written anywhere.
    """
    if not branch:
        return None
    branch = branch.strip()
    if not branch or branch in set(protected_branches):
        return None
    pattern = re.compile(regex) if isinstance(regex, str) else regex
    if pattern.groups < 1:
        raise ValueError("task_id_branch_regex needs a capture group")
    m = pattern.search(branch)
    if m is None or m.group(1) is None:
        return None
    ref = m.group(1)
    return ref if TASK_ID_RE.fullmatch(ref) else None


def utc_now_iso(now: datetime | None = None) -> str:
    """UTC ISO-8601 with milliseconds and a Z suffix: 2026-09-05T12:34:56.789Z."""
    now = datetime.now(UTC) if now is None else now
    if now.tzinfo is None:
        raise ValueError("utc_now_iso needs an aware datetime")
    now = now.astimezone(UTC)
    return f"{now.strftime('%Y-%m-%dT%H:%M:%S')}.{now.microsecond // 1000:03d}Z"
