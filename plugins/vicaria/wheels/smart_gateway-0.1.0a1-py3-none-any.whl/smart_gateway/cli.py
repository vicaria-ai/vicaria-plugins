"""`sg`: the argparse dispatcher for every operator command (spec section 15).

Heavy modules are imported inside the command that needs them, so `sg --help` costs one
module and the receiver the hook spawns (`sg otel serve`) starts fast. hook.py is never
imported here: the hook is its own entry point (`python3 -m smart_gateway.hook`), so nothing
an operator runs can change what a hook records.

Exit codes: 0 ok; 1 usage error, red doctor, verify mismatch or a failed operation;
2 refused (invalid config, bad or missing admin key, foreign OTEL endpoint, privacy audit
failure on export).
"""

from __future__ import annotations

import argparse
import copy
import json
import os
import signal
import socket
import sys
import time
from collections.abc import Sequence
from dataclasses import asdict
from pathlib import Path
from typing import TYPE_CHECKING

from smart_gateway import __version__
from smart_gateway.capture import cli as capture_cli

if TYPE_CHECKING:  # for annotations; the otel commands import the module when they run
    from smart_gateway.otel_receiver import PidRecord

__all__ = [
    "EXIT_OK",
    "EXIT_REFUSED",
    "EXIT_USAGE",
    "INGEST_DEADLINE_S",
    "OTEL_ENV_KEYS",
    "CliError",
    "build_parser",
    "foreign_otel_keys",
    "main",
    "otel_env_block",
    "settings_path",
]

EXIT_OK = 0
EXIT_USAGE = 1
EXIT_REFUSED = 2

# The settings `env` block `sg init` manages (spec section 6.2): logs only, http/json, local
# endpoint. No metrics exporter and none of the OTEL_LOG_* switches that would export text.
OTEL_ENV_KEYS = (
    "CLAUDE_CODE_ENABLE_TELEMETRY",
    "OTEL_LOGS_EXPORTER",
    "OTEL_EXPORTER_OTLP_PROTOCOL",
    "OTEL_EXPORTER_OTLP_ENDPOINT",
    "OTEL_LOGS_EXPORT_INTERVAL",
    "OTEL_METRICS_INCLUDE_VERSION",
)
INGEST_DEADLINE_S = 20.0  # per session, for the ingest that precedes a diagnosis
_STOP_WAIT_S = 5.0
_PROBE_TIMEOUT_S = 0.1
_SETTINGS_SCOPES = ("user", "project")
_BOOLS = {"true": True, "false": False}


class CliError(Exception):
    """A message for stderr plus the exit code; raised by commands, printed by main()."""

    def __init__(self, message: str, exit_code: int = EXIT_USAGE) -> None:
        super().__init__(message)
        self.exit_code = exit_code


class _Parser(argparse.ArgumentParser):
    """Usage errors exit 1 (spec: "1 usage"), not argparse's default 2, which means refused."""

    def error(self, message: str) -> None:  # type: ignore[override]
        self.print_usage(sys.stderr)
        print(f"{self.prog}: error: {message}", file=sys.stderr)
        raise SystemExit(EXIT_USAGE)


# --- small shared helpers -------------------------------------------------------------


def _data_dir() -> Path:
    from smart_gateway.config import resolve_data_dir

    return resolve_data_dir()


def _ready_data_dir() -> Path:
    from smart_gateway.config import ensure_data_dir, resolve_data_dir

    return ensure_data_dir(resolve_data_dir())


def _emit_json(obj: object) -> None:
    print(json.dumps(obj, indent=2, sort_keys=True))


def _rel(path: Path, data_dir: Path) -> str:
    try:
        return str(path.relative_to(data_dir))
    except ValueError:
        return str(path)


def _parse_bool(text: str, name: str) -> bool:
    try:
        return _BOOLS[text.lower()]
    except KeyError:
        raise CliError(f"{name} must be true or false") from None


def _derived_rows(data_dir: Path, name: str) -> list[dict]:
    from smart_gateway.rawlog import iter_lines

    path = data_dir / "derived" / name
    if not path.is_file():
        raise CliError(f"no derived/{name}: run `sg build` first")
    return [obj for _line_no, obj in iter_lines(path)]


def _build_json(data_dir: Path) -> dict:
    path = data_dir / "derived" / "build.json"
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise CliError("no derived/build.json: run `sg build` first") from None
    if not isinstance(obj, dict) or not isinstance(obj.get("build_id"), str):
        raise CliError("derived/build.json is not a build manifest: run `sg build` first")
    return obj


def _plugin_dir() -> Path | None:
    """The repo's plugin/ when the package runs from a checkout (the --plugin-dir target)."""
    candidate = Path(__file__).resolve().parents[2] / "plugin"
    return candidate if (candidate / "hooks" / "hooks.json").is_file() else None


def _print_checks(checks: Sequence) -> None:
    for c in checks:
        print(f"{'ok ' if c.ok else 'RED'} {c.name}: {c.detail}")


def _measure_mark(measure_json: dict) -> str:
    if "unknown" in measure_json:
        return "?"
    return "T" if measure_json["value"] else "F"


# --- sg init ------------------------------------------------------------------------------


def otel_env_block(port: int) -> dict[str, str]:
    """The six settings `env` entries that route Claude Code's OTEL logs to the receiver."""
    return {
        "CLAUDE_CODE_ENABLE_TELEMETRY": "1",
        "OTEL_LOGS_EXPORTER": "otlp",
        "OTEL_EXPORTER_OTLP_PROTOCOL": "http/json",
        "OTEL_EXPORTER_OTLP_ENDPOINT": f"http://127.0.0.1:{port}",
        "OTEL_LOGS_EXPORT_INTERVAL": "2000",
        "OTEL_METRICS_INCLUDE_VERSION": "true",
    }


def foreign_otel_keys(env: dict, desired: dict[str, str]) -> list[str]:
    """Exporter variables already pointing somewhere else: any OTEL_EXPORTER_OTLP_* key we do
    not set (headers, a logs-specific endpoint, ...) or one of ours with another value."""
    return sorted(
        k
        for k, v in env.items()
        if (k.startswith("OTEL_EXPORTER_OTLP_") or k == "OTEL_LOGS_EXPORTER")
        and desired.get(k) != str(v)
    )


def settings_path(scope: str) -> Path:
    """`~/.claude/settings.json` (user) or `./.claude/settings.json` (project) — the same two
    files `sg doctor` reads, so what init writes is what doctor checks."""
    if scope not in _SETTINGS_SCOPES:
        raise CliError(f"--scope must be one of {', '.join(_SETTINGS_SCOPES)}")
    base = Path.home() if scope == "user" else Path.cwd()
    return base / ".claude" / "settings.json"


def _read_settings(path: Path) -> dict:
    if not path.exists():
        return {}
    try:
        obj = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise CliError(f"cannot read {path}: {e}; fix it by hand", EXIT_REFUSED) from None
    if not isinstance(obj, dict):
        raise CliError(f"{path} is not a JSON object; fix it by hand", EXIT_REFUSED)
    return obj


def _write_settings(path: Path, doc: dict) -> None:
    from smart_gateway.rawlog import atomic_write

    mode = path.stat().st_mode & 0o777 if path.exists() else None
    path.parent.mkdir(parents=True, exist_ok=True)
    atomic_write(path, json.dumps(doc, indent=2) + "\n")
    if mode is not None:
        path.chmod(mode)  # atomic_write creates 0600; keep the user's own mode on their file


def _init_config(data_dir: Path, args: argparse.Namespace) -> dict:
    from smart_gateway.config import CONFIG_FILE, DEFAULT_CONFIG, load_config

    config = (
        load_config(data_dir)
        if (data_dir / CONFIG_FILE).is_file()
        else copy.deepcopy(DEFAULT_CONFIG)
    )
    for flag, key in (
        ("team", "team"),
        ("engineer_usd_per_hour", "engineer_usd_per_hour"),
        ("repair_minutes_team_estimate", "repair_minutes_team_estimate"),
        ("branch_regex", "task_id_branch_regex"),
    ):
        value = getattr(args, flag)
        if value is not None:
            config[key] = value
    for flag, key in (
        ("delta", "delta"),
        ("primary_outcome", "primary_outcome"),
        ("current_label", "current_config_label"),
    ):
        value = getattr(args, flag)
        if value is not None:
            config["gate"][key] = value
    if args.port is not None:
        config["otel"]["port"] = args.port
    return config


def cmd_init(args: argparse.Namespace) -> int:
    from smart_gateway.config import write_config
    from smart_gateway.doctor import doctor
    from smart_gateway.ids import load_or_create_salt

    data_dir = _ready_data_dir()
    load_or_create_salt(data_dir)
    config = _init_config(data_dir, args)
    port = config["otel"]["port"]
    desired = otel_env_block(port)
    path = settings_path(args.scope)
    doc = _read_settings(path)
    env = doc.get("env")
    if env is None:
        env = {}
    elif not isinstance(env, dict):
        raise CliError(f"{path}: `env` is not an object; fix it by hand", EXIT_REFUSED)
    foreign = foreign_otel_keys(env, desired)
    if foreign:
        config["otel"]["mode"] = "external"
        write_config(data_dir, config)
        raise CliError(
            f"refusing to overwrite {', '.join(foreign)} in {path}: another OTEL exporter is "
            "configured. config.otel.mode set to external; collection runs transcript-only "
            "until you point OTEL_EXPORTER_OTLP_ENDPOINT at the sg receiver yourself.",
            EXIT_REFUSED,
        )
    config["otel"]["mode"] = "local"
    write_config(data_dir, config)
    print(f"data dir: {data_dir} (config.json, salt, raw/, state/, derived/, reports/)")
    merged = {**env, **desired}
    if args.yes:
        if merged != env or not path.exists():
            doc["env"] = merged
            _write_settings(path, doc)
            print(f"wrote the OTEL env block into {path} ({args.scope} scope)")
        else:
            print(f"OTEL env block already present in {path}")
    else:
        print(f"would merge into {path} ({args.scope} scope); re-run with --yes to write it:")
        for key in OTEL_ENV_KEYS:
            print(f"  {key}={desired[key]}")
    plugin = _plugin_dir()
    print()
    print("start Claude Code with the plugin loaded:")
    print(f"  claude --plugin-dir {plugin if plugin else '/path/to/smart-gateway/plugin'}")
    print("weekly cadence (each command is idempotent and non-interactive):")
    print("  sg billing fetch            # pull usage_report + cost_report with SG_ADMIN_API_KEY")
    print("  sg diagnose                 # ingest transcripts, rebuild derived/, write the report")
    print("daily backstop: sg ingest transcripts (before the 30-day transcript cleanup)")
    print()
    checks, _code = doctor(data_dir)
    _print_checks(checks)
    return EXIT_OK


# --- sg doctor / privacy-audit / export -----------------------------------------------------


def cmd_control_serve(args: argparse.Namespace) -> int:
    from smart_gateway.control.commit_point import serve
    from smart_gateway.control.config import load_control

    data_dir = _ready_data_dir()
    control = load_control(data_dir)
    server = serve(control, data_dir, port=args.port)
    host, port = server.server_address[:2]
    print(f"vicaria commit point listening on http://{host}:{port} -> {control.upstream}")
    try:
        server.serve_forever()
    finally:
        server.server_close()
    return EXIT_OK


def cmd_control_plan_source(args: argparse.Namespace) -> int:
    from pathlib import Path as _Path

    from smart_gateway.control.arms import ArmsError, ArmsPolicy, load_arms
    from smart_gateway.control.plans import PlanServer

    try:
        arms = load_arms(_Path(args.arms))
    except (ArmsError, OSError) as exc:
        print(f"sg: {exc}", file=sys.stderr)
        return EXIT_REFUSED
    server = PlanServer(ArmsPolicy(arms), host=args.host, port=args.port).start()
    print(
        f"vicaria plan source serving experiment {arms.experiment_id!r} "
        f"({', '.join(sorted(arms.arms))}) on {server.url}"
    )
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.stop()
    return EXIT_OK


def cmd_control_conformance(args: argparse.Namespace) -> int:
    import json as _json
    from pathlib import Path as _Path

    from vicaria_contracts.conformance import CheckStatus, run_conformance

    keep = _Path(args.keep) if args.keep else None
    driver: object
    if args.harness == "opencode-vicaria":
        # The v1 product: @vicaria/opencode, the service and the gateway.
        from smart_gateway.conformance.opencode_vicaria import VicariaOpenCodeDriver

        driver = VicariaOpenCodeDriver(opencode_bin=args.bin or "opencode", keep_dir=keep)
    elif args.harness == "opencode":
        from smart_gateway.conformance.opencode import OpenCodeDriver

        driver = OpenCodeDriver(
            opencode_bin=args.bin or "opencode",
            python_bin=args.python_bin,
            keep_dir=keep,
        )
    else:
        from smart_gateway.conformance.claude_code import ClaudeCodeDriver

        driver = ClaudeCodeDriver(
            claude_bin=args.bin or "claude",
            model=args.model,
            candidate_model=args.candidate_model,
            keep_dir=keep,
        )
    report = run_conformance(driver)
    if args.json:
        print(_json.dumps(report.to_dict(), indent=2, sort_keys=True))
    else:
        print(report.summary())
        print()
        for result in report.results:
            mark = {
                CheckStatus.PASSED: "PASS",
                CheckStatus.FAILED: "FAIL",
                CheckStatus.NOT_RUN: "----",
            }
            print(f"  {mark[result.status]}  {int(result.check):>2}. {result.check.name.lower()}")
            print(f"        {result.detail}")
    if report.by_status(CheckStatus.FAILED):
        return 1
    if report.by_status(CheckStatus.NOT_RUN):
        return 2
    return EXIT_OK


def cmd_doctor(args: argparse.Namespace) -> int:
    from smart_gateway.doctor import doctor

    checks, code = doctor(_data_dir(), bench_hook=args.bench_hook)
    if args.json:
        _emit_json([c.to_json() for c in checks])
    else:
        _print_checks(checks)
    return code


def cmd_privacy_audit(args: argparse.Namespace) -> int:
    from smart_gateway.doctor import privacy_audit

    target = Path(args.path) if args.path else _data_dir()
    findings = privacy_audit(target)
    if args.json:
        _emit_json([f.to_json() for f in findings])
    elif findings:
        for f in findings:
            print(str(f))
        print(f"privacy audit: {len(findings)} issue(s) under {target}")
    else:
        print(f"privacy audit clean: raw/, derived/ and reports/ under {target}")
    return EXIT_USAGE if findings else EXIT_OK


def cmd_export(args: argparse.Namespace) -> int:
    from smart_gateway.doctor import ExportRefused, export

    try:
        result = export(_data_dir(), Path(args.out), with_reports=args.with_reports)
    except ExportRefused as e:
        print(f"sg export: {e}", file=sys.stderr)
        for f in e.findings:
            print(f"  {f}", file=sys.stderr)
        return e.exit_code
    if args.json:
        _emit_json(result.to_json())
    else:
        print(f"wrote {result.path} ({len(result.members)} member(s), {result.size_bytes} bytes)")
        print("rebuild elsewhere with: sg build --raw-dir <extracted>/sg-export/raw")
    return EXIT_OK


# --- sg otel ------------------------------------------------------------------------------


def _otel_port(data_dir: Path) -> tuple[str, int]:
    from smart_gateway.config import load_config

    otel = load_config(data_dir, missing_ok=True)["otel"]
    return otel["mode"], otel["port"]


def _listening(port: int) -> bool:
    try:
        socket.create_connection(("127.0.0.1", port), timeout=_PROBE_TIMEOUT_S).close()
    except OSError:
        return False
    return True


def _pid_state(pid: int) -> str:
    """What a signal from this process finds at ``pid``: ``alive``; ``gone``
    (ESRCH); or ``not ours`` (EPERM), a process this one may not signal ---
    another user's, or one outside the sandbox this process runs in."""
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return "gone"
    except PermissionError:
        return "not ours"
    return "alive"


def _alive(pid: int) -> bool:
    """Whether a process this one may signal runs at ``pid``: while ``sg otel stop`` waits
    for the receiver it signalled to exit.  A pid it may not signal is not one."""
    return _pid_state(pid) == "alive"


def _receiver_state(record: PidRecord | None) -> str | None:
    """What ``sg otel stop`` finds at the pid state/otel.pid names, which ``sg otel status``
    reports too: None, no pidfile; ``alive``, the receiver that wrote the pidfile, the one
    state ``stop`` signals; ``gone`` (ESRCH); ``not ours`` (EPERM); ``reused``, a process that
    started at another time than the pidfile's writer, so the pidfile outlived its receiver
    and the pid is another process's now (after a reboot, say); ``unverified``, a process
    whose start cannot be compared with the writer's, since the pidfile records none (an
    older sg wrote it) or the process's start cannot be read."""
    from smart_gateway.otel_receiver import process_start

    if record is None:
        return None
    state = _pid_state(record.pid)
    if state != "alive":
        return state
    if record.start is None:
        return "unverified"
    now = process_start(record.pid)
    if now is None:
        return "unverified"
    return "alive" if now == record.start else "reused"


def _stale_reason(record: PidRecord, state: str, pidfile: str) -> str:
    """Why the pidfile names no receiver ``stop`` may signal; ``status`` prints it as well."""
    pid = record.pid
    if state == "gone":
        return f"stale pidfile: pid {pid} is not running"
    if state == "not ours":
        # EPERM: the pidfile outlived its receiver and the pid is another user's now, or
        # this process runs in a sandbox that may not signal outside it.
        return f"stale pidfile: pid {pid} is not a receiver this process may signal"
    if state == "reused":
        return f"stale pidfile: pid {pid} is another process now, not the receiver that wrote it"
    why = (
        f"{pidfile} records no start time (an older sg wrote it)"
        if record.start is None
        else f"the start time of pid {pid} cannot be read"
    )
    return f"stale pidfile: pid {pid} cannot be verified as the receiver: {why}"


def _stale_remedy(record: PidRecord, state: str, pidfile: str) -> str:
    """What to do about a live process ``stop`` would not signal; '' for the other states."""
    pid = record.pid
    if state == "reused":
        return (
            f"; `sg otel stop` leaves pid {pid} alone. Remove {pidfile}; "
            "`sg otel status` says whether a receiver still listens"
        )
    if state == "unverified":
        return (
            f"; `sg otel stop` leaves pid {pid} alone. If `ps -o command= -p {pid}` shows "
            f"`otel serve`, stop it with `kill {pid}`; otherwise remove {pidfile}"
        )
    return ""


def cmd_otel_serve(args: argparse.Namespace) -> int:
    from smart_gateway.otel_receiver import serve

    return serve(port=args.port, heartbeat_s=args.heartbeat_s, idle_s=args.idle_s)


def cmd_otel_status(args: argparse.Namespace) -> int:
    from smart_gateway.otel_receiver import pidfile_path, read_pidfile_record

    data_dir = _data_dir()
    mode, port = _otel_port(data_dir)
    record = read_pidfile_record(data_dir)
    state = _receiver_state(record)
    status = {
        "mode": mode,
        "port": port,
        "pid": record.pid if record is not None else None,
        # The receiver that wrote the pidfile, the one process `stop` signals.
        "alive": state == "alive",
        "pid_state": state,
        "listening": _listening(port),
    }
    if state is None:
        who = "no pidfile"
    elif state == "alive":
        who = f"pid {record.pid} alive"
    else:  # As `sg otel stop` says it.
        who = _stale_reason(record, state, _rel(pidfile_path(data_dir), data_dir))
    if args.json:
        _emit_json(status)
    elif mode == "external":
        print(f"otel.mode is external: no local receiver is managed (port {port})")
    elif status["listening"]:
        print(f"receiver: listening on 127.0.0.1:{port} ({who})")
    else:
        print(f"receiver: not listening on 127.0.0.1:{port} ({who}); start: sg otel serve")
    if mode == "external":
        return EXIT_OK
    return EXIT_OK if status["listening"] else EXIT_USAGE


def cmd_otel_stop(args: argparse.Namespace) -> int:
    from smart_gateway.otel_receiver import pidfile_path, read_pidfile, read_pidfile_record

    data_dir = _data_dir()
    pidfile = _rel(pidfile_path(data_dir), data_dir)
    record = read_pidfile_record(data_dir)
    if record is None:
        raise CliError(f"no receiver pidfile at {pidfile}")
    # Only the process that wrote the pidfile is signalled. A pidfile that outlived its
    # receiver (SIGKILL, a crash, a power loss) can name, after a reboot, an unrelated
    # process of this user's; its start differs from the one the receiver recorded.
    state = _receiver_state(record)
    if state != "alive":
        reason = _stale_reason(record, state, pidfile)
        raise CliError(reason + _stale_remedy(record, state, pidfile))
    pid = record.pid
    try:
        os.kill(pid, signal.SIGTERM)
    except ProcessLookupError:  # it exited since the check
        raise CliError(_stale_reason(record, "gone", pidfile)) from None
    except PermissionError:
        raise CliError(_stale_reason(record, "not ours", pidfile)) from None
    deadline = time.monotonic() + _STOP_WAIT_S
    while time.monotonic() < deadline and (_alive(pid) or read_pidfile(data_dir) == pid):
        time.sleep(0.05)
    stopped = not _alive(pid)
    if args.json:
        _emit_json({"pid": pid, "stopped": stopped})
    elif stopped:
        print(f"stopped receiver pid {pid}")
    else:
        print(f"sent SIGTERM to pid {pid}; still running after {_STOP_WAIT_S:.0f} s")
    return EXIT_OK if stopped else EXIT_USAGE


# --- sg ingest transcripts -------------------------------------------------------------------


def cmd_ingest_transcripts(args: argparse.Namespace) -> int:
    from smart_gateway import transcript

    data_dir = _ready_data_dir()
    projects_dir = Path(args.projects_dir) if args.projects_dir else None
    sessions = [args.session] if args.session else transcript.known_sessions(data_dir, projects_dir)
    results: dict[str, dict] = {}
    for sid in sessions:
        try:
            stats = transcript.ingest(
                sid, args.deadline_s, trigger="cli", data_dir=data_dir, projects_dir=projects_dir
            )
        except ValueError as e:
            raise CliError(f"session {sid!r}: {e}") from None
        results[sid] = stats.to_json()
    if args.json:
        _emit_json(results)
    else:
        for sid, s in results.items():
            tail = " (deadline reached; the next run continues)" if s["stopped_by_deadline"] else ""
            print(
                f"{sid}: {s['records_emitted']} record(s) from {s['files_seen']} file(s), "
                f"{s['elapsed_ms']} ms{tail}"
            )
        print(f"ingested {len(results)} session(s)")
    return EXIT_OK


# --- sg run -------------------------------------------------------------------------------


def cmd_run(args: argparse.Namespace) -> int:
    from smart_gateway.ids import sanitize_task_id

    try:
        task_id = sanitize_task_id(args.task)
    except ValueError as e:
        raise CliError(f"--task: {e}") from None
    if args.assignment == "randomized" and args.propensity is None:
        raise CliError("--assignment randomized requires --propensity")
    if args.propensity is not None and not 0 < args.propensity < 1:
        raise CliError("--propensity must be strictly between 0 and 1")
    env = dict(os.environ)
    env["SG_TASK_ID"] = task_id
    for key, value in (
        ("SG_CONFIG_LABEL", args.label),
        ("SG_ASSIGNMENT", args.assignment),
        ("SG_PROPENSITY", None if args.propensity is None else repr(args.propensity)),
        ("SG_EXPERIMENT", args.experiment),
    ):
        if value is not None:
            env[key] = value
    command = list(args.command)
    if command[:1] == ["--"]:  # the separator itself, never claude's own arguments
        command = command[1:]
    command = command or ["claude"]
    try:
        os.execvpe(command[0], command, env)
    except OSError as e:
        raise CliError(f"cannot exec {command[0]}: {e}") from None
    return EXIT_OK  # pragma: no cover - exec never returns


# --- sg task / bind / unbind ---------------------------------------------------------------


def _record_op(
    args: argparse.Namespace,
    op: str,
    task_id: str,
    fields: dict,
    session_id: str | None = None,
    attempt_id: str | None = None,
) -> int:
    from smart_gateway.tasks import write_op

    data_dir = _ready_data_dir()
    try:
        path, record = write_op(data_dir, op, task_id, fields, session_id, attempt_id)
    except ValueError as e:
        raise CliError(f"{op}: {e}") from None
    if args.json:
        _emit_json(record.to_json())
    else:
        scope = ""
        if record.session_id:
            scope = f" session {record.session_id}"
        elif record.attempt_id:
            scope = f" attempt {record.attempt_id}"
        print(f"recorded {op} for task {record.task_id}{scope} -> {_rel(path, data_dir)}")
    return EXIT_OK


def _evaluator(text: str | None) -> dict | None:
    if text is None:
        return None
    kind, _sep, ident = text.partition(":")
    return {"kind": kind, "id": ident or None}


def cmd_task_new(args: argparse.Namespace) -> int:
    from smart_gateway.ids import sanitize_task_id

    fields = {
        "population": args.population,
        "evaluator": _evaluator(args.evaluator),
        "family": args.family,
        "created_at": args.created_at,
    }
    code = _record_op(args, "new", args.task_id, fields)
    if args.start:
        task_id = sanitize_task_id(args.task_id)
        marker_dir = Path.cwd() / ".sg"
        marker_dir.mkdir(mode=0o700, exist_ok=True)
        (marker_dir / "task").write_text(task_id + "\n", encoding="utf-8")
        if not args.json:
            print(f"wrote .sg/task (marker binding for sessions started in {Path.cwd()})")
    return code


def cmd_task_label(args: argparse.Namespace) -> int:
    fields = {
        "config_label": args.config_label,
        "assignment": args.assignment,
        "propensity": args.propensity,
        "experiment": args.experiment,
    }
    return _record_op(args, "label", args.task_id, fields, args.session, args.attempt)


def cmd_task_accept(args: argparse.Namespace) -> int:
    from smart_gateway.ids import utc_now_iso

    fields = {"accepted_by": args.by, "at": args.at or utc_now_iso(), "source": args.source}
    return _record_op(args, "accept", args.task_id, fields, attempt_id=args.attempt)


def cmd_task_observe(args: argparse.Namespace) -> int:
    from smart_gateway.ids import utc_now_iso

    fields = {
        "column": args.column,
        "value": _parse_bool(args.value, "value"),
        "source": args.source,
        "at": args.at or utc_now_iso(),
    }
    return _record_op(args, "observe", args.task_id, fields, attempt_id=args.attempt)


def cmd_task_repair(args: argparse.Namespace) -> int:
    fields = {
        "human_minutes": args.human_minutes,
        "human_minutes_source": args.minutes_source,
        "follow_up_edits": args.follow_up_edits,
        "reopened": None if args.reopened is None else _parse_bool(args.reopened, "--reopened"),
        "source": args.source,
        "at": args.at,
    }
    return _record_op(args, "repair", args.task_id, fields, attempt_id=args.attempt)


def cmd_task_verify(args: argparse.Namespace) -> int:
    fields = {
        "ci_minutes": args.ci_minutes,
        "review_minutes": args.review_minutes,
        "source": args.source,
    }
    return _record_op(args, "verify", args.task_id, fields, attempt_id=args.attempt)


def _unbound_row(attempt: dict) -> dict:
    ref = attempt.get("branch_task_ref")
    return {
        "session_id": attempt["session_id"],
        "attempt_id": attempt["attempt_id"],
        "started_at": attempt["span"]["started_at"],
        "cwd_hash": attempt.get("cwd_hash"),
        "branch_task_ref": ref,
        "bind_command": f"sg bind {attempt['session_id']} {ref or '<task_id>'}",
    }


def _task_row(task: dict) -> dict:
    return {
        "task_id": task["task_id"],
        "population": task["population"],
        "auto_declared": task["auto_declared"],
        "n_attempts": task["n_attempts"],
        "attempts": list(task["attempts"]),
        "labels_seen": list(task["labels_seen"]),
        "accepted_by": task["acceptance"]["accepted_by"],
        "observations": {
            col: _measure_mark(o["value"]) for col, o in sorted(task["observations"].items())
        },
    }


def cmd_task_list(args: argparse.Namespace) -> int:
    data_dir = _data_dir()
    attempts = _derived_rows(data_dir, "attempts.jsonl")
    tasks = _derived_rows(data_dir, "tasks.jsonl")
    if args.week:
        from smart_gateway.config import load_config
        from smart_gateway.diagnose import week_window

        start, end = week_window(args.week, load_config(data_dir, missing_ok=True)["week_start"])
        attempts = [a for a in attempts if start <= a["span"]["started_at"] < end]
        in_week = {a["attempt_id"] for a in attempts}
        tasks = [t for t in tasks if in_week.intersection(t["attempts"])]
    if args.unbound:
        rows = [_unbound_row(a) for a in attempts if "unknown" in a["task_id"]]
        if args.json:
            _emit_json(rows)
        else:
            for r in rows:
                print(
                    f"{r['session_id']} attempt {r['attempt_id']} started {r['started_at']} "
                    f"cwd {r['cwd_hash'] or '-'} branch_ref {r['branch_task_ref'] or '-'}"
                )
                print(f"  {r['bind_command']}")
            print(f"{len(rows)} unbound attempt(s)")
        return EXIT_OK
    rows = [_task_row(t) for t in tasks]
    if args.json:
        _emit_json(rows)
    else:
        for r in rows:
            marks = " ".join(f"{col}={mark}" for col, mark in r["observations"].items())
            auto = " (auto-declared)" if r["auto_declared"] else ""
            print(
                f"{r['task_id']}{auto} {r['population']} attempts={r['n_attempts']} "
                f"labels={','.join(r['labels_seen']) or '-'} accepted_by={r['accepted_by']} {marks}"
            )
        print(f"{len(rows)} task(s)")
    return EXIT_OK


def cmd_bind(args: argparse.Namespace) -> int:
    return _record_op(args, "bind", args.task_id, {}, session_id=args.session_id)


def cmd_unbind(args: argparse.Namespace) -> int:
    from smart_gateway.tasks import bindings, iter_ops, supersede

    task_id = args.task
    if task_id is None:
        current, _history = supersede(iter_ops(_ready_data_dir()))
        task_id = bindings(current).get(args.session_id, (None, ""))[0]
        if task_id is None:
            raise CliError(f"session {args.session_id} is not bound to a task (nothing to unbind)")
    return _record_op(args, "unbind", task_id, {}, session_id=args.session_id)


# --- sg billing fetch --------------------------------------------------------------------------


def cmd_billing_fetch(args: argparse.Namespace) -> int:
    from smart_gateway import billing
    from smart_gateway.rawlog import utc_date

    data_dir = _ready_data_dir()
    from_day = args.from_day or billing.suggested_from_day(data_dir)
    if from_day is None:
        raise CliError("--from YYYY-MM-DD is required for the first fetch (no billing cursor yet)")
    to_day = args.to_day or utc_date()
    result = billing.fetch(
        data_dir, from_day, to_day, args.bucket_width, allow_missing_key=args.allow_missing_key
    )
    if args.json:
        out = {k: (str(v) if isinstance(v, Path) else v) for k, v in asdict(result).items()}
        out["path"] = None if result.path is None else _rel(result.path, data_dir)
        _emit_json(out)
    elif result.skipped_missing_key:
        print(
            "SG_ADMIN_API_KEY is not set: nothing fetched; cost_billed stays "
            "unknown(admin_key_absent) (--allow-missing-key)"
        )
    else:
        where = _rel(result.path, data_dir) if result.path else "-"
        print(
            f"fetched {result.rows_written} row(s) in {result.requests_made} request(s) "
            f"for {result.from_day}..{result.to_day} -> {where}"
        )
        if result.partial_day:
            print(f"day {result.partial_day} is partial (window capped at now - 15 min); ")
            print("the next `sg billing fetch` re-pulls it")
    return EXIT_OK


# --- sg build / diagnose / gate / sample-size ---------------------------------------------------


def cmd_build(args: argparse.Namespace) -> int:
    from smart_gateway.build import build

    data_dir = _data_dir()
    extra = [Path(p) for p in (args.raw_dir or [])]
    result = build(data_dir, extra_raw_dirs=extra, verify=args.verify)
    if args.json:
        _emit_json(result.to_json())
    else:
        c = result.counts
        print(f"build_id {result.build_id}")
        print(
            f"sessions {c['sessions']['total']}  attempts {c['attempts']['total']} "
            f"(bound {c['attempts']['bound']}, unbound {c['attempts']['unbound']})  "
            f"api_calls {c['api_calls']['total']} (errors {c['api_calls']['errors']})  "
            f"tasks {c['tasks']['total']}  reconciliation buckets {c['reconciliation']['buckets']}"
        )
        corrupt = sum(i.corrupt_lines for i in result.inputs)
        print(f"raw inputs {len(result.inputs)} file(s), corrupt lines {corrupt}")
        if result.verify:
            if result.verify_ok:
                print("verify: derived/ matches a fresh build")
            else:
                print(f"verify: derived/ differs: {', '.join(result.differing_files)}")
        else:
            print(f"wrote {', '.join(result.written)} under {_rel(result.derived_dir, data_dir)}/")
    return EXIT_USAGE if result.verify and not result.verify_ok else EXIT_OK


def cmd_diagnose(args: argparse.Namespace) -> int:
    from smart_gateway import diagnose, transcript
    from smart_gateway.build import build

    data_dir = _ready_data_dir()
    week = args.week or diagnose.current_week()
    diagnose.report_paths(data_dir, week)  # validates the week before any work is done
    if not args.no_ingest:
        for sid in transcript.known_sessions(data_dir):
            transcript.ingest(sid, INGEST_DEADLINE_S, trigger="cli", data_dir=data_dir)
    if not args.no_build:
        build(data_dir)
    try:
        markdown, report = diagnose.render(data_dir, week)
    except diagnose.StaleBuildError as e:
        raise CliError(str(e)) from None
    md_path, json_path = diagnose.report_paths(data_dir, week)
    if args.json:
        _emit_json(report)
    else:
        print(markdown, end="" if markdown.endswith("\n") else "\n")
    print(f"wrote {_rel(md_path, data_dir)} and {_rel(json_path, data_dir)}", file=sys.stderr)
    return EXIT_OK


def cmd_gate(args: argparse.Namespace) -> int:
    from smart_gateway import gate
    from smart_gateway.config import config_digest, load_config

    data_dir = _data_dir()
    config = load_config(data_dir)
    overrides = {
        "delta": args.delta,
        "outcome": args.outcome,
        "current": args.current,
        "seed": args.seed,
        "p": args.p,
    }
    if not args.exploratory and any(
        overrides[k] is not None for k in ("delta", "outcome", "current", "p")
    ):
        raise CliError(
            "--delta/--outcome/--current/--p are not pre-registered in config.gate: "
            "add --exploratory to run with them (the verdict is then exploratory)"
        )
    if args.exploratory and args.candidate is not None:
        overrides["candidate"] = args.candidate
    candidates = [args.candidate] if args.candidate else config["gate"]["candidate_config_labels"]
    if not candidates:
        raise CliError("no candidate: set config.gate.candidate_config_labels or pass --candidate")
    tasks = _derived_rows(data_dir, "tasks.jsonl")
    attempts = _derived_rows(data_dir, "attempts.jsonl")
    manifest = _build_json(data_dir)
    build_id = manifest["build_id"]
    # A confirmatory verdict is only as frozen as the parameters it was derived under.
    # Reading fresh config against derived records built from a different config would let
    # an edited delta flip a refusal into a recommendation while still quoting that build's
    # id and overwriting its report, so the mismatch is refused rather than reported.
    if manifest.get("config_digest") != config_digest(config):
        raise CliError(
            "config.json has changed since derived/ was built "
            f"(build {build_id[:8]} was made under a different config): "
            "run `sg build` so the decision and its records share one set of parameters"
        )
    decisions = []
    for candidate in candidates:
        try:
            decision = gate.decide(
                tasks, attempts, config["gate"], candidate, build_id, cli_overrides=overrides
            )
        except ValueError as e:
            raise CliError(f"gate: {e}") from None
        path = gate.write_decision(data_dir, decision)
        decisions.append((decision, path))
    if args.json:
        _emit_json([d.to_json() for d, _path in decisions])
        return EXIT_OK
    for decision, path in decisions:
        print(f"== {decision.current or 'unset'} vs {decision.candidate} ==")
        print(decision.text)
        reasons = ", ".join(decision.reasons) or "none"
        print(f"verdict: {decision.verdict}; reasons: {reasons}")
        n = decision.n
        required = decision.sample_size["required_n_per_arm"]
        print(
            f"randomized n per arm: current {n['current']}, candidate {n['candidate']}; "
            f"required n per arm: {'n/a' if required is None else required}; "
            f"cost basis: {decision.cost_basis}"
        )
        print(f"written: {_rel(path, data_dir)}")
    return EXIT_OK


def cmd_sample_size(args: argparse.Namespace) -> int:
    from smart_gateway import stats
    from smart_gateway.config import load_config

    gate_cfg = load_config(_data_dir(), missing_ok=True)["gate"]
    alpha = gate_cfg["alpha"] if args.alpha is None else args.alpha
    power = gate_cfg["power"] if args.power is None else args.power
    try:
        out: dict[str, object] = {
            "p": args.p,
            "delta": args.delta,
            "alpha": alpha,
            "power": power,
            "required_n_per_arm": stats.sample_size_noninferiority(
                args.p, args.delta, alpha, power
            ),
        }
        if args.n is not None:
            out["n"] = args.n
            out["delta_min_at_n"] = round(stats.delta_min(args.p, args.n, alpha, power), 4)
    except ValueError as e:
        raise CliError(f"sample-size: {e}") from None
    if args.json:
        _emit_json(out)
    else:
        print(
            f"required n per arm: {out['required_n_per_arm']} "
            f"(p={args.p}, delta={args.delta}, alpha={alpha}, power={power}, one-sided)"
        )
        if args.n is not None:
            print(f"delta_min at n={args.n} per arm: {out['delta_min_at_n']}")
    return EXIT_OK


# --- parser -----------------------------------------------------------------------------------


def _add_json(p: argparse.ArgumentParser) -> None:
    p.add_argument("--json", action="store_true", help="print machine-readable JSON")


def _add_attempt(p: argparse.ArgumentParser) -> None:
    p.add_argument("--attempt", metavar="ATTEMPT_ID", help="scope the op to one attempt")


def build_parser() -> argparse.ArgumentParser:
    parser = _Parser(
        prog="sg",
        description="Smart Gateway: measures what coding-agent work costs, reconciled to billing.",
    )
    parser.add_argument("--version", action="version", version=f"sg {__version__}")
    sub = parser.add_subparsers(dest="command", required=True, metavar="<command>")

    p = sub.add_parser("init", help="create the data dir and config; write the OTEL env block")
    p.add_argument("--team")
    p.add_argument("--engineer-usd-per-hour", type=float)
    p.add_argument("--repair-minutes-team-estimate", type=int)
    p.add_argument("--branch-regex", help="regex with one capture group for the task id")
    p.add_argument("--delta", type=float, help="pre-registered noninferiority margin")
    p.add_argument(
        "--primary-outcome",
        choices=("tests_passed", "reviewer_accepted", "task_reopened", "classifier_flagged"),
    )
    p.add_argument("--current-label", help="config label of the current configuration")
    p.add_argument("--scope", choices=_SETTINGS_SCOPES, default="user")
    p.add_argument("--port", type=int, help="receiver port (default: config, 4318)")
    p.add_argument("--yes", action="store_true", help="write the env block into settings.json")
    p.set_defaults(func=cmd_init)

    p = sub.add_parser("control", help="the control half: commit point, plan source, conformance")
    csub = p.add_subparsers(dest="control_cmd", required=True)
    q = csub.add_parser(
        "serve", help="run the commit point (ANTHROPIC_BASE_URL target) in the foreground"
    )
    q.add_argument("--port", type=int, help="override control.json listen.port")
    q.set_defaults(func=cmd_control_serve)
    q = csub.add_parser(
        "plan-source",
        help="serve plans by assigned arm from an arms file (sg.arms.v1): the reference source",
    )
    q.add_argument("--arms", required=True, metavar="FILE", help="the experiment's arms (JSON)")
    q.add_argument("--host", default="127.0.0.1")
    q.add_argument("--port", type=int, default=8800)
    q.set_defaults(func=cmd_control_plan_source)
    from smart_gateway.control.config import HARNESSES
    from smart_gateway.control.launch_cli import add_launch_parser

    add_launch_parser(csub)
    q = csub.add_parser("conformance", help="run RFC 0009 §6 against a real harness; exit 0/1/2")
    q.add_argument(
        "--harness", choices=sorted([*HARNESSES, "opencode-vicaria"]), default="claude-code"
    )
    q.add_argument("--json", action="store_true", help="emit the report as JSON")
    q.add_argument("--keep", metavar="DIR", help="copy every run's directory here for inspection")
    q.add_argument("--bin", help="path to the harness binary (default: found on PATH)")
    q.add_argument("--python-bin", help="interpreter for the adapter's own subprocesses (opencode)")
    q.add_argument("--model", default="claude-opus-5", help="claude-code only")
    q.add_argument("--candidate-model", default="claude-haiku-4-5", help="claude-code only")
    q.set_defaults(func=cmd_control_conformance)

    p = sub.add_parser("doctor", help="red/green checklist; exit 1 on any red")
    p.add_argument("--bench-hook", action="store_true", help="time the shim 20x")
    _add_json(p)
    p.set_defaults(func=cmd_doctor)

    p = sub.add_parser("otel", help="local OTLP receiver lifecycle")
    osub = p.add_subparsers(dest="otel_command", required=True, metavar="<serve|status|stop>")
    q = osub.add_parser("serve", help="run the receiver in the foreground (spawned by hooks)")
    q.add_argument("--port", type=int)
    q.add_argument("--heartbeat-s", type=float, default=60.0)
    q.add_argument("--idle-s", type=float, default=7200.0)
    q.set_defaults(func=cmd_otel_serve)
    q = osub.add_parser("status", help="is a receiver listening on the configured port")
    _add_json(q)
    q.set_defaults(func=cmd_otel_status)
    q = osub.add_parser("stop", help="SIGTERM the receiver named in state/otel.pid")
    _add_json(q)
    q.set_defaults(func=cmd_otel_stop)

    p = sub.add_parser("ingest", help="incremental usage-only transcript extraction")
    isub = p.add_subparsers(dest="ingest_command", required=True, metavar="transcripts")
    q = isub.add_parser("transcripts", help="all known sessions, or --session")
    q.add_argument("--session", metavar="ID")
    q.add_argument("--projects-dir", metavar="P", help="default ~/.claude/projects")
    q.add_argument("--deadline-s", type=float, default=INGEST_DEADLINE_S, metavar="N")
    _add_json(q)
    q.set_defaults(func=cmd_ingest_transcripts)

    p = sub.add_parser("run", help="exec claude with SG_TASK_ID (and label provenance) set")
    p.add_argument("--task", required=True)
    p.add_argument("--label", help="SG_CONFIG_LABEL")
    p.add_argument("--assignment", choices=("randomized", "observational"))
    p.add_argument("--propensity", type=float)
    p.add_argument("--experiment")
    p.add_argument("command", nargs=argparse.REMAINDER, help="-- claude [args]")
    p.set_defaults(func=cmd_run)

    p = sub.add_parser("task", help="declare tasks and record their signals")
    tsub = p.add_subparsers(dest="task_command", required=True, metavar="<op>")
    q = tsub.add_parser("new", help="declare a task")
    q.add_argument("task_id")
    q.add_argument("--population", choices=("production", "benchmark"), default="production")
    q.add_argument("--evaluator", metavar="KIND[:ID]", help="human|ci|script|unknown[:id]")
    q.add_argument("--family")
    q.add_argument("--created-at", metavar="ISO")
    q.add_argument("--start", action="store_true", help="write <cwd>/.sg/task")
    _add_json(q)
    q.set_defaults(func=cmd_task_new)
    q = tsub.add_parser("label", help="provenance of an attempt or session")
    q.add_argument("task_id")
    scope = q.add_mutually_exclusive_group(required=True)
    scope.add_argument("--session", metavar="SESSION_ID")
    scope.add_argument("--attempt", metavar="ATTEMPT_ID")
    q.add_argument("--config-label", required=True)
    q.add_argument("--assignment", choices=("observational", "randomized"), default="observational")
    q.add_argument("--propensity", type=float)
    q.add_argument("--experiment")
    _add_json(q)
    q.set_defaults(func=cmd_task_label)
    q = tsub.add_parser("accept", help="acceptance by a human or CI")
    q.add_argument("task_id")
    q.add_argument("--by", choices=("human", "ci"), required=True)
    q.add_argument("--at", metavar="ISO", help="default: now")
    q.add_argument("--source")
    _add_attempt(q)
    _add_json(q)
    q.set_defaults(func=cmd_task_accept)
    q = tsub.add_parser("observe", help="one observation column")
    q.add_argument("task_id")
    q.add_argument(
        "column",
        choices=("tests_passed", "reviewer_accepted", "task_reopened", "classifier_flagged"),
    )
    q.add_argument("value", choices=("true", "false"))
    q.add_argument("--source", required=True)
    q.add_argument("--at", metavar="ISO", help="default: now")
    _add_attempt(q)
    _add_json(q)
    q.set_defaults(func=cmd_task_observe)
    q = tsub.add_parser("repair", help="repair signals; omitted fields stay unknown")
    q.add_argument("task_id")
    q.add_argument("--human-minutes", type=int)
    q.add_argument("--minutes-source", choices=("entered", "timer"))
    q.add_argument("--follow-up-edits", type=int)
    q.add_argument("--reopened", choices=("true", "false"))
    q.add_argument("--source")
    q.add_argument("--at", metavar="ISO")
    _add_attempt(q)
    _add_json(q)
    q.set_defaults(func=cmd_task_repair)
    q = tsub.add_parser("verify", help="verification effort")
    q.add_argument("task_id")
    q.add_argument("--ci-minutes", type=int)
    q.add_argument("--review-minutes", type=int)
    q.add_argument("--source")
    _add_attempt(q)
    _add_json(q)
    q.set_defaults(func=cmd_task_verify)
    q = tsub.add_parser("list", help="derived tasks, or unbound attempts with bind commands")
    q.add_argument("--unbound", action="store_true")
    q.add_argument("--week", metavar="YYYY-Www")
    _add_json(q)
    q.set_defaults(func=cmd_task_list)

    p = sub.add_parser("bind", help="manual session -> task binding (highest precedence)")
    p.add_argument("session_id")
    p.add_argument("task_id")
    _add_json(p)
    p.set_defaults(func=cmd_bind)
    p = sub.add_parser("unbind", help="remove a manual binding")
    p.add_argument("session_id")
    p.add_argument("--task", help="default: the task the session is bound to")
    _add_json(p)
    p.set_defaults(func=cmd_unbind)

    p = sub.add_parser("billing", help="Admin API usage/cost reports")
    bsub = p.add_subparsers(dest="billing_command", required=True, metavar="fetch")
    q = bsub.add_parser("fetch", help="pull usage_report + cost_report into raw/billing/")
    q.add_argument("--from", dest="from_day", metavar="YYYY-MM-DD", help="default: cursor")
    q.add_argument("--to", dest="to_day", metavar="YYYY-MM-DD", help="default: today (UTC)")
    q.add_argument("--bucket-width", choices=("1d", "1h"), default="1d")
    q.add_argument("--allow-missing-key", action="store_true", help="exit 0 without a key")
    _add_json(q)
    q.set_defaults(func=cmd_billing_fetch)

    p = sub.add_parser("build", help="derive attempts, api_calls, tasks and reconciliation")
    p.add_argument("--raw-dir", action="append", metavar="DIR", help="extra raw/ trees")
    p.add_argument("--verify", action="store_true", help="compare derived/ with a fresh build")
    _add_json(p)
    p.set_defaults(func=cmd_build)

    p = sub.add_parser("diagnose", help="ingest, build, then render the weekly diagnosis")
    p.add_argument("--week", metavar="YYYY-Www", help="default: the current ISO week")
    p.add_argument("--no-ingest", action="store_true")
    p.add_argument("--no-build", action="store_true")
    _add_json(p)
    p.set_defaults(func=cmd_diagnose)

    p = sub.add_parser("gate", help="pre-registered decision gate; writes reports/gate-*.json")
    p.add_argument("--candidate", metavar="LABEL")
    p.add_argument("--exploratory", action="store_true", help="allow non-preregistered params")
    p.add_argument("--current", metavar="LABEL")
    p.add_argument("--delta", type=float)
    p.add_argument(
        "--outcome",
        choices=("tests_passed", "reviewer_accepted", "task_reopened", "classifier_flagged"),
    )
    p.add_argument("--seed", type=int, help="bootstrap seed (not a pre-registration change)")
    p.add_argument(
        "--p", type=float, help="exploratory sample-size baseline rate (requires --exploratory)"
    )
    _add_json(p)
    p.set_defaults(func=cmd_gate)

    p = sub.add_parser("sample-size", help="required n per arm; with --n, delta_min")
    p.add_argument("--p", type=float, required=True)
    p.add_argument("--delta", type=float, required=True)
    p.add_argument("--alpha", type=float)
    p.add_argument("--power", type=float)
    p.add_argument("--n", type=int)
    _add_json(p)
    p.set_defaults(func=cmd_sample_size)

    p = sub.add_parser("privacy-audit", help="scan raw/, derived/, reports/ for text")
    p.add_argument("--path", metavar="P", help="default: the data dir")
    _add_json(p)
    p.set_defaults(func=cmd_privacy_audit)

    p = sub.add_parser("export", help="raw/ + config + build manifest as a tar.gz (audited)")
    p.add_argument("--out", required=True, metavar="FILE")
    p.add_argument("--with-reports", action="store_true")
    _add_json(p)
    p.set_defaults(func=cmd_export)

    # Consent-bound capture for the continuous-benchmark loop. It lives in its
    # own module because it is a different channel from everything above: a
    # separate endpoint, a separate token, and content rather than shape-only
    # records.
    capture_cli.add_parser(sub)
    return parser


def main(argv: list[str] | None = None) -> int:
    """Parse, dispatch, and turn the known failure classes into exit codes."""
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except SystemExit as e:  # --help/--version (0) or a usage error (1)
        return e.code if isinstance(e.code, int) else EXIT_USAGE
    try:
        return args.func(args)
    except KeyboardInterrupt:
        return 130
    except Exception as e:
        code = getattr(e, "exit_code", None)
        if not isinstance(code, int) or isinstance(code, bool):
            raise
        print(f"sg: {e}", file=sys.stderr)
        return code


if __name__ == "__main__":
    sys.exit(main())
