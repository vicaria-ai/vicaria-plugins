"""The configuration artifact: one content-addressed identity per configuration (RFC 0024 §5.2).

The client digests a configuration over native values with the prompt as a
recipe *id*; two harnesses' client digests of one configuration differ, and a
recipe body change under one id would merge two arms. The artifact fixes both:
its content is the dimensions alone, with the prompt as ``{id, content_digest}``,
under one canonical serializer. The client's digest is kept beside it on the
row, never inside it. Stdlib only, plus ``traces`` itself (which is stdlib only
here too): both halves of the advisor import this.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from typing import Any

from vicaria_contracts.capability import Dimension
from vicaria_contracts.plan import Configuration
from vicaria_contracts.toolset import decode_tool_set, encode_tool_set

CONFIG_RECIPE_VERSION = 1
RECIPE_NONE = "none"


def canonical_json(obj: Any) -> str:
    """The client's recipe: sorted keys, no spaces, UTF-8, no ASCII escaping."""
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def unknown(reason: str) -> dict[str, str]:
    """A Measure that could not be observed, as its JSON (RFC 0024 §5.8)."""
    return {"unknown": reason}


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def prompt_dimension(recipe_id: str, recipe_book: Mapping[str, str]) -> dict[str, Any]:
    """The prompt dimension's registered value: the id and a digest of its body.

    ``none`` is the empty recipe. An id the book does not hold is an unknown
    content, canonicalized as its Measure JSON, never guessed.
    """
    if recipe_id == RECIPE_NONE:
        return {"id": recipe_id, "content_digest": _sha256("")}
    text = recipe_book.get(recipe_id)
    if text is None:
        return {"id": recipe_id, "content_digest": unknown("recipe_unresolved")}
    return {"id": recipe_id, "content_digest": _sha256(text)}


def artifact_id(
    kind: str, recipe_version: int, params: Mapping[str, Any], content: Any
) -> str:
    """RFC 0024 §3.8's artifact id: ``<kind>/v<recipe>/sha256:<hex>`` over the canonical JSON."""
    body = {
        "kind": kind,
        "recipe_version": recipe_version,
        "params": dict(params),
        "content": content,
    }
    return f"{kind}/v{recipe_version}/sha256:" + _sha256(canonical_json(body))


def tools_dimension(value: str) -> str:
    """The tools dimension's registered value: an explicit set, canonically encoded.

    ``set:read,bash`` and ``set:bash,read`` keep the same tools, so they are one
    configuration and must have one artifact id. The encoding is already
    canonical where the service builds it (:func:`vicaria_contracts.toolset.encode_tool_set`
    sorts), but a client's value arrives as the client wrote it. Any other value
    — a profile id — is opaque and passes through untouched.
    """
    names = decode_tool_set(value)
    return value if names is None else encode_tool_set(names)


def configuration_artifact_id(
    config: Configuration, *, recipe_book: Mapping[str, str]
) -> str:
    dims: dict[str, Any] = {d.value: config.value(d) for d in Dimension}
    dims[Dimension.PROMPT.value] = prompt_dimension(
        config.value(Dimension.PROMPT), recipe_book
    )
    dims[Dimension.TOOLS.value] = tools_dimension(config.value(Dimension.TOOLS))
    return artifact_id("configuration", CONFIG_RECIPE_VERSION, {"dims": dims}, None)


__all__ = [
    "CONFIG_RECIPE_VERSION",
    "RECIPE_NONE",
    "artifact_id",
    "canonical_json",
    "configuration_artifact_id",
    "prompt_dimension",
    "tools_dimension",
    "unknown",
]
