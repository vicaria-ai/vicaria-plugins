"""The harness declaration: what a vendor's harness holds, stated by the vendor.

vicaria-docs RFC 0040 §5.2 and §10.3.  A harness Vicaria does not drive cannot be
probed, so its vendor declares it: the capability descriptor the SDK will send
on every plan request, the signal vocabulary its ``harness.signal`` events may
use (``cb.session_event.v5``), the map from its own workflow ids to intent
nodes, the phase each tool name belongs to, and whether the harness knows a
unit's entry workflow when it creates the session --- which decides whether a
source policy may include units by workflow at all (RFC 0040 §5.5).

Like every ``vicaria.*`` contract this is a Python module: a schema string and a
frozen dataclass that reads the wire refusing rather than coercing.  Nothing here
is inferred from traffic; RFC 0005 and RFC 0009's rule that an adapter states
what it holds and the shared layer never probes applies to a vendor's harness
by the vendor's own hand.
"""

from __future__ import annotations

import re
from collections.abc import Mapping
from dataclasses import dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any

from vicaria_contracts._wire import (
    optional_str,
    require_enum,
    require_mapping,
    require_schema,
    require_str,
)
from vicaria_contracts.capability import CapabilityDescriptor

HARNESS_DECLARATION_SCHEMA_VERSION = "vicaria.harness-declaration.v1"

#: A signal name is a routable id (``$defs/id`` of the cb contracts): the
#: ``cb.session_event.v5`` schema binds ``payload.signal`` to the same
#: definition, so a name that passes here passes there.
_SIGNAL_NAME = re.compile(r"^[A-Za-z0-9_.:@+,=~-]{1,200}$")

#: The phases RFC 0031 §3's ``path@1`` annotator reads a tool call into.
PHASES = frozenset({"orient", "change", "execute", "delegate"})


class SignalKind(str, Enum):
    """How a signal was read (RFC 0030 §4's evidence classes, per signal).

    ``checked``: read from something the harness ran (an exit status, a
    render).  ``inferred``: read from what the requester did afterwards (an
    undo within a horizon).  Neither is an outcome until the evaluator built on
    it clears the precision floor on the audit sample.
    """

    CHECKED = "checked"
    INFERRED = "inferred"


@dataclass(frozen=True)
class Signal:
    """One name in the harness's signal vocabulary."""

    name: str
    kind: SignalKind
    reads: str | None = None
    horizon_s: int | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.name, str) or not _SIGNAL_NAME.match(self.name):
            raise ValueError(f"signal name {self.name!r} is not a token of at most 200 characters")
        if self.horizon_s is not None:
            if type(self.horizon_s) is not int or self.horizon_s <= 0:
                raise ValueError(f"signal {self.name!r}: horizon_s must be a positive integer")
            if self.kind is not SignalKind.INFERRED:
                raise ValueError(f"signal {self.name!r}: only an inferred signal has a horizon")

    @classmethod
    def from_dict(cls, payload: Any) -> Signal:
        obj = require_mapping(payload, "signal")
        horizon = obj.get("horizon_s")
        if horizon is not None and (type(horizon) is not int or isinstance(horizon, bool)):
            raise ValueError("signal horizon_s must be an integer or absent")
        return cls(
            name=require_str(obj, "name"),
            kind=require_enum(obj, "kind", SignalKind),
            reads=optional_str(obj, "reads"),
            horizon_s=horizon,
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {"name": self.name, "kind": self.kind.value}
        if self.reads is not None:
            out["reads"] = self.reads
        if self.horizon_s is not None:
            out["horizon_s"] = self.horizon_s
        return out


def _string_map(payload: Mapping[str, Any], key: str, what: str) -> Mapping[str, str]:
    raw = payload.get(key, {})
    if not isinstance(raw, Mapping):
        raise ValueError(f"{key} must be an object mapping {what}")
    out: dict[str, str] = {}
    for k, v in raw.items():
        if not isinstance(k, str) or not k or not isinstance(v, str) or not v:
            raise ValueError(f"{key} must map nonempty strings to nonempty strings")
        out[k] = v
    return MappingProxyType(out)


@dataclass(frozen=True)
class HarnessDeclaration:
    """A vendor's statement of one harness version.

    ``descriptor`` is the capability descriptor the SDK sends on every plan
    request; the declaration's ``harness`` and ``harness_version`` must be the
    descriptor's, so a plan request can be checked against the declaration the
    organization holds by two fields.  ``signals`` is the closed vocabulary for
    ``harness.signal`` events.  ``workflow_hints`` maps the harness's own
    workflow ids to intent-taxonomy paths (RFC 0040 D2).  ``phases`` maps tool
    names to the four phases.  ``workflow_at_start`` says whether the harness
    names a unit's entry workflow when it creates the session.
    """

    harness: str
    harness_version: str
    adapter_version: str
    descriptor: CapabilityDescriptor
    signals: tuple[Signal, ...] = ()
    workflow_hints: Mapping[str, str] = field(default_factory=lambda: MappingProxyType({}))
    phases: Mapping[str, str] = field(default_factory=lambda: MappingProxyType({}))
    workflow_at_start: bool = False
    coverage_id: str | None = None

    def __post_init__(self) -> None:
        for name in ("harness", "harness_version", "adapter_version"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value:
                raise ValueError(f"{name} must be a nonempty string")
        if self.descriptor.harness != self.harness:
            raise ValueError(
                f"the descriptor is for harness {self.descriptor.harness!r}, "
                f"the declaration for {self.harness!r}"
            )
        if self.descriptor.harness_version != self.harness_version:
            raise ValueError(
                f"the descriptor is for version {self.descriptor.harness_version!r}, "
                f"the declaration for {self.harness_version!r}"
            )
        names = [signal.name for signal in self.signals]
        if len(set(names)) != len(names):
            raise ValueError("signal names must be unique")
        for tool, phase in self.phases.items():
            if phase not in PHASES:
                raise ValueError(
                    f"tool {tool!r} names phase {phase!r}; one of {sorted(PHASES)}"
                )
        if type(self.workflow_at_start) is not bool:
            raise ValueError("workflow_at_start must be a boolean")

    @property
    def signal_names(self) -> frozenset[str]:
        return frozenset(signal.name for signal in self.signals)

    def declares_signal(self, name: str) -> bool:
        """Whether a ``harness.signal`` naming ``name`` is in the vocabulary."""
        return name in self.signal_names

    def node_for_workflow(self, workflow_id: str) -> str | None:
        """The intent path the harness's own workflow id maps to, or None."""
        return self.workflow_hints.get(workflow_id)

    @classmethod
    def from_dict(cls, payload: Any) -> HarnessDeclaration:
        obj = require_mapping(payload, "harness declaration")
        require_schema(obj, HARNESS_DECLARATION_SCHEMA_VERSION)
        raw_signals = obj.get("signals", [])
        if not isinstance(raw_signals, list):
            raise ValueError("signals must be a list")
        at_start = obj.get("workflow_at_start", False)
        if type(at_start) is not bool:
            raise ValueError("workflow_at_start must be a boolean")
        return cls(
            harness=require_str(obj, "harness"),
            harness_version=require_str(obj, "harness_version"),
            adapter_version=require_str(obj, "adapter_version"),
            descriptor=CapabilityDescriptor.from_dict(obj.get("descriptor")),
            signals=tuple(Signal.from_dict(item) for item in raw_signals),
            workflow_hints=_string_map(obj, "workflow_hints", "workflow ids to intent paths"),
            phases=_string_map(obj, "phases", "tool names to phases"),
            workflow_at_start=at_start,
            coverage_id=optional_str(obj, "coverage_id"),
        )

    def to_dict(self) -> dict[str, Any]:
        out: dict[str, Any] = {
            "schema": HARNESS_DECLARATION_SCHEMA_VERSION,
            "harness": self.harness,
            "harness_version": self.harness_version,
            "adapter_version": self.adapter_version,
            "descriptor": self.descriptor.to_dict(),
            "signals": [signal.to_dict() for signal in self.signals],
            "workflow_hints": dict(self.workflow_hints),
            "phases": dict(self.phases),
            "workflow_at_start": self.workflow_at_start,
        }
        if self.coverage_id is not None:
            out["coverage_id"] = self.coverage_id
        return out
