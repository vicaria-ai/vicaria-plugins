"""Rubric definition, scoring records, and collection (Agent Eval design §2, §4).

WHY A RUBRIC LIVES HERE AT ALL

`eval_metrics` measures what a trajectory *is*. A rubric scores what it was
*worth*, and that judgement is not ours to make — §4 puts it with verifiers, an
autorater, and human reviewers. What belongs in this repo is the part those
three have in common: **the rubric as a versioned artifact, and the score as an
evidence-bearing record of who judged, against which version, with what
confidence**.

So this module defines and collects. It does not grade. `RubricScore` is
produced by a caller — a programmatic verifier, an autorater, a human — and
this module's job is to refuse records that cannot be audited later.

WHAT MAKES A SCORE AUDITABLE

§4 requires the autorater to be "versioned like code" and to publish its
human-agreement rate; §5 requires a "public methodology changelog". Neither is
possible if a stored score does not say what produced it. Every
:class:`RubricScore` therefore carries:

* ``rubric_id`` **and** ``rubric_version`` — a score against a rubric that has
  since been reworded is not comparable to one against the current text, and
  silently pooling them is how a leaderboard drifts without anyone editing it;
* ``judge`` — kind (verifier / autorater / human) and identity, because §4's
  escalation path and active-learning loop both depend on knowing which scores
  a human actually produced;
* ``confidence`` — optional, and the routing signal for §4's adjudication queue.

CRITERION SCORES ARE ANCHORED, NOT FREE NUMBERS

A rubric criterion declares discrete anchors ("0 = no citation, 2 = clause
cited"). A score must land ON an anchor. Free-floating floats are how two
judges silently disagree about what 0.6 means, and the design leans on
inter-judge agreement to calibrate the autorater — which is unmeasurable if the
scale is continuous and unlabelled.
"""

from __future__ import annotations

from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

RUBRIC_SCHEMA_VERSION = "vicaria.rubric.v1"
RUBRIC_SCORE_SCHEMA_VERSION = "vicaria.rubric-score.v1"


class JudgeKind(str, Enum):
    """Who produced a score. §4's stack, in descending order of trust."""

    VERIFIER = "verifier"  # programmatic; ground truth
    AUTORATER = "autorater"  # LLM; calibrated against human labels
    HUMAN = "human"  # explicit review


@dataclass(frozen=True, slots=True)
class Anchor:
    """One discrete, labelled point on a criterion's scale."""

    value: float
    label: str

    def to_dict(self) -> dict[str, Any]:
        return {"value": self.value, "label": self.label}


@dataclass(frozen=True, slots=True)
class Criterion:
    """One thing a rubric asks about, with its anchors and weight."""

    key: str
    question: str
    anchors: tuple[Anchor, ...]
    weight: float = 1.0

    def __post_init__(self) -> None:
        if not self.key:
            raise ValueError("criterion key must be non-empty")
        if len(self.anchors) < 2:
            raise ValueError(
                f"criterion {self.key!r} needs at least two anchors to discriminate"
            )
        values = [anchor.value for anchor in self.anchors]
        if len(values) != len(set(values)):
            raise ValueError(f"criterion {self.key!r} has duplicate anchor values")
        if self.weight < 0:
            raise ValueError(f"criterion {self.key!r} weight must not be negative")

    @property
    def anchor_values(self) -> tuple[float, ...]:
        return tuple(sorted(anchor.value for anchor in self.anchors))

    def to_dict(self) -> dict[str, Any]:
        return {
            "key": self.key,
            "question": self.question,
            "weight": self.weight,
            "anchors": [anchor.to_dict() for anchor in self.anchors],
        }


@dataclass(frozen=True, slots=True)
class Rubric:
    """A versioned set of criteria. Immutable — a change means a new version.

    Editing a rubric in place silently repartitions every score already stored
    against it, so ``version`` is part of identity rather than metadata.
    """

    rubric_id: str
    version: str
    domain: str
    criteria: tuple[Criterion, ...]
    schema_version: str = RUBRIC_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not self.rubric_id or not self.version:
            raise ValueError("a rubric needs both an id and a version")
        if not self.criteria:
            raise ValueError(f"rubric {self.rubric_id!r} has no criteria")
        keys = [criterion.key for criterion in self.criteria]
        if len(keys) != len(set(keys)):
            raise ValueError(f"rubric {self.rubric_id!r} has duplicate criterion keys")

    @property
    def ref(self) -> str:
        """The identity a score pins: ``id@version``."""
        return f"{self.rubric_id}@{self.version}"

    def criterion(self, key: str) -> Criterion:
        for candidate in self.criteria:
            if candidate.key == key:
                return candidate
        raise KeyError(f"rubric {self.ref} has no criterion {key!r}")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schemaVersion": self.schema_version,
            "rubricId": self.rubric_id,
            "version": self.version,
            "ref": self.ref,
            "domain": self.domain,
            "criteria": [criterion.to_dict() for criterion in self.criteria],
        }


@dataclass(frozen=True, slots=True)
class Judge:
    """Who scored, specifically enough to reproduce or retire the judgement."""

    kind: JudgeKind
    identity: str  # "verifier:pytest-exit", "autorater:claude-opus-5@v3", "human:alice"

    def __post_init__(self) -> None:
        if not self.identity:
            raise ValueError("a judge must be identifiable")

    def to_dict(self) -> dict[str, Any]:
        return {"kind": self.kind.value, "identity": self.identity}


@dataclass(frozen=True, slots=True)
class CriterionScore:
    """One criterion's verdict. ``value`` must be one of the criterion's anchors."""

    key: str
    value: float
    rationale: str | None = None

    def to_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {"key": self.key, "value": self.value}
        if self.rationale:
            payload["rationale"] = self.rationale
        return payload


@dataclass(frozen=True, slots=True)
class RubricScore:
    """One judge's scoring of one task against one rubric version.

    Constructed through :func:`score` so the anchor and coverage checks cannot
    be skipped by building the dataclass directly with plausible-looking values.
    """

    task_id: str
    rubric_ref: str
    judge: Judge
    criteria: tuple[CriterionScore, ...]
    weighted_total: float
    max_total: float
    confidence: float | None = None
    schema_version: str = RUBRIC_SCORE_SCHEMA_VERSION

    @property
    def normalized(self) -> float | None:
        """Score in [0, 1], or None when the rubric's anchors sum to zero span."""
        if self.max_total <= 0:
            return None
        return round(self.weighted_total / self.max_total, 4)

    def needs_adjudication(self, threshold: float) -> bool:
        """§4 escalation: low-confidence scores route to a human queue.

        A score with NO confidence escalates. An autorater that declines to say
        how sure it is has not earned the benefit of the doubt, and treating
        absent confidence as high is how an unreviewed guess becomes a label.
        """
        if self.judge.kind is JudgeKind.HUMAN:
            return False
        return self.confidence is None or self.confidence < threshold

    def to_dict(self) -> dict[str, Any]:
        return {
            "schemaVersion": self.schema_version,
            "taskId": self.task_id,
            "rubricRef": self.rubric_ref,
            "judge": self.judge.to_dict(),
            "criteria": [criterion.to_dict() for criterion in self.criteria],
            "weightedTotal": self.weighted_total,
            "maxTotal": self.max_total,
            "normalized": self.normalized,
            "confidence": self.confidence,
        }


def score(
    rubric: Rubric,
    *,
    task_id: str,
    judge: Judge,
    values: Mapping[str, float],
    rationales: Mapping[str, str] | None = None,
    confidence: float | None = None,
) -> RubricScore:
    """Build a validated :class:`RubricScore`, or raise.

    Three refusals, each closing a way a bad score looks like a good one:

    * an **unknown criterion key** — a judge scoring a criterion this rubric
      version does not have is scoring a different rubric;
    * a **missing criterion** — partial coverage silently lowers the total
      against a full ``max_total``, which reads as a bad run rather than an
      incomplete judgement;
    * an **off-anchor value** — the scale is discrete on purpose, and a 0.63
      between anchors cannot be compared across judges.
    """
    known = {criterion.key for criterion in rubric.criteria}
    provided = set(values)
    if unknown := provided - known:
        raise ValueError(f"{rubric.ref} has no criteria {sorted(unknown)}")
    if missing := known - provided:
        raise ValueError(
            f"{rubric.ref} scored incompletely: missing {sorted(missing)}. "
            "A partial score is not a low score."
        )
    if confidence is not None and not 0.0 <= confidence <= 1.0:
        raise ValueError("confidence must be within [0, 1]")

    rationales = rationales or {}
    scored: list[CriterionScore] = []
    weighted_total = 0.0
    max_total = 0.0
    for criterion in rubric.criteria:
        value = float(values[criterion.key])
        if value not in criterion.anchor_values:
            raise ValueError(
                f"{rubric.ref}/{criterion.key}: {value} is not an anchor "
                f"{list(criterion.anchor_values)} — the scale is discrete so judges "
                "can be compared"
            )
        scored.append(
            CriterionScore(criterion.key, value, rationales.get(criterion.key))
        )
        weighted_total += value * criterion.weight
        max_total += max(criterion.anchor_values) * criterion.weight

    return RubricScore(
        task_id=task_id,
        rubric_ref=rubric.ref,
        judge=judge,
        criteria=tuple(scored),
        weighted_total=round(weighted_total, 6),
        max_total=round(max_total, 6),
        confidence=confidence,
    )


def agreement(a: RubricScore, b: RubricScore) -> dict[str, Any]:
    """Per-criterion agreement between two judges of the SAME task and rubric.

    §4 calibrates the autorater against human labels and publishes the
    agreement rate; this is the per-pair input to that. Comparing scores against
    different rubric versions is refused rather than averaged — that is the
    silent drift `rubric_ref` exists to catch.
    """
    if a.task_id != b.task_id:
        raise ValueError(f"different tasks: {a.task_id} vs {b.task_id}")
    if a.rubric_ref != b.rubric_ref:
        raise ValueError(
            f"different rubric versions: {a.rubric_ref} vs {b.rubric_ref} — "
            "scores against different versions are not comparable"
        )
    left = {criterion.key: criterion.value for criterion in a.criteria}
    right = {criterion.key: criterion.value for criterion in b.criteria}
    exact = {key: left[key] == right[key] for key in left}
    return {
        "taskId": a.task_id,
        "rubricRef": a.rubric_ref,
        "judges": [a.judge.to_dict(), b.judge.to_dict()],
        "perCriterion": exact,
        "exactAgreementRate": round(sum(exact.values()) / len(exact), 4)
        if exact
        else None,
        "totalDelta": round(a.weighted_total - b.weighted_total, 6),
    }


@dataclass
class ScoreCollection:
    """Collected scores for a run of judging, with the §4 escalation split.

    Deliberately not an average. Pooling scores across rubric versions or judge
    kinds is the aggregation this repo does not do (see docs/EVAL_DESIGN.md);
    what it offers is the grouping an eval service needs to do it correctly.
    """

    scores: list[RubricScore] = field(default_factory=list)

    def add(self, item: RubricScore) -> None:
        self.scores.append(item)

    def extend(self, items: Iterable[RubricScore]) -> None:
        self.scores.extend(items)

    def by_rubric_ref(self) -> dict[str, list[RubricScore]]:
        grouped: dict[str, list[RubricScore]] = {}
        for item in self.scores:
            grouped.setdefault(item.rubric_ref, []).append(item)
        return grouped

    def adjudication_queue(self, threshold: float = 0.7) -> list[RubricScore]:
        """§4: low-confidence machine scores route to a human."""
        return [item for item in self.scores if item.needs_adjudication(threshold)]

    def human_labelled(self) -> list[RubricScore]:
        """The active-learning training set (§4/§9)."""
        return [item for item in self.scores if item.judge.kind is JudgeKind.HUMAN]

    def to_dict(self) -> dict[str, Any]:
        return {
            "scores": [item.to_dict() for item in self.scores],
            "rubricRefs": sorted(self.by_rubric_ref()),
            "adjudicationQueueSize": len(self.adjudication_queue()),
            "humanLabelledCount": len(self.human_labelled()),
        }


def rubric_from_dict(payload: Mapping[str, Any]) -> Rubric:
    """Load a rubric from its stored form, validating on the way in."""
    criteria_payload: Sequence[Mapping[str, Any]] = payload["criteria"]
    criteria = tuple(
        Criterion(
            key=str(item["key"]),
            question=str(item.get("question", "")),
            anchors=tuple(
                Anchor(value=float(anchor["value"]), label=str(anchor.get("label", "")))
                for anchor in item["anchors"]
            ),
            weight=float(item.get("weight", 1.0)),
        )
        for item in criteria_payload
    )
    return Rubric(
        rubric_id=str(payload["rubricId"]),
        version=str(payload["version"]),
        domain=str(payload.get("domain", "")),
        criteria=criteria,
    )
