"""The plan, and validating it before anything runs (RFC 0009 §4).

WHY THIS EXISTS

A plan is what the server proposes; a descriptor is what the adapter can do.
Neither alone decides what executes. RFC 0009 §4.1 puts the adapter last on
purpose: the server's view of a harness is a cached descriptor that may be
stale — the user upgraded, an admin narrowed permissions, a provider path
changed — while the adapter's view is current. Where they disagree the adapter
wins, and the disagreement is evidence the server needs.

WHAT VALIDATION IS FOR

Catching, before execution, the configurations that would otherwise run and look
deliberate afterwards. Three of those are the reason this module refuses rather
than coerces:

*An inherited baseline.* A plan that changes only effort, computed while the
user was on model A, must not execute against model B. So a plan names its
whole target (:class:`Configuration` resolves every dimension) and the baseline
it assumed, and a mismatch is refused before the user's work runs — not
detected afterwards in a diff.

*A downgraded prompt patch.* A substitutive patch handed to an additive adapter
is refused, never quietly applied as an addition. The applied result would be a
different configuration from the evaluated one, and every execution record of it
would be consistent, so nothing downstream could find it.

*An unverifiable dimension.* A dimension the adapter can neither set nor read
fails a plan even when the plan does not change it, because an unchanged
dimension is *verified* against the baseline rather than assumed.

WHAT IT DOES NOT DO

No dispatch, no application, no admission. This module answers "may this plan
proceed", and a caller that gets :data:`PlanValidation.ok` still owes the
staging protocol (RFC 0009 §4.2) and, on any fallback to a reference, a fresh
admission check for that reference (§4.2.1). Neither is implemented here, and a
passing validation is not a licence to skip them.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from typing import Any

from vicaria_contracts._wire import (
    optional_enum,
    optional_str,
    require_enum,
    require_mapping,
    require_schema,
    require_str,
)
from vicaria_contracts.capability import (
    CapabilityDescriptor,
    ControlLevel,
    Dimension,
    PromptShape,
    ValueSupport,
    satisfies,
)

PLAN_SCHEMA_VERSION = "vicaria.plan.v1"


class Disposition(str, Enum):
    """What the server is asking for. Four, not three (RFC 0009 §4.5)."""

    APPLY = "apply"  # set the named changes
    SUGGEST = "suggest"  # show them; set nothing
    RETAIN = "retain"  # keep the current configuration; a success, not an error
    CANNOT_EXECUTE = "cannot_execute"  # nothing admissible; the adapter stops


class Refusal(str, Enum):
    """Every reason a plan can be refused, in the order they are checked.

    A closed vocabulary because these are recorded and counted. Free text would
    make "how often does a stale baseline refuse a plan" unanswerable.
    """

    STALE_REQUEST_REVISION = "stale_request_revision"
    BASELINE_MISMATCH = "baseline_mismatch"
    MISSING_EFFECTIVE_CONFIG = "missing_effective_config"
    RETAIN_CHANGES_CONFIGURATION = "retain_changes_configuration"
    UNVERIFIABLE_DIMENSION = "unverifiable_dimension"
    INSUFFICIENT_LEVEL = "insufficient_level"
    NOT_AUTHORIZED = "not_authorized"
    UNDECLARED_VALUE_SUPPORT = "undeclared_value_support"
    UNSUPPORTED_VALUE = "unsupported_value"
    PROMPT_SHAPE_MISMATCH = "prompt_shape_mismatch"


def _require_id(value: Any, name: str) -> None:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} must be a nonempty string, got {value!r}")


@dataclass(frozen=True, slots=True)
class Configuration:
    """A complete configuration: every dimension resolved, nothing inherited.

    RFC 0009 §4.0 forbids expressing "retain the model" as an absent field, so
    every dimension is required here. Absence then means one thing only — the
    server said nothing about this dimension — and it is never a licence to
    inherit whatever happens to be active at execution time.
    """

    model: str
    effort: str
    prompt: str
    tools: str
    workflow: str

    def __post_init__(self) -> None:
        for dimension in Dimension:
            _require_id(getattr(self, dimension.value), dimension.value)

    def value(self, dimension: Dimension) -> str:
        return str(getattr(self, dimension.value))

    def digest(self) -> str:
        """A canonical content digest, stable across processes and orderings."""
        canonical = json.dumps(
            {d.value: self.value(d) for d in Dimension},
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
        )
        return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()

    @classmethod
    def from_dict(cls, payload: Any) -> Configuration:
        """Read a configuration off the wire, requiring every dimension.

        A reader that defaulted a missing dimension would reintroduce exactly
        the inheritance §4.0 forbids, one layer lower and harder to see.
        """
        obj = require_mapping(payload, "configuration")
        return cls(**{d.value: require_str(obj, d.value) for d in Dimension})

    def changed_from(self, other: Configuration) -> frozenset[Dimension]:
        """Dimensions whose value differs. The unit validation is scoped to."""
        return frozenset(d for d in Dimension if self.value(d) != other.value(d))


@dataclass(frozen=True, slots=True)
class Plan:
    """What the server returned, and what it assumed when returning it."""

    decision_id: str
    request_revision: str
    base_config_digest: str
    disposition: Disposition
    effective_config: Configuration | None = None
    prompt_shape: PromptShape | None = None
    evidence_ref: str | None = None
    reason: str | None = None

    def __post_init__(self) -> None:
        for name in ("decision_id", "request_revision", "base_config_digest"):
            _require_id(getattr(self, name), name)
        if not isinstance(self.disposition, Disposition):
            raise ValueError(
                f"disposition must be a Disposition, got {type(self.disposition).__name__}"
            )

        if self.disposition is Disposition.CANNOT_EXECUTE:
            if self.effective_config is not None:
                raise ValueError(
                    "a cannot_execute plan names no configuration to run — "
                    "carrying one invites a caller to run it"
                )
            if not self.reason:
                raise ValueError(
                    "a cannot_execute plan must carry the reason nothing was admissible"
                )
        else:
            if self.effective_config is None:
                raise ValueError(
                    f"a {self.disposition.value} plan must resolve every dimension "
                    "(RFC 0009 §4.0); absence must never be read as retain"
                )
            if not isinstance(self.effective_config, Configuration):
                raise ValueError(
                    "effective_config must be a Configuration, got "
                    f"{type(self.effective_config).__name__}"
                )

        if self.prompt_shape is not None and not isinstance(
            self.prompt_shape, PromptShape
        ):
            raise ValueError(
                f"prompt_shape must be a PromptShape, got {type(self.prompt_shape).__name__}"
            )

    @classmethod
    def from_dict(cls, payload: Any) -> Plan:
        """Read a plan off the wire.

        The plan arrives from the server and authorizes a change to the user's
        execution, so every constructor invariant applies to a wire payload
        too — reached by handing the parsed fields to ``__post_init__`` rather
        than by re-stating the rules here, where they could drift.
        """
        obj = require_mapping(payload, "plan")
        require_schema(obj, PLAN_SCHEMA_VERSION)
        config = obj.get("effective_config")
        return cls(
            decision_id=require_str(obj, "decision_id"),
            request_revision=require_str(obj, "request_revision"),
            base_config_digest=require_str(obj, "base_config_digest"),
            disposition=require_enum(obj, "disposition", Disposition),
            effective_config=None
            if config is None
            else Configuration.from_dict(config),
            prompt_shape=optional_enum(obj, "prompt_shape", PromptShape),
            evidence_ref=optional_str(obj, "evidence_ref"),
            reason=optional_str(obj, "reason"),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": PLAN_SCHEMA_VERSION,
            "decision_id": self.decision_id,
            "request_revision": self.request_revision,
            "base_config_digest": self.base_config_digest,
            "disposition": self.disposition.value,
            "effective_config": (
                {d.value: self.effective_config.value(d) for d in Dimension}
                if self.effective_config
                else None
            ),
            "prompt_shape": self.prompt_shape.value if self.prompt_shape else None,
            "evidence_ref": self.evidence_ref,
            "reason": self.reason,
        }


@dataclass(frozen=True, slots=True)
class PlanValidation:
    """The answer, with enough detail to record why.

    ``ok`` False is not an error condition — a refused plan is an ordinary and
    expected outcome, and the reason is evidence the server needs (§4.1).
    ``stop`` is different: it means dispatch nothing at all, which only
    ``cannot_execute`` produces.
    """

    ok: bool
    stop: bool = False
    refusal: Refusal | None = None
    detail: str | None = None
    changed: frozenset[Dimension] = frozenset()

    def __post_init__(self) -> None:
        if self.ok and self.refusal is not None:
            raise ValueError("a passing validation carries no refusal")
        if not self.ok and not self.stop and self.refusal is None:
            raise ValueError("a failing validation must name its refusal")


def _required_level(disposition: Disposition) -> ControlLevel:
    return (
        ControlLevel.APPLY if disposition is Disposition.APPLY else ControlLevel.SUGGEST
    )


def validate_plan(
    plan: Plan,
    descriptor: CapabilityDescriptor,
    *,
    active_config: Configuration,
    current_request_revision: str,
) -> PlanValidation:
    """Decide whether ``plan`` may proceed against what the adapter can do.

    Checked in order, and the order matters. The stop comes first (RFC 0009
    §4.5): a ``cannot_execute`` plan stops even when it is stale, because every
    refusal below falls back to the reference — the configuration the service
    has just said may not run. Staleness is next: a plan computed against a
    superseded request describes a situation that no longer exists, so its
    other fields are not worth interpreting.
    """
    # cannot_execute carries no configuration and is not compared to one. It is
    # the one disposition where doing nothing is not the safe default: retaining
    # would run a configuration the organization has prohibited (§4.5). Ahead of
    # the revision check on purpose — refused as stale, it would not stop.
    if plan.disposition is Disposition.CANNOT_EXECUTE:
        return PlanValidation(ok=False, stop=True, detail=plan.reason)

    if plan.request_revision != current_request_revision:
        return PlanValidation(
            ok=False,
            refusal=Refusal.STALE_REQUEST_REVISION,
            detail=(
                f"plan computed against {plan.request_revision!r}, "
                f"client is at {current_request_revision!r}"
            ),
        )

    active_digest = active_config.digest()
    if plan.base_config_digest != active_digest:
        return PlanValidation(
            ok=False,
            refusal=Refusal.BASELINE_MISMATCH,
            detail=(
                f"plan assumed {plan.base_config_digest}, active is {active_digest} — "
                "the evidence behind this plan was gathered for a different baseline"
            ),
        )

    if (
        plan.effective_config is None
    ):  # pragma: no cover - Plan.__post_init__ forbids it
        return PlanValidation(ok=False, refusal=Refusal.MISSING_EFFECTIVE_CONFIG)

    changed = plan.effective_config.changed_from(active_config)
    required = _required_level(plan.disposition)

    # RETAIN means retain. A plan that names a different configuration and asks
    # for it to be kept is contradictory, and admitting it would apply a change
    # under the one disposition whose whole meaning is that nothing changes.
    if plan.disposition is Disposition.RETAIN and changed:
        names = ", ".join(sorted(d.value for d in changed))
        return PlanValidation(
            ok=False,
            refusal=Refusal.RETAIN_CHANGES_CONFIGURATION,
            detail=(
                f"disposition is retain but {names} differs from the active configuration; "
                "retain names the configuration already running or it names nothing"
            ),
            changed=changed,
        )

    for dimension in Dimension:
        control = descriptor.control(dimension)
        held = control.level
        if dimension in changed:
            if not satisfies(held, required):
                return PlanValidation(
                    ok=False,
                    refusal=Refusal.INSUFFICIENT_LEVEL,
                    detail=(
                        f"{dimension.value} changes, so {plan.disposition.value} needs "
                        f"{required.value}; adapter holds {held.value}"
                    ),
                    changed=changed,
                )
            if not control.authorized:
                # Distinct from INSUFFICIENT_LEVEL on purpose: the mechanism
                # exists and this package may not use it, which an administrator
                # can change and a missing capability cannot.
                return PlanValidation(
                    ok=False,
                    refusal=Refusal.NOT_AUTHORIZED,
                    detail=(
                        f"{dimension.value} changes and the harness exposes it at "
                        f"{held.value}, but this package is not authorized to use it"
                    ),
                    changed=changed,
                )
            target = plan.effective_config.value(dimension)
            if control.value_support is ValueSupport.UNKNOWN:
                # Separate from UNSUPPORTED_VALUE because the fix is different.
                # "That model is not in the set" is answered by choosing another;
                # "no set was ever declared" is answered only by the adapter, and
                # counting them together makes neither answerable.
                return PlanValidation(
                    ok=False,
                    refusal=Refusal.UNDECLARED_VALUE_SUPPORT,
                    detail=(
                        f"{dimension.value} changes to {target!r}, but this adapter has not "
                        "established which values it can reach — silence is not a claim that "
                        "it can reach this one"
                    ),
                    changed=changed,
                )
            if not control.admits(target):
                # A level says the adapter can select a model. It says nothing
                # about whether this one exists, and discovering that at dispatch
                # is discovering it after the user's turn has started.
                return PlanValidation(
                    ok=False,
                    refusal=Refusal.UNSUPPORTED_VALUE,
                    detail=(
                        f"{dimension.value}={target!r} is not one of the values this "
                        "adapter declared it can reach"
                    ),
                    changed=changed,
                )
        elif not satisfies(held, ControlLevel.OBSERVE):
            # Unchanged dimensions are verified, not assumed. That verification
            # is how base_config_digest gets checked dimension by dimension
            # rather than only in aggregate, so a dimension nobody can read
            # fails the plan even though the plan leaves it alone.
            return PlanValidation(
                ok=False,
                refusal=Refusal.UNVERIFIABLE_DIMENSION,
                detail=(
                    f"{dimension.value} is unchanged but the adapter holds "
                    f"{held.value}, so its baseline cannot be verified"
                ),
                changed=changed,
            )

    if Dimension.PROMPT in changed:
        # Reachable only once prompt cleared the level check above, and a
        # descriptor declaring SUGGEST or APPLY on prompt must carry a shape, so
        # the adapter's side is known here by construction.
        held_shape = descriptor.prompt_shape
        wanted = plan.prompt_shape
        if wanted is None:
            # Not a missing nicety: with no declared form there is nothing to
            # compare, and the mismatch check would pass by being skipped —
            # which is the silent failure the check exists to prevent.
            return PlanValidation(
                ok=False,
                refusal=Refusal.PROMPT_SHAPE_MISMATCH,
                detail=(
                    "plan changes the prompt without naming the form its patch was "
                    f"evaluated in; adapter applies {held_shape.value if held_shape else '?'}"
                ),
                changed=changed,
            )
        if wanted is not held_shape:
            return PlanValidation(
                ok=False,
                refusal=Refusal.PROMPT_SHAPE_MISMATCH,
                detail=(
                    f"plan's patch was evaluated as {wanted.value}, adapter applies "
                    f"{held_shape.value if held_shape else '?'} — applying it would execute "
                    "a configuration the evidence never evaluated"
                ),
                changed=changed,
            )

    return PlanValidation(ok=True, changed=changed)


def summarize(validation: PlanValidation) -> Mapping[str, Any]:
    """A recordable form. Refusals are counted, so they serialize as codes."""
    return {
        "ok": validation.ok,
        "stop": validation.stop,
        "refusal": validation.refusal.value if validation.refusal else None,
        "detail": validation.detail,
        "changed": sorted(d.value for d in validation.changed),
    }
