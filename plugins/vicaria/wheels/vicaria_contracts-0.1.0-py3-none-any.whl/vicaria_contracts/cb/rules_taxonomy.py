"""Document-local semantic rules for ``taxonomy.schema.json``.

JSON Schema can make whole array members unique, but taxonomy identity lives in
one member of each object: ``dimensions[].key`` and ``values[].value``.  Two
objects with the same identity and different display labels would therefore
pass ``uniqueItems`` while giving readers two answers for one key.  These pure
rules are wired through ``x-cb-rules`` so every contract validator refuses the
same ambiguous document.
"""

from __future__ import annotations

from typing import Any


def rule_dimensions_are_unambiguous(document: dict[str, Any]) -> list[str]:
    """Refuse duplicate dimension keys, values, and reserved-value entries."""
    errors: list[str] = []
    dimensions = document["dimensions"]
    keys = [dimension["key"] for dimension in dimensions]
    if len(keys) != len(set(keys)):
        errors.append("dimensions: each dimension key must appear exactly once")

    for index, dimension in enumerate(dimensions):
        values = [entry["value"] for entry in dimension["values"]]
        if len(values) != len(set(values)):
            errors.append(
                f"dimensions[{index}].values: each value must appear exactly once"
            )
        if values.count(document["unassigned_value"]) != 1:
            errors.append(
                f"dimensions[{index}].values: must contain exactly one "
                f"{document['unassigned_value']!r} value"
            )
    return errors


RULES = {
    "taxonomy_dimensions_are_unambiguous": rule_dimensions_are_unambiguous,
}
