"""The cross-DOCUMENT admissibility rules, and the one place the owners are asked.

What changed here, and why
--------------------------
This module used to carry its own copy of the per-document rules.  So did the
schema-wired ``rules_*.py`` modules.  Two implementations of one decision is not
redundancy - it is a coin toss, and a fourth review of PR #57 caught the coin
landing differently on three records:

===========================================  ==================  =============
record                                       schema-wired rule   this module
===========================================  ==================  =============
approved case, reference check not run, cap   accepted            refused
``17:12:09+08:00`` = the fixture's ``09:12:09Z``  accepted        refused
retry rewriting ``producer_seq`` 3 as 3.0     retry               conflict
===========================================  ==================  =============

Each row is one question with one right answer, asked twice.  So the rule
modules own every question a SINGLE document settles, this module calls them,
and what is left here is only what a single document cannot settle.

How the three were resolved, and why each way won
-------------------------------------------------
1. **A reference check recorded NOT RUN, capped, on an approved case.**  The
   rule module accepts and this module used to refuse.  The rule module wins:
   RFC 0018:383 states the tri-state ("only ``ran=true, passed=false`` blocks"),
   the register's ``reference-fix-must-pass`` row names
   ``rule_admission_requires_completed_validation`` as refusing a PERFORMED
   check that failed, and ``tests/test_cb_case_revision_rules.py:475`` is a
   positive fixture for exactly this document.  Refusing it meant rewriting all
   three, and the reason they say what they say - "not run" and "failed" are
   different facts about the world, and collapsing them hides which one
   happened - is still true.  What must not regress is the other half: a check
   that RAN and FAILED still blocks approval and drawability (finding 4 of the
   previous review), and
   ``tests/test_cb_one_owner_agreement.py`` pins both halves through every
   entry point.
2. **Two spellings of one instant.**  This module compared ``event_time``
   against the interval bounds as STRINGS.  ``2026-09-14T17:12:09+08:00`` and
   ``2026-09-14T09:12:09Z`` are one instant, and string order put them eight
   hours apart, so a batch refused an event the single-event path admitted.
   The string comparison was simply wrong; ``primitives.instant`` parses, and
   the per-event rule that already did so is now the only implementation.
3. **``producer_seq`` 3 versus 3.0.**  Two serializers: RFC 8785 writes both as
   ``3`` (they are one double), ``json.dumps`` writes ``3`` and ``3.0``.  So
   ``classify_repeat`` called the pair a retry while the batch here called it a
   conflict.  One canonical form settles it - RFC 8785, the one the contract
   declares - and this module no longer serializes an event at all: it asks
   ``rules_session_event.classify_repeat``, which recomputes both digests.  The
   answer is *retry*, on both paths.

What is still decided here
--------------------------
Only what needs more than one document, or more than one event, at once:

* **A repeat across a stream** - retry or conflict.  The DECISION belongs to
  ``rules_session_event.classify_repeat``; finding the pairs to ask about needs
  the batch.
* **Producer sequence** - monotonic per producer, which is a statement about
  the event before this one.
* **Lineage** - a child sits after the parent it names, which needs the parent.
* **A run names the bundle version it drew from** - ``run_names_its_bundle``,
  which needs the bundle version document.  This one arrived here by being
  REMOVED from the run's own rules: ``rules_run_attempt`` used to rebuild the
  producer's id from the line and the version and refuse anything spelled
  differently, which made the consumer the owner of the producer's id scheme.
  ``bundle-version.schema.json:29`` declares that id ``$ref: #/$defs/id`` -
  opaque - so a bundle its own contract called valid could not be named by any
  run.  A pure function of one run cannot resolve a bundle it cannot see; this
  module can, because its callers hold both documents.  No caller holds both
  YET, which is a real gap and is written down as one: RFC 0018 §6.1 marks
  ``run-names-what-it-was-drawn-from`` NOT WIRED rather than BUILT, and
  ``tests/test_cb_commitment_register.py`` measures the two against each other
  so neither can drift into flattering the other.
* **Adapter coverage** - ``adapter-coverage.schema.json`` has no ``x-cb-rules``
  and no ``rules_`` module, so this module is its sole owner rather than its
  second one.  The check is still a single-document check; it simply lives with
  the only implementation it has.  Its second argument is not a document but the
  closed observable VOCABULARY, which is the other thing a caller resolves and
  can therefore mis-resolve - see ``unresolved_second_argument``.

Two entry points here take a second argument the caller RESOLVED, and both can
be handed a resolver miss wearing the shape of an answer.  There is one function
that says whether that happened and one table of what each argument must be, and
what it asks is the CONTRACT - ``unresolved_second_argument``.  A predicate
spelled here instead is a second record of an identity a schema already pins,
and the first one written admitted a run as its own corroboration.

That one function answers the WHOLE question about the argument - shape,
membership, count, and whether the thing is still there to be read - and hands
back the materialised value it judged.  Splitting it left the same bug one level
down: the guard walked ``iter(OBSERVABLE_KINDS)``, found the closed list and said
resolved, and ``check_adapter_coverage`` then walked the exhausted iterator and
judged a valid record against a vocabulary of zero.  One reader, one reading, one
value everyone uses.

Everything else delegates.  A violation's ``rule`` says which: an id with
underscores (``case_admission_requires_completed_validation``) is an owner's
rule, named exactly as the schema names it in ``x-cb-rules``; a dotted id
(``evt.producer-sequence-is-monotonic``) is one of the three cross-document
rules above, owned here.

What no module can reach
------------------------
Several commitments in RFC 0018 §6.1 are **transactional**, not documentary:
they are facts about the service at the moment of a write, and a document can
only *claim* them.  They are deliberately NOT implemented anywhere, because a
check that re-reads a self-report and calls it verified is exactly the failure
these modules were written to end: tombstone fences, authorization lookup,
erasure and retention, plan freezing, the provenance of the three measurements,
and whether a conformance suite actually ran.

Nothing here reads a file, a clock, or a network, and nothing mutates its
argument.
"""

from __future__ import annotations

import importlib.util
import itertools
import sys
from collections.abc import Iterable, Iterator
from pathlib import Path
from typing import Any, NamedTuple


def _load(name: str) -> Any:
    """Load a sibling contract module once, by file, sharing one instance.

    ``contracts/cb`` is not a package - ``validate.py`` discovers these modules
    by location - so there is no package for a relative import to be relative
    to.  The ``sys.modules`` guard makes every consumer share ONE module object,
    which is what makes "one owner" true at runtime and not only on paper.
    """
    # ``cb_contract_<name>``: the key scheme ``primitives.load`` uses, and the
    # one ``validate.py`` uses.  "Which object is this module?" is a single
    # decision; a second key scheme executes a second copy, and two copies of
    # one rule module are two owners again - with the same source, so nothing
    # disagrees and nothing warns.
    key = f"cb_contract_{name}"
    if key not in sys.modules:
        path = Path(__file__).resolve().parent / f"{name}.py"
        spec = importlib.util.spec_from_file_location(key, path)
        if (
            spec is None or spec.loader is None
        ):  # pragma: no cover - unreachable for a real file
            raise ImportError(f"cannot load {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[key] = module  # before exec_module, so a re-entrant import sees it
        spec.loader.exec_module(module)
    return sys.modules[key]


primitives = _load("primitives")
case_rules = _load("rules_case_revision")
run_rules = _load("rules_run_attempt")
event_rules = _load("rules_session_event")
slice_rules = _load("rules_task_slice")
#: The schema checker, loaded under the same key scheme, so "is this document the
#: thing its contract describes?" has ONE implementation in this process.  This
#: module used to answer that question for itself wherever it needed it - see
#: :func:`unresolved_second_argument` for the one it got wrong.
validate = _load("validate")


def _contract(name: str) -> dict:
    """One contract schema, read from disk.

    Not cached, for the reason ``continuous-benchmark-server``'s
    ``contracts.schema`` gives: a schema is small, and a cached one is a second
    place the answer lives.  Read once per call, the file on disk is the only
    copy and a schema edit takes effect without a restart.
    """
    return validate.load(Path(__file__).resolve().parent / f"{name}.schema.json")


def _node(schema: dict, pointer: str) -> dict:
    """The sub-schema at a JSON pointer, or the whole schema for ``""``."""
    node: Any = schema
    for part in pointer.split("/"):
        if not part:
            continue
        node = node[part.replace("~1", "/").replace("~0", "~")]
    if not isinstance(node, dict):  # pragma: no cover - a pointer into a non-object
        raise KeyError(f"{pointer} does not name a schema object")
    return node


#: Where each two-argument entry point's SECOND argument is defined: the contract
#: that owns it, and a JSON pointer into that contract (``""`` = the whole
#: document).  Two entry points take a resolved second argument, and this is the
#: one table saying what each of them has to be.
BUNDLE_VERSION_CONTRACT = ("bundle-version", "")
OBSERVABLE_VOCABULARY_CONTRACT = (
    "adapter-coverage",
    "/properties/observables/items/properties/what",
)


class SecondArgument(NamedTuple):
    """One answer about a caller's resolved second argument, and the usable form of it.

    ``unresolved`` is why the argument cannot answer for the first one, or
    ``None`` when it can - the whole verdict, unchanged.

    ``value`` is the argument in a form an entry point may READ, and it is here
    because "is this usable?" and "here is the usable one" are the same answer.
    A one-shot iterable is read by whoever reaches it first and is empty for
    everyone after, so a guard that walks the caller's argument and hands back
    only a verdict leaves the entry point a second, EXHAUSTED walk to do.  That
    is not a second opinion about the contract, it is a second reading of the
    argument, and it produced the same class of defect: ``iter(OBSERVABLE_KINDS)``
    passed the guard - all eighteen kinds were there - and left
    ``check_adapter_coverage`` a vocabulary of none, so an empty coverage record
    was admitted and a valid one had all eighteen of its kinds reported as
    strangers to a closed list of zero.

    So materialisation happens ONCE, here, before anything reads the value, and
    every caller reads THIS rather than its own argument.  For a document the
    value is the document itself; for a closed vocabulary it is a tuple, which
    is re-iterable and whose ``len`` is the count the guard actually judged.
    """

    unresolved: str | None
    value: Any


def unresolved_second_argument(
    value: Any, contract: str, pointer: str = ""
) -> SecondArgument:
    """Why a caller's RESOLVED second argument cannot answer for the first - or ``None``.

    Two entry points here take a second argument the CALLER resolved:
    :func:`run_names_its_bundle` takes the bundle version a run claims to have
    drawn from, and :func:`check_adapter_coverage` takes the closed observable
    vocabulary.  Both then use that argument as an AUTHORITY over the first, so
    both have the same failure available: what came back cannot answer, every
    comparison is skipped, and the empty violation list that results is the same
    value a verified match produces.  A resolver miss read as agreement.

    So this is one question with one answer, asked once, by whichever entry point
    needs it -- and the answer comes from the CONTRACT, never from a predicate
    spelled here.  That distinction is the whole repair.  The first version of
    this guard asked a hand-written four-field predicate ("does it state any of
    ``bundle_line_id, version, bundle_version_id, membership_digest``?"), which
    is a copy of an identity ``bundle-version.schema.json`` already pins - and a
    copy that admitted three documents the contract refuses:

    * ``check_run_attempt(run, run["plan"]["bundle"])`` -- the run confirming
      ITSELF.  The four fields are there, so the predicate said yes; the block is
      15 errors away from being a bundle version.
    * ``{"schema_version": "cb.case_revision.v1", ...the four fields...}`` -- a
      case revision wearing four borrowed keys, 14 errors from being a bundle.
    * a real published bundle version -- indistinguishable from the other two.

    One shape of miss was refused and the others were not, which is not a guard,
    it is a narrower hole.  ``bundle-version.schema.json`` is what a bundle
    version IS; asking it is the only check that separates "this is the bundle"
    from "this is whatever the resolver returned", and it cannot narrow as the
    contract grows because it is not a second record of the contract.

    ``pointer`` is how the same function serves a vocabulary as well as a
    document.  A node carrying ``enum`` names a CLOSED list, and the second
    argument is then the caller's copy of that whole list rather than one member
    of it, so the contract's answer is set equality AND count: a vocabulary
    missing a member is exactly as unresolved as one carrying a stranger, and one
    that lists a member twice is nineteen entries where the contract closes
    eighteen - not the closed list either, and the count is what the rules below
    then report to a reader.  ``[]`` is the list-shaped resolver miss - it makes
    every kind "not declared", so nothing is absent, nothing is unknown, and a
    coverage record observing nothing passes.

    Being the closed list is not enough on its own; it has to still BE there when
    the caller reads it.  ``iter(OBSERVABLE_KINDS)`` is the closed list by every
    test above and is gone the moment those tests have run, so what this returns
    is a :class:`SecondArgument` - the verdict together with the materialised
    value the caller must use.  Shape, membership, count and re-iterability are
    one question about one argument, and one function answers all of it; a
    caller re-reading its own argument afterwards is the second reading this
    return type exists to remove.
    """
    schema = _contract(contract)
    node = _node(schema, pointer)
    where = f"{contract}.schema.json{pointer}"

    # A one-shot iterable is materialised HERE, before any check reads it, so
    # that no check - and no caller - is handed the exhausted remains of one.
    if isinstance(value, Iterator):
        value = tuple(value)

    closed = node.get("enum")
    if closed is not None:
        if isinstance(value, (str, bytes)) or not isinstance(value, Iterable):
            return SecondArgument(
                f"expected the closed vocabulary {where} declares, got {type(value).__name__}",
                value,
            )
        have = tuple(value)
        absent = [k for k in closed if k not in have]
        unknown = sorted({repr(k) for k in have if k not in closed})
        repeated = sorted({repr(k) for k in have if have.count(k) > 1})
        if not absent and not unknown and len(have) == len(closed):
            return SecondArgument(None, have)
        parts = []
        if absent:
            parts.append(f"does not declare {absent}")
        if unknown:
            parts.append(f"declares {', '.join(unknown)}, which {where} does not")
        if len(have) != len(closed):
            counted = (
                f"offers {len(have)} entries for the {len(closed)} kinds {where} closes"
            )
            parts.append(
                f"{counted}, repeating {', '.join(repeated)}" if repeated else counted
            )
        return SecondArgument(
            f"the vocabulary offered is not the closed list {where} declares: it "
            + " and ".join(parts),
            have,
        )

    errors = validate.validate(value, node, root=schema)
    if not errors:
        return SecondArgument(None, value)
    return SecondArgument(
        f"it fails {where} with {len(errors)} error{'' if len(errors) == 1 else 's'}, "
        f"the first being {errors[0]!r}",
        value,
    )


#: The closed observable vocabulary of ``contracts/cb/adapter-coverage.schema.json``
#: (``properties.observables.items.properties.what.enum``), spelled here so
#: ``check_adapter_coverage`` has a default to offer a caller that has not
#: resolved one.  It is not the authority: every call - this default included -
#: is checked against the schema's own enum by
#: :func:`unresolved_second_argument`, and ``tests/test_cb_semantics.py``
#: asserts the tuple still equals it, so drift fails the suite rather than
#: silently widening the rule.
OBSERVABLE_KINDS: tuple[str, ...] = (
    "user_message_text",
    "assistant_message_text",
    "assistant_reasoning",
    "tool_call_input",
    "tool_call_output",
    "tool_completion_status",
    "tool_exit_status",
    "attachments",
    "feedback_direction",
    "feedback_comment_text",
    "workspace_checkpoint",
    "working_tree_diff_at_turn_start",
    "working_tree_diff_at_turn_end",
    "token_usage",
    "turn_termination",
    "subagent_boundary",
    "session_end_instant",
    "task_latency",
)

#: Two rules below have NO row in the RFC 0018 6.1 register.  Their authority is
#: the contract text, cited here rather than given an invented commitment id ---
#: minting one would be the same move this module exists to stop.  Both deserve
#: a register row; adding one is the register owner's change, not this module's.
ADAPTER_EXHAUSTIVENESS = "contracts/cb/adapter-coverage.schema.json:5 (no register row)"
CONFORMANCE_IS_A_CLAIM = "intelligent-tools/docs/harness-support.md:8 (no register row)"

#: What a delegated violation says when its owner declared no commitment for the
#: rule.  Naming the owner is the honest answer; inventing a commitment id is
#: the move this module exists to stop.
UNDECLARED = "no commitment declared by the owning rule module"


class Violation(NamedTuple):
    """One refused rule.

    ``rule`` is the stable identifier a test asserts on.  An id with underscores
    is an owner's rule, spelled exactly as the schema spells it in
    ``x-cb-rules``, so a reader can go from a refusal to the one function that
    produced it; a dotted id is one of this module's own cross-document rules.

    ``commitment`` names the RFC 0018 §6.1 row the rule is holding up - read
    from the owning module's ``COMMITMENTS`` table, so the commitment a rule
    claims to hold up is declared next to the rule and not in a second table
    here - or, for the two rules the register has no row for, the contract text
    that states them, spelled ``repo/path:LINE``.

    ``path`` locates the offending document (``$`` for a single document,
    ``$[3]`` for the fourth event of a batch); ``detail`` says what was wrong in
    words, and for a delegated violation it is the owner's own message.
    """

    rule: str
    commitment: str
    path: str
    detail: str

    def __str__(self) -> str:  # pragma: no cover - a convenience for pytest output
        return f"{self.rule} at {self.path}: {self.detail} ({self.commitment})"


def rules_of(violations: Iterable[Violation]) -> set[str]:
    """The set of rule ids in a result, which is what a test usually asserts."""
    return {v.rule for v in violations}


def _delegate(owner: Any, document: Any, path: str = "$") -> list[Violation]:
    """Every rule the owning module declares, over one document.

    This is the whole of the delegation: the rules come from ``owner.RULES`` -
    the same mapping ``validate.py`` merges and the schema names in
    ``x-cb-rules`` - and the commitment from ``owner.COMMITMENTS``.  Adding a
    rule to an owner adds it here with no edit, and there is nowhere for a
    second opinion to live.
    """
    if not isinstance(document, dict):
        return [
            Violation(
                f"{owner.__name__}.not-a-document",
                UNDECLARED,
                path,
                f"expected an object, got {type(document).__name__}",
            )
        ]
    commitments = getattr(owner, "COMMITMENTS", {})
    out: list[Violation] = []
    for name, rule in owner.RULES.items():
        for message in rule(document):
            out.append(
                Violation(name, commitments.get(name, UNDECLARED), path, message)
            )
    return out


# ------------------------------------------------------------- case revision


def check_case_revision(doc: dict) -> list[Violation]:
    """Every rule ``contracts/cb/rules_case_revision.py`` owns, over one document.

    A case revision is settled by itself: its identity is a digest of its own
    covered fields, its evidence and approval name their own revision, its
    counters bound each other, and its admission gates read its own validation
    block.  None of that needs a second document, so none of it is decided here.

    This function used to decide all of it a second time, and refused an
    approved case whose reference check was recorded not-run and capped, which
    the owner admits.  See the module docstring for which answer won and why.
    """
    return _delegate(case_rules, doc)


# --------------------------------------------------------------- run attempt


#: The fields a run's ``plan.bundle`` block copies from the bundle version it
#: drew from.  Each is spelled the same on both documents, so the comparison is
#: a field-for-field one and there is no mapping table to drift.  ``version`` is
#: compared as a NUMBER (``primitives.as_integer``) rather than as a value:
#: ``1`` and ``1.0`` are one integer to this contract set, and a run spelling it
#: the second way names the same bundle version.
#:
#: This tuple is a COPY of a fact both schemas already state - it is exactly
#: ``run-attempt.schema.json``'s ``plan.bundle.required`` and a subset of
#: ``bundle-version.schema.json``'s root ``required``.  It is a copy because it
#: is a comparison ORDER, not an identity: what a bundle version IS is asked of
#: the contract (:func:`unresolved_second_argument`), and this says only which
#: of its fields the run repeats.  A copy with no guard is the defect this whole
#: pass is about, so it is guarded on three sides: ``tests/test_cb_semantics.py``
#: asserts the tuple against BOTH schemas, and
#: ``tests/test_cb_commitment_register.py`` asserts it against RFC 0018 §6.1's
#: owner field list for ``run-names-what-it-was-drawn-from``, which used to name
#: a different fourth field.  Drift on any side fails the suite instead of
#: silently narrowing the comparison.
BUNDLE_IDENTITY_FIELDS: tuple[str, ...] = (
    "bundle_line_id",
    "version",
    "bundle_version_id",
    "membership_digest",
)


def run_names_its_bundle(run: dict, bundle_version: dict) -> list[Violation]:
    """commitment run-names-what-it-was-drawn-from, over the two documents it needs.

    A result is a result ABOUT A CORPUS AT A VERSION, so the run copies four
    facts out of the bundle version it drew from: the line, the version, the
    version id and the membership digest.  The schema already says all four are
    present and non-null.  What no keyword can say - and what no pure function of
    the run can say either - is whether those four facts are the bundle's.

    Why this is not a rule on the run.  ``rules_run_attempt`` used to answer it
    by SYNTHESIZING the id it expected, ``f"bundlev_{line}_v{version}"``, and
    refusing every other spelling.  That is the consumer enforcing a rule that
    belongs to the producer, and enforcing a guess at it: ``bundle-version.
    schema.json:29`` declares ``bundle_version_id`` as ``$ref: #/$defs/id``, an
    opaque identifier, and RFC 0018 §6.1's ``run-names-what-it-was-drawn-from``
    row commits to the run naming ``membership_digest, bundle_line_id, version,
    library_revision`` and to no spelling at all.  The cost was concrete: a
    bundle published as ``bundle_version_opaque_123``, with an empty error list
    from its own contract, was unnameable by any run.

    The alternative was to make the derivation real on the producing schema.
    That is simpler, and it is wrong twice over: it mints a commitment the
    register does not carry, and it repairs a mishandled valid input by making
    that input unrepresentable.  Asking the bundle is what the consumer should
    have done in the first place, so the consumer asks.

    Stricter, not merely relocated: the old rule compared ONE synthesized string
    and could say nothing about ``membership_digest`` - a run could name the
    right line and version at the wrong membership and pass.  This compares all
    four, so a run that names a real bundle version while claiming a corpus it
    does not contain is refused too.

    Absence is not a refusal here, but a MIS-RESOLUTION is.  There are two
    different ignorances and they had the same answer, which is the defect this
    function was carrying:

    * the caller holds no bundle at all - it passes nothing, ``check_run_attempt``
      never reaches this function, and the four fields go unjudged.  That is the
      stated hole; see ``check_run_attempt``.
    * the caller DID resolve, and what came back cannot answer.  ``{}`` is the
      idiomatic dict-shaped resolver miss, a sqlite row for an absent bundle is
      also a dict, and neither is ``None``.  Every ``actual`` then read as
      ``None``, every field was skipped as "the schemas' report", and the empty
      list that came back was indistinguishable from a verified match - a run
      naming ``bundle_never_published`` at v99 "verified" against nothing.

    So the second argument has to answer for ITSELF before it may answer for the
    run, and what it answers to is ``bundle-version.schema.json`` -
    :func:`unresolved_second_argument`, which is also the guard
    :func:`check_adapter_coverage` asks.  The first version of this guard asked a
    hand-written "does it state any of the four fields?" predicate instead, and
    that predicate accepted the run's OWN ``plan.bundle`` block as the authority
    confirming the run: a document may not be its own corroboration, and nothing
    but the contract can say so, because the four fields are exactly what the run
    copied.

    Note which side of the comparison keeps its ``continue``.  A field the RUN
    does not state is still not this rule's business: ``run-attempt.schema.json``
    requires all four in ``plan.bundle``, so ``validate(run, schema)`` already
    refuses that document and a second refusal here would be the second owner
    this module exists to remove.  The asymmetry is the whole point - the run's
    silence has an owner, the bundle's silence had none.

    The BUNDLE's silence needs no case of its own any more.  All four identity
    fields are in ``bundle-version.schema.json``'s root ``required``
    (``tests/test_cb_semantics.py`` pins that), so a bundle version silent on any
    one of them never reaches the comparison: the contract refused it above, as
    a document that is not a bundle version rather than as a bundle version with
    a hole in it.  One refusal, from the owner, instead of two spellings of it.

    The alternative was to make ``check_run_attempt`` reject a falsy bundle
    argument.  That is the consumer guessing at what a resolver miss looks like
    (``{}``? ``[]``? a row with every column ``None``?), and it would still pass
    a half-populated row straight through to be read as agreement.  Asking the
    contract is the check that actually distinguishes "this is the bundle" from
    "this is whatever the resolver returned".
    """
    if not isinstance(run, dict) or not isinstance(bundle_version, dict):
        return [
            Violation(
                "run.names-the-bundle-version-it-drew-from",
                "run-names-what-it-was-drawn-from",
                "$.plan.bundle",
                "expected two objects, got "
                f"{type(run).__name__} and {type(bundle_version).__name__}",
            )
        ]

    named = run.get("plan")
    named = named.get("bundle") if isinstance(named, dict) else None

    # -- the resolved document answers for itself first ---------------------
    # Asked of `bundle-version.schema.json`, which owns what a bundle version is.
    # Before the run's own shape is looked at: a caller holding a malformed run
    # AND a resolver miss must not be told the pair agrees.
    resolved = unresolved_second_argument(bundle_version, *BUNDLE_VERSION_CONTRACT)
    if resolved.unresolved is not None:
        claimed_id = named.get("bundle_version_id") if isinstance(named, dict) else None
        return [
            Violation(
                "run.a-resolved-bundle-states-its-own-identity",
                "run-names-what-it-was-drawn-from",
                "$.plan.bundle",
                "the document offered as this run's bundle version is not a bundle "
                f"version: {resolved.unresolved}.  So it is a resolver miss and not an "
                f"authority, and the run's claim to have drawn from {claimed_id!r} is "
                "unverified, which is not the same fact as verified",
            )
        ]
    # The guard's value, not the argument: the checked thing and the read thing
    # are one thing.  Here they are the same object; in the vocabulary's case
    # they are not, and the rule is the same on both paths for that reason.
    bundle = resolved.value

    if not isinstance(named, dict):
        return []  # the run's own schema reports a missing or malformed plan.bundle

    out: list[Violation] = []
    for field in BUNDLE_IDENTITY_FIELDS:
        claimed, actual = named.get(field), bundle.get(field)
        if field == "version":
            claimed, actual = (
                primitives.as_integer(claimed),
                primitives.as_integer(actual),
            )
        if claimed is None:
            continue  # required by run-attempt.schema.json; validate(run, schema) owns it
        if claimed != actual:
            out.append(
                Violation(
                    "run.names-the-bundle-version-it-drew-from",
                    "run-names-what-it-was-drawn-from",
                    f"$.plan.bundle.{field}",
                    f"the run names {claimed!r}; bundle version "
                    f"{bundle.get('bundle_version_id')!r} carries {actual!r}, so the "
                    "run names a corpus that does not exist",
                )
            )
    return out


def check_run_attempt(doc: dict, bundle_version: dict | None = None) -> list[Violation]:
    """Every rule ``contracts/cb/rules_run_attempt.py`` owns, over one document.

    The plan, the attempts, the accounting and the three separated measurements
    are all members of the same record, so every question about them is settled
    by that record.  Two of those questions - the three measurements staying
    three, and a run naming the bundle version it drew from - had no owner among
    the schema-wired rules and lived only here, which meant
    ``validate(document, schema)`` did not refuse a document that broke them.
    The first is now a rule on the owner and named by the schema.

    The second came back, because it was never a question one document settles.
    Pass ``bundle_version`` - the published bundle version document the plan's
    ``plan.bundle`` block claims to have drawn from - and
    :func:`run_names_its_bundle` checks the claim against it.

    Omitting it is a REAL hole and is stated rather than hidden: with no bundle
    to ask, nothing here can tell a correct opaque id from an invented one, and
    this function says nothing about the four fields instead of inventing a
    spelling to test them against.  ``validate(run, schema)`` is silent for the
    same reason.  A caller that can resolve the reference - an ingest route, the
    server's run endpoint - is the caller that must pass it.  Today no such
    caller exists, which is why RFC 0018 §6.1 marks
    ``run-names-what-it-was-drawn-from`` NOT WIRED rather than BUILT, and why
    ``tests/test_cb_commitment_register.py`` measures that rather than trusting it.

    Passing a document is NOT the same as omitting one, and the difference is the
    whole of the ``bundle_version is not None`` test.  ``None`` means "I have no
    bundle"; ``{}`` means "I looked, and this is what I got back".  The second is
    a resolver miss wearing the shape of an answer, and it used to produce an
    empty violation list - the same value a verified match produces.  It now
    reaches :func:`run_names_its_bundle`, which refuses it.  Making the guard
    falsy instead (``if bundle_version:``) would have sent ``{}`` back down the
    silent path and re-hidden exactly this case.
    """
    out = _delegate(run_rules, doc)
    if bundle_version is not None:
        out += run_names_its_bundle(doc, bundle_version)
    return out


# ---------------------------------------------------------------- task slice


def check_task_slice(doc: dict) -> list[Violation]:
    """Every rule ``contracts/cb/rules_task_slice.py`` owns, over one document.

    A slice had no entry point here at all, which is why nothing in this module
    ever disagreed with its rules.  It has one now, for the same reason the
    other three do: one callable that answers "is this document admissible"
    without the caller having to know which module holds the answer.
    """
    return _delegate(slice_rules, doc)


# ------------------------------------------------------------ session events


def check_session_events(events: list) -> list[Violation]:
    """Every event's own rules, plus the three questions a batch settles.

    Per event, this delegates to ``contracts/cb/rules_session_event.py``: the
    canonical form, the digest, the turn and the instant against the consent
    interval.  That is where the instant comparison lives, and comparing
    instants rather than strings is the second of the three disagreements this
    pass resolved.

    What is added, and cannot be expressed against a single event:

    * a repeat of one identity is a retry or a conflict, decided by
      ``classify_repeat`` - which RECOMPUTES both digests rather than believing
      what either event declares, so a producer cannot buy idempotency by
      writing the digest it prefers;
    * a producer's sequence advances;
    * a child sits after the parent it names.

    Note what is no longer checked separately: that a retry repeats its
    immutable envelope.  The digest covers the whole immutable producer event,
    so a repeat that moved its sequence, parent or event time has a different
    digest and IS the conflict above.  Keeping a second rule for it meant
    keeping a second serializer to compare envelope fields with, and that
    serializer is where ``3`` versus ``3.0`` came apart.
    """
    if not isinstance(events, list):
        return [
            Violation(
                "evt.a-batch-is-an-array",
                UNDECLARED,
                "$",
                f"expected an array of events, got {type(events).__name__}",
            )
        ]

    out: list[Violation] = []
    for index, event in enumerate(events):
        out += _delegate(event_rules, event, f"$[{index}]")

    rows = [(index, e) for index, e in enumerate(events) if isinstance(e, dict)]

    # -- a repeated id is a retry only when the content is the same ---------
    first_seen: dict[tuple, tuple[int, dict]] = {}
    repeats: set[int] = set()
    for index, event in rows:
        key = event_rules.identity(event)
        if key not in first_seen:
            first_seen[key] = (index, event)
            continue
        repeats.add(index)
        earlier_index, earlier = first_seen[key]
        try:
            verdict = event_rules.classify_repeat(earlier, event)
        except (primitives.Uncanonical, ValueError):
            continue  # an event with no canonical form is refused per event, once
        if verdict == "conflict":
            out.append(
                Violation(
                    "evt.a-repeat-with-another-digest-is-a-conflict",
                    event_rules.COMMITMENTS[
                        "event-content-digest-covers-the-immutable-event"
                    ],
                    f"$[{index}].content_digest",
                    f"event id {event.get('event_id')!r} was already recorded at "
                    f"$[{earlier_index}]; the canonical content differs, so this is a "
                    "contradiction and not a retry - the digest, not arrival order, decides",
                )
            )

    # -- producer sequence is monotonic per producer ------------------------
    by_producer: dict[tuple, list[tuple[int, dict]]] = {}
    for index, event in rows:
        if index in repeats:
            continue  # a retry repeats its sequence by definition; judged above
        key = (event.get("org_id"), event.get("producer_id"))
        by_producer.setdefault(key, []).append((index, event))
    for key, items in by_producer.items():
        for (previous_index, previous), (index, event) in itertools.pairwise(items):
            before = primitives.as_integer(previous.get("producer_seq"))
            after = primitives.as_integer(event.get("producer_seq"))
            if before is not None and after is not None and after <= before:
                out.append(
                    Violation(
                        "evt.producer-sequence-is-monotonic",
                        "producer-sequence-and-relationships",
                        f"$[{index}].producer_seq",
                        f"producer {key[1]!r} recorded seq {after} after seq {before} at "
                        f"$[{previous_index}]; ordering comes from this number, never from "
                        "timestamps",
                    )
                )

    # -- a child follows the parent it names --------------------------------
    # The FIRST event carrying an identity is the record; a later repeat is a
    # retry or a conflict, judged above.  Resolving a parent to the repeat would
    # let a rewritten retry redefine where its own children sit.
    by_id: dict[tuple, dict] = {}
    for _, event in rows:
        by_id.setdefault(event_rules.identity(event), event)
    for index, event in rows:
        parent_id = event.get("parent_event_id")
        if not parent_id:
            continue
        parent = by_id.get((event.get("org_id"), event.get("producer_id"), parent_id))
        if parent is None:
            continue  # the parent is simply not in this batch, which is not a defect
        before = primitives.as_integer(parent.get("producer_seq"))
        after = primitives.as_integer(event.get("producer_seq"))
        if before is not None and after is not None and after <= before:
            out.append(
                Violation(
                    "evt.a-child-follows-the-parent-it-names",
                    "producer-sequence-and-relationships",
                    f"$[{index}].parent_event_id",
                    f"seq {after} does not follow its parent {parent_id!r} at seq {before}",
                )
            )

    return out


# --------------------------------------------------------- adapter coverage


def check_adapter_coverage(
    doc: dict, declared: Iterable[str] = OBSERVABLE_KINDS
) -> list[Violation]:
    """Rules an adapter coverage record must satisfy beyond its schema.

    Every declared observable appears exactly once; a duplicate entry is
    refused even when the array length is unchanged.

    ``adapter-coverage.schema.json`` carries no ``x-cb-rules`` and there is no
    ``rules_adapter_coverage.py``, so this function is the coverage record's
    only implementation rather than its second one.  That is the same rule this
    pass is applying everywhere - one owner per decision - and here the owner
    happens to be this module.  Wiring it into the schema the way the other four
    objects are wired is worth doing and is a schema change, not a rewrite of
    this function.

    ``declared`` is the other RESOLVED second argument in this module, and it had
    the same hole :func:`run_names_its_bundle` had, with no guard at all:
    ``check_adapter_coverage({"observables": []}, [])`` returned ``[]``.  Every
    kind is absent from an empty vocabulary and therefore not "declared", so
    nothing is missing, nothing is a stranger, and a record observing NOTHING
    reads as a record covering everything.  A caller that resolved the closed
    list and got nothing back gets the same answer as a caller that resolved it
    and got the list.  So the vocabulary answers for itself first, against the
    contract that closes it - one function, the same one the bundle version
    answers to; see :func:`unresolved_second_argument`.

    That guard then had one reading of the argument and this function had a
    second, and the two disagreed for exactly the reason two owners always do.
    ``declared`` is typed ``Iterable[str]``, so it may be one-shot: the guard
    walked ``iter(OBSERVABLE_KINDS)``, found the closed list and said resolved -
    and this function's own ``tuple(declared)`` then walked the exhausted
    remains and got ``()``.  A vocabulary of none absents nothing, so a record
    observing NOTHING was admitted again, and a VALID record had all eighteen of
    its kinds refused as strangers to a closed list of zero.  The materialised
    value now comes back from the guard together with the verdict, and nothing
    here reads ``declared`` a second time.
    """
    if not isinstance(doc, dict):
        return [
            Violation(
                "cov.a-coverage-record-is-an-object",
                ADAPTER_EXHAUSTIVENESS,
                "$",
                f"expected an object, got {type(doc).__name__}",
            )
        ]
    resolved = unresolved_second_argument(declared, *OBSERVABLE_VOCABULARY_CONTRACT)
    if resolved.unresolved is not None:
        return [
            Violation(
                "cov.the-declared-vocabulary-is-the-contracts-closed-list",
                ADAPTER_EXHAUSTIVENESS,
                "$.observables",
                f"{resolved.unresolved}.  Every rule below is stated RELATIVE to that list, "
                "so a vocabulary that is not it cannot judge this record: what it fails to "
                "declare, it also fails to miss",
            )
        ]
    out: list[Violation] = []
    # The guard's value, never ``declared`` again: ``declared`` may have been a
    # one-shot iterable, and the guard has already spent it.
    vocabulary = resolved.value
    rows = doc.get("observables")
    rows = (
        [row for row in rows if isinstance(row, dict)] if isinstance(rows, list) else []
    )
    listed = [row.get("what") for row in rows]

    duplicated = sorted(
        {k for k in listed if listed.count(k) > 1 and isinstance(k, str)}
    )
    if duplicated:
        out.append(
            Violation(
                "cov.every-observable-appears-exactly-once",
                ADAPTER_EXHAUSTIVENESS,
                "$.observables",
                f"{duplicated} listed more than once; the array length is not the check, "
                "one entry per kind is",
            )
        )
    absent = [k for k in vocabulary if k not in listed]
    if absent:
        out.append(
            Violation(
                "cov.every-declared-observable-is-present",
                ADAPTER_EXHAUSTIVENESS,
                "$.observables",
                f"{absent} absent; a kind missing from this list reads as an empty value "
                "rather than as an omission",
            )
        )
    unknown = sorted({str(k) for k in listed if k not in vocabulary})
    if unknown:
        out.append(
            Violation(
                "cov.no-observable-outside-the-closed-vocabulary",
                ADAPTER_EXHAUSTIVENESS,
                "$.observables",
                f"{unknown} is not one of the {len(vocabulary)} declared kinds",
            )
        )

    for index, row in enumerate(rows):
        path = f"$.observables[{index}]"
        if row.get("state") in ("not_observed", "partial"):
            if not str(row.get("reason") or "").strip():
                out.append(
                    Violation(
                        "cov.an-unobserved-kind-states-its-reason",
                        ADAPTER_EXHAUSTIVENESS,
                        f"{path}.reason",
                        f"{row.get('what')!r} is {row.get('state')!r} with no reason",
                    )
                )
            if not row.get("downstream_effect"):
                out.append(
                    Violation(
                        "cov.an-unobserved-kind-states-its-downstream-cost",
                        ADAPTER_EXHAUSTIVENESS,
                        f"{path}.downstream_effect",
                        f"{row.get('what')!r} is {row.get('state')!r} with no downstream_effect; "
                        "a refusal later must be traceable to a capability now",
                    )
                )

    conformance = doc.get("conformance")
    conformance = conformance if isinstance(conformance, dict) else {}
    passed = primitives.as_integer(conformance.get("checks_passed"))
    total = primitives.as_integer(conformance.get("checks_total"))
    if (
        conformance.get("state") == "verified"
        and passed is not None
        and total is not None
        and passed != total
    ):
        out.append(
            Violation(
                "cov.a-verified-claim-passed-every-check",
                CONFORMANCE_IS_A_CLAIM,
                "$.conformance",
                f"state 'verified' with {passed} of {total} checks passed; a row is a claim "
                "until the suite passes, and reverts to a claim when it fails",
            )
        )

    return out


CHECKS = {
    "case-revision": check_case_revision,
    "run-attempt": check_run_attempt,
    "task-slice": check_task_slice,
    "session-event": check_session_events,
    "adapter-coverage": check_adapter_coverage,
}
