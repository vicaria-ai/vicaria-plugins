"""Document-local semantic rules for ``item-label.schema.json``.

Membership in a taxonomy, complete assignment of that taxonomy, and whether a
superseded label is the current label all need stored state.  The invariants
below need only this candidate document, so they belong to the contract itself.
"""

from __future__ import annotations

from typing import Any


def rule_assignments_are_unambiguous(document: dict[str, Any]) -> list[str]:
    """One label cannot assign two values to the same dimension."""
    keys = [assignment["dimension_key"] for assignment in document["assignments"]]
    if len(keys) != len(set(keys)):
        return ["assignments: each dimension key must appear exactly once"]
    return []


def rule_provenance_is_consistent(document: dict[str, Any]) -> list[str]:
    """Initial assignments name no predecessor; corrections name another label."""
    provenance = document["provenance"]
    action = provenance["action"]
    supersedes = provenance["supersedes"]
    errors: list[str] = []
    if action == "assigned" and supersedes is not None:
        errors.append("provenance.supersedes: an initial assignment has no predecessor")
    if action == "corrected" and supersedes is None:
        errors.append("provenance.supersedes: a correction must name its predecessor")
    if supersedes == document["label_id"]:
        errors.append("provenance.supersedes: a label cannot supersede itself")
    return errors


RULES = {
    "item_label_assignments_are_unambiguous": rule_assignments_are_unambiguous,
    "item_label_provenance_is_consistent": rule_provenance_is_consistent,
}
