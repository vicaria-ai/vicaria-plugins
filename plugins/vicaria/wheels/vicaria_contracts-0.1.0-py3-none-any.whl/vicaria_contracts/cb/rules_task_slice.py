"""Cross-field rules for ``task-slice.schema.json``.

Every function here is a **pure function of a candidate document**: it takes any
dict and returns the reasons that document is inadmissible, empty meaning
admissible.  Nothing reads the checked-in example and nothing reads the
filesystem, so the function that lets the example through is the same function
that refuses a mutation of it.

That distinction is the finding this file answers.  ``tests/test_cb_contracts.py``
carried::

    before = slice_doc["workspace_state_at_cut"]["patch_digest"]
    after = slice_doc["reference_evidence"]["turn_diff_digest"]
    assert before and after and before != after

which refuses no document at all - it agrees with a good one.  The rules below
are named on the schema through ``x-cb-rules`` (see ``validate.py``), so
``validate(document, schema)`` is the refusal, and every rule has a document in
``tests/test_cb_rules_slice_and_run.py`` mutated to break exactly it.

Standard library only: the repository declares ``dependencies = []``
(pyproject.toml:15).

    python contracts/cb/validate.py \
        contracts/cb/examples/task-slice.example.json \
        contracts/cb/task-slice.schema.json
"""

from __future__ import annotations

import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path
from typing import Any


def _load_primitives() -> Any:
    """The one shared-semantics module, loaded once under a fixed name.

    ``contracts/cb`` is not a package - ``validate.py`` discovers these modules
    by file location - so there is no package for a relative import to be
    relative to.  The ``sys.modules`` guard is what makes every consumer share
    ONE module object, and therefore one set of predicates.
    """
    # The key ``primitives.load`` itself uses.  It is the SAME string in every
    # module that bootstraps this file, because "which object is primitives?"
    # is one decision: two keys execute two copies, and ``Uncanonical`` then
    # has two identities that no ``except`` clause can span.
    # tests/test_cb_primitives.py pins that there is exactly one.
    name = "cb_contract_primitives"
    if name not in sys.modules:
        path = Path(__file__).resolve().parent / "primitives.py"
        spec = importlib.util.spec_from_file_location(name, path)
        if (
            spec is None or spec.loader is None
        ):  # pragma: no cover - unreachable for a real file
            raise ImportError(f"cannot load the shared primitives from {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module  # before exec_module, so a re-entrant import sees it
        spec.loader.exec_module(module)
    return sys.modules[name]


primitives = _load_primitives()


def _hashable(value: Any) -> Any:
    """``value`` as something a ``set`` can hold.

    Event ids are strings in the schema, so this only matters for a document
    whose shape is already wrong - and it matters then.
    ``selected_event_ids[0] = []`` used to raise ``TypeError: unhashable type:
    'list'`` out of :func:`rule_selected_events_cover_what_the_slice_cites`,
    from a function whose advertised contract is to RETURN the reasons a
    document is inadmissible.  A checker that crashes at a malformed document
    has not refused it.
    """
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    try:
        return "json:" + primitives.canonical_json(value)
    except primitives.Uncanonical:
        return "repr:" + repr(value)


#: What each workspace kind must name, and what it may not name because that
#: kind reconstructed nothing of the sort.  The schema says this in keywords
#: too; saying it once more as data is what lets a positive fixture exist for
#: every kind rather than for the one kind the example happens to use.
WORKSPACE_KINDS: dict[str, tuple[tuple[str, ...], tuple[str, ...]]] = {
    "repo_at_commit": (
        ("remote", "commit"),
        ("patch_ref", "patch_digest", "human_written_note"),
    ),
    "repo_at_commit_with_patch": (
        ("remote", "commit", "patch_ref", "patch_digest"),
        ("human_written_note",),
    ),
    "operator_snapshot": (
        ("container_image",),
        ("patch_ref", "patch_digest", "human_written_note"),
    ),
    "human_written": (
        ("human_written_note",),
        ("remote", "commit", "patch_ref", "patch_digest"),
    ),
    "none": (
        (),
        (
            "remote",
            "commit",
            "patch_ref",
            "patch_digest",
            "container_image",
            "human_written_note",
        ),
    ),
}

#: The content a v2 slice seals.  The v1 shape predates an executable digest
#: rule and remains readable for compatibility; every v2 producer and consumer
#: shares this owner instead of maintaining a private copy of the field list.
SLICE_DIGEST_COVERS: tuple[str, ...] = (
    "selection",
    "cut",
    "selected_event_ids",
    "context_at_cut",
    "workspace_state_at_cut",
    "reference_evidence",
)


def covered_content(document: dict) -> dict:
    """The six v2 slice fields sealed by ``slice_digest``."""
    return {field: document.get(field) for field in SLICE_DIGEST_COVERS}


def _es_number(value: float) -> str:
    """Spell a finite double as ECMAScript Number-to-string does.

    RFC 8785 section 3.2.2.3 adopts that spelling: the shortest digits that
    round-trip, fixed notation from 1e-7 up to 1e21, exponent notation with a
    signed exponent and no leading zeros beyond it.  Python's repr already
    yields the shortest round-tripping digits; only the dressing differs, so
    the digits are taken from repr and re-dressed here.
    """
    if not math.isfinite(value):
        raise primitives.Uncanonical(f"{value!r} has no canonical JSON spelling")
    sign = "-" if value < 0 else ""
    mantissa, _, exponent_text = repr(abs(value)).lower().partition("e")
    exponent = int(exponent_text or 0)
    whole, _, fraction = mantissa.partition(".")
    digits = (whole + fraction).lstrip("0")
    if not digits.strip("0"):
        return "0"
    # value = 0.<digits> * 10**point, with the leading zeros of a fraction
    # such as 0.0012 folded into the exponent.
    if whole.strip("0"):
        point = len(whole) + exponent
    else:
        point = exponent - (len(fraction) - len(fraction.lstrip("0")))
    digits = digits.rstrip("0")
    count = len(digits)
    if count <= point <= 21:
        return sign + digits + "0" * (point - count)
    if 0 < point <= 21:
        return sign + digits[:point] + "." + digits[point:]
    if -6 < point <= 0:
        return sign + "0." + "0" * (-point) + digits
    exponent = point - 1
    head = digits[0] + ("." + digits[1:] if count > 1 else "")
    return f"{sign}{head}e{'+' if exponent >= 0 else '-'}{abs(exponent)}"


def slice_json(value: Any) -> str:
    """The v2 slice byte form: sorted keys, no whitespace, RFC 8785 numbers.

    Only :func:`slice_digest` uses it.  The case-revision digest keeps
    :func:`primitives.sorted_json`, which spells floats as Python does, and
    the run-attempt digest uses :func:`primitives.canonical_json`, the full
    RFC 8785 form; the slice digest publishes the sorted-key form with RFC
    8785 numbers, which is what this function produces.

    Identical to :func:`primitives.sorted_json` for everything but a
    non-integral number, which json.dumps would spell with Python's repr
    (``1e-07``) where the contract promises the ECMAScript spelling
    (``1e-7``).  Integral floats have already become integers by the time
    :func:`slice_digest` calls this.
    """
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        return _es_number(value)
    if isinstance(value, str):
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, list):
        return "[" + ",".join(slice_json(item) for item in value) + "]"
    if isinstance(value, dict):
        if any(not isinstance(key, str) for key in value):
            raise primitives.Uncanonical("object keys must be strings")
        members = (
            json.dumps(key, ensure_ascii=False) + ":" + slice_json(value[key])
            for key in sorted(value, key=lambda key: key.encode("utf-16-be"))
        )
        return "{" + ",".join(members) + "}"
    raise primitives.Uncanonical(f"{type(value).__name__} has no JSON form")


def slice_digest(document: dict) -> str:
    """Digest the covered content using the contract's published sorted form.

    JSON numbers that are equal stay equal: an exactly representable integral
    float is normalized to its integer spelling first, and every remaining
    number is spelled as RFC 8785 spells it, so two producers cannot digest
    one value two ways.  Unbounded JSON integers remain unbounded integers,
    which is why this form can name every count the task-slice schema admits.
    """
    normalized = primitives.normalize_integers(covered_content(document))
    digest = hashlib.sha256(slice_json(normalized).encode("utf-8")).hexdigest()
    return "sha256:" + digest


def _turn_indexes(document: dict) -> list[tuple[str, Any]]:
    """Every turn index the slice states, with the field that stated it."""
    found: list[tuple[str, Any]] = []
    cut = document.get("cut")
    if isinstance(cut, dict):
        found.append(("cut.turn_index", cut.get("turn_index")))
    context = document.get("context_at_cut")
    if isinstance(context, dict):
        for i, turn in enumerate(context.get("later_user_turns") or []):
            if isinstance(turn, dict):
                found.append(
                    (
                        f"context_at_cut.later_user_turns[{i}].turn_index",
                        turn.get("turn_index"),
                    )
                )
    for i, record in enumerate(document.get("success_evidence") or []):
        if not isinstance(record, dict):
            continue
        for field in ("turn_index", "anchor_turn_index"):
            if field in record:
                found.append((f"success_evidence[{i}].{field}", record.get(field)))
    return found


def rule_two_diffs_are_two_artifacts(document: dict) -> list[str]:
    """commitments two-diffs-two-jobs, two-diffs-digest-bound-separately.

    The state the behaviour began from and what the behaviour changed are two
    artifacts captured at two instants.  One end-of-turn diff cannot serve as
    both; a slice whose two digests are equal is refused one_diff_used_twice.
    """
    state = document.get("workspace_state_at_cut")
    evidence = document.get("reference_evidence")
    if not isinstance(state, dict) or not isinstance(evidence, dict):
        return []
    before, after = state.get("patch_digest"), evidence.get("turn_diff_digest")
    if before is not None and before == after:
        return [
            "workspace_state_at_cut.patch_digest and reference_evidence.turn_diff_digest are "
            f"the same artifact {before!r}; refusal one_diff_used_twice"
        ]
    return []


def rule_nothing_precedes_the_first_consented_turn(document: dict) -> list[str]:
    """commitments mark-is-not-retroactive, authorized-interval-bounds-derivatives.

    The mark is not retroactive, so no turn index anywhere on a derivative may be
    earlier than the first turn the authorization covers - not the cut, not a
    later user turn, not the turn a piece of success evidence is anchored to.
    """
    authorization = document.get("authorization")
    if not isinstance(authorization, dict):
        return []
    first = primitives.as_integer(authorization.get("first_consented_turn"))
    if first is None:
        return []
    return [
        f"{where}: turn {turn} precedes first_consented_turn {first}"
        for where, turn in (
            (where, primitives.as_integer(index))
            for where, index in _turn_indexes(document)
        )
        if turn is not None and turn < first
    ]


def rule_selected_events_cover_what_the_slice_cites(document: dict) -> list[str]:
    """commitment slice-records-which-events-it-selected.

    What a case claims to test is traceable to specific captured facts only if
    every event the slice cites is one of the events it says it selected.
    """
    selected = document.get("selected_event_ids")
    if not isinstance(selected, list):
        return []
    known = {_hashable(event) for event in selected}
    cited: list[tuple[str, Any]] = []
    cut = document.get("cut")
    if isinstance(cut, dict):
        cited.append(("cut.before_event_id", cut.get("before_event_id")))
    context = document.get("context_at_cut")
    if isinstance(context, dict):
        for i, event in enumerate(context.get("prefix_event_ids") or []):
            cited.append((f"context_at_cut.prefix_event_ids[{i}]", event))
    for i, record in enumerate(document.get("success_evidence") or []):
        if isinstance(record, dict) and record.get("source_event_id") is not None:
            cited.append(
                (
                    f"success_evidence[{i}].source_event_id",
                    record.get("source_event_id"),
                )
            )
    return [
        f"{where}: {event!r} is not in selected_event_ids"
        for where, event in cited
        if event is not None and _hashable(event) not in known
    ]


def rule_the_prefix_stops_at_the_cut(document: dict) -> list[str]:
    """commitment prefix-is-fixed-not-re-executed.

    The prefix is what the candidate is shown before the behaviour under test.
    An event at or after the cut is not context: it is the answer.
    """
    selected = document.get("selected_event_ids")
    cut = document.get("cut")
    context = document.get("context_at_cut")
    if not (
        isinstance(selected, list)
        and isinstance(cut, dict)
        and isinstance(context, dict)
    ):
        return []
    boundary = cut.get("before_event_id")
    if boundary not in selected:
        return []
    limit = selected.index(boundary)
    errors: list[str] = []
    for i, event in enumerate(context.get("prefix_event_ids") or []):
        if event == boundary:
            errors.append(
                f"context_at_cut.prefix_event_ids[{i}]: the cut event is not its own context"
            )
        elif event in selected and selected.index(event) > limit:
            errors.append(
                f"context_at_cut.prefix_event_ids[{i}]: {event!r} is after the cut at {boundary!r}"
            )
    return errors


def rule_workspace_kind_carries_its_reconstruction(document: dict) -> list[str]:
    """commitment reconstruction-fidelity-recorded.

    Fidelity is recorded at its real value and never smoothed, which means each
    kind names what it actually reconstructed from and nothing it did not.
    """
    state = document.get("workspace_state_at_cut")
    if not isinstance(state, dict):
        return []
    kind = state.get("kind")
    if kind not in WORKSPACE_KINDS:
        return []
    needed, forbidden = WORKSPACE_KINDS[kind]
    errors = [
        f"workspace_state_at_cut.{field}: a {kind} state must name it"
        for field in needed
        if state.get(field) in (None, "")
    ]
    errors += [
        f"workspace_state_at_cut.{field}: a {kind} state reconstructed nothing of the kind, "
        f"yet names {state.get(field)!r}"
        for field in forbidden
        if state.get(field) is not None
    ]
    if kind == "none" and state.get("may_enter_a_comparison") is not False:
        errors.append(
            "workspace_state_at_cut.may_enter_a_comparison: a state nobody could reconstruct "
            "stays as evidence of a cluster's shape and never enters a comparison"
        )
    return errors


def rule_reference_evidence_absence_is_never_a_pass(document: dict) -> list[str]:
    """commitments missing-reference-evidence-is-recorded-not-passed,
    no-end-state-evidence-is-not-a-pass.

    Where the evidence exists it is named and digested; where it does not, which
    of the two absences it was is named, and neither shape is ever a verdict.
    """
    evidence = document.get("reference_evidence")
    if not isinstance(evidence, dict):
        return []
    errors: list[str] = []
    if evidence.get("reads_as_pass") is not False:
        errors.append(
            "reference_evidence.reads_as_pass: reference evidence is never a verdict"
        )
    if evidence.get("present") is True:
        if not evidence.get("turn_diff_ref") or not evidence.get("turn_diff_digest"):
            errors.append(
                "reference_evidence: present, so the turn diff is named and digested"
            )
        if evidence.get("absence_reason") is not None:
            errors.append(
                "reference_evidence.absence_reason: present evidence has no absence to explain"
            )
    else:
        if not evidence.get("absence_reason"):
            errors.append(
                "reference_evidence.absence_reason: an absence is recorded, never left blank"
            )
        if evidence.get("turn_diff_digest") is not None:
            errors.append(
                "reference_evidence.turn_diff_digest: absent evidence has no digest"
            )
    return errors


def rule_human_correction_carries_its_provenance(document: dict) -> list[str]:
    """commitment human-edit-provenance-record.

    A human edit is permitted only WITH provenance: who, when, what it was, what
    it became, and a structured record of what changed.  An edit that leaves no
    such record is not an edit the system admits - and a record of a correction
    nobody made is the same defect from the other side.
    """
    correction = document.get("human_correction")
    if not isinstance(correction, dict):
        return []
    errors: list[str] = []
    changes = correction.get("change_record") or []
    original = correction.get("original_slice_digest")
    resulting = correction.get("resulting_slice_digest")
    if correction.get("corrected") is True:
        for field in (
            "corrected_by",
            "corrected_at",
            "original_slice_digest",
            "resulting_slice_digest",
        ):
            if correction.get(field) in (None, ""):
                errors.append(f"human_correction.{field}: a human edit records it")
        if not changes:
            errors.append(
                "human_correction.change_record: an edit with no structured record is not an edit"
            )
        if original is not None and original == resulting:
            errors.append(
                "human_correction: an edit that changed nothing is not an edit"
            )
        if resulting is not None and resulting != document.get("slice_digest"):
            errors.append(
                "human_correction.resulting_slice_digest: names a revision other than this one "
                f"({resulting!r} vs {document.get('slice_digest')!r})"
            )
    else:
        if changes:
            errors.append(
                "human_correction.change_record: changes recorded for a slice nobody corrected"
            )
        for field in (
            "original_slice_digest",
            "resulting_slice_digest",
            "corrected_by",
            "corrected_at",
        ):
            if correction.get(field) is not None:
                errors.append(
                    f"human_correction.{field}: set on a slice nobody corrected"
                )
    return errors


def rule_collection_selection_provenance_is_consistent(document: dict) -> list[str]:
    """The frozen selection names one admitted collection decision faithfully.

    Only a selected collection decision can produce a slice.  Its source and
    categorical reason travel together so an operator decision cannot become a
    developer decision on the derivative, or vice versa.
    """
    selection = document.get("selection")
    if not isinstance(selection, dict):
        return []
    expected = {
        "developer": "developer_worth_testing",
        "operator": "operator_selected",
    }
    source = selection.get("source")
    if source in expected and selection.get("collection_reason") != expected[source]:
        return [
            "selection.collection_reason: must agree with selection.source "
            f"({source!r} requires {expected[source]!r})"
        ]
    return []


def rule_slice_digest_covers_the_frozen_content(document: dict) -> list[str]:
    """A v2 selection or cut cannot move under an unchanged digest.

    Version 1 never published an executable digest derivation, so its stored
    documents remain readable as the legacy shape.  Version 2 publishes both
    the covered fields and the byte representation and refuses any stale
    declaration.
    """
    if document.get("schema_version") != "cb.task_slice.v2":
        return []
    declared = document.get("slice_digest")
    if not isinstance(declared, str):
        return []  # structural validation owns the type and pattern
    try:
        expected = slice_digest(document)
    except (primitives.Uncanonical, UnicodeEncodeError) as failure:
        return [f"slice content has no digestible form: {failure}"]
    if declared != expected:
        return [
            f"slice_digest {declared!r} is not the digest of the frozen "
            f"fields {list(SLICE_DIGEST_COVERS)!r}; that content digests to "
            f"{expected!r}"
        ]
    return []


#: Named on ``task-slice.schema.json``'s root through ``x-cb-rules``.
RULES = {
    "slice_two_diffs_are_two_artifacts": rule_two_diffs_are_two_artifacts,
    "slice_nothing_precedes_the_first_consented_turn": rule_nothing_precedes_the_first_consented_turn,
    "slice_selected_events_cover_what_the_slice_cites": rule_selected_events_cover_what_the_slice_cites,
    "slice_the_prefix_stops_at_the_cut": rule_the_prefix_stops_at_the_cut,
    "slice_workspace_kind_carries_its_reconstruction": rule_workspace_kind_carries_its_reconstruction,
    "slice_reference_evidence_absence_is_never_a_pass": rule_reference_evidence_absence_is_never_a_pass,
    "slice_human_correction_carries_its_provenance": rule_human_correction_carries_its_provenance,
    "slice_collection_selection_provenance_is_consistent": rule_collection_selection_provenance_is_consistent,
    "slice_digest_covers_the_frozen_content": rule_slice_digest_covers_the_frozen_content,
}

#: The RFC 0018 §6.1 row each rule holds up, declared beside the rule that holds
#: it, so no other module keeps a second table naming a different commitment.
COMMITMENTS = {
    "slice_two_diffs_are_two_artifacts": "two-diffs-two-jobs",
    "slice_nothing_precedes_the_first_consented_turn": "mark-is-not-retroactive",
    "slice_selected_events_cover_what_the_slice_cites": "slice-records-which-events-it-selected",
    "slice_the_prefix_stops_at_the_cut": "prefix-is-fixed-not-re-executed",
    "slice_workspace_kind_carries_its_reconstruction": "reconstruction-fidelity-recorded",
    "slice_reference_evidence_absence_is_never_a_pass": "missing-reference-evidence-is-recorded-not-passed",
    "slice_human_correction_carries_its_provenance": "human-edit-provenance-record",
    "slice_collection_selection_provenance_is_consistent": "provenance-edges-exist-for-the-walk",
    "slice_digest_covers_the_frozen_content": "edit-mints-new-revision",
}


def check(document: Any) -> list[str]:
    """Every cross-field rule, over an arbitrary document.  Empty means admissible."""
    if not isinstance(document, dict):
        return ["a task slice is an object"]
    errors: list[str] = []
    for name, rule in RULES.items():
        errors += [f"{name}: {message}" for message in rule(document)]
    return errors
