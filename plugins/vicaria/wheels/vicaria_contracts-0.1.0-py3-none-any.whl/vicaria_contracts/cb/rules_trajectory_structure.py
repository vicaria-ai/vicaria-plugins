"""Document-local graph rules for ``trajectory-structure.schema.json`` (structure.v1).

The schema judges one node or one edge at a time.  These rules judge how they
fit together: an edge's endpoints exist and have the types its kind allows, a
membership field and the edge that carries its evidence agree, and a
subagent's spawning call sits in the lane its own record names as its parent.
They need only the candidate document, so they belong to the contract and run
inside ``validate(document, schema)``: a document that passes validation is
graph-valid, not merely shaped right.
"""

from __future__ import annotations

from typing import Any

#: kind -> (allowed source node types, allowed target node types)
ENDPOINTS: dict[str, tuple[frozenset[str], frozenset[str]]] = {
    "issued": (frozenset({"response"}), frozenset({"call"})),
    "ran": (frozenset({"call"}), frozenset({"command"})),
    "spawned": (frozenset({"call"}), frozenset({"subagent"})),
    "messaged": (frozenset({"call"}), frozenset({"subagent"})),
    "returned": (frozenset({"subagent"}), frozenset({"call", "marker"})),
    "joined": (frozenset({"call"}), frozenset({"marker"})),
    "result_before_next_response": (frozenset({"call", "marker"}), frozenset({"response"})),
    "call_before_next_response": (frozenset({"call"}), frozenset({"response"})),
}
NEXT_RESPONSE = frozenset({"result_before_next_response", "call_before_next_response"})


def _nodes(document: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {n.get("id"): n for n in document.get("nodes", []) if isinstance(n, dict)}


def rule_nodes_are_placed(document: dict[str, Any]) -> list[str]:
    """Every node sits in a lane that exists and a turn of that lane; ids are unique."""
    errors: list[str] = []
    seen: set[str] = set()
    for n in document.get("nodes", []):
        if n.get("id") in seen:
            errors.append(f"nodes: duplicate id {n.get('id')!r}")
        seen.add(n.get("id"))
    nodes = _nodes(document)
    lanes = {"main"} | {i for i, n in nodes.items() if n.get("type") == "subagent"}
    collapsed = set((document.get("collapsed") or {}).get("lanes", []))
    for i, n in nodes.items():
        lane = n.get("agent")
        if lane not in lanes:
            errors.append(f"{i}: lane {lane!r} is neither main nor a subagent node")
        if n.get("type") == "subagent" and lane != i:
            errors.append(f"{i}: a subagent node heads its own lane (agent must equal id)")
        if n.get("type") != "subagent" and lane in collapsed:
            errors.append(f"{i}: lane {lane!r} is collapsed, so it keeps no nodes")
        turn = n.get("turn")
        if turn is not None:
            t = nodes.get(turn)
            if t is None or t.get("type") != "turn" or t.get("agent") != lane:
                errors.append(f"{i}: turn {turn!r} is not a turn in lane {lane!r}")
    return errors


def rule_edges_join_typed_nodes(document: dict[str, Any]) -> list[str]:
    """An edge's endpoints exist and have the types its kind allows."""
    errors: list[str] = []
    nodes = _nodes(document)
    for e in document.get("edges", []):
        kind, a, b = e.get("kind"), nodes.get(e.get("from")), nodes.get(e.get("to"))
        label = f"{kind} {e.get('from')} -> {e.get('to')}"
        if a is None or b is None:
            errors.append(f"{label}: endpoint missing")
            continue
        sources, targets = ENDPOINTS.get(kind, (frozenset(), frozenset()))
        if a.get("type") not in sources or b.get("type") not in targets:
            errors.append(f"{label}: {a.get('type')} -> {b.get('type')} is not allowed")
            continue
        if kind in NEXT_RESPONSE:
            if a.get("background") is True:
                errors.append(f"{label}: a background call returns through its completion, not the next response")
            if a.get("agent") != b.get("agent"):
                errors.append(f"{label}: crosses lanes")
            issuer = nodes.get(a.get("response")) if a.get("type") == "call" else None
            if issuer is not None and issuer.get("index", -1) >= b.get("index", -1):
                errors.append(f"{label}: target is not a later response")
    return errors


def rule_background_returns_agree(document: dict[str, Any]) -> list[str]:
    """A recorded join is a background call's completion, and only that.

    A ``joined`` edge leaves a background call and reaches the
    ``background_join`` marker that names it, and that marker is the call's
    ``completion``. A call with a completion is a background call with exactly
    that one joined edge. So a synchronous result, a capture stop, or a second
    notification cannot pass as the recorded return, and the edge and the call
    cannot pick different returns.
    """
    errors: list[str] = []
    nodes = _nodes(document)
    joins: dict[Any, list[Any]] = {}
    for e in document.get("edges", []):
        if e.get("kind") != "joined":
            continue
        src, dst = nodes.get(e.get("from")), nodes.get(e.get("to"))
        if src is None or dst is None or src.get("type") != "call" or dst.get("type") != "marker":
            continue  # rule_edges_join_typed_nodes reports it
        label = f"joined {e.get('from')} -> {e.get('to')}"
        joins.setdefault(e.get("from"), []).append(e.get("to"))
        if src.get("background") is not True:
            errors.append(f"{label}: only a background call has a recorded join")
        if dst.get("marker") != "background_join":
            errors.append(f"{label}: a join reaches a background_join marker, not {dst.get('marker')!r}")
        if dst.get("call") != e.get("from"):
            errors.append(f"{label}: the marker names another call")
        completion = src.get("completion")
        if not isinstance(completion, dict) or completion.get("marker") != e.get("to"):
            errors.append(f"{label}: the call's completion does not name this marker")
    notices: dict[Any, list[str]] = {}
    for i, n in nodes.items():
        if n.get("type") == "marker" and n.get("marker") == "background_join":
            notices.setdefault(n.get("call"), []).append(i)
    for call_id, markers in notices.items():
        if len(markers) > 1:
            errors.append(f"{call_id}: one completion notice per call, counted once; got {sorted(markers)}")
    for i, n in nodes.items():
        if n.get("type") == "marker" and n.get("marker") == "background_join":
            call = nodes.get(n.get("call"))
            if call is None or call.get("type") != "call" or call.get("background") is not True:
                errors.append(f"{i}: a background_join names {n.get('call')!r}, which is not a background call")
        if n.get("type") != "call" or not isinstance(n.get("completion"), dict):
            continue
        if n.get("background") is not True:
            errors.append(f"{i}: only a background call has a completion")
        if joins.get(i) != [n["completion"].get("marker")]:
            errors.append(f"{i}: joined edges {joins.get(i)} disagree with completion {n['completion'].get('marker')!r}")
    return errors


def rule_parents_form_a_tree(document: dict[str, Any]) -> list[str]:
    """Every known parent is a lane that exists, and the lanes form a tree rooted at main.

    Checked whether or not the spawning call is known: a subagent with a known
    parent and an unknown spawn still names a real lane, never a call, a
    missing lane or itself, and no chain of parents loops. A parent whose
    contents are unavailable is still a subagent node (a stub), not a dangling id.
    """
    errors: list[str] = []
    nodes = _nodes(document)
    lanes = {"main"} | {i for i, n in nodes.items() if n.get("type") == "subagent"}
    parent = {i: n.get("parent_agent") for i, n in nodes.items() if n.get("type") == "subagent"}
    for i, p in parent.items():
        if p is None:
            continue
        if p == i:
            errors.append(f"{i}: a subagent cannot be its own parent")
        elif p not in lanes:
            errors.append(f"{i}: parent {p!r} is neither main nor a subagent node")
    for start in parent:
        seen, at = {start}, parent.get(start)
        while at is not None and at != "main" and at in parent:
            if at in seen:
                errors.append(f"{start}: its parents loop back through {at!r}")
                break
            seen.add(at)
            at = parent.get(at)
    return errors


def rule_membership_matches_edges(document: dict[str, Any]) -> list[str]:
    """A membership field and the edge that carries its evidence say the same thing.

    A call names its response exactly when one issued edge comes from it; a
    command names its outer call exactly when one ran edge does; a subagent
    names its spawning call exactly when one spawned edge does, and that call
    sits in the lane the subagent's own record names as its parent.  A null
    membership has no edge: nothing is invented for it.
    """
    errors: list[str] = []
    nodes = _nodes(document)
    into: dict[tuple[str, Any], list[Any]] = {}
    for e in document.get("edges", []):
        into.setdefault((e.get("kind"), e.get("to")), []).append(e.get("from"))

    def check(i: str, kind: str, field: str, value: Any) -> None:
        want = [value] if value is not None else None
        got = into.get((kind, i))
        if got != want:
            errors.append(f"{i}: {kind} edges {got} disagree with {field} {value!r}")

    for i, n in nodes.items():
        t = n.get("type")
        if t == "call":
            check(i, "issued", "response", n.get("response"))
            r = nodes.get(n.get("response"))
            if r is not None and r.get("agent") != n.get("agent"):
                errors.append(f"{i}: its response is in another lane")
        elif t == "command":
            check(i, "ran", "outer_call", n.get("outer_call"))
        elif t == "subagent":
            check(i, "spawned", "spawned_by", n.get("spawned_by"))
            call = nodes.get(n.get("spawned_by"))
            parent = n.get("parent_agent")
            if call is not None and parent is not None and call.get("agent") != parent:
                errors.append(f"{i}: started by a call in lane {call.get('agent')!r}, but its parent is {parent!r}")
    return errors


RULES = {
    "trajectory_structure_nodes_are_placed": rule_nodes_are_placed,
    "trajectory_structure_edges_join_typed_nodes": rule_edges_join_typed_nodes,
    "trajectory_structure_membership_matches_edges": rule_membership_matches_edges,
    "trajectory_structure_background_returns_agree": rule_background_returns_agree,
    "trajectory_structure_parents_form_a_tree": rule_parents_form_a_tree,
}
