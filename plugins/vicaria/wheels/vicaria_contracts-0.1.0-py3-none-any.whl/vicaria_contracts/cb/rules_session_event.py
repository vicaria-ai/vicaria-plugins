"""Cross-field rules for ``session-event.schema.json``.

Every function here is a **pure function of one whole event** returning a list
of messages, empty when the event is admissible.  ``validate.py`` discovers this
module and runs the named rules wherever a schema carries ``x-cb-rules``, so
``validate(event, schema)`` is the single answer to "may this event be written",
and the ingest route will ask it with this function rather than a second copy
that drifts.  A test that reads the checked-in example and agrees with it
refuses nothing; each rule below is exercised on a valid event AND on an event
mutated to break exactly that rule, in ``tests/test_cb_session_event_rules.py``.

This module OWNS every question a single event settles: its canonical form, its
digest, whether a repeat of it is a retry or a conflict, and whether it sits
inside the authorization it names.  ``semantics.check_session_events`` calls
these functions rather than restating them, and adds only what needs several
events at once (see that module's docstring for the list).

The digest: what it covers and how the bytes are produced
--------------------------------------------------------
``content_digest`` decides whether a repeat of an ``event_id`` is a harmless
retry or a conflict to record (commitments ``content-digest-for-retry-conflict``
and ``events-append-only-idempotent-refusing``).  It therefore has to cover
everything a producer asserted that may never change, not just the payload.  A
payload-only digest lets two events share an identity, a session, a consent
interval and a digest while disagreeing about producer sequence, parent and
event time - contradictory ordering and lineage arriving as a "retry" and the
conflict quietly lost.

**Covered:** every member of the event except the two named below, including
``consent`` (the authorization this event rests on), ``adapter``,
``producer_seq``, ``parent_event_id``, ``correlation_id``, ``subagent_id``,
``turn_index``, ``recorded_omissions`` and ``payload``.

**Excluded, and only these two:**

* ``content_digest`` itself - a digest cannot cover itself.
* ``observed_at`` - transport metadata.  The COLLECTOR writes it, not the
  producer, and a genuine retry of the same event is observed at a different
  instant by construction.  Covering it would make every retry a conflict.

``event_time`` is *not* transport metadata: the producer asserts it, it is the
instant the fact happened, and two different values for it are two different
claims about the world.

**Canonical bytes** are RFC 8785 (JSON Canonicalization Scheme), implemented
once in ``contracts/cb/primitives.py`` and used unchanged here.  This module
chooses the SCOPE - which members the digest covers - and primitives produces
the BYTES.  Splitting it that way is the point of this pass: a second
serializer living next to this one is how ``producer_seq`` 3 and 3.0 came to be
one event on the single-event path and two on the batch path.

Two consequences of using the published canonicalization rather than an
ASCII-only stand-in:

* **Unicode keys are canonical, not refused.**  A tool call's ``input`` is an
  arbitrary JSON object; ``{"updates": {"用户数": 42}}`` is a structurally valid
  one that the schema admits.  RFC 8785 §3.2.3 orders members by their UTF-16
  code units and says nothing about ASCII, so such an event canonicalizes,
  digests and reseals.  The captured keys are written back exactly as they
  arrived - changing a key would change the evidence.
* **``3`` and ``3.0`` are one number.**  RFC 8785 §3.2.2.3 names the double, so
  a repeat that only rewrites the spelling of a number is a retry, and
  :func:`classify_repeat` and the batch path now say so together.

An event the canonical form cannot name at all - an integer past 2^53-1, a
non-finite float, an unpaired surrogate - is refused by
:func:`rule_canonical_form_is_reachable` rather than left to two services to
discover by disagreeing about the same bytes.
"""

from __future__ import annotations

import hashlib
import importlib.util
import re
import sys
from pathlib import Path
from typing import Any


def _load_primitives() -> Any:
    """The one shared-semantics module, loaded once under a fixed name.

    ``contracts/cb`` is not a package - ``validate.py`` discovers these modules
    by file location - so there is no package for a relative import to be
    relative to.  The ``sys.modules`` guard is what makes every consumer share
    ONE module object, and therefore one ``Uncanonical`` class and one set of
    predicates.
    """
    # The key ``primitives.load`` itself uses.  It is the SAME string in every
    # module that bootstraps this file, because "which object is primitives?"
    # is one decision: two keys execute two copies, and ``Uncanonical`` then
    # has two identities that no ``except`` clause can span.
    # tests/test_cb_primitives.py pins that there is exactly one.
    name = "cb_contract_primitives"
    if name not in sys.modules:
        path = Path(__file__).resolve().parent / "primitives.py"
        spec = importlib.util.spec_from_file_location(name, path)
        if (
            spec is None or spec.loader is None
        ):  # pragma: no cover - unreachable for a real file
            raise ImportError(f"cannot load the shared primitives from {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module  # before exec_module, so a re-entrant import sees it
        spec.loader.exec_module(module)
    return sys.modules[name]


primitives = _load_primitives()

SCHEMA_ID = "https://vicaria.ai/contracts/cb/session-event.schema.json"

#: The only two members the digest does not cover, and why (see the module
#: docstring).  Everything else a producer wrote is immutable and covered.
EXCLUDED_FROM_DIGEST = ("content_digest", "observed_at")

#: Beyond this an integer is not exactly a double, so RFC 8785 cannot name it.
MAX_EXACT_INTEGER = primitives.MAX_EXACT_INTEGER

#: Raised when a document holds a value no canonical form can name.  It is
#: ``primitives.Uncanonical`` itself, not a subclass: one class, so an
#: ``except`` here catches what a sibling module raised.
Uncanonical = primitives.Uncanonical


# ------------------------------------------------------------ canonical bytes


def digest_input(event: dict) -> dict:
    """The covered region: the event minus the two excluded members."""
    return {k: v for k, v in event.items() if k not in EXCLUDED_FROM_DIGEST}


def canonical_bytes(event: dict) -> bytes:
    """The exact bytes the digest is taken over: RFC 8785 over the covered region."""
    return primitives.canonical_bytes(digest_input(event))


def content_digest(event: dict) -> str:
    """The digest this event must carry."""
    return "sha256:" + hashlib.sha256(canonical_bytes(event)).hexdigest()


def identity(event: dict) -> tuple:
    """The idempotency key: org, producer, event id."""
    return (event.get("org_id"), event.get("producer_id"), event.get("event_id"))


def classify_repeat(existing: dict, incoming: dict) -> str:
    """``retry`` or ``conflict`` for two events sharing one identity.

    The commitment says the digest, not arrival order, decides.  This
    recomputes both digests rather than trusting what either event declares,
    so a producer cannot buy idempotency by writing the digest it prefers.

    This is the ONE implementation of the question.  ``semantics`` calls it for
    every repeat in a batch instead of comparing declared digests itself, which
    is what let the two paths answer differently.
    """
    if identity(existing) != identity(incoming):
        raise ValueError(
            "these two events do not share an identity; neither repeats the other"
        )
    return (
        "retry" if content_digest(existing) == content_digest(incoming) else "conflict"
    )


# -------------------------------------------------------------------- the rules


def rule_canonical_form_is_reachable(event: dict) -> list[str]:
    """An event the canonical form cannot name has no stable digest at all.

    Refused here rather than discovered later by two services disagreeing about
    the same bytes.  Note what this no longer refuses: a non-ASCII object key.
    RFC 8785 orders keys by UTF-16 code unit and canonicalizes them fine, and a
    captured tool argument is an arbitrary object, so refusing one was refusing
    a valid capture.
    """
    try:
        canonical_bytes(event)
    except Uncanonical as failure:
        return [f"no canonical form for this event: {failure}"]
    return []


def rule_content_digest_covers_the_immutable_event(event: dict) -> list[str]:
    """commitments content-digest-for-retry-conflict, events-append-only-idempotent-refusing.

    The digest covers the whole immutable producer event.  A digest computed
    over the payload alone lets two events that disagree about sequence, parent
    or event time present themselves as one retry.
    """
    try:
        expected = content_digest(event)
    except Uncanonical:
        return []  # rule_canonical_form_is_reachable reports this once
    declared = event.get("content_digest")
    if declared != expected:
        return [
            "content_digest does not cover this event: declared "
            f"{declared!r}, canonical over the immutable event {expected!r}"
        ]
    return []


#: The envelope's own turn, under the name :func:`turns` reports it by.  A
#: consumer that persists "the turn this event belongs to" wants THIS site and
#: not the anchor of a piece of feedback or the effective turn of a consent
#: change, and naming it here is how it asks for it without re-deriving where
#: the envelope keeps its turn.
ENVELOPE_TURN = "turn_index"


def turns(event: dict) -> list[tuple[str, Any]]:
    """Every turn number this event states, envelope and payload alike.

    Public, and the ONE answer to "which turns does this event claim?".  The
    question has four sites and only this module knows all four, because only
    this module knows the payload vocabulary: ``turn_index`` on the envelope,
    ``payload.turn_index`` on the shapes that carry one, the
    ``payload.effective_turn_index`` a ``consent.changed`` states, and the
    ``payload.anchor.turn_index`` a ``feedback.added`` is pinned to.  A payload
    may also state NO turn at all --- ``session.started`` and
    ``collection.stopped`` have no turn field in the schema --- and the empty
    list is that answer, not a missing one.

    It was private, and the continuous-benchmark server consequently grew a
    second, narrower reader beside it that knew two of the four sites and gated
    its whole consent check on the first one it found.  The cost was exact: a
    ``feedback.added`` anchored at turn 0 of a session marked at turn 5, and a
    ``session.started`` with no turn at all, were both stored by a server that
    had recorded no grant covering them --- capture outside the authorized
    interval, admitted because the consumer's reader could not see the turn the
    producer had written.  ``mark-is-not-retroactive`` is a promise about every
    turn an event states, so the list of those turns has to be one list.

    The alternative was to leave this private and let each consumer keep its
    own reader in step by hand.  That is what was tried; the two drifted the
    first time a payload shape gained a turn field, and nothing was red.

    Returns ``(where, turn)`` pairs, ``where`` being the dotted path, so a
    refusal can name the field it refused.  Values are returned AS WRITTEN ---
    ``primitives.as_integer`` is the caller's to apply, because a caller that
    wants to persist the number wants the producer's spelling and a caller that
    wants to compare it wants the integer.
    """
    found: list[tuple[str, Any]] = [(ENVELOPE_TURN, event.get("turn_index"))]
    payload = event.get("payload")
    if isinstance(payload, dict):
        found.append(("payload.turn_index", payload.get("turn_index")))
        found.append(
            ("payload.effective_turn_index", payload.get("effective_turn_index"))
        )
        anchor = payload.get("anchor")
        if isinstance(anchor, dict):
            found.append(("payload.anchor.turn_index", anchor.get("turn_index")))
    return [(where, turn) for where, turn in found if turn is not None]


def id_faults(value: Any, where: str = "id") -> list[str]:
    """What ``session-event.schema.json``'s ``$defs/id`` says about one bare id.

    Empty means the id is one this vocabulary admits.  The messages are the
    checker's own, so a consumer quotes the contract rather than paraphrasing
    it.

    Why a contract accessor and not three lines of ``re.match`` in each
    producer.  ``$defs/id`` is one decision --- ``minLength`` 1, ``maxLength``
    200, and a character class chosen so that *"No '/', so an id is a single
    path segment"* --- and it is already enforced on every id INSIDE a document,
    because the schema reaches it through ``$ref``.  What no document-level
    check can reach is an id arriving on its own: a session id in a POST body,
    a path parameter, a query string.  A producer that minted such an id
    without asking accepted ``""`` (routable nowhere, and unnameable afterwards
    by any consumer that tests a query parameter for truthiness),
    ``ses/../../etc/passwd`` (three path segments wearing one name), a
    five-thousand-character id, and ids carrying newlines and markup --- all of
    which the schema had already forbidden for the same id written inside an
    event.  Two answers to "what may an id be", differing only in which door
    the id came through.

    The cost of the alternative is what it was before: copying the pattern into
    the producer makes the producer a second owner, and the copy is invisible
    until the day the class changes here and does not change there.

    ``validate`` is loaded lazily, through ``primitives.load`` so it is the
    same module object every other caller holds.  It cannot be imported at
    module scope: ``validate`` discovers and executes every ``rules_*.py``
    beside it while it is itself still initialising, and this file is one of
    them.
    """
    validate = primitives.load("validate")
    root = validate.load(Path(__file__).resolve().parent / "session-event.schema.json")
    return validate.validate(value, root["$defs"]["id"], root, where)


def rule_turn_is_inside_the_authorized_interval(event: dict) -> list[str]:
    """commitments mark-is-not-retroactive, authorized-interval-bounds-derivatives.

    A mark covers the turn it was taken at and everything after it, never the
    turns already taken.

    Turn numbers are read with ``primitives.as_integer``, so a turn written
    ``0.0`` is the turn ``0`` and not a value this rule quietly skips: the
    schema admits both spellings under ``"type": "integer"``, and an
    ``isinstance(v, int)`` here was a consent gate a producer could walk past by
    writing a decimal point.
    """
    consent = event.get("consent")
    if not isinstance(consent, dict):
        return []
    first = primitives.as_integer(consent.get("first_consented_turn"))
    if first is None:
        return []
    errors = []
    interval = consent.get("authorized_interval_id")
    for where, stated in turns(event):
        turn = primitives.as_integer(stated)
        if turn is not None and turn < first:
            errors.append(
                f"{where} is turn {turn}, before turn {first}, the first turn interval "
                f"{interval!r} consented to"
            )
    return errors


def rule_envelope_and_payload_agree_on_the_turn(event: dict) -> list[str]:
    """One fact written twice may not disagree with itself.

    ``turn_index`` on the envelope and on the payload name the same turn; a
    projection that reads one and a check that reads the other would otherwise
    describe two different sessions.  ``0`` and ``0.0`` are the same turn, so
    they are compared as numbers rather than as Python objects.
    """
    payload = event.get("payload")
    if not isinstance(payload, dict):
        return []
    envelope, inner = event.get("turn_index"), payload.get("turn_index")
    if envelope is None or inner is None:
        return []
    outer_turn, inner_turn = (
        primitives.as_integer(envelope),
        primitives.as_integer(inner),
    )
    if outer_turn is not None and inner_turn is not None:
        if outer_turn != inner_turn:
            return [
                f"turn_index is {envelope} on the envelope and {inner} on the payload"
            ]
        return []
    if envelope != inner:
        return [f"turn_index is {envelope} on the envelope and {inner} on the payload"]
    return []


def rule_event_time_is_inside_the_authorized_interval(event: dict) -> list[str]:
    """commitment authorized-interval-bounds-derivatives.

    The named interval bounds the instant as well as the turn: an event falling
    in a gap between two intervals rests on no authorization at all.

    The comparison is of INSTANTS, through ``primitives.before``.
    ``2026-09-14T17:12:09+08:00`` and ``2026-09-14T09:12:09Z`` are one instant
    written two ways; comparing the strings - which the batch path used to do -
    puts them eight hours apart and refuses an event that is inside its
    interval.

    It is ``before`` and not ``<`` over two ``primitives.instant`` values, and
    that is the second half of the same repair.  The leap second is READ as the
    last instant of its own minute, and ``:59.999999`` is a timestamp a producer
    may also write, so the two share one datetime: an event at
    ``09:41:60Z`` against an interval that closed at ``09:41:59.999999Z`` is
    after the close and compares equal, and the bound this rule exists to hold
    admits it.  ``primitives.instant_key`` carries the leap second's
    displacement beside the datetime and ``before`` orders on it, so the bound
    asks the contract its question instead of re-deriving the answer from a
    value that cannot express it.

    Silence here is earned, not assumed
    -----------------------------------
    This rule used to open by parsing the three timestamps and returning ``[]``
    the moment one came back ``None``, over the comment "the ``format`` keyword
    reports an unreadable instant".  For a value that is not a date-time at all
    that is true.  For a value the ``date-time`` GRAMMAR accepts and the parser
    cannot read it was false - ``format`` had looked at it and been satisfied -
    and nothing anywhere reported it.  The consequence was a hole in the
    commitment this rule exists to hold: ``2016-12-31T23:59:60Z`` is a sealed,
    schema-valid leap-second event that cleared a consent interval which opened
    in September 2026, with an empty error list.

    So the two silences are now separated, once, in
    ``primitives.instant_faults``.  A value nothing can read is the contract's
    own bug and REFUSES the event; only a value ``format`` genuinely owns is
    passed over.  Had the alternative been taken - teaching this rule to parse
    leap seconds itself - the bound would have had one more owner and the same
    hole would still be open in every other rule that reads a timestamp.
    """
    consent = event.get("consent")
    if not isinstance(consent, dict):
        return []
    faults = primitives.instant_faults(
        {
            "event_time": event.get("event_time"),
            "consent.interval_start": consent.get("interval_start"),
            "consent.interval_end": consent.get("interval_end"),
        }
    )
    if faults:
        return faults
    # `is True` and not truthiness: `before` is three-valued, and its `None` -
    # "one of these is not a date-time at all" - is the one silence the `format`
    # keyword genuinely owns.  An unreadable-but-grammatical value never reaches
    # here; `instant_faults` above has already refused the event.
    when = event.get("event_time")
    interval = consent.get("authorized_interval_id")
    if primitives.before(when, consent.get("interval_start")) is True:
        return [
            f"event_time {event['event_time']} precedes interval {interval!r}, "
            f"which opened at {consent['interval_start']}"
        ]
    # An interval with no end is still open, and `before(None, when)` is `None`,
    # so the open interval bounds nothing on this side without a second branch
    # saying so.
    if primitives.before(consent.get("interval_end"), when) is True:
        return [
            f"event_time {event['event_time']} follows interval {interval!r}, "
            f"which closed at {consent['interval_end']}"
        ]
    return []


#: Where a substitution may be recorded: the captured text values.  A member
#: mapped to True is captured text all the way down (a structured tool input:
#: any string inside it, never a key; an output is always a string).  Nothing an identity, a consent
#: member or a protocol value lives in is here: a NUL there is not captured
#: text to deliver, and replacing it could make two different values one.
SUBSTITUTABLE: dict[tuple[str, ...], bool] = {
    ("payload", "text"): False,
    ("payload", "reasoning"): False,
    ("payload", "comment_text"): False,
    ("payload", "input"): True,
    ("payload", "output"): False,
    ("subagent_label",): False,
}

#: What a NUL in a captured text value is replaced by, and the one thing a
#: recorded substitution may mean.
NUL, REPLACEMENT = "\u0000", "\ufffd"


#: An RFC 6901 reference token (sec. 3): any character but ``~``, or ``~``
#: followed by ``0`` or ``1``.  Checked whole and decoded in one pass, so no
#: second spelling of a token survives (``~~01`` is not a token; a chained
#: replace read it as one, found in review, sanjay-eng, 2026-10-07).
POINTER_TOKEN = re.compile(r"(?:[^~]|~[01])*")
#: An array index (sec. 4): ASCII digits without a leading zero.  ``str.isdigit``
#: also took ``٠`` and ``０`` for 0, a second name for one element.
ARRAY_INDEX = re.compile(r"0|[1-9][0-9]*")


def pointer_tokens(pointer: Any) -> list[str] | None:
    """An RFC 6901 pointer's reference tokens, or None when it is not one.

    ``~1`` is ``/`` and ``~0`` is ``~``; a ``~`` followed by anything else is not
    a pointer.  The whole document (``""``) is never a substitution's target.
    An object key is any Unicode the event holds; only array indexes are ASCII.
    """
    if not isinstance(pointer, str) or not pointer.startswith("/"):
        return None
    tokens = []
    for raw in pointer[1:].split("/"):
        if not POINTER_TOKEN.fullmatch(raw):
            return None
        tokens.append(re.sub("~[01]", lambda m: "/" if m.group() == "~1" else "~", raw))
    return tokens


def _resolve(document: Any, tokens: list[str]) -> tuple[bool, Any]:
    """The value ``tokens`` name in ``document``, and whether they name one."""
    node = document
    for token in tokens:
        if isinstance(node, dict) and token in node:
            node = node[token]
        elif (
            isinstance(node, list)
            and ARRAY_INDEX.fullmatch(token)
            and int(token) < len(node)
        ):
            node = node[int(token)]
        else:
            return False, None
    return True, node


def rule_substitutions_name_captured_text(event: dict) -> list[str]:
    """commitment captured-text-substitutions-explicit.

    A NUL no store can hold is replaced by U+FFFD, and the event says where and
    how many: the value was recorded and these characters of it were changed,
    never silently.  Each pointer names one captured text value of this event
    (:data:`SUBSTITUTABLE`), at most once, in code-point order so the list has
    one form; the value is a string and holds at least ``count`` U+FFFD, the
    replacements it reports.  A pointer into an identity, a consent member, a
    protocol value or this list is refused: a substitution there could turn
    two different values into one (found in review, sanjay-eng, 2026-10-07).
    """
    substitutions = event.get("recorded_substitutions")
    if not isinstance(substitutions, list):
        return []  # absent, or a shape the schema already refuses
    errors: list[str] = []
    pointers = [
        entry.get("pointer") for entry in substitutions if isinstance(entry, dict)
    ]
    # One spelling per value: with tokens checked whole and indexes ASCII
    # (:data:`POINTER_TOKEN`, :data:`ARRAY_INDEX`), equal strings are equal targets.
    if len(set(map(str, pointers))) != len(pointers):
        errors.append("recorded_substitutions names one value more than once")
    if all(isinstance(pointer, str) for pointer in pointers) and pointers != sorted(
        pointers
    ):
        errors.append("recorded_substitutions is not ordered by pointer")
    for entry in substitutions:
        if not isinstance(entry, dict):
            continue
        pointer, count = entry.get("pointer"), entry.get("count")
        tokens = pointer_tokens(pointer)
        if tokens is None:
            errors.append(
                f"recorded_substitutions pointer {pointer!r} is not an RFC 6901 pointer"
            )
            continue
        root = tuple(tokens[:2]) if tokens[:1] == ["payload"] else tuple(tokens[:1])
        nested = SUBSTITUTABLE.get(root)
        if nested is None or (len(tokens) > len(root) and not nested):
            errors.append(
                f"recorded_substitutions pointer {pointer!r} names no captured text value"
            )
            continue
        found, value = _resolve(event, tokens)
        if not found or not isinstance(value, str):
            errors.append(
                f"recorded_substitutions pointer {pointer!r} names no string here"
            )
            continue
        if (
            isinstance(count, (int, float))
            and not isinstance(count, bool)
            and value.count(REPLACEMENT) < count
        ):
            errors.append(
                f"recorded_substitutions says {count} NULs were replaced at {pointer!r}, "
                f"but the value holds {value.count(REPLACEMENT)} U+FFFD"
            )
    return errors


#: The names ``session-event.schema.json`` refers to in its ``x-cb-rules``.
RULES = {
    "event-canonical-form-is-reachable": rule_canonical_form_is_reachable,
    "event-content-digest-covers-the-immutable-event": rule_content_digest_covers_the_immutable_event,
    "event-turn-is-inside-the-authorized-interval": rule_turn_is_inside_the_authorized_interval,
    "event-envelope-and-payload-agree-on-the-turn": rule_envelope_and_payload_agree_on_the_turn,
    "event-time-is-inside-the-authorized-interval": rule_event_time_is_inside_the_authorized_interval,
    "event-substitutions-name-captured-text": rule_substitutions_name_captured_text,
}

#: The RFC 0018 §6.1 row each rule holds up, declared beside the rule that holds
#: it.  ``semantics`` reads this to label a violation rather than keeping a
#: second table of its own that could name a different commitment.
COMMITMENTS = {
    "event-canonical-form-is-reachable": "content-digest-for-retry-conflict",
    "event-content-digest-covers-the-immutable-event": "content-digest-for-retry-conflict",
    "event-turn-is-inside-the-authorized-interval": "mark-is-not-retroactive",
    "event-envelope-and-payload-agree-on-the-turn": "mark-is-not-retroactive",
    "event-time-is-inside-the-authorized-interval": "authorized-interval-bounds-derivatives",
    "event-substitutions-name-captured-text": "captured-text-substitutions-explicit",
}


def check(document: Any) -> list[str]:
    """Every cross-field rule, over one arbitrary event.  Empty means admissible.

    ``validate(event, schema)`` reaches the same functions through
    ``x-cb-rules``; this is the direct entry point for a caller holding no
    schema, and the one ``semantics.check_session_events`` delegates to.
    """
    if not isinstance(document, dict):
        return ["a session event is an object"]
    errors: list[str] = []
    for name, rule in RULES.items():
        errors += [f"{name}: {message}" for message in rule(document)]
    return errors
