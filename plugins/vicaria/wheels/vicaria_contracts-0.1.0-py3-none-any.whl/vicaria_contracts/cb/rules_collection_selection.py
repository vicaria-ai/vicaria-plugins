"""Document-local semantic rules for ``collection-selection.schema.json``."""

from __future__ import annotations

from typing import Any


def rule_reason_is_consistent(document: dict[str, Any]) -> list[str]:
    """The categorical reason must agree with source, decision, and actor claim."""
    expected = {
        ("developer", True): "developer_worth_testing",
        ("developer", False): "developer_cleared",
        ("operator", True): "operator_selected",
        ("operator", False): "operator_excluded",
    }
    errors: list[str] = []
    if document["reason"] != expected[(document["source"], document["selected"])]:
        errors.append("reason: must agree with source and selected")
    if document["source"] == "operator" and document["actor_claim"] is None:
        errors.append("actor_claim: an operator selection must name its actor claim")
    if document["supersedes"] == document["selection_id"]:
        errors.append("supersedes: a selection cannot supersede itself")
    return errors


RULES = {
    "collection_selection_reason_is_consistent": rule_reason_is_consistent,
}
