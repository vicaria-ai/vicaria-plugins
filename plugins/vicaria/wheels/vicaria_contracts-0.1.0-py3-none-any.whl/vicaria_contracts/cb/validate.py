"""A small JSON Schema (draft 2020-12) validator, stdlib only.

This repository declares ``dependencies = []`` (pyproject.toml:15), so the
contracts under ``contracts/cb/`` cannot lean on ``jsonschema`` to become
executable.  They have to carry their own checker.  This is that checker: the
subset of the vocabulary the six contracts actually use, and nothing else.

Supported keywords
------------------
``$ref`` (local, ``#/...`` JSON pointers only), ``type``, ``enum``, ``const``,
``required``, ``properties``, ``additionalProperties`` (boolean or schema),
``minProperties``, ``maxProperties``, ``items``, ``prefixItems``, ``contains``,
``minItems``, ``maxItems``, ``uniqueItems``, ``minimum``, ``maximum``,
``exclusiveMinimum``, ``exclusiveMaximum``, ``multipleOf``, ``minLength``,
``maxLength``, ``pattern``, ``allOf``, ``anyOf``, ``oneOf``, ``not``,
``if``/``then``/``else``.

Every name on that list is enforced.  Five of them - ``exclusiveMinimum``,
``exclusiveMaximum``, ``multipleOf``, ``maxProperties`` and ``prefixItems`` -
sat on the allowlist with no implementation behind them until a review found
them: unused by today's six contracts, but a trap laid for the seventh, because
a schema could have written one and been told it held.  An allowlisted keyword
nobody implements is the same decoration as an unknown keyword, so they are
implemented here and probed in ``tests/test_cb_validate_keywords.py``.

``format`` is read and, for ``date-time``, checked; every other format value is
annotation only, which is what the specification says it is by default.
``date-time`` means the RFC 3339 §5.6 grammar, not whatever
``datetime.fromisoformat`` happens to parse: that function accepts
``2026-09-14`` with no time and ``2026-09-14T09:12:09`` with no timezone, and
these timestamps bound authorization intervals.  A local time is not an
instant, and an interval bounded by a non-instant does not bound anything.  The
grammar lives in ``contracts/cb/primitives.py`` with the parse and the
comparison that go with it, so this checker and every cross-field rule are
strict about the same strings.

``date-time`` also means an instant this system can READ, and not only one it
can spell.  Those came apart: RFC 3339 §5.6 allows a leap second, the grammar
accepted ``2016-12-31T23:59:60Z``, ``primitives.instant`` returned ``None``, and
the consent rule read that ``None`` as "the ``format`` keyword reported it" - so
a sealed December 2016 event satisfied a September 2026 authorized interval with
an empty error list.  A gate that admits what its own reader cannot read is a
hole, not a division of labour, so this keyword now asks for the instant the
rules will ask for.  ``primitives.unreadable_instant`` owns the question and
``primitives.instant_faults`` puts the same refusal in front of the rules, for
the callers (``semantics``, an ingest route, a test) that run them without a
schema.

An unknown keyword is an error rather than a silent pass.  A validator that
ignores what it does not understand turns a constraint into decoration, which
is the failure mode these contracts exist to avoid.

``pattern`` is ECMA-262, and Python's ``$`` is one character wider
-----------------------------------------------------------------
``pattern`` is not "a regular expression": draft 2020-12 §6.3.3 names a
DIALECT, ECMA-262.  Enforcement used ``re.search`` --- right, because a JSON
Schema pattern is unanchored by default --- against Python's dialect, and the
two disagree about one character.  Without the ``m`` flag ECMA-262's ``$``
matches only at the end of the input; Python's ``$`` matches there *and*
immediately before a final newline.  So ``^[A-Za-z0-9_.:@+,=~-]+$`` admitted
``"case_x\\n"`` and ``^sha256:[0-9a-f]{64}$`` admitted a digest with a newline
glued to it --- and those two patterns, at all twenty positions that write one,
are every id and every digest these contracts define.  ``$defs/id`` says
"Routable identifier.  No '/', so an id is a single path segment"; a newline in
an id is exactly what that sentence forbids, and it reached the store through
the shipped route (``POST /v1/sessions`` answered 201 for ``"ses_ok\\n"``).

The repair has to hold for an ARBITRARY pattern, because ``pattern`` takes
whatever a schema author writes.  No flag does it: Python has none that removes
the before-final-newline match, ``re.MULTILINE`` widens ``$`` further, and
``re.ASCII`` would narrow ``\\s`` and ``\\w`` BELOW ECMA-262 --- refusing strings
the dialect accepts, which is the worse failure.  So :func:`_ecma262_anchors`
translates the two anchors and nothing else: ``^`` becomes ``\\A`` and ``$``
becomes ``\\Z``, skipping escapes and character-class interiors, where both
characters are literals.  :func:`pattern_matches` is the one owner of the
question; it is where a second site (``patternProperties``, if this checker ever
grows it) must ask, rather than reaching for ``re.search`` again.

Equivalence is not claimed beyond the anchors.  ``.``, ``\\d``, ``\\w``, ``\\s``
and ``\\b`` keep Python's meanings, which are wider than ECMA-262's in places
(``.`` matches U+2028 and U+2029; ``\\d`` matches non-ASCII digits), and
ECMA-262 syntax Python has no spelling for (``[]``, ``[^]``) still raises out of
``re``.  No pattern in these contracts uses any of them, and the gap is
recorded in ``tests/test_cb_validate_keywords.py`` rather than papered over.

Numbers, and one meaning of "integer"
-------------------------------------
JSON has one number type: ``1`` and ``1.0`` are the same number, and
``"type": "integer"`` admits both.  This checker said so; the cross-field rules
said otherwise, testing ``isinstance(value, int)`` and skipping floats, so an
approved case with zero rebuilds and zero stability runs was refused when its
counters were ``0`` and admitted when they were ``0.0``.  The predicate now has
one owner --- ``primitives.is_integer`` --- which this file uses for
``"type": "integer"`` and every rule module uses in place of ``isinstance``.

Equality for ``const``, ``enum`` and ``uniqueItems`` is equality of JSON values
(draft 2020-12 §4.2.3: numbers are equal when they are mathematically equal),
so it is taken over ``primitives.canonical_json``.  Under the previous
``json.dumps`` comparison a ``const`` of ``1`` refused an instance of ``1.0``,
which is the same defect wearing a different keyword.

Two ways to keep that one meaning, and they are not alternatives.  The
predicate is the net: every gate asks ``primitives.is_integer``, which is what
closed this finding.  The boundary is the removal: ``load_document`` normalizes
integral floats to ``int`` as documents enter from JSON, so no gate downstream
ever meets ``0.0`` and the next comparison someone writes cannot reintroduce
the defect.  Normalization is the recommendation - it removes the class rather
than patching its instances - and ``check`` does **not** use it yet, for one
concrete reason spelled out at ``load_document``: ``revision_id`` is still
published against a second serialization that distinguishes ``0.0`` from ``0``.

And one meaning of "number": finite
-----------------------------------
``"type": "number"`` ended in ``isinstance(value, _TYPES["number"])``, and
``float('nan')`` is a float, so NaN, Infinity and -Infinity passed it.
``primitives.is_number`` had always refused them and ``primitives._number``
raises rather than spell one (RFC 8785 §3.2.2.3), so this was again two owners
of one decision answering opposite ways - and the gate was the one that said
yes.  Python's ``json.loads`` accepts those three literals by default, so they
arrive from a real request body; nothing downstream can write them back out.
The record was stored and then unreadable, 500 on the POST that wrote it and
500 on the GET that read it, where a 400 belonged.

The refusal is made at three doors because a number reaches this checker by
three routes, and any one of them alone leaves a hole:

* the **type check**, which now asks ``primitives.is_number`` - one owner;
* the **parse boundary**, ``load`` and ``load_document``, which give ``json``
  a ``parse_constant`` that raises, so a file cannot carry in a value the type
  check would refuse;
* the **document sweep** in ``validate``, ``primitives.non_finite_faults``,
  because a schema reaches a value only where it says something about it and
  these contracts say nothing at three positions - ``calibration`` and
  ``decision_rule.params`` are ``additionalProperties: true`` and
  ``evaluator_file_state.checks[].value`` is the empty schema.  A parsed body
  handed straight to ``validate()`` by an ingest route is refused there.

Cross-field rules: ``x-cb-rules``
---------------------------------
Some commitments are not sayable in JSON Schema keywords.  ``revision_id`` must
equal a sha256 taken over six named fields; ``agreements`` may not exceed
``runs``; a validation block must name the revision it was produced against.
Draft 2020-12 has no arithmetic, no hashing and no ``$data``, so a schema that
only used keywords would leave those commitments to a test that reads the
checked-in example and agrees with it - which refuses nothing.

``x-cb-rules`` is an array of rule names on any schema object.  Each name
resolves to a **pure function of the instance** returning a list of messages,
empty when the instance is admissible.  The functions live in sibling modules
named ``rules_<object>.py``; this module discovers and merges them at import, so
``validate(document, schema)`` alone refuses a document that breaks one.  A name
with no function behind it raises ``SchemaError`` rather than passing quietly,
for the same reason an unknown keyword does.

Order: structure first, and the checker never raises at a document
------------------------------------------------------------------
A cross-field rule is written against a document whose *shape* already holds:
``rule_selected_events_cover_what_the_slice_cites`` puts ids in a ``set``, and
``rule_attempt_bodies_match_the_plan`` calls ``.get`` on ``plan``.  Until this
pass, ``validate`` accumulated the schema errors and then ran the rules anyway,
so a structurally invalid document reached them: ``selected_event_ids[0] = []``
raised ``TypeError: unhashable type: 'list'`` and ``plan = "bad"`` raised
``AttributeError``, out of a function whose advertised contract is to *return*
its errors.  A checker that crashes at a malformed document does not refuse it;
it takes the caller down with it, and an ingest route that cannot refuse is
worse than one that refuses too much.

So there are two phases, in order:

1. **Structure.**  Every keyword above, over the whole document.  While walking,
   each ``x-cb-rules`` name is resolved --- a missing rule is a ``SchemaError``
   here, whatever the document looks like, so a structurally invalid document
   never *hides* a rule name with no function behind it.  The two faults stay
   distinct: an unresolvable ``$ref`` or an unknown keyword says the schema is
   missing something; ``no cross-field rule named`` says a rule is.
2. **Semantics.**  The collected rules run **only when phase 1 found nothing**.
   A rule may then assume what its schema already guaranteed.  Should one still
   raise, the exception is caught and reported as an error against that rule:
   a defect worth seeing loudly, but never an exception out of ``validate``.

``validate`` therefore never raises because of the *instance*.  ``SchemaError``
remains, and remains loud, for a fault in the *schema* argument --- an unknown
keyword, an unresolvable ``$ref``, a ``multipleOf`` that is not a positive
number, a rule name nobody implements.  A schema is code in this repository,
not input; ``tests/test_cb_validate_keywords.py:124`` and ``:140`` pin that it
stays loud.

One document against one schema::

    python contracts/cb/validate.py \
        contracts/cb/examples/case-revision.example.json \
        contracts/cb/case-revision.schema.json

Every schema, every example, and the commitments no keyword can hold::

    python -m pytest tests/test_cb_contracts.py
"""

from __future__ import annotations

import functools
import importlib.util
import json
import re
import sys
from collections.abc import Callable
from fractions import Fraction
from pathlib import Path
from typing import Any


def _load_primitives() -> Any:
    """Bootstrap ``primitives.py``, under the key ``primitives.load`` itself uses.

    ``contracts/cb`` is not a package and this file is routinely loaded by
    location (``tests/test_cb_contracts.py:35``), so there is no package for a
    relative import to be relative to.  ``primitives.load`` is the loader every
    sibling module then uses; this is the one bootstrap of the loader's own
    module, and it caches under exactly the same ``sys.modules`` key
    (``cb_contract_primitives``) so that ``primitives.load("primitives")``
    returns *this* object rather than executing a second copy.  One object
    matters: two copies would give ``Uncanonical`` two identities, and an
    ``except Uncanonical`` would stop catching what a sibling raised.
    """
    key = "cb_contract_primitives"
    existing = sys.modules.get(key)
    if existing is not None:
        return existing
    path = Path(__file__).resolve().parent / "primitives.py"
    spec = importlib.util.spec_from_file_location(key, path)
    if (
        spec is None or spec.loader is None
    ):  # pragma: no cover - unreachable for a real file
        raise SchemaError(f"cannot load the shared primitives from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module  # before exec_module, so a re-entrant load sees it
    try:
        spec.loader.exec_module(module)
    except BaseException:
        del sys.modules[key]
        raise
    return module


class SchemaError(Exception):
    """The schema itself is malformed or uses a keyword this checker refuses."""


primitives = _load_primitives()

_KNOWN = frozenset(
    {
        "$schema",
        "$id",
        "$defs",
        "$ref",
        "title",
        "description",
        "examples",
        "default",
        "type",
        "enum",
        "const",
        "required",
        "properties",
        "additionalProperties",
        "minProperties",
        "maxProperties",
        "items",
        "prefixItems",
        "contains",
        "minItems",
        "maxItems",
        "uniqueItems",
        "minimum",
        "maximum",
        "exclusiveMinimum",
        "exclusiveMaximum",
        "multipleOf",
        "minLength",
        "maxLength",
        "pattern",
        "format",
        "allOf",
        "anyOf",
        "oneOf",
        "not",
        "if",
        "then",
        "else",
        "x-cb-rules",
    }
)

_TYPES: dict[str, Any] = {
    "object": dict,
    "array": list,
    "string": str,
    "boolean": bool,
    "number": (int, float),
    "integer": int,
    "null": type(None),
}

#: name -> pure function of the instance, returning messages (empty == admissible).
RULES: dict[str, Callable[[Any], list[str]]] = {}


def _load_rule_modules() -> None:
    """Merge every sibling ``rules_<object>.py`` module's ``RULES`` mapping.

    Discovery rather than a hard-coded import list: one contract's cross-field
    rules arrive as one new file, and a contract with none adds nothing here.
    ``primitives`` is already in ``sys.modules`` by the time these execute, so a
    rule module that loads it the same way gets the same object.
    """
    for source in sorted(Path(__file__).resolve().parent.glob("rules_*.py")):
        # Through ``primitives.load``, which caches in ``sys.modules``.  Executing
        # the file here instead produced a SECOND copy of every rule module -
        # ``validate.RULES[name]`` and ``semantics``'s rule of the same name were
        # different function objects.  Identical source, so they never disagreed
        # and no test could see it; but "one owner" was true only on paper, and
        # the ``Uncanonical`` raised by one copy is not the one the other catches.
        try:
            module = primitives.load(source.stem)
        except ImportError as failure:  # pragma: no cover - unreachable for a real file
            raise SchemaError(
                f"cannot load cross-field rules from {source}: {failure}"
            ) from failure
        declared = getattr(module, "RULES", {})
        # A module may publish its rules as {name: function} or as a plain
        # sequence of functions, in which case each is keyed by its own name.
        if not isinstance(declared, dict):
            declared = {rule.__name__: rule for rule in declared}
        for name, rule in declared.items():
            if not callable(rule):
                raise SchemaError(
                    f"{source.name}: cross-field rule {name!r} is not callable"
                )
            if name in RULES and RULES[name] is not rule:
                raise SchemaError(f"two modules define the cross-field rule {name!r}")
            RULES[name] = rule


_load_rule_modules()


def _written_decimal(value: float) -> Fraction:
    """The decimal as written, not the binary double nearest to it.

    ``multipleOf`` over doubles is a trap: ``0.3 % 0.1`` is not zero in binary.
    Comparing the written decimals is what a reader of the schema means.
    """
    return Fraction(str(value))


def _type_ok(value: Any, name: str) -> bool:
    if name not in _TYPES:
        raise SchemaError(f"unknown type {name!r}")
    if name == "boolean":
        return isinstance(value, bool)
    if name in ("number", "integer") and isinstance(value, bool):
        return False  # a bool is not a number here, whatever Python thinks
    if name == "integer":
        return primitives.is_integer(value)  # one owner for "is this an integer"
    if name == "number":
        # ...and the same owner for "is this a number".  This line used to fall
        # through to `isinstance(value, float)`, which `float('nan')` satisfies,
        # so NaN and Infinity passed a gate `primitives.is_number` had always
        # refused and `primitives._number` could not serialize.
        return primitives.is_number(value)
    return isinstance(value, _TYPES[name])


def _resolve(root: dict, pointer: str) -> dict:
    if not pointer.startswith("#/"):
        raise SchemaError(f"only local JSON pointers are supported, got {pointer!r}")
    node: Any = root
    for raw in pointer[2:].split("/"):
        key = raw.replace("~1", "/").replace("~0", "~")
        if not isinstance(node, dict) or key not in node:
            raise SchemaError(f"unresolvable $ref {pointer!r}")
        node = node[key]
    if not isinstance(node, dict):
        raise SchemaError(f"$ref {pointer!r} does not name a schema")
    return node


def _equality_key(value: Any) -> str:
    """A key equal for equal JSON values, which is what ``const``/``enum`` mean.

    Draft 2020-12 §4.2.3: two numbers are equal when they are mathematically
    equal, however they are written, which is also what RFC 8785 says by giving
    ``1`` and ``1.0`` one spelling.  Scalars are keyed directly rather than
    through ``canonical_json`` because ``enum`` over strings is the hottest path
    in this checker and the canonical form's per-character escape loop cost 40%
    of a whole validation when it was asked to answer ``"a" == "b"``.  The
    prefixes keep the kinds apart: the string ``"true"`` keys as ``strue`` and
    never collides with the boolean.

    A value the canonical form cannot name --- an integer past 2^53, a
    non-finite float, an unpaired surrogate --- still has to be *comparable*,
    since ``const`` refuses it by not matching rather than by crashing, so
    containers fall back to a deterministic sorted dump.
    """
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, str):
        return "s" + value
    if isinstance(value, (int, float)):
        whole = primitives.as_integer(value)
        return "n" + (str(whole) if whole is not None else repr(float(value)))
    try:
        return "j" + primitives.canonical_json(value)
    except primitives.Uncanonical:
        return "r" + json.dumps(
            value, sort_keys=True, separators=(",", ":"), ensure_ascii=False
        )


def _ecma262_anchors(pattern: str) -> str:
    """Rewrite ``^`` to ``\\A`` and ``$`` to ``\\Z`` where they are anchors.

    The whole difference between the dialect the specification names and the one
    ``re`` implements, for these two characters: ECMA-262 without the ``m`` flag
    anchors at the ends of the INPUT, and a schema ``pattern`` is compiled
    without flags, so that is always the meaning it has.  Python's ``^`` already
    matches only at the start of the string; its ``$`` also matches immediately
    before a final newline, which is the hole.  Both are translated, so the
    anchors keep this meaning even if a pattern turns Python's ``MULTILINE`` on
    inline --- ``(?m)`` is not ECMA-262 syntax at all, so no ECMA-262 pattern
    loses a match it should have had.

    Only outside a character class and only unescaped: ``[$]``, ``[^a-z]`` and
    ``\\$`` all spell literals, and rewriting one of those would refuse a string
    the dialect accepts.  A ``]`` in the first position of a class is a member
    rather than the close (``[]]`` is the class of ``]``, Python and POSIX), so
    the scan tracks that position.

    The scan is deliberately naive about one thing: a ``[`` inside a ``(?#...)``
    comment or a verbose-mode ``#`` comment puts it in class state early, and the
    anchors after it are then left as Python wrote them.  That is the direction
    the error has to fall --- an untranslated anchor is the behaviour of every
    release before this one, while a stray translation would refuse a valid
    string.  No such pattern exists in these contracts.
    """
    out: list[str] = []
    index = 0
    in_class = False
    first_in_class = -1  # where a ``]`` is still a member and not the close
    while index < len(pattern):
        char = pattern[index]
        if char == "\\":
            out.append(pattern[index : index + 2])  # an escape, whatever it escapes
            index += 2
            continue
        if in_class:
            if char == "]" and index != first_in_class:
                in_class = False
            out.append(char)
        elif char == "[":
            in_class = True
            first_in_class = index + (2 if pattern[index + 1 : index + 2] == "^" else 1)
            out.append(char)
        elif char == "^":
            out.append("\\A")
        elif char == "$":
            out.append("\\Z")
        else:
            out.append(char)
        index += 1
    return "".join(out)


@functools.lru_cache(maxsize=512)
def _ecma262_compiled(pattern: str) -> re.Pattern[str]:
    """The translated pattern, compiled once.  Bounded: patterns come from
    schemas, which are code here, but a cache with no ceiling in front of a
    keyword that reads a *document* is a leak waiting for the day they do not.
    An invalid pattern still raises ``re.error``, as it did before: a schema
    fault, loud, and not something an instance can cause."""
    return re.compile(_ecma262_anchors(pattern))


def pattern_matches(pattern: str, text: str) -> bool:
    """Does ``text`` satisfy the schema ``pattern``?  One owner of the question.

    ``search``, not ``fullmatch``: a JSON Schema pattern is unanchored unless it
    says otherwise (draft 2020-12 §6.3.3), and a pattern that says otherwise now
    means it.
    """
    return _ecma262_compiled(pattern).search(text) is not None


#: One collected cross-field rule application: where, over what, by which rule.
_Site = tuple[str, dict, str]


def _check(
    instance: Any, schema: dict, root: dict, path: str, sites: list[_Site]
) -> list[str]:
    """Phase 1: structure only.  Rule *names* are resolved, rules are not run.

    Every ``x-cb-rules`` name reached by an applicator that actually applies is
    appended to ``sites``; :func:`validate` runs them afterwards, and only if
    this phase returned nothing.
    """
    errors: list[str] = []

    if not isinstance(schema, dict):
        raise SchemaError(
            f"{path}: schema must be an object, got {type(schema).__name__}"
        )

    unknown = set(schema) - _KNOWN
    if unknown:
        raise SchemaError(f"{path}: unsupported keyword(s) {sorted(unknown)}")

    if "$ref" in schema:
        errors += _check(instance, _resolve(root, schema["$ref"]), root, path, sites)

    if "type" in schema:
        names = schema["type"]
        names = [names] if isinstance(names, str) else names
        if not any(_type_ok(instance, n) for n in names):
            errors.append(
                f"{path}: expected type {names}, got {type(instance).__name__}"
            )

    if "const" in schema and _equality_key(instance) != _equality_key(schema["const"]):
        errors.append(f"{path}: must equal {schema['const']!r}, got {instance!r}")

    if "enum" in schema and not any(
        _equality_key(instance) == _equality_key(choice) for choice in schema["enum"]
    ):
        errors.append(f"{path}: {instance!r} not one of {schema['enum']!r}")

    if isinstance(instance, str):
        if "minLength" in schema and len(instance) < schema["minLength"]:
            errors.append(f"{path}: shorter than minLength {schema['minLength']}")
        if "maxLength" in schema and len(instance) > schema["maxLength"]:
            errors.append(f"{path}: longer than maxLength {schema['maxLength']}")
        if "pattern" in schema and not pattern_matches(schema["pattern"], instance):
            errors.append(f"{path}: {instance!r} does not match {schema['pattern']!r}")
        if schema.get("format") == "date-time":
            # Two refusals, because they are two different facts and the rules
            # downstream act on the difference.  "Not a date-time" is this
            # keyword's own; a date-time the shared parser cannot READ is a
            # disagreement between the grammar and the reader, which used to be
            # reported by nobody - `format` was satisfied, and every rule read
            # the resulting `None` as "already reported" and returned no errors.
            # Catching it in this phase means a structurally valid document can
            # no longer carry one into a rule at all; primitives.instant_faults
            # is the same refusal for the callers that run rules without a
            # schema.  One question, one predicate, asked at both doors.
            if not primitives.is_rfc3339(instance):
                errors.append(f"{path}: {instance!r} is not an RFC 3339 date-time")
            else:
                unreadable = primitives.unreadable_instant(instance)
                if unreadable is not None:
                    errors.append(f"{path}: {unreadable}")

    if primitives.is_number(instance):
        # The same owner decides whether the number keywords apply at all.  Spelled
        # `isinstance(instance, (int, float))` this admitted a non-finite float,
        # and `multipleOf` then handed it to `Fraction(str(value))`, which raises
        # `ValueError: Invalid literal` - an exception out of a function whose
        # advertised contract is to RETURN its errors.  `validate` refuses
        # non-finite numbers before this walk, so no verdict moves; what moves is
        # that this block can no longer be reached by a value it cannot compare.
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append(f"{path}: {instance} below minimum {schema['minimum']}")
        if "maximum" in schema and instance > schema["maximum"]:
            errors.append(f"{path}: {instance} above maximum {schema['maximum']}")
        if "exclusiveMinimum" in schema and instance <= schema["exclusiveMinimum"]:
            errors.append(
                f"{path}: {instance} not above exclusiveMinimum {schema['exclusiveMinimum']}"
            )
        if "exclusiveMaximum" in schema and instance >= schema["exclusiveMaximum"]:
            errors.append(
                f"{path}: {instance} not below exclusiveMaximum {schema['exclusiveMaximum']}"
            )
        if "multipleOf" in schema:
            divisor = schema["multipleOf"]
            if (
                isinstance(divisor, bool)
                or not isinstance(divisor, (int, float))
                or divisor <= 0
            ):
                raise SchemaError(f"{path}: multipleOf must be a positive number")
            if _written_decimal(instance) % _written_decimal(divisor) != 0:
                errors.append(f"{path}: {instance} is not a multiple of {divisor}")

    if isinstance(instance, list):
        if "minItems" in schema and len(instance) < schema["minItems"]:
            errors.append(
                f"{path}: {len(instance)} items, minItems {schema['minItems']}"
            )
        if "maxItems" in schema and len(instance) > schema["maxItems"]:
            errors.append(
                f"{path}: {len(instance)} items, maxItems {schema['maxItems']}"
            )
        if schema.get("uniqueItems"):
            seen = [_equality_key(item) for item in instance]
            if len(set(seen)) != len(seen):
                errors.append(f"{path}: duplicate items")
        first_unprefixed = 0
        if "prefixItems" in schema:
            prefix = schema["prefixItems"]
            if not isinstance(prefix, list):
                raise SchemaError(f"{path}: prefixItems must be an array of schemas")
            for i, sub in enumerate(prefix[: len(instance)]):
                errors += _check(instance[i], sub, root, f"{path}[{i}]", sites)
            first_unprefixed = len(prefix)
        if "items" in schema:
            # Draft 2020-12: `items` applies to what `prefixItems` did not reach.
            for i in range(first_unprefixed, len(instance)):
                errors += _check(
                    instance[i], schema["items"], root, f"{path}[{i}]", sites
                )
        if "contains" in schema:
            # A probe, not an application: `contains` asks whether some item
            # matches, so nothing it touches contributes rules.
            hits = sum(
                1
                for item in instance
                if not _check(item, schema["contains"], root, path, [])
            )
            if hits == 0:
                errors.append(f"{path}: no item satisfies `contains`")

    if isinstance(instance, dict):
        for key in schema.get("required", []):
            if key not in instance:
                errors.append(f"{path}: missing required property {key!r}")
        if "minProperties" in schema and len(instance) < schema["minProperties"]:
            errors.append(f"{path}: fewer than minProperties {schema['minProperties']}")
        if "maxProperties" in schema and len(instance) > schema["maxProperties"]:
            errors.append(f"{path}: more than maxProperties {schema['maxProperties']}")
        props = schema.get("properties", {})
        for key, sub in props.items():
            if key in instance:
                errors += _check(instance[key], sub, root, f"{path}.{key}", sites)
        if "additionalProperties" in schema:
            extra = [k for k in instance if k not in props]
            ap = schema["additionalProperties"]
            if ap is False:
                for k in extra:
                    errors.append(f"{path}: additional property {k!r} is not allowed")
            elif isinstance(ap, dict):
                for k in extra:
                    errors += _check(instance[k], ap, root, f"{path}.{k}", sites)

    for name in schema.get("x-cb-rules", []):
        # Resolved during the structural walk, whatever the document looks like:
        # a rule nobody implements must not be able to hide behind a malformed
        # document.  A missing rule and a missing schema stay distinct faults.
        if name not in RULES:
            raise SchemaError(f"{path}: no cross-field rule named {name!r}")
        if isinstance(instance, dict):
            sites.append((path, instance, name))

    for sub in schema.get("allOf", []):
        errors += _check(instance, sub, root, path, sites)

    if "anyOf" in schema:
        matched = False
        for sub in schema["anyOf"]:
            branch: list[_Site] = []
            if not _check(instance, sub, root, path, branch):
                matched = True
                sites += branch  # a branch that applies contributes its rules
        if not matched:
            errors.append(f"{path}: matches none of anyOf")

    if "oneOf" in schema:
        hits: list[int] = []
        kept: list[_Site] = []
        for i, sub in enumerate(schema["oneOf"]):
            branch = []
            if not _check(instance, sub, root, path, branch):
                hits.append(i)
                kept = branch
        if len(hits) != 1:
            detail = "none" if not hits else f"{len(hits)} branches {hits}"
            errors.append(f"{path}: oneOf matched {detail}")
        else:
            sites += kept

    if "not" in schema and not _check(instance, schema["not"], root, path, []):
        errors.append(f"{path}: must not match the `not` schema")

    if "if" in schema:
        # The `if` branch is a predicate; only the branch it selects applies.
        if _check(instance, schema["if"], root, path, []):
            if "else" in schema:
                errors += _check(instance, schema["else"], root, path, sites)
        elif "then" in schema:
            errors += _check(instance, schema["then"], root, path, sites)

    return errors


def validate(
    instance: Any, schema: dict, root: dict | None = None, path: str = "$"
) -> list[str]:
    """Return a list of human-readable errors.  Empty means valid.

    Structure first; the cross-field rules only on a document whose structure
    already holds.  Never raises because of ``instance`` --- see the module
    docstring for why, and for the one thing that still raises.
    """
    root = schema if root is None else root
    sites: list[_Site] = []
    # Numbers first, and over the WHOLE document rather than only where a `type`
    # is written.  `_type_ok` now asks `primitives.is_number`, but a schema
    # reaches a value only where it says something about it, and these contracts
    # have three places that say nothing: two `additionalProperties: true`
    # objects and one empty schema.  A NaN there satisfied every keyword, the row
    # was stored, and the GET that read it back raised
    # `ValueError: Out of range float values are not JSON compliant` - a record
    # written and unreadable, 500 at both ends where a 400 belonged.  The sweep
    # runs alongside the structural walk rather than instead of it, so a schema
    # fault (an unknown keyword, a rule name with nothing behind it) still raises
    # `SchemaError` whatever the document holds.
    errors = primitives.non_finite_faults(instance, path) + _check(
        instance, schema, root, path, sites
    )
    if errors:
        # A rule is written against a shape the schema guarantees.  This
        # document does not have that shape, so the rules are not asked; the
        # structural errors are the answer.
        return errors

    for site_path, node, name in sites:
        rule = RULES[name]  # resolved in phase 1; a missing name raised there
        try:
            messages = list(rule(node))
        except Exception as failure:  # noqa: BLE001 - a rule may not take the caller down
            errors.append(
                f"{site_path}: cross-field rule {name!r} could not judge this "
                f"structurally valid document: {type(failure).__name__}: {failure}"
            )
            continue
        errors += [f"{site_path}: {message}" for message in messages]
    return errors


def _not_a_json_number(literal: str) -> float:
    """``json``'s hook for the three literals JSON does not have.

    ``json.load`` maps ``NaN``, ``Infinity`` and ``-Infinity`` to floats by
    default.  That is a documented Python extension, not JSON (RFC 8259 §6), and
    a parse that accepts what :func:`_type_ok` refuses is the same defect one
    layer down: the value would be built, carried past the boundary as an
    ordinary float, and only refused later - or, at a position no ``type``
    reaches, not refused at all.  So the boundary and the type check make the
    same decision, which is why this hook exists rather than a second sweep.

    Raising is right here and returning errors is right in :func:`validate`:
    this is a malformed *file*, which is what ``json.JSONDecodeError`` already
    is, while ``validate`` is handed a document and owes the caller a list.
    """
    raise ValueError(
        f"{literal} is not JSON - RFC 8259 §6 permits no NaN or Infinity; "
        f"Python's parser accepts the literal as an extension and nothing "
        f"downstream can serialize the float it would build"
    )


def load(path: str | Path) -> dict:
    """A JSON file, as written.  Schemas are read with this."""
    with open(path, encoding="utf-8") as handle:
        return json.load(handle, parse_constant=_not_a_json_number)


def load_document(path: str | Path) -> Any:
    """A JSON document, with integral floats normalized to ``int``.

    The recommended boundary, and **not yet the one ``check`` uses.**  It is
    written, exported and tested here because the recommendation is real: doing
    this once, where JSON becomes Python, removes the ``0`` versus ``0.0`` class
    instead of asking every present and future gate to remember
    ``primitives.is_integer``.  The predicate closed the defect this pass (the
    reviewer's capture probe now refuses both spellings identically); the
    boundary is what stops the next one being written.

    **What blocks turning it on, precisely.**  Normalization is digest-preserving
    under RFC 8785, which writes ``0`` and ``0.0`` the same way - but
    ``case-revision.revision_id`` is published against
    ``primitives.sorted_json``, which does *not*.  The checked-in example freezes
    ``sampling.temperature: 0.0`` and ``sampling.top_p: 1.0`` inside
    ``execution_limits``, a field ``digest_covers`` names, so normalizing on the
    way in rewrites them to ``0`` and ``1`` and every published ``revision_id``
    stops matching its own content.  That is not a bug in normalization; it is
    the second serialization still existing, one layer down.

    So the order is: retire ``sorted_json`` in favour of one canonical form -
    an RFC's decision, since it re-identifies every case revision in existence -
    and then ``check`` reads documents with this function instead of
    :func:`load`.  ``tests/test_cb_primitives.py`` pins both halves, so the day
    that fold lands the precondition is checkable rather than remembered.

    Schemas are always read with :func:`load`: a schema is not a document, and
    ``multipleOf: 0.5`` means what it says.
    """
    with open(path, encoding="utf-8") as handle:
        return primitives.normalize_integers(
            json.load(handle, parse_constant=_not_a_json_number)
        )


def check(instance_path: str | Path, schema_path: str | Path) -> list[str]:
    """One document against one schema, both read as written.

    Deliberately :func:`load` and not :func:`load_document`; that docstring says
    what has to happen first.
    """
    return validate(load(instance_path), load(schema_path))


if __name__ == "__main__":  # pragma: no cover - a convenience, not the test
    problems = check(sys.argv[1], sys.argv[2])
    for problem in problems:
        print(problem)
    sys.exit(1 if problems else 0)
