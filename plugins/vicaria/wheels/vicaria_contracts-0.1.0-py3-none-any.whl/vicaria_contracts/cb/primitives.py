"""The shared semantics of the continuous-benchmark contracts, defined once.

Why this module exists
----------------------
A fourth review of PR #57 found the same per-object decision implemented twice
and answering differently each time.  Three examples, all reproduced:

* ``validate.py`` read ``0.0`` as an integer (JSON Schema draft 2020-12 §6.1.1:
  a number with a zero fractional part *is* an integer) while every semantic
  rule tested ``isinstance(value, int)`` and skipped floats.  The same case
  passed with counters written ``0.0`` and was refused with the same counters
  written ``0``.
* One rule compared instants by parsing them; another compared the *strings*.
  ``2026-09-14T17:12:09+08:00`` and ``2026-09-14T09:12:09Z`` are one instant and
  two strings, so the two rules disagreed about whether an event sat inside its
  authorized interval.
* Two serializers existed for one digest.  Under RFC 8785 ``3`` and ``3.0`` have
  one canonical form, so a retry that rewrites the number is still a retry;
  under ``json.dumps`` they are ``3`` and ``3.0``, so the batch path called the
  same pair a conflict.

None of those is a hard question.  Each is one answer that had two
implementations.  This module is the single implementation of each: an integer
predicate, instant parsing and comparison, RFC 8785 canonicalization with full
Unicode key support, and the digest taken over it.  Every other module in this
package imports these; none reimplements them.

Two serializations, named rather than accidental
------------------------------------------------
:func:`canonical_json` is RFC 8785 (JSON Canonicalization Scheme) and is the
form every NEW digest is taken over, including ``session-event.content_digest``.

:func:`sorted_json` is the older sorted-key ``json.dumps`` form.  It is NOT a
second opinion about canonical JSON: it is the serialization that
``case-revision.revision_id`` and ``traces/eval_task.py:169`` are already
published against, and it differs from RFC 8785 in exactly one way that reaches
a real document - it writes ``1.0`` where RFC 8785 writes ``1``.  Every case
revision in existence carries an id derived from it, so switching that digest
silently re-identifies every case.  It therefore stays, defined here once, with
one caller (``rules_case_revision.revision_digest``) and this note.  A change of
form is a change of every identity and belongs in an RFC, not in a refactor.

Standard library only: the repository declares ``dependencies = []``
(pyproject.toml:15).
"""

from __future__ import annotations

import datetime as _dt
import hashlib
import json
import math
import re
from typing import Any

#: Beyond this an integer is not exactly a double, so RFC 8785 §3.2.2.3 cannot
#: name it without depending on the reader's parser.
MAX_EXACT_INTEGER = 2**53 - 1


class Uncanonical(ValueError):
    """The document holds a value the canonical form cannot name unambiguously."""


# ------------------------------------------------------------------- integers


def is_integer(value: Any) -> bool:
    """True when ``value`` is an integer *as the schema means it*.

    JSON Schema draft 2020-12 §6.1.1: ``integer`` matches any number with a zero
    fractional part, so ``0`` and ``0.0`` are one value written two ways.
    ``validate._type_ok`` already read it that way; the semantic rules read it
    as ``isinstance(value, int)``, which is where the two interpretations came
    apart.  This is the one predicate both sides now call.

    A boolean is not a number here, whatever Python thinks, and a non-finite
    float is not a JSON number at all.
    """
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    if isinstance(value, float):
        return math.isfinite(value) and value.is_integer()
    return False


def as_integer(value: Any) -> int | None:
    """``value`` as an ``int`` when :func:`is_integer` admits it, else ``None``.

    The rules that compare counts use this, so ``0`` and ``0.0`` compare as the
    same count rather than one of them silently falling out of the comparison.
    """
    return int(value) if is_integer(value) else None


def normalize_integers(value: Any) -> Any:
    """``value`` with every integral float replaced by the equal ``int``.

    The boundary coercion that goes with :func:`is_integer`.  Applied once where
    JSON becomes Python (``validate.load_document``), it removes the ``0``
    versus ``0.0`` class of defect instead of asking each of the system's gates
    to remember the predicate.  Both are needed and they are not alternatives:
    normalization only reaches documents that entered through a boundary this
    repository owns, so a document handed straight to ``validate()`` by an
    ingest route, a test or a reviewer's probe still relies on
    :func:`is_integer` at each gate.  The predicate is the net under the
    boundary.

    It is value-preserving and digest-preserving: the numbers are equal, and
    :func:`canonical_json` already writes ``3`` and ``3.0`` identically, so no
    ``content_digest`` and no retry-versus-conflict verdict moves.  Even
    :func:`sorted_json` - the older published form, which *does* distinguish
    them - only ever sees documents that came through this boundary, so it sees
    ``3`` consistently rather than whichever spelling a producer chose.

    Bounded at ±(2^53-1), unlike :func:`as_integer`, because this REWRITES the
    document: beyond that limit an integral float is not an exact integer, and
    writing ``int(1e30)`` into the record would put 31 exact digits where the
    double only ever carried 16.  Such a value is left as the float it was, and
    :func:`canonical_json` keeps naming it the way RFC 8785 does.

    Keys, ordering and every other value are untouched.  A captured object comes
    back with the same members, spelled exactly the same way - the keys are the
    evidence.
    """
    if isinstance(value, bool):
        return value
    if isinstance(value, float):
        if (
            math.isfinite(value)
            and value.is_integer()
            and abs(value) <= MAX_EXACT_INTEGER
        ):
            return int(value)
        return value
    if isinstance(value, dict):
        return {key: normalize_integers(item) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize_integers(item) for item in value]
    return value


def is_number(value: Any) -> bool:
    """True for a JSON number: an int or a finite float, never a bool.

    The one owner of "is this a JSON number".  ``validate._type_ok`` asks it for
    ``"type": "number"``; before it did, that keyword ended in
    ``isinstance(value, float)`` and ``float('nan')`` is a float, so NaN,
    Infinity and -Infinity passed a gate this predicate had already refused and
    :func:`_number` could not serialize.  Two owners, opposite answers.
    """
    if isinstance(value, bool):
        return False
    if isinstance(value, int):
        return True
    return isinstance(value, float) and math.isfinite(value)


def non_finite_faults(value: Any, path: str = "$") -> list[str]:
    """Every non-finite number in ``value``, named and located.  Empty is clean.

    The loud half of :func:`is_number`, and the same pairing as
    :func:`unreadable_instant` / :func:`instant_faults`: a predicate for the
    gates, and a document-level sweep for the callers that have no schema to
    hang the predicate on.

    Why a whole-document sweep and not only the type keyword
    -------------------------------------------------------
    Because the type keyword does not reach every number.  ``json.loads``
    accepts the literals ``NaN``, ``Infinity`` and ``-Infinity`` by default -
    a Python extension, not JSON (RFC 8259 §6: "Numeric values that cannot be
    represented ... are not permitted") - so they arrive from a real request
    body.  The contracts have positions where a number carries no ``type``:
    ``case-revision.calibration`` and ``run-attempt.plan.decision_rule.params``
    are ``additionalProperties: true``, and
    ``case-revision.$defs.evaluator_file_state.checks[].value`` is an empty
    schema.  A NaN at any of those satisfies the whole schema, so a gate that
    only asked :func:`is_number` where a ``type`` is written would still admit
    the record - and ``json.dumps`` cannot write it back out.  That is the shape
    this contract keeps meeting: **the gate admits what nothing downstream can
    handle**, and the record is persisted and then unreadable, which is strictly
    worse than a refusal because both ends answer 500 instead of 400.

    RFC 8785 §3.2.2.3 already said so
    ---------------------------------
    The canonicalization scheme serializes numbers as ECMAScript does and says
    plainly that NaN and Infinity are not permitted - a serializer that meets
    one must fail rather than invent a spelling.  :func:`_number` does exactly
    that, raising :class:`Uncanonical`.  So the contract's own serializer had
    been refusing these values all along while the structural gate admitted
    them; this function is not a new opinion, it is that opinion moved to the
    door, where refusing costs a 400 instead of an unreadable row.

    Booleans are not numbers here and are skipped, as everywhere in this module.
    """
    faults: list[str] = []
    if isinstance(value, dict):
        for key, item in value.items():
            faults += non_finite_faults(item, f"{path}.{key}")
    elif isinstance(value, list):
        for index, item in enumerate(value):
            faults += non_finite_faults(item, f"{path}[{index}]")
    elif isinstance(value, float) and not math.isfinite(value):
        faults.append(
            f"{path}: {value!r} is not a JSON number - RFC 8259 §6 permits no NaN "
            f"or Infinity and RFC 8785 §3.2.2.3 refuses to serialize one, so a "
            f"record carrying it could be written and never read back"
        )
    return faults


# ------------------------------------------------------------------- instants

#: RFC 3339 §5.6 ``date-time``.  Date and time are both mandatory, the separator
#: is ``T`` (either case, per the same section), and the offset is mandatory -
#: ``Z`` or ``±HH:MM``.  A local time is not an instant, and an interval bounded
#: by a non-instant does not bound anything.
#:
#: **The digits are ASCII, because RFC 3339's ABNF says ``DIGIT`` and RFC 5234
#: §B.1 defines that as ``%x30-39``.**  Written with ``\d`` this pattern matched
#: any Unicode decimal digit, and the two halves of the module's oldest defect
#: both came back through that one character class:
#:
#: * ``2026-09-14T09:12:٠٩Z`` was ACCEPTED and read as ``...09:12:09Z``, because
#:   :func:`_read` rebuilds the seconds field through ``int()`` - and Python's
#:   ``int`` reads every Unicode numeral - so two distinct strings became one
#:   instant.  A producer could write a timestamp that reads as another one, and
#:   :func:`same_instant` agreed they were the same.
#: * a Unicode numeral anywhere ELSE passed the gate and returned ``None`` from
#:   the reader, since ``datetime.fromisoformat`` is ASCII-only: the
#:   gate-admits-what-its-reader-cannot-read hole of the leap second, in the
#:   same function, arriving by a different door.
#:
#: The classes are spelled ``[0-9]`` and the pattern is compiled ``re.ASCII``:
#: the spelling says what is meant here, and the flag keeps the next ``\d``,
#: ``\w`` or ``\s`` anyone adds to this grammar from widening it again.
RFC3339 = re.compile(
    r"(?P<year>[0-9]{4})-(?P<month>[0-9]{2})-(?P<day>[0-9]{2})"
    r"[Tt]"
    r"(?P<hour>[0-9]{2}):(?P<minute>[0-9]{2}):(?P<second>[0-9]{2})"
    r"(?:\.(?P<fraction>[0-9]+))?"
    r"(?:[Zz]|(?P<sign>[+-])(?P<offset_hour>[0-9]{2}):(?P<offset_minute>[0-9]{2}))",
    re.ASCII,
)

#: The finest a ``datetime`` resolves.  A leap second is read as the LAST
#: instant of its own minute, which is this many microseconds past ``:59``.
#: :func:`instant` says why that is the mapping and not one of the two
#: collapses a reader might reach for first; :func:`instant_key` says why the
#: mapping cannot also be the order.
_LAST_MICROSECOND = 999_999


def is_rfc3339(text: Any) -> bool:
    """True when ``text`` names exactly one instant, RFC 3339 §5.6."""
    if not isinstance(text, str):
        return False
    match = RFC3339.fullmatch(text)
    if match is None:
        return False
    try:
        _dt.date(int(match["year"]), int(match["month"]), int(match["day"]))
    except ValueError:
        return False
    if int(match["hour"]) > 23 or int(match["minute"]) > 59:
        return False
    if int(match["second"]) > 60:  # 60 is the leap second RFC 3339 §5.6 allows
        return False
    if match["sign"] and (
        int(match["offset_hour"]) > 23 or int(match["offset_minute"]) > 59
    ):
        return False
    return True


def instant(value: Any) -> _dt.datetime | None:
    """The instant ``value`` names, as an aware UTC datetime, or ``None``.

    ``None`` means "``value`` names no instant this contract can compare".  It
    is NOT a silence a caller may read as "somebody else already complained":
    :func:`unreadable_instant` separates the two cases and every rule in this
    package asks it before it is allowed to stay quiet.  See that function for
    the hole this pair closes.

    The return is normalized to UTC so that comparison is comparison of
    INSTANTS.  ``2026-09-14T17:12:09+08:00`` and ``2026-09-14T09:12:09Z`` are
    one instant; comparing the strings puts them eight hours apart and was the
    second of the three disagreements this module exists to end.

    Every timestamp the grammar accepts is read
    -------------------------------------------
    :func:`is_rfc3339` is the gate and this is the reader, and a gate that
    admits what its reader cannot read is a hole, not a pair of opinions.  It
    was one: ``2016-12-31T23:59:60Z`` passed the grammar (correctly - RFC 3339
    §5.6 allows second 60), ``fromisoformat`` refused it, this function returned
    ``None``, and ``rules_session_event`` read that ``None`` as "structural
    validation already reported it" and returned no errors.  A correctly sealed
    event from 2016 therefore satisfied a consent interval that opened in 2026.
    Two things had to move: the reader, here, and the silence, below.

    **The leap second is the last instant of its own minute.**  RFC 3339 §5.6
    allows ``:60`` as the final second of a minute; ``datetime`` has no 61st
    second, so a mapping has to be chosen.  Two collapses suggest themselves and
    both are refused, for the same reason:

    * onto ``:59`` - then an interval that CLOSED at ``:59`` admits an event
      that happened after it closed, because the two compare equal;
    * onto the following ``:00`` - the POSIX ``time_t`` and Java
      ``ISO_INSTANT`` reading - then an interval that OPENED at that ``:00``
      admits an event that happened before it opened, which is the exact
      direction of the defect this docstring exists for.  It also has no answer
      at all for ``9999-12-31T23:59:60Z``: the following ``:00`` is year 10000,
      which ``datetime`` cannot hold, so the last leap second the grammar admits
      would go straight back to having no instant.

    So the leap second is read as ``:59`` plus :data:`_LAST_MICROSECOND` - the
    last instant of the minute it ends.  That is where it actually is: strictly
    after every ordinary second of that minute and strictly before the first
    instant of the next.  The property that buys is the one the collapses lose -
    **a leap second is never admitted by a bound that refuses both of the
    ordinary seconds around it**, in either direction, and
    ``tests/test_cb_primitives.py`` enumerates all four arrangements.

    **What comes back is the instant's place, not this contract's order.**  The
    mapping is deliberately onto a datetime that already has an ordinary name:
    ``2016-12-31T23:59:60Z`` and ``2016-12-31T23:59:59.999999Z`` are two
    timestamps the grammar accepts, one microsecond apart, and one datetime.  So
    ``<`` and ``==`` over these return values cannot separate them, and a rule
    that separates two instants by comparing them - "this attempt ended before
    it began", "this event fell outside its interval" - is defeated by writing
    either of the two as the leap second beside the other.  That is not a
    hypothetical: it is how a run record whose attempt ended a microsecond
    before it started was admitted with an empty error list.  Ordering is
    :func:`instant_key`'s question, asked through :func:`before` and
    :func:`same_instant`; what is returned HERE is for arithmetic over a
    duration and for display, and a caller that compares it is a second,
    narrower reader of a question that is already answered.

    **The fraction is cut HERE, not by the interpreter, and not by the
    contract.**  pyproject declares ``requires-python = ">=3.10"``, and 3.10's
    ``fromisoformat`` reads only 3- or 6-digit fractions while 3.11's reads any
    length and truncates.  Left to the interpreter, ``2026-09-14T09:12:09.1Z`` -
    a valid RFC 3339 date-time - would be a readable instant on one supported
    interpreter and an unreadable one on another, and a document's
    admissibility would depend on which Python a service happened to run.  A
    contract may not answer two ways, so the fraction is padded and cut to
    microseconds here.

    The cut is a property of THIS return value and of nothing else.  RFC 3339
    §5.6 puts no limit on ``time-secfrac`` and :func:`is_rfc3339` accepts every
    length, so ``...09.000000001Z`` and ``...09.000000002Z`` are two instants
    this contract admits and one ``datetime`` - which is the same
    non-injectivity the leap second has, a microsecond finer, and it reached the
    same bound: ``before`` said ``False`` for the genuinely earlier of the two,
    and a consent interval opening at the later one admitted an event from
    before it opened.  The digits are not discarded; :func:`_read` returns them
    beside the datetime and they are part of :func:`instant_key`.  Cutting them
    from the datetime is unavoidable - the type holds six - and that is exactly
    why ordering does not go through the datetime.

    **What is still unreadable, and therefore refused.**  ``+HH:MM`` offsets are
    legal out to ``±23:59``, so the grammar accepts instants that fall outside
    ``datetime``'s range once shifted to UTC - ``0001-01-01T00:00:00+00:01`` is
    year 0, ``9999-12-31T23:59:59-23:59`` is year 10000.  Those return ``None``,
    and it is deliberate that they are not clamped to ``datetime.min``/``max``:
    a clamp would silently make such a value earlier or later than everything
    and sail through exactly the bounds that should refuse it.  The refusal
    belongs to :func:`unreadable_instant`, which makes it loud.
    """
    read = _read(value)
    return None if read is None else read[0]


def _read(value: Any) -> tuple[_dt.datetime, _dt.timedelta, str] | None:
    """The one parse behind every instant question: place, and displacement.

    The first part is where the timestamp sits on ``datetime``'s line, UTC
    normalized - what :func:`instant` returns.  The rest is how far past that
    datetime the timestamp REALLY is, and it is in two pieces because the two
    things ``datetime`` cannot hold are of different sizes:

    * whole microseconds, for the leap second, which has no datetime of its own
      at all (see :func:`instant_key` for what that buys).  Zero for every
      ordinary second;
    * the fractional digits finer than a microsecond, kept as the decimal
      fraction of a microsecond they are.  Empty when there are none.

    **Nothing the grammar accepts is narrowed here.**  RFC 3339 §5.6's
    ``time-secfrac`` is a dot and *any* number of digits, and :func:`is_rfc3339`
    accepts all of them, so the digits past the sixth are part of a timestamp
    this contract admits.  They used to be cut - ``ljust(6, "0")[:6]`` - which
    made ``...09.000000001Z`` and ``...09.000000002Z``, two distinct instants
    the gate admits, one datetime and one key: ``before`` answered ``False`` for
    the genuinely earlier of the two, and a consent interval opening at the
    later one admitted an event from before it opened.  That is the
    leap-second defect of P1-4 arriving by a sibling path - a gate that admits
    what its reader cannot fully read - and the reply is the same one: the
    distinction that does not fit in the datetime travels BESIDE it.

    So the split here is a split and not a truncation.  The first six digits go
    into the datetime, which is what a microsecond-resolution type can hold;
    everything finer is returned, and :func:`instant_key` puts it in the order.

    Trailing zeros are stripped from those finer digits because equal instants
    must have equal keys: ``.1`` and ``.100000`` and ``.1000000000`` are one
    instant a producer may write three ways, and a key that told them apart
    would be the string-comparison defect this module exists to end, one decimal
    place lower down.  With the zeros gone, the digits compare left to right as
    the fraction they are - which is why they are kept as a string and not as an
    integer: read as an integer ``02`` would follow ``1``, but ``.00000002``
    precedes ``.0000001``.

    Every part comes out of one parse of one string because the alternative -
    :func:`instant` reading it for the arithmetic and :func:`instant_key`
    reading it again for the order - is two readers of one grammar, which is
    precisely how ``is_rfc3339`` and ``instant`` came to disagree about second
    60 in the first place.  A second reader here would cost the same twice.
    """
    if not is_rfc3339(value):
        return None
    match = RFC3339.fullmatch(value)
    if match is None:  # pragma: no cover - is_rfc3339 fullmatched it a line ago
        return None
    second = int(match["second"])
    digits = match["fraction"] or ""
    fraction = digits[:6].ljust(6, "0")
    finer = digits[6:].rstrip("0")
    displacement = _dt.timedelta(0)
    if second == 60:
        # Second 60 is read as the last instant of its own minute, and the
        # distance from there to where it actually is travels beside it: the one
        # microsecond from ``:59.999999`` to the end of the minute, plus the
        # leap second's own fraction.  So the whole of second 60 lands past the
        # datetime it shares with ``:59.999999`` and short of the next minute,
        # which is exactly the gap the datetime line does not have room for.
        # ``finer`` is untouched: it is the same sub-microsecond tail of the
        # same fraction, and it still sorts after the whole microseconds.
        displacement = _dt.timedelta(microseconds=1 + int(fraction))
        second, fraction = 59, f"{_LAST_MICROSECOND:06d}"
    offset = (
        "+00:00"
        if match["sign"] is None
        else f"{match['sign']}{match['offset_hour']}:{match['offset_minute']}"
    )
    text = (
        f"{match['year']}-{match['month']}-{match['day']}"
        f"T{match['hour']}:{match['minute']}:{second:02d}.{fraction}{offset}"
    )
    try:
        parsed = _dt.datetime.fromisoformat(text)
    except ValueError:  # pragma: no cover - the grammar has already checked each field
        return None
    if (
        parsed.tzinfo is None
    ):  # pragma: no cover - the grammar makes the offset mandatory
        return None
    try:
        return parsed.astimezone(_dt.timezone.utc), displacement, finer
    except (OverflowError, OSError, ValueError):
        # An offset carried the instant out of datetime's range.  Unreadable is
        # the honest answer; unreadable-and-loud is unreadable_instant's job.
        return None


def instant_key(value: Any) -> tuple[_dt.datetime, _dt.timedelta, str] | None:
    """Where ``value`` sits in this contract's order of instants, or ``None``.

    An opaque sort key, ordered by ordinary ``tuple`` comparison: the datetime
    decides, and the displacement beside it only ever separates two timestamps
    that share one.  ``None`` means the same thing it means everywhere in this
    module - no instant this contract can read - and :func:`unreadable_instant`
    is what makes that loud rather than silent.

    Do not take the key apart, and in particular do not add its parts together:
    the sum of ``:59.999999`` and one microsecond is the NEXT minute's ``:00``,
    which is a different instant with a key of its own.  The displacement
    separates; it does not relocate.

    Why the order is not simply the datetime
    ----------------------------------------
    Because that datetime is not injective, and an order that cannot separate
    two values admits a document that should be refused.  It is not injective in
    two different ways, and both of them were reported as the same defect a
    round apart.

    **The leap second.**  The P1-4 repair made ``2016-12-31T23:59:60Z`` readable
    by reading it as the last instant of its own minute - but ``:59.999999`` is
    itself a timestamp a producer may write, so the two collapse together, and

        started_at  2016-12-31T23:59:60Z         (truly later)
        ended_at    2016-12-31T23:59:59.999999Z  (truly earlier)

    is an attempt that ended before it began, with both timestamps readable, no
    fault to report, and ``end < start`` false.

    **The fraction finer than a microsecond.**  ``time-secfrac`` is any number
    of digits (RFC 3339 §5.6) and a ``datetime`` holds six, so

        event_time              2026-09-14T09:12:09.000000001Z  (truly earlier)
        consent.interval_start  2026-09-14T09:12:09.000000002Z  (truly later)

    is an event from before its authorization opened - two timestamps the gate
    admits, nine digits deep, one datetime, and ``before`` answering ``False``.
    The reading used to cut those digits; :func:`_read` now returns them and
    they are the key's third part, so the order separates what a
    microsecond-resolution type cannot.

    Every rule that distinguishes two instants by comparison was open to both
    moves, in either direction, on any pair where one side could be written as
    the leap second beside the other or one digit deeper than the other.

    What was refused, and what it would have cost
    ---------------------------------------------
    * **Making second 60 unreadable again.**  That is the P1-4 defect itself: a
      sealed leap-second event from December 2016 clearing a consent interval
      that opened in September 2026, because the grammar accepted what the
      reader returned ``None`` for and every rule read the ``None`` as silence.
    * **Collapsing onto ``:59`` or onto the following ``:00``.**  Refused for
      the reason :func:`instant` gives: each ties the leap second to an ordinary
      neighbour, so a bound that refuses that neighbour admits the leap second.
      Those are the same non-injectivity, one second coarser.
    * **Giving the leap second a datetime of its own.**  There is none to give.
      Every microsecond of the minute is spoken for and ``datetime`` has no 61st
      second, so the distinction has to travel BESIDE the datetime or not at
      all.
    * **Ordering on the string.**  ``2026-09-14T17:12:09+08:00`` and
      ``2026-09-14T09:12:09Z`` are one instant that string order puts eight
      hours apart - the second of the three disagreements this module exists to
      end.  The key keeps UTC normalization because it is built on the parse.
    * **Narrowing the grammar to six fractional digits instead.**  That is the
      other way to close the second collapse, and it is the wrong side of the
      gate: RFC 3339 admits the digits, producers emit them (Go's
      ``RFC3339Nano`` and every nanosecond clock write nine), and refusing a
      well-formed timestamp to spare the reader is the reader deciding what the
      contract says.  Widening the reader is the direction that costs nothing
      the contract was promising.
    * **Keeping the finer digits as a number.**  ``int("02")`` is ``2`` and
      ``.00000002`` precedes ``.0000001``; a count inverts the pair.  They are a
      decimal fraction and are kept and compared as one - left to right, with
      trailing zeros stripped in :func:`_read` so that one instant has one key.

    What the key holds
    ------------------
    **Injective over the grammar.**  Two timestamps have the same key exactly
    when they name the same instant.  The parts are ordered whole-to-fine and
    each one only separates values the previous ones tie, so nothing the gate
    admits is merged and nothing distinct compares equal.

    The P1-4 property is unchanged and now rests on the order rather than on the
    mapping: the displacement is strictly positive for a leap second and zero
    for every ordinary one, and the datetime is compared FIRST, so a leap second
    is strictly after every ordinary instant of its own minute - including
    ``:59.999999`` and every digit past it, which is what this pass adds - and
    strictly before the first instant of the next minute, whose datetime is
    already larger.  Note that it is the datetime's precedence and not the size
    of the displacement that holds the upper bound: ``:60.999999999`` sits a
    hair more than a second past ``:59.999999`` and still cannot reach the next
    minute, because it never gets past the first part of the tuple.

    Ordering INSIDE second 60 comes back with it, at full depth: ``:60.100``
    precedes ``:60.900``, and ``:60.0000001`` precedes ``:60.0000002``, where
    the collapse alone made each pair one instant.
    ``tests/test_cb_primitives.py`` pins all of it, the microsecond neighbour
    and the nanosecond one included.

    What it does not hold is duration: a leap second is a second of real elapsed
    time that ``datetime`` subtraction cannot see, and no key can put it back
    without a leap table this contract does not carry.  The callers that
    subtract say so where they subtract.
    """
    return _read(value)


def unreadable_instant(value: Any) -> str | None:
    """Why ``value`` passed the ``date-time`` grammar and yielded no instant.

    ``None`` when there is nothing to report: ``value`` is readable, or it is
    not an RFC 3339 date-time at all and the ``format`` keyword owns that
    refusal.

    Why this exists
    ---------------
    Every rule in this package used to open with some spelling of::

        when = primitives.instant(document["event_time"])
        if when is None:
            return []  # structural validation already reported it

    The comment was an assumption, and it was false for one whole class of
    input: a value the GRAMMAR accepts and the READER cannot read is reported by
    nobody, because ``format`` looked at it and was satisfied.  The rule then
    returned no errors, which its caller reads as "this document is admissible",
    and a December 2016 leap-second event cleared a September 2026 consent
    interval with an empty error list.

    The parse no longer fails for any timestamp a producer can reasonably write
    (see :func:`instant`), so this is the net rather than the fix.  It stays
    because the assumption, not the leap second, is the defect: the day the
    grammar widens, or an offset carries an instant past year 9999, the rule
    that trusted the silence must REFUSE the document instead of admitting it.
    A gate and a reader that disagree are a bug in this contract, and a contract
    bug is the last thing that may be resolved in the document's favour.
    """
    if not is_rfc3339(value):
        return None
    if instant(value) is not None:
        return None
    return (
        f"{value} is a valid RFC 3339 date-time that this contract cannot read as an "
        "instant, so nothing here can bound it; the document is refused rather than "
        "admitted unchecked"
    )


def instant_faults(named: dict[str, Any]) -> list[str]:
    """:func:`unreadable_instant` over the timestamps one rule reads, labelled.

    The rules call this instead of looping themselves, so "what do I do when the
    grammar and the parser disagree?" has one answer in one place rather than
    one per rule - which is how the answer came to be "say nothing" in the first
    place.  ``named`` maps the path a reader would use to point at the field
    (``consent.interval_start``) to the value found there.
    """
    faults = []
    for where, value in named.items():
        fault = unreadable_instant(value)
        if fault is not None:
            faults.append(f"{where} {fault}")
    return faults


def same_instant(left: Any, right: Any) -> bool:
    """True when both name one instant and it is the same one.

    ``False`` here is two-valued on purpose and therefore lossy: an unreadable
    timestamp is "not the same instant" as everything, including itself.  A
    caller that must not treat an unreadable value as a settled answer asks
    :func:`unreadable_instant` first; :func:`before` is the three-valued one.

    The comparison is over :func:`instant_key`, so a leap second is not "the
    same instant" as the ``:59.999999`` it is read as - it is one microsecond
    later, and two timestamps a microsecond apart are two instants.
    """
    first, second = instant_key(left), instant_key(right)
    return first is not None and second is not None and first == second


def before(left: Any, right: Any) -> bool | None:
    """``left`` strictly precedes ``right``; ``None`` when either is unreadable.

    Over :func:`instant_key` and never over the datetimes :func:`instant`
    returns.  Those are not injective - a leap second shares one with the
    ``:59.999999`` beside it - so a bound that compares them admits the instant
    it exists to refuse, which is the defect this pair of readers was split to
    end.  Every ordering question in ``contracts/cb`` comes here.
    """
    first, second = instant_key(left), instant_key(right)
    if first is None or second is None:
        return None
    return first < second


# ------------------------------------------------- RFC 8785 canonical bytes

_ESCAPES = {
    '"': '\\"',
    "\\": "\\\\",
    "\b": "\\b",
    "\f": "\\f",
    "\n": "\\n",
    "\r": "\\r",
    "\t": "\\t",
}


def _string(text: str) -> str:
    """RFC 8785 §3.2.2.2: escape only what JSON requires; everything else literal."""
    out = ['"']
    for char in text:
        if char in _ESCAPES:
            out.append(_ESCAPES[char])
        elif char < "\x20":
            out.append(f"\\u{ord(char):04x}")
        elif "\ud800" <= char <= "\udfff":
            raise Uncanonical(
                f"the string contains the unpaired surrogate U+{ord(char):04X}, "
                "which is not text and has no UTF-8 encoding"
            )
        else:
            out.append(char)
    out.append('"')
    return "".join(out)


def _number(value: float) -> str:
    """ECMAScript ``Number::toString``, which is RFC 8785 §3.2.2.3.

    This is where ``3`` and ``3.0`` become one form.  They are one double and
    RFC 8785 names a double, so a retry that rewrites the representation of a
    number is the same event arriving twice - which is what the single-event
    path already said and the batch path did not.
    """
    if isinstance(value, int) and not isinstance(value, bool):
        if abs(value) > MAX_EXACT_INTEGER:
            raise Uncanonical(
                f"the integer {value} is beyond 2^53-1, so no canonical form names it exactly"
            )
        return str(value)
    if math.isnan(value) or math.isinf(value):
        raise Uncanonical(f"{value!r} is not a JSON number")
    if value == int(value) and abs(value) <= MAX_EXACT_INTEGER:
        return str(int(value))  # 3.0 is the double 3, and RFC 8785 writes it "3"
    if value == 0:
        return "0"  # RFC 8785: -0 and 0 share one canonical form
    sign = "-" if value < 0 else ""
    mantissa, _, exponent = repr(abs(value)).partition("e")
    power = int(exponent or 0)
    whole, _, fraction = mantissa.partition(".")
    # value = digits x 10 ** (n - k), with k digits and no leading or trailing zero
    stripped = (whole + fraction).lstrip("0")
    digits = stripped.rstrip("0") or "0"
    k = len(digits)
    n = k + power - len(fraction) + (len(stripped) - k)
    if k <= n <= 21:
        return sign + digits + "0" * (n - k)
    if 0 < n <= 21:
        return sign + digits[:n] + "." + digits[n:]
    if -6 < n <= 0:
        return sign + "0." + "0" * (-n) + digits
    head = digits[0] if k == 1 else digits[0] + "." + digits[1:]
    return sign + head + "e" + ("+" if n - 1 >= 0 else "-") + str(abs(n - 1))


def utf16_order(key: str) -> bytes:
    """The sort key RFC 8785 §3.2.3 names: the key's UTF-16 code units.

    Comparing the UTF-16 big-endian bytes of two strings compares their code
    unit sequences, which is what the specification says and what the published
    test vectors check.  It differs from code-point order only above the basic
    multilingual plane, where a supplementary character sorts before U+E000..
    U+FFFF because its surrogates begin at 0xD800 - the case an ASCII-only
    validator never has to think about and therefore got to refuse instead.
    """
    try:
        return key.encode("utf-16-be")
    except UnicodeEncodeError as failure:  # an unpaired surrogate in a key
        raise Uncanonical(f"object key {key!r} is not text: {failure}") from failure


def _serialize(value: Any) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if isinstance(value, (int, float)):
        return _number(value)
    if isinstance(value, str):
        return _string(value)
    if isinstance(value, list):
        return "[" + ",".join(_serialize(item) for item in value) + "]"
    if isinstance(value, dict):
        for key in value:
            if not isinstance(key, str):
                raise Uncanonical(f"object key {key!r} is not a string")
        members = [
            _string(key) + ":" + _serialize(value[key])
            for key in sorted(value, key=utf16_order)
        ]
        return "{" + ",".join(members) + "}"
    raise Uncanonical(f"{type(value).__name__} is not a JSON value")


def canonical_json(value: Any) -> str:
    """RFC 8785 canonical JSON, Unicode keys included.

    Keys are sorted by UTF-16 code unit (§3.2.3) and written as they arrived.
    A tool call's arguments are an arbitrary JSON object - ``{"用户数": 42}`` is a
    structurally valid one - and the captured keys are the evidence, so they are
    preserved exactly rather than refused or transliterated.
    """
    return _serialize(value)


def canonical_bytes(value: Any) -> bytes:
    """The exact bytes a digest is taken over: :func:`canonical_json` as UTF-8."""
    return canonical_json(value).encode("utf-8")


def digest_over(value: Any) -> str:
    """``sha256:`` + lowercase hex of SHA-256 over :func:`canonical_bytes`."""
    return "sha256:" + hashlib.sha256(canonical_bytes(value)).hexdigest()


# --------------------------------------------- the older published form


def sorted_json(value: Any) -> str:
    """Sorted-key JSON with no insignificant whitespace, non-ASCII written out.

    The serialization ``case-revision.revision_id`` and
    ``traces/eval_task.py:169`` are already published against.  See the module
    docstring for why it is not folded into :func:`canonical_json`: that fold
    would rewrite every case identity in existence, which is an RFC's decision
    and not a refactor's.
    """
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def sorted_digest_over(value: Any) -> str:
    """``sha256:`` + hex over :func:`sorted_json`, for the identities using it."""
    return "sha256:" + hashlib.sha256(sorted_json(value).encode("utf-8")).hexdigest()


# ------------------------------------------------------------- module loading


def load(name: str):
    """Import a sibling module of this package by file, once per process.

    ``validate.py`` discovers ``rules_*.py`` by path rather than by package
    import (this directory is contract material, not an installed package), so a
    rule module cannot write ``from . import primitives``.  This is the one
    loader they all use, and it caches in ``sys.modules`` so every caller shares
    one instance of the module - and therefore one instance of these functions.
    """
    import importlib.util
    import sys
    from pathlib import Path

    key = f"cb_contract_{name}"
    existing = sys.modules.get(key)
    if existing is not None:
        return existing
    spec = importlib.util.spec_from_file_location(
        key, Path(__file__).resolve().parent / f"{name}.py"
    )
    if (
        spec is None or spec.loader is None
    ):  # pragma: no cover - unreachable for a real file
        raise ImportError(f"cannot load {name}.py beside {__file__}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module
    try:
        spec.loader.exec_module(module)
    except BaseException:
        del sys.modules[key]
        raise
    return module
