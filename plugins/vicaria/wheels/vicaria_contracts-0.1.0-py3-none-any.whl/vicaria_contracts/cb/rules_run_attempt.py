"""Cross-field admissibility rules for ``run-attempt.schema.json``.

Why this file exists
--------------------
The third external review of PR #57 found that the cross-field checks in
``tests/test_cb_contracts.py`` assert properties *of the checked-in example*
rather than rules over *any* document: they read the example, compare two of its
fields, and pass.  Nothing anywhere took an arbitrary run record and said whether
it was admissible, so a mutated record could violate every advertised invariant
while every test stayed green.  The reviewer demonstrated it: replacing a
timed-out attempt with a byte-copy of a successful one left ``accounting``
reporting planned 12, reported 12, extra 0, missing 0 — numbers that agreed with
nothing.

Each rule below is a pure function of one document.  It returns a list of
strings; empty means the document satisfies that rule.  ``check`` runs all of
them; ``admissible`` runs the schema first and then all of them, and is the one
callable that answers "may this document exist?".

Every rule here has a negative fixture in ``tests/test_cb_rules_slice_and_run.py``
— a document mutated to break exactly that rule and nothing else.  A rule with no
negative fixture is a rule nobody has shown refuses anything.

The rules are wired into the schema through ``x-cb-rules`` (see ``validate.py``),
so ``validate(document, schema)`` is itself the refusal.

Standard library only: the repository declares ``dependencies = []``
(pyproject.toml:15).

    python contracts/cb/validate.py \
        contracts/cb/examples/run-attempt.example.json \
        contracts/cb/run-attempt.schema.json
"""

from __future__ import annotations

import importlib.util
import sys
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any


def _load_primitives() -> Any:
    """The one shared-semantics module, loaded once under a fixed name.

    ``contracts/cb`` is not a package - ``validate.py`` discovers these modules
    by file location - so there is no package for a relative import to be
    relative to.  The ``sys.modules`` guard is what makes every consumer share
    ONE module object, and therefore one set of predicates.
    """
    # The key ``primitives.load`` itself uses.  It is the SAME string in every
    # module that bootstraps this file, because "which object is primitives?"
    # is one decision: two keys execute two copies, and ``Uncanonical`` then
    # has two identities that no ``except`` clause can span.
    # tests/test_cb_primitives.py pins that there is exactly one.
    name = "cb_contract_primitives"
    if name not in sys.modules:
        path = Path(__file__).resolve().parent / "primitives.py"
        spec = importlib.util.spec_from_file_location(name, path)
        if (
            spec is None or spec.loader is None
        ):  # pragma: no cover - unreachable for a real file
            raise ImportError(f"cannot load the shared primitives from {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module  # before exec_module, so a re-entrant import sees it
        spec.loader.exec_module(module)
    return sys.modules[name]


primitives = _load_primitives()

#: An attempt's duration and its two instants are written by the same runner, so
#: they may disagree only by the resolution the instants are recorded at.
INSTANT_RESOLUTION_S = 1.0

#: The three axes a run reports separately, and never as one number.
SEPARATED_AXES = (
    "environment_reconstruction",
    "evaluator_stability",
    "solver_variability",
)


def _instant(value: Any):
    """The instant ``value`` names, through the one parser, for ARITHMETIC only.

    ``primitives.instant`` normalizes to UTC, so a duration taken across two
    timestamps written in different offsets is the duration between the instants
    they name rather than between their strings.

    It is not an ordering key and nothing here may compare two of these.  The
    datetime a leap second is read as belongs to the ``:59.999999`` beside it as
    well, so ``end < start`` over these two values answers "no" for a pair that
    really is inverted; ``primitives.before`` orders on
    ``primitives.instant_key``, which separates them.  That is the whole of the
    producer/consumer split here: the contract owns "which instant is earlier",
    and a rule that re-derives it from a datetime is a second, narrower reader
    of an answer it could have asked for.
    """
    return primitives.instant(value)


def _object(node: Any, key: str) -> dict:
    """``node[key]`` when it is an object, else ``{}``.

    A structurally invalid document reaches these rules whenever a caller runs
    them without the schema, and a rule that answers ``.get`` on a string takes
    its caller down instead of refusing the document.  ``validate()`` now runs
    the schema first, and this is the belt to that pair of braces.
    """
    value = node.get(key) if isinstance(node, dict) else None
    return value if isinstance(value, dict) else {}


def _rows(node: Any, key: str) -> list:
    """``node[key]`` when it is an array, else ``[]``."""
    value = node.get(key) if isinstance(node, dict) else None
    return value if isinstance(value, list) else []


def _hashable(value: Any) -> Any:
    """``value`` as something a ``set`` or a ``Counter`` can hold.

    An id is a string in every schema here, so this only ever matters for a
    document whose shape is already wrong.  It matters then: counting ids is how
    a duplicate is found, and ``TypeError: unhashable type`` out of a checker is
    not a refusal of the document, it is the caller falling over.
    """
    if isinstance(value, (str, int, float, bool, type(None))):
        return value
    try:
        return "json:" + primitives.canonical_json(value)
    except primitives.Uncanonical:
        return "repr:" + repr(value)


def _same(left: Any, right: Any) -> bool:
    """Equality of JSON values: ``0`` and ``0.0`` are one number, not two."""
    if primitives.is_number(left) and primitives.is_number(right):
        return float(left) == float(right)
    return left == right


def _number_key(value: Any) -> Any:
    """An integral number as the ``int`` it is, so ``0`` and ``0.0`` count once."""
    normalized = primitives.as_integer(value)
    return normalized if normalized is not None else _hashable(value)


def _identity(row: dict) -> tuple:
    """The triple an attempt was planned under: one case, one side, one index."""
    return (
        _hashable(row.get("case_id")),
        _hashable(row.get("side_id")),
        _number_key(row.get("attempt_index")),
    )


def _plan(document: dict) -> dict:
    return _object(document, "plan")


def _planned(document: dict) -> list[dict]:
    return [
        r for r in _rows(_plan(document), "planned_attempts") if isinstance(r, dict)
    ]


def _attempts(document: dict) -> list[dict]:
    return [r for r in _rows(document, "attempts") if isinstance(r, dict)]


# --------------------------------------------------------------- the accounting


def accounting_of(document: dict) -> dict[str, int]:
    """The four counters, computed from the plan and the attempts.

    This is the definition ``accounting`` must equal.  Nothing reads the stored
    numbers, so a record whose counters were left untouched while its attempt
    list was rewritten cannot agree with this.
    """
    planned = Counter(_hashable(r.get("attempt_id")) for r in _planned(document))
    reported = Counter(_hashable(r.get("attempt_id")) for r in _attempts(document))
    keys = set(planned) | set(reported)
    return {
        "planned": sum(planned.values()),
        "reported": sum(reported.values()),
        "extra": sum(max(0, reported[k] - planned[k]) for k in keys),
        "missing": sum(max(0, planned[k] - reported[k]) for k in keys),
    }


def rule_accounting_is_a_function_of_the_attempts(document: dict) -> list[str]:
    """commitment run-reports-every-planned-attempt.

    Extra and missing are hard failures, which the schema pins to zero; that pin
    is worth nothing unless the counters are derived from the arrays rather than
    written beside them.
    """
    stated = document.get("accounting")
    if not isinstance(stated, dict):
        return ["accounting: missing"]
    computed = accounting_of(document)
    return [
        f"accounting.{key}: says {stated.get(key)!r}, the plan and the attempts say {value}"
        for key, value in computed.items()
        if not _same(stated.get(key), value)
    ]


def rule_attempt_identity_is_unique(document: dict) -> list[str]:
    """An attempt is one attempt_id and one (case, side, index) triple.

    Without this, two copies of one attempt are two rows and the run reports a
    result twice.
    """
    errors: list[str] = []
    for label, rows in (
        ("attempts", _attempts(document)),
        ("plan.planned_attempts", _planned(document)),
    ):
        for key, counted in (
            ("attempt_id", Counter(_hashable(r.get("attempt_id")) for r in rows)),
            ("identity", Counter(_identity(r) for r in rows)),
        ):
            for value, count in sorted(counted.items(), key=lambda kv: str(kv[0])):
                if count > 1:
                    errors.append(f"{label}: {key} {value!r} appears {count} times")
    return errors


def rule_attempt_bodies_match_the_plan(document: dict) -> list[str]:
    """An attempt carries the case, revision, side and index it was planned under.

    An attempt_id that resolves to a different body is a substitution, which is
    what replacing a timed-out attempt with a copy of a successful one is.
    """
    plan_by_id = {_hashable(r.get("attempt_id")): r for r in _planned(document)}
    errors: list[str] = []
    for row in _attempts(document):
        ident = _hashable(row.get("attempt_id"))
        planned = plan_by_id.get(ident)
        if planned is None:
            errors.append(f"attempts: {ident!r} was never planned")
            continue
        for field in ("case_id", "revision_id", "side_id", "attempt_index"):
            if not _same(row.get(field), planned.get(field)):
                errors.append(
                    f"attempts[{ident}].{field}: {row.get(field)!r} but planned as {planned.get(field)!r}"
                )
    reported = {_hashable(r.get("attempt_id")) for r in _attempts(document)}
    for ident in plan_by_id:
        if ident not in reported:
            errors.append(f"attempts: planned attempt {ident!r} was not reported")
    return errors


def rule_one_revision_per_case(document: dict) -> list[str]:
    """A run measures one revision of a case, or it is two runs wearing one id."""
    by_case: dict[Any, set] = defaultdict(set)
    for row in _planned(document) + _attempts(document):
        by_case[_hashable(row.get("case_id"))].add(_hashable(row.get("revision_id")))
    return [
        f"case {case!r} is run at {len(revisions)} revisions: {sorted(map(str, revisions))}"
        for case, revisions in sorted(by_case.items(), key=lambda kv: str(kv[0]))
        if len(revisions) > 1
    ]


def rule_every_attempt_names_a_planned_side(document: dict) -> list[str]:
    """A side that is not in the plan is a configuration nobody froze a digest for."""
    sides = {
        _hashable(s.get("side_id"))
        for s in _rows(_plan(document), "sides")
        if isinstance(s, dict)
    }
    return [
        f"attempts[{row.get('attempt_id')}].side_id: {row.get('side_id')!r} is not a planned side"
        for row in _planned(document) + _attempts(document)
        if _hashable(row.get("side_id")) not in sides
    ]


def rule_attempts_per_case_matches_the_plan(document: dict) -> list[str]:
    """``attempts_per_case`` is the shape of the plan, not a note about it.

    Each (case, side) is planned exactly that many times, indexed 0..n-1.
    """
    per_case = primitives.as_integer(_plan(document).get("attempts_per_case"))
    if per_case is None:
        return ["plan.attempts_per_case: missing"]
    groups: dict[tuple, list] = defaultdict(list)
    for row in _planned(document):
        key = (_hashable(row.get("case_id")), _hashable(row.get("side_id")))
        groups[key].append(_number_key(row.get("attempt_index")))
    errors: list[str] = []
    for (case, side), indexes in sorted(groups.items(), key=lambda kv: str(kv[0])):
        if len(indexes) != per_case:
            errors.append(
                f"plan.planned_attempts: case {case!r} side {side!r} planned {len(indexes)} "
                f"times, attempts_per_case says {per_case}"
            )
        numbered = sorted(i for i in indexes if isinstance(i, int))
        if len(numbered) != len(indexes) or numbered != list(range(len(indexes))):
            shown = (
                numbered if len(numbered) == len(indexes) else sorted(indexes, key=repr)
            )
            errors.append(
                f"plan.planned_attempts: case {case!r} side {side!r} indexes {shown} "
                f"are not 0..{len(indexes) - 1}"
            )
    return errors


def rule_budget_bounds_the_planned_attempts(document: dict) -> list[str]:
    """commitment budget-bounds-the-run-not-the-corpus.

    A cap enforced at draw time that the drawn plan already exceeds was not a cap.
    """
    cap = primitives.as_integer(_object(_plan(document), "budget").get("max_attempts"))
    if cap is None:
        return ["plan.budget.max_attempts: missing"]
    errors: list[str] = []
    if len(_planned(document)) > cap:
        errors.append(
            f"plan.planned_attempts: {len(_planned(document))} attempts exceed the budget of {cap}"
        )
    reported = primitives.as_integer(_object(document, "accounting").get("reported"))
    if reported is not None and reported > cap:
        errors.append(f"accounting.reported: {reported} exceeds the budget of {cap}")
    return errors


# ------------------------------------------------- an outcome and its own record


def rule_outcome_agrees_with_its_measurements(document: dict) -> list[str]:
    """An attempt's state, its instants, its verdict and its measurements are one
    account of one event, and a record in which they disagree says two things.

    commitments missing-reference-evidence-is-recorded-not-passed,
    missing-measurement-is-shown.

    Note what is deliberately NOT here: "an unavailable verdict names its
    reason".  ``semantics`` carried that rule, but the schema already says it in
    keywords - ``verdict.unavailable_reason`` is a non-nullable string on the
    ``unavailable`` branch - so implementing it again here would put three
    implementations where the review found two.  It was deleted, not moved;
    ``tests/test_cb_rules_slice_and_run.py`` records that the schema refuses it.
    """
    errors: list[str] = []
    for row in _attempts(document):
        ident = row.get("attempt_id")
        state = row.get("state")
        verdict = row.get("verdict") if isinstance(row.get("verdict"), dict) else {}
        measurements = (
            row.get("measurements") if isinstance(row.get("measurements"), list) else []
        )
        start, end = _instant(row.get("started_at")), _instant(row.get("ended_at"))

        # An instant the grammar accepted and the parser could not read is a bug
        # in this contract, not a fact about the attempt, and it silently
        # disarmed both checks below: the ordering check and the wall-clock
        # cross-check were both guarded on `start and end`, so an unreadable pair
        # made an attempt that ended before it began, with a wall clock agreeing
        # with neither, look admissible.  The reported case is the same one
        # rules_session_event carried - a leap second - and the reply is the
        # same: name the field, refuse the document.
        errors += [
            f"attempts[{ident}]: {fault}"
            for fault in primitives.instant_faults(
                {"started_at": row.get("started_at"), "ended_at": row.get("ended_at")}
            )
        ]

        if state == "not_run":
            if row.get("started_at") is not None:
                errors.append(f"attempts[{ident}]: not_run but carries a start instant")
            if row.get("ended_at") is not None:
                errors.append(f"attempts[{ident}]: not_run but carries an end instant")
            if measurements:
                errors.append(
                    f"attempts[{ident}]: not_run but carries {len(measurements)} measurements"
                )
            if verdict.get("unavailable_reason") != "attempt_not_run":
                errors.append(
                    f"attempts[{ident}]: not_run but the verdict blames "
                    f"{verdict.get('unavailable_reason')!r}"
                )
        else:
            if start is None:
                errors.append(
                    f"attempts[{ident}]: state {state!r} started, so it must say when"
                )
            if verdict.get("unavailable_reason") == "attempt_not_run":
                errors.append(
                    f"attempts[{ident}]: state {state!r} but the verdict says it never ran"
                )

        if state == "completed":
            if verdict.get("state") not in ("pass", "fail"):
                errors.append(
                    f"attempts[{ident}]: completed but the verdict is {verdict.get('state')!r}"
                )
            if end is None:
                errors.append(f"attempts[{ident}]: completed but has no end instant")
        elif verdict.get("state") != "unavailable":
            errors.append(
                f"attempts[{ident}]: state {state!r} did not complete, so the verdict may not be "
                f"{verdict.get('state')!r}"
            )

        if (
            state in ("timed_out", "infrastructure_error")
            and verdict.get("unavailable_reason") != state
        ):
            errors.append(
                f"attempts[{ident}]: state {state!r} but the verdict blames "
                f"{verdict.get('unavailable_reason')!r}"
            )

        # Asked of the contract, not re-derived from the two datetimes above.
        # `end < start` was that second derivation and it was defeated by the
        # leap-second repair it sat beside: `instant` reads `:59:60` as the last
        # instant of its own minute, `:59.999999` is that same datetime, so an
        # attempt started at `2016-12-31T23:59:60Z` and ended a microsecond
        # EARLIER at `2016-12-31T23:59:59.999999Z` compared equal - two readable
        # timestamps, no fault to report, and the inversion admitted.
        # `primitives.before` orders on `primitives.instant_key`, which carries
        # the leap second's displacement beside the datetime and separates them.
        # `None` (unreadable) is not an ordering answer and is not treated as
        # one; `instant_faults` above has already refused the document.
        if primitives.before(row.get("ended_at"), row.get("started_at")) is True:
            errors.append(
                f"attempts[{ident}]: ended {row['ended_at']} before it started {row['started_at']}"
            )

        for measurement in measurements:
            if not isinstance(measurement, dict):
                continue
            if (
                measurement.get("name") == "wall_clock_s"
                and measurement.get("state") == "measured"
            ):
                value = measurement.get("value")
                # A DURATION, so it is taken over the instants and not over the
                # ordering key: the key separates, it does not measure.  The
                # residual is stated because it is real - a leap second is a
                # second of elapsed time the datetime line has no room for, so a
                # span with a leap-second endpoint reads up to one second short,
                # which is what INSTANT_RESOLUTION_S already tolerates.  Putting
                # it back would need a leap table this contract does not carry,
                # and an ordinary attempt is refused before it gets here if its
                # two instants are inverted at all.
                if start and end and primitives.is_number(value):
                    span = (end - start).total_seconds()
                    if abs(span - value) > INSTANT_RESOLUTION_S:
                        errors.append(
                            f"attempts[{ident}]: wall_clock_s {value} disagrees with the "
                            f"{span:g} s between its own instants"
                        )
            if measurement.get("state") == "measured" and not primitives.is_number(
                measurement.get("value")
            ):
                errors.append(
                    f"attempts[{ident}]: measurement {measurement.get('name')!r} is measured with no value"
                )
            if (
                measurement.get("state") != "measured"
                and measurement.get("value") is not None
            ):
                errors.append(
                    f"attempts[{ident}]: measurement {measurement.get('name')!r} is "
                    f"{measurement.get('state')!r} but carries {measurement.get('value')!r}"
                )
    return errors


# ------------------------------------------------------- reporting and the halves


def rule_denominator_counts_what_was_reported(document: dict) -> list[str]:
    """A rate is over what ran.  A denominator that outruns the attempts is a rate
    over attempts nobody made (commitment aggregate-by-default)."""
    stated = primitives.as_integer(_object(document, "reporting").get("denominator"))
    reported = primitives.as_integer(_object(document, "accounting").get("reported"))
    if stated is None or reported is None:
        return []
    if stated != reported:
        return [
            f"reporting.denominator: {stated} but {reported} attempts were reported"
        ]
    return []


def rule_per_case_detail_pairs_with_an_exposure_row(document: dict) -> list[str]:
    """commitment open-is-a-write-never-refused: opening per-case held-out detail
    always appends a row, and an open with no stated reason is refused."""
    reporting = _object(document, "reporting")
    exposure = _rows(document, "exposure")
    errors: list[str] = []
    if reporting.get("per_case_detail_included") and not exposure:
        errors.append(
            "reporting.per_case_detail_included: per-case detail was included with no exposure row"
        )
    for row in exposure:
        if not isinstance(row, dict) or not str(row.get("reason", "")).strip():
            errors.append(
                f"exposure[{(row or {}).get('exposure_id')}]: opened with no stated reason"
            )
    return errors


def rule_exposure_rows_name_this_run(document: dict) -> list[str]:
    """An exposure row belongs to the plan and the bundle version it was opened
    under.  A row naming another plan is somebody else's audit trail."""
    plan = _plan(document)
    digest = plan.get("plan_digest")
    bundle_version = _object(plan, "bundle").get("bundle_version_id")
    cases = {_hashable(r.get("case_id")) for r in _planned(document)}
    errors: list[str] = []
    for row in _rows(document, "exposure"):
        if not isinstance(row, dict):
            continue
        ident = row.get("exposure_id")
        if row.get("plan_digest") != digest:
            errors.append(
                f"exposure[{ident}].plan_digest: names a plan this run did not run"
            )
        if row.get("bundle_version_id") != bundle_version:
            errors.append(
                f"exposure[{ident}].bundle_version_id: names a bundle version this run did not draw from"
            )
        if _hashable(row.get("case_id")) not in cases:
            errors.append(
                f"exposure[{ident}].case_id: {row.get('case_id')!r} is not a case this run planned"
            )
    return errors


def rule_every_case_run_was_committed(document: dict) -> list[str]:
    """commitments reserve-at-draw-spend-at-run, reserve-at-plan-commit-at-execution.

    A case a run executed must carry a spent eligibility row, committed inside
    the execution transaction.  A run over a case nobody spent is the double
    spend the constraint exists to stop.
    """
    rows = _rows(document, "eligibility")
    spent = {
        _hashable(r.get("case_id"))
        for r in rows
        if isinstance(r, dict)
        and r.get("state") == "spent"
        and r.get("confirmed_in_execution_transaction") is True
        and r.get("committed_at")
    }
    ran = {
        _hashable(r.get("case_id"))
        for r in _attempts(document)
        if r.get("state") != "not_run"
    }
    return [
        f"eligibility: case {case!r} was run with no spent, execution-confirmed row"
        for case in sorted(map(str, ran - spent))
    ]


# ------------------------------------------- what the run reports, and about what


def rule_the_three_measurements_stay_three(document: dict) -> list[str]:
    """commitment three-measurements-separated.

    Environment reconstruction, evaluator stability and solver variability are
    three measurements of three different things, and a run reports them in
    three fields with three sets of counters.  Two axes reporting the same
    measurement is one number wearing two names: the reader cannot tell which of
    the three moved, which is the whole reason they are separated.

    This check had no owner among the schema-wired rules and lived only in
    ``semantics``, which nothing wires into ``validate()``.  It is settled by one
    document, so it belongs here.
    """
    separated = _object(document, "separated_measurements")
    if not separated:
        return []
    messages: list[str] = []
    names = [
        _object(separated, axis).get("name")
        for axis in SEPARATED_AXES
        if axis in separated
    ]
    if names and len(set(map(_hashable, names))) != len(names):
        messages.append(
            f"separated_measurements: two axes report the same measurement {names}"
        )
    for axis in SEPARATED_AXES:
        recorded = _object(separated, axis).get("name")
        if recorded is not None and recorded != axis:
            messages.append(
                f"separated_measurements.{axis}.name: the axis carries the measurement named "
                f"{recorded!r}"
            )
    return messages


# -- where "the run names the bundle version it drew from" is decided, and why
#    it is NOT decided here ----------------------------------------------------
#
# A rule named ``run_the_bundle_version_id_matches_its_line_and_version`` used to
# sit at this point in the file.  It rebuilt the producer's id from the line and
# the version --- ``f"bundlev_{line.removeprefix('bundle_')}_v{version}"`` --- and
# refused any run that named a bundle version spelled some other way.
#
# That made the RUN the owner of the BUNDLE's id scheme, and the two sides did
# not agree.  ``bundle-version.schema.json`` declares ``bundle_version_id`` as
# ``$ref: #/$defs/id``: an opaque identifier with a charset and nothing else.
# Where this contract set means "derived", it says so on the PRODUCING schema in
# a keyword a reader can see --- ``revision_id`` carries
# ``"pattern": "^sha256:[0-9a-f]{64}$"``, every digest carries the same --- and
# the bundle version id carries no such pattern and the bundle root carries no
# ``x-cb-rules`` at all.  RFC 0018 §6.1's ``run-names-what-it-was-drawn-from``
# row names ``run#plan.bundle.membership_digest, bundle_line_id, version,
# library_revision``; it commits to the run NAMING the corpus and commits to no
# spelling of the id.  So a bundle whose own contract called it valid ---
# ``bundle_version_id: "bundle_version_opaque_123"`` --- could not be named by
# any run, and the consumer was guessing a scheme the producer never published.
#
# The two ways out, and why one of them was not taken.  Deriving the id on the
# producing schema would make the scheme real, but it would do so by making a
# contract-VALID bundle unrepresentable, which is repairing a mishandled input
# by outlawing it, and it would mint a commitment the register does not carry.
# So the id stays opaque and the correspondence is what it actually is: a
# question about TWO documents, unanswerable by either alone.  A pure function of
# one run cannot resolve a bundle it cannot see; ``validate(run, schema)`` is
# therefore silent here rather than guessing, and the refusal lives with the only
# caller that holds both documents --- ``semantics.run_names_its_bundle``, reached
# through ``semantics.check_run_attempt(run, bundle_version)``.  It compares all
# four fields the run copies (line, version, version id, membership digest)
# against the bundle version itself, where the old rule compared one synthesized
# string, so the check got stricter in moving.
#
# What a single run document still settles about this is already owned, one file
# away from here: ``rule_exposure_rows_name_this_run`` refuses an exposure row
# naming a bundle version the plan did not draw from.  Adding a second run-side
# reader of the same field is the defect this note exists to prevent.


#: Named on ``run-attempt.schema.json``'s root through ``x-cb-rules``, so
#: ``validate(document, schema)`` alone refuses a document that breaks one.
RULES = {
    "run_accounting_is_a_function_of_the_attempts": rule_accounting_is_a_function_of_the_attempts,
    "run_attempt_identity_is_unique": rule_attempt_identity_is_unique,
    "run_attempt_bodies_match_the_plan": rule_attempt_bodies_match_the_plan,
    "run_one_revision_per_case": rule_one_revision_per_case,
    "run_every_attempt_names_a_planned_side": rule_every_attempt_names_a_planned_side,
    "run_attempts_per_case_matches_the_plan": rule_attempts_per_case_matches_the_plan,
    "run_budget_bounds_the_planned_attempts": rule_budget_bounds_the_planned_attempts,
    "run_outcome_agrees_with_its_measurements": rule_outcome_agrees_with_its_measurements,
    "run_denominator_counts_what_was_reported": rule_denominator_counts_what_was_reported,
    "run_per_case_detail_pairs_with_an_exposure_row": rule_per_case_detail_pairs_with_an_exposure_row,
    "run_exposure_rows_name_this_run": rule_exposure_rows_name_this_run,
    "run_every_case_run_was_committed": rule_every_case_run_was_committed,
    "run_the_three_measurements_stay_three": rule_the_three_measurements_stay_three,
}

#: The RFC 0018 §6.1 row each rule holds up, declared beside the rule that holds
#: it.  ``semantics`` reads this to label a violation rather than keeping a
#: second table that could name a different commitment for the same rule.
COMMITMENTS = {
    "run_accounting_is_a_function_of_the_attempts": "run-reports-every-planned-attempt",
    "run_attempt_identity_is_unique": "run-reports-every-planned-attempt",
    "run_attempt_bodies_match_the_plan": "run-reports-every-planned-attempt",
    "run_one_revision_per_case": "run-comparable-only-to-itself",
    "run_every_attempt_names_a_planned_side": "run-comparable-only-to-itself",
    "run_attempts_per_case_matches_the_plan": "run-reports-every-planned-attempt",
    "run_budget_bounds_the_planned_attempts": "budget-bounds-the-run-not-the-corpus",
    "run_outcome_agrees_with_its_measurements": "missing-measurement-is-shown",
    "run_denominator_counts_what_was_reported": "aggregate-by-default",
    "run_per_case_detail_pairs_with_an_exposure_row": "open-is-a-write-never-refused",
    "run_exposure_rows_name_this_run": "open-is-a-write-never-refused",
    "run_every_case_run_was_committed": "reserve-at-draw-spend-at-run",
    "run_the_three_measurements_stay_three": "three-measurements-separated",
}


def check(document: Any) -> list[str]:
    """Every cross-field rule, over an arbitrary document.  Empty means admissible.

    ``validate(document, schema)`` reaches the same functions through
    ``x-cb-rules``; this is the direct entry point for a caller holding no schema.
    """
    if not isinstance(document, dict):
        return ["a run record is an object"]
    errors: list[str] = []
    for name, rule in RULES.items():
        errors += [f"{name}: {message}" for message in rule(document)]
    return errors
