"""Cross-field rules for ``case-revision.schema.json``.

Every function here is a **pure function of a candidate document**.  It takes
any dict and returns the reasons the document is inadmissible; an empty list
means admissible.  Nothing reads the checked-in example, nothing reads the
filesystem, and nothing mutates its argument - so the same function that lets
the example through is the function that refuses a mutation of it.

That is the point.  A test that reads ``case-revision.example.json`` and asserts
``case["validation"]["revision_id"] == case["revision_id"]`` refuses no
document at all: it agrees with a good one.  These rules are wired into the
schema through ``x-cb-rules`` (see ``validate.py``), so
``validate(document, schema)`` is the refusal, and the tests supply both a valid
document and a document mutated to break exactly one rule.

This module is the ONE owner of every question a single case revision settles.
``semantics.check_case_revision`` calls these functions; it does not restate
them.  It used to, and the two disagreed: on an approved case whose reference
check was recorded as NOT RUN with the evaluator-quality cap applied, the rules
here admitted the document and ``semantics`` refused it.  The rules here are
right and the register says so - RFC 0018:383 makes the tri-state survive, only
``ran=true, passed=false`` blocks - so ``semantics`` now asks rather than
answers.  "Not run" and "failed" are two different facts about the world and
this file keeps them apart (see
:func:`rule_admission_requires_completed_validation`).

Numbers, instants and canonical bytes come from ``contracts/cb/primitives.py``.
A counter is read with ``primitives.as_integer``, so ``0`` and ``0.0`` are one
count - the schema admits both under ``"type": "integer"``, and an
``isinstance(value, int)`` here meant a case with zero rebuilds passed the
admission gate when its counters were written as decimals.

The canonicalization used for ``revision_id`` is ``primitives.sorted_json``,
which is the form this identity is already published against (and the one
``traces/eval_task.py:169`` uses).  It is deliberately NOT the RFC 8785 form
used for ``session-event.content_digest``: see the note in ``primitives`` for
why moving it would silently re-identify every case that exists.  What matters
for this pass is that neither form is implemented twice.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path
from typing import Any


def _load_primitives() -> Any:
    """The one shared-semantics module, loaded once under a fixed name.

    ``contracts/cb`` is not a package - ``validate.py`` discovers these modules
    by file location - so there is no package for a relative import to be
    relative to.  The ``sys.modules`` guard is what makes every consumer share
    ONE module object, and therefore one set of predicates.
    """
    # The key ``primitives.load`` itself uses.  It is the SAME string in every
    # module that bootstraps this file, because "which object is primitives?"
    # is one decision: two keys execute two copies, and ``Uncanonical`` then
    # has two identities that no ``except`` clause can span.
    # tests/test_cb_primitives.py pins that there is exactly one.
    name = "cb_contract_primitives"
    if name not in sys.modules:
        path = Path(__file__).resolve().parent / "primitives.py"
        spec = importlib.util.spec_from_file_location(name, path)
        if (
            spec is None or spec.loader is None
        ):  # pragma: no cover - unreachable for a real file
            raise ImportError(f"cannot load the shared primitives from {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[name] = module  # before exec_module, so a re-entrant import sees it
        spec.loader.exec_module(module)
    return sys.modules[name]


primitives = _load_primitives()

#: The fields the revision digest is taken over, in the order ``digest_covers``
#: fixes them.  Provenance and calibration are deliberately outside it
#: (commitment frozen-content-excludes-provenance).
DIGEST_COVERS = (
    "input",
    "allowed_history",
    "starting_state",
    "expected_behaviour",
    "evaluator",
    "execution_limits",
)

#: Highest evaluator-quality an unperformed reference check may leave behind.
NOT_RUN_QUALITY_CAP = 0.6

#: A stability check is three runs or it is not a stability check.
STABILITY_MINIMUM_RUNS = 3


# ------------------------------------------------------------------- identity


def canonical_json(payload: Any) -> str:
    """The exact serialization the revision digest is taken over.

    ``primitives.sorted_json``: RFC 8259 JSON with keys sorted at every level,
    no insignificant whitespace, and non-ASCII characters written literally.
    Defined once there and called here, so this module cannot drift from it -
    the drift between two copies of a serializer is what made one repeat a
    retry on one path and a conflict on the other.
    """
    return primitives.sorted_json(payload)


def covered_content(document: dict) -> dict:
    """The six covered fields and nothing else, keyed by name.

    ``digest_covers`` on the document is authoritative where present, so a
    document that widens or narrows it is digested over what it claims rather
    than over what this module assumes - and the claim is itself pinned by a
    ``const`` in the schema.
    """
    covers = document.get("digest_covers")
    if not isinstance(covers, list) or not all(
        isinstance(name, str) for name in covers
    ):
        covers = list(DIGEST_COVERS)
    return {name: document.get(name) for name in covers}


def revision_digest(document: dict) -> str:
    """``sha256:`` + lowercase hex of SHA-256 over ``canonical_json`` UTF-8 bytes."""
    return primitives.sorted_digest_over(covered_content(document))


def rule_revision_id_is_the_digest_of_its_covered_fields(document: dict) -> list[str]:
    """commitments identity-is-the-content, edit-mints-new-revision.

    Two runs on a silently edited case are two runs on different problems
    pooled under one number.  So the declared id is checked against the content,
    and a mismatch is refused rather than corrected.

    A ``digest_covers`` that names a field the document does not carry is
    refused here too, and instead of the mismatch rather than beside it: the
    digest would otherwise be taken over a ``null`` standing in for the missing
    field, which is a digest of something that is not the document.  It is the
    same decision - the id is the content - so it stays with the rule that owns
    that decision rather than becoming a second rule somewhere else.
    """
    declared = document.get("revision_id")
    if not isinstance(declared, str):
        return []  # the `pattern`/`type` keywords already said this

    covers = document.get("digest_covers")
    if isinstance(covers, list):
        missing = [
            name for name in covers if isinstance(name, str) and name not in document
        ]
        if missing:
            return [
                f"digest_covers names {missing}, which the document does not carry; "
                "the id would be a digest of a null standing in for the content"
            ]

    derived = revision_digest(document)
    if declared != derived:
        return [
            f"revision_id {declared} is not the digest of the fields digest_covers "
            f"names; that content digests to {derived}"
        ]
    return []


def rule_evidence_binds_the_revision_it_was_produced_for(document: dict) -> list[str]:
    """commitments reference-and-negative-controls-bind-the-revision,
    approval-binds-a-revision, edit-invalidates-prior-approval.

    Validation results and an approval are statements about one exact digest.
    Editing a revision mints a new one, and neither the evidence nor the
    approval travels across the change.
    """
    messages: list[str] = []
    revision_id = document.get("revision_id")
    if not isinstance(revision_id, str):
        return messages

    validation = document.get("validation")
    if isinstance(validation, dict):
        produced_for = validation.get("revision_id")
        if isinstance(produced_for, str) and produced_for != revision_id:
            messages.append(
                f"validation.revision_id {produced_for} is evidence for another "
                f"revision; this one is {revision_id}"
            )

    approval = document.get("approval")
    if isinstance(approval, dict):
        binds = approval.get("binds_revision_id")
        if isinstance(binds, str) and binds != revision_id:
            messages.append(
                f"approval.binds_revision_id {binds} approves another revision; "
                f"this one is {revision_id}"
            )

    derived_from = document.get("derived_from")
    if (
        isinstance(derived_from, dict)
        and derived_from.get("revision_id") == revision_id
    ):
        messages.append(
            "derived_from.revision_id names this revision as its own parent"
        )

    return messages


def rule_two_diffs_are_two_artifacts(document: dict) -> list[str]:
    """commitment two-diffs-two-jobs; refusal one_diff_used_twice.

    The patch that builds the starting state and the reference fix that repairs
    it are two different artifacts.  One digest standing in for both means the
    case is asking for the state it was handed.
    """
    starting = document.get("starting_state")
    expected = document.get("expected_behaviour")
    if not isinstance(starting, dict) or not isinstance(expected, dict):
        return []
    reference = expected.get("reference_fix")
    if not isinstance(reference, dict):
        return []
    patch = starting.get("patch_digest")
    fix = reference.get("diff_digest")
    if patch is not None and patch == fix:
        return [
            "starting_state.patch_digest and expected_behaviour.reference_fix."
            f"diff_digest are the same artifact ({patch}); refusal one_diff_used_twice"
        ]
    return []


# ----------------------------------------------------- what the runs can claim


def _int(node: Any, key: str) -> int | None:
    """The integer ``node[key]`` states, or ``None`` when it states no number.

    ``primitives.as_integer`` decides, so ``3`` and ``3.0`` are one count.  The
    schema says ``"type": "integer"`` and admits both spellings; a rule that
    accepted only one of them was a second, narrower definition of "integer"
    living in the same system as the validator's.
    """
    return primitives.as_integer(node.get(key)) if isinstance(node, dict) else None


def rule_counters_never_exceed_their_runs(document: dict) -> list[str]:
    """A count of agreeing runs cannot exceed the runs that were made.

    Zero runs is a truthful record of a check not yet performed - drafts exist
    before validation does (see ``rule_admission_requires_completed_validation``
    for where the execution requirements attach).  What is refused here is a
    record that claims more agreement than it has evidence for, and a record
    that observed a disagreement without saying the case is unstable
    (commitment evaluator-stability-blocks).
    """
    messages: list[str] = []
    validation = document.get("validation")
    if not isinstance(validation, dict):
        return messages

    reconstruction = validation.get("reconstruction")
    if isinstance(reconstruction, dict):
        rebuilds = _int(reconstruction, "rebuilds")
        identical = _int(reconstruction, "identical")
        if rebuilds is not None and identical is not None and identical > rebuilds:
            messages.append(
                f"validation.reconstruction claims {identical} identical rebuilds out of {rebuilds}"
            )
        if rebuilds == 0 and reconstruction.get("divergence_class") is not None:
            messages.append(
                "validation.reconstruction names a divergence_class with no rebuild "
                "to have observed it"
            )

    stability = validation.get("stability")
    if isinstance(stability, dict):
        runs = _int(stability, "runs")
        agreements = _int(stability, "agreements")
        if runs is not None and agreements is not None:
            if agreements > runs:
                messages.append(
                    f"validation.stability claims {agreements} agreements out of {runs} runs"
                )
            elif agreements < runs and stability.get("unstable") is not True:
                messages.append(
                    f"validation.stability records {runs - agreements} disagreeing run(s) "
                    "and does not mark the case unstable"
                )
        if runs is not None and 0 < runs < STABILITY_MINIMUM_RUNS:
            messages.append(
                f"validation.stability records {runs} run(s): a stability check is "
                f"{STABILITY_MINIMUM_RUNS} runs or none (commitment evaluator-stability-blocks)"
            )

    return messages


def rule_stability_baseline_is_the_revisions_frozen_settings(
    document: dict,
) -> list[str]:
    """commitment stability-baseline-frozen-at-creation.

    A stability check run under settings that later changed is not a check of
    this case.  Only a check that was actually run has a baseline to state.
    """
    validation = document.get("validation")
    limits = document.get("execution_limits")
    if not isinstance(validation, dict) or not isinstance(limits, dict):
        return []
    stability = validation.get("stability")
    frozen = limits.get("frozen_settings")
    if not isinstance(stability, dict) or not isinstance(frozen, dict):
        return []
    if not _int(stability, "runs"):
        return []
    declared = stability.get("settings_digest")
    expected = frozen.get("settings_digest")
    if isinstance(declared, str) and isinstance(expected, str) and declared != expected:
        return [
            f"validation.stability.settings_digest {declared} is a result for other "
            f"settings; this revision froze {expected}"
        ]
    return []


def rule_an_unperformed_reference_check_caps_evaluator_quality(
    document: dict,
) -> list[str]:
    """commitment no-end-state-evidence-is-not-a-pass.

    Where there is no end-state evidence the check is recorded as NOT RUN and
    the evaluator-quality score is capped.  A cap that the axis then ignores is
    a cap in name only.

    The other half of the same commitment is here too: a check that did not run
    may not report itself as passed or as reading like a pass.  The absence of
    end-state evidence is recorded, capped and carried onto the review screen -
    it is never converted into a verdict on the way.  Both halves are one
    decision about one block of one document, so they have one owner.
    """
    validation = document.get("validation")
    if not isinstance(validation, dict):
        return []
    check = validation.get("reference_fix_check")
    if not isinstance(check, dict):
        return []

    messages: list[str] = []
    ran, passed = check.get("ran"), check.get("passed")
    reads_as_pass = check.get("reads_as_pass")
    if ran is not True and (passed is True or reads_as_pass is True):
        messages.append(
            f"validation.reference_fix_check records ran={ran!r} yet passed={passed!r}, "
            f"reads_as_pass={reads_as_pass!r}; a check that did not run never reads as a pass"
        )

    cap = check.get("evaluator_quality_cap")
    if not primitives.is_number(cap):
        return messages
    for axis in validation.get("evidence_axes") or []:
        if not isinstance(axis, dict) or axis.get("axis") != "evaluator_quality":
            continue
        value = axis.get("value")
        if primitives.is_number(value) and value > cap:
            messages.append(
                f"the evaluator_quality axis reads {value} against a reference check "
                f"capped at {cap}"
            )
    return messages


# ------------------------------------------------------------ admission gates


def _admission_gates(document: dict) -> list[str]:
    """Where the case is asking to be drawn or approved, name the gate."""
    gates: list[str] = []
    validation = document.get("validation")
    if isinstance(validation, dict) and validation.get("drawable") is True:
        gates.append("drawable")
    if document.get("state") == "approved":
        gates.append("an approved state")
    return gates


def rule_admission_requires_completed_validation(document: dict) -> list[str]:
    """The execution requirements attach at the gate, not at every state.

    A draft exists before its validation runs: the acceptance flow creates a
    draft, a person edits it, and an edit mints a new revision that carries no
    validation results until they are re-run (commitments edit-mints-new-revision,
    reference-and-negative-controls-bind-the-revision).  So zero rebuilds and
    zero stability runs are representable, and are refused only where the
    document asks to enter a comparison.

    At that gate the reconstruction must have been rebuilt at least once, the
    stability check must have made its runs and agreed, and - the part the
    keyword branches missed - a reference check that was PERFORMED must have
    passed.  "Not run" stays distinct from "failed": a check with no end-state
    evidence is recorded, capped and carried onto the review screen, and never
    reads as a pass, but it is not a reference fix that was tried and did not
    work (commitments reference-fix-must-pass, no-end-state-evidence-is-not-a-pass;
    refusal acceptance_unreachable).

    That distinction is the first of the three disagreements this pass
    resolved.  ``semantics`` refused an approved case whose reference check was
    recorded not-run and capped; this rule admits it.  This rule wins: RFC
    0018:383 states the tri-state explicitly, the register's
    ``reference-fix-must-pass`` row names THIS function as refusing a PERFORMED
    check that failed, and
    ``tests/test_cb_case_revision_rules.py:475`` is a positive fixture for the
    not-run case.  Deciding the other way meant changing all three, and the
    reason they say what they say - "not run" and "failed" are different facts
    about the world - is still true.
    """
    gates = _admission_gates(document)
    if not gates:
        return []
    named = " and ".join(gates)

    validation = document.get("validation")
    if not isinstance(validation, dict):
        return []
    messages: list[str] = []

    rebuilds = _int(validation.get("reconstruction"), "rebuilds")
    if rebuilds is not None and rebuilds < 1:
        messages.append(
            f"{named} over a starting state that was never rebuilt "
            "(validation.reconstruction.rebuilds is 0)"
        )

    stability = validation.get("stability")
    runs = _int(stability, "runs")
    if runs is not None and runs < STABILITY_MINIMUM_RUNS:
        messages.append(
            f"{named} over {runs} stability run(s); a case enters a comparison only "
            f"after {STABILITY_MINIMUM_RUNS} runs that agree"
        )
    if isinstance(stability, dict) and stability.get("unstable") is True:
        messages.append(f"{named} for a case that disagrees with itself")

    check = validation.get("reference_fix_check")
    if (
        isinstance(check, dict)
        and check.get("ran") is True
        and check.get("passed") is not True
    ):
        messages.append(
            f"{named} with a reference fix that was applied and did not pass the "
            "check; refusal acceptance_unreachable"
        )

    pre_check = validation.get("pre_check")
    if isinstance(pre_check, dict):
        if pre_check.get("ran") is not True:
            messages.append(
                f"{named} with no pre-check against the untouched starting state"
            )
        elif pre_check.get("passed") is not False:
            messages.append(
                f"{named} over a check that was already green; refusal acceptance_already_passing"
            )

    return messages


RULES = {
    "case_revision_id_is_the_digest_of_its_covered_fields": rule_revision_id_is_the_digest_of_its_covered_fields,
    "case_evidence_binds_the_revision_it_was_produced_for": rule_evidence_binds_the_revision_it_was_produced_for,
    "case_two_diffs_are_two_artifacts": rule_two_diffs_are_two_artifacts,
    "case_counters_never_exceed_their_runs": rule_counters_never_exceed_their_runs,
    "case_stability_baseline_is_the_revisions_frozen_settings": rule_stability_baseline_is_the_revisions_frozen_settings,
    "case_an_unperformed_reference_check_caps_evaluator_quality": rule_an_unperformed_reference_check_caps_evaluator_quality,
    "case_admission_requires_completed_validation": rule_admission_requires_completed_validation,
}

#: The RFC 0018 §6.1 row each rule holds up, declared beside the rule that holds
#: it.  ``semantics`` reads this to label a violation rather than keeping a
#: second table that could name a different commitment for the same rule.
COMMITMENTS = {
    "case_revision_id_is_the_digest_of_its_covered_fields": "identity-is-the-content",
    "case_evidence_binds_the_revision_it_was_produced_for": "reference-and-negative-controls-bind-the-revision",
    "case_two_diffs_are_two_artifacts": "two-diffs-two-jobs",
    "case_counters_never_exceed_their_runs": "evaluator-stability-blocks",
    "case_stability_baseline_is_the_revisions_frozen_settings": "stability-baseline-frozen-at-creation",
    "case_an_unperformed_reference_check_caps_evaluator_quality": "no-end-state-evidence-is-not-a-pass",
    "case_admission_requires_completed_validation": "reference-fix-must-pass",
}


def check(document: Any) -> list[str]:
    """Every cross-field rule, over an arbitrary document.  Empty means admissible.

    ``validate(document, schema)`` reaches the same functions through
    ``x-cb-rules``; this is the direct entry point for a caller holding no
    schema, and the one ``semantics.check_case_revision`` delegates to.
    """
    if not isinstance(document, dict):
        return ["a case revision is an object"]
    errors: list[str] = []
    for name, rule in RULES.items():
        errors += [f"{name}: {message}" for message in rule(document)]
    return errors
