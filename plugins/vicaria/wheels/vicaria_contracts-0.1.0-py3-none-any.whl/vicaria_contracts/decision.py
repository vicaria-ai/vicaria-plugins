"""Decision records: what was decided, how, and who it counts against (RFC 0009 §4.3-§4.4).

WHY THIS EXISTS

Every episode carries a decision record, including the ones where no plan ever
arrived. §2.1 requires a ``decision_id`` on every record, so an unreachable
server would otherwise force a caller to fabricate a plan or drop the linkage —
and both destroy the distinction the record exists to preserve, between a server
that *declined* to recommend and a server that could not be reached.

THE DISTINCTION THAT COSTS MONEY TO LOSE

Origin is not attribution, and conflating them biases a study in the candidate's
favour.

Consider an episode assigned to a candidate policy whose plan then times out.
Executing at the reference and attributing the result *to the reference* deletes
that timeout — and its cost, and whatever the fallback produced — from the
candidate's record. The candidate's measured performance then excludes precisely
the occasions on which it failed to work, which across a study is survivorship
bias with a plausible-sounding justification.

So three facts are recorded separately and none is derived from another:
``assigned_policy`` (what the episode was allocated to), ``origin`` (how the
configuration was arrived at), and ``actual_config`` (what in fact ran).
:meth:`DecisionRecord.attributed_to` reads the first — intention to treat — and
:meth:`DecisionRecord.trains` reads the third, because a fallback run trains the
reference's model of itself and not the candidate's. Two questions, two fields,
and the reason to keep all three.

A REFUSED EPISODE IS STILL AN EPISODE

``cannot_execute`` requires a decision to be recorded when nothing ran, so
``actual_config`` is optional. Requiring one would force a caller to fabricate
an executed configuration or drop the refusal from the record entirely, and both
destroy exactly what the refusal is evidence of. :meth:`DecisionRecord.trains`
returns ``None`` there: a refusal says something about the decision and nothing
about any configuration's performance, and inventing one would create training
evidence for a run that never happened.

Attribution is unaffected — a refused episode assigned to a candidate still
counts against that candidate, because "this policy could not be executed" is a
true and decision-relevant fact about it.

WHAT IT DOES NOT PROVE

Every identifier here is a string a caller supplies, so these records prove
self-consistency and never authenticity — the same limit RFC 0008 states for
selection provenance. A well-formed ``assigned_policy`` naming a policy this
episode was never allocated to reads back clean.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Any

from vicaria_contracts._wire import (
    optional_enum,
    optional_str,
    require_enum,
    require_mapping,
    require_schema,
    require_str,
)
from vicaria_contracts.capability import Dimension
from vicaria_contracts.plan import Configuration

DECISION_RECORD_SCHEMA_VERSION = "vicaria.decision-record.v1"
APPLICATION_RECORD_SCHEMA_VERSION = "vicaria.application-record.v1"

#: What an unassigned episode's costs and outcomes count against. Not a policy
#: id: no policy was allocated, so naming one would invent an allocation.
REFERENCE = "reference"


class DecisionOrigin(str, Enum):
    """How the configuration for this episode was arrived at."""

    SERVED = "served"  # a plan came back and was validated
    LOCAL = "local"  # a cached policy bundle decided, with no round trip
    UNAVAILABLE = "unavailable"  # no plan and no usable bundle; not a decision at all


class UnavailableReason(str, Enum):
    """Why no decision was available. Closed, because these are counted."""

    UNREACHABLE = "unreachable"
    EXPIRED = "expired"
    REFUSED = "refused"
    TIMED_OUT = "timed_out"


@dataclass(frozen=True, slots=True)
class ConfigurationDiff:
    """What changed between the original and effective requests, by dimension.

    Typed, not textual (§2.1). A prompt addition, a model substitution and a
    tool-profile change have different validity rules, and a textual diff erases
    that distinction exactly where it matters.

    Derived rather than stored — see :meth:`ApplicationRecord.diff`.
    """

    changes: Mapping[Dimension, tuple[str, str]]

    def __post_init__(self) -> None:
        object.__setattr__(self, "changes", MappingProxyType(dict(self.changes)))

    def __bool__(self) -> bool:
        return bool(self.changes)

    def dimensions(self) -> frozenset[Dimension]:
        return frozenset(self.changes)

    def to_dict(self) -> dict[str, Any]:
        return {
            d.value: {"original": before, "effective": after}
            for d, (before, after) in sorted(
                self.changes.items(), key=lambda kv: kv[0].value
            )
        }


@dataclass(frozen=True, slots=True)
class ApplicationRecord:
    """The four records an applied plan owes (§2.1).

    ``diff`` is a method rather than a field. A stored diff is a derived value
    that can disagree with the two configurations it summarizes — and a diff
    that disagrees with its own inputs is worse than none, because it is the
    artifact a later investigation trusts.
    """

    decision_id: str
    original: Configuration
    effective: Configuration

    def __post_init__(self) -> None:
        if not isinstance(self.decision_id, str) or not self.decision_id:
            raise ValueError(
                f"decision_id must be a nonempty string, got {self.decision_id!r}"
            )
        for name in ("original", "effective"):
            if not isinstance(getattr(self, name), Configuration):
                raise ValueError(f"{name} must be a Configuration")

    def diff(self) -> ConfigurationDiff:
        changed = self.effective.changed_from(self.original)
        return ConfigurationDiff(
            {d: (self.original.value(d), self.effective.value(d)) for d in changed}
        )

    def applied_nothing(self) -> bool:
        """True when the effective request equals the original.

        Distinct from a failure: a ``retain`` plan applies nothing and is a
        success. It matters because "the recommendation did not help" and "the
        recommendation was never applied" are the same thing in the evidence
        without it.
        """
        return not self.diff()

    def to_dict(self) -> dict[str, Any]:
        """All four things §2.1 requires, as one record.

        The diff is emitted alongside the two configurations it summarizes even
        though it is derivable from them, because the reader of an uploaded
        record is not this process and a downstream consumer should not have to
        reimplement :meth:`diff` to answer "what changed". It stays *derived* on
        the way out, so it cannot disagree with its own inputs — which is the
        property :meth:`diff` being a method rather than a field buys.
        """
        return {
            "schema": APPLICATION_RECORD_SCHEMA_VERSION,
            "decision_id": self.decision_id,
            "original": {d.value: self.original.value(d) for d in Dimension},
            "effective": {d.value: self.effective.value(d) for d in Dimension},
            "diff": self.diff().to_dict(),
            "applied_nothing": self.applied_nothing(),
        }

    @classmethod
    def from_dict(cls, payload: Any) -> ApplicationRecord:
        """Read an application record off the wire.

        The stored ``diff`` is **not** read back. It is derived from the two
        configurations here exactly as it is on the way out, so a payload whose
        diff disagreed with its own configurations cannot import that
        disagreement — and a diff that disagrees with its inputs is worse than
        none, because it is the artifact a later investigation trusts.
        """
        obj = require_mapping(payload, "application record")
        require_schema(obj, APPLICATION_RECORD_SCHEMA_VERSION)
        return cls(
            decision_id=require_str(obj, "decision_id"),
            original=Configuration.from_dict(obj.get("original")),
            effective=Configuration.from_dict(obj.get("effective")),
        )


@dataclass(frozen=True, slots=True)
class DecisionRecord:
    """One episode's decision, origin, assignment and outcome configuration."""

    decision_id: str
    episode_id: str
    origin: DecisionOrigin
    actual_config: Configuration | None
    assigned_policy: str | None = None
    policy_bundle_id: str | None = None
    unavailable_reason: UnavailableReason | None = None

    def __post_init__(self) -> None:
        for name in ("decision_id", "episode_id"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value:
                raise ValueError(f"{name} must be a nonempty string, got {value!r}")
        if not isinstance(self.origin, DecisionOrigin):
            raise ValueError(
                f"origin must be a DecisionOrigin, got {type(self.origin).__name__}"
            )
        if self.actual_config is not None and not isinstance(
            self.actual_config, Configuration
        ):
            raise ValueError(
                f"actual_config must be a Configuration or None, "
                f"got {type(self.actual_config).__name__}"
            )

        if self.origin is DecisionOrigin.UNAVAILABLE:
            if self.unavailable_reason is None:
                raise ValueError(
                    "an unavailable record must say why — unreachable, expired, refused and "
                    "timed out are different operational facts"
                )
            if self.policy_bundle_id is not None:
                raise ValueError(
                    "an unavailable record names no bundle: a usable bundle would have "
                    "made this a local decision"
                )
        else:
            if self.unavailable_reason is not None:
                raise ValueError(
                    f"a {self.origin.value} decision was available, so it carries no "
                    "unavailable reason"
                )
            if self.origin is DecisionOrigin.LOCAL and not self.policy_bundle_id:
                raise ValueError(
                    "a local decision must name the bundle that produced it, or it cannot "
                    "be replayed and is not auditable as a decision"
                )
        if self.assigned_policy is not None and (
            not isinstance(self.assigned_policy, str) or not self.assigned_policy
        ):
            raise ValueError(
                f"assigned_policy must be a nonempty string, got {self.assigned_policy!r}"
            )

    def attributed_to(self) -> str:
        """Who this episode's costs and outcomes count against.

        Intention to treat: the assigned policy, whatever actually executed. A
        candidate that frequently times out into reference execution is a
        candidate that frequently costs a fallback and delivers reference
        quality, and that is a true and decision-relevant fact about it.

        Only an episode with no assignment at all is attributable to the
        reference outright, because there is nothing else for it to belong to.
        """
        return REFERENCE if self.assigned_policy is None else self.assigned_policy

    def trains(self) -> Configuration | None:
        """Which configuration this episode is evidence *about*.

        The actual one, or ``None`` when nothing ran. Attribution and training
        read different fields on purpose: a fallback run trains the reference's
        model of itself, not the candidate's, while still counting against the
        candidate above.

        A refused episode returns ``None`` rather than a configuration, because
        a refusal is evidence about the *decision* and about nothing's
        performance. Handing back any configuration here would create training
        evidence for a run that never happened — and the obvious candidates are
        both wrong: the reference did not execute, and the candidate was
        refused.
        """
        return self.actual_config

    def executed(self) -> bool:
        """False when the decision refused and nothing reached a provider."""
        return self.actual_config is not None

    def is_fallback(self) -> bool:
        """True when an assigned episode ran without a decision behind it."""
        return (
            self.origin is DecisionOrigin.UNAVAILABLE
            and self.assigned_policy is not None
            and self.executed()
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": DECISION_RECORD_SCHEMA_VERSION,
            "decision_id": self.decision_id,
            "episode_id": self.episode_id,
            "origin": self.origin.value,
            "actual_config": (
                {d.value: self.actual_config.value(d) for d in Dimension}
                if self.actual_config is not None
                else None
            ),
            "executed": self.executed(),
            "assigned_policy": self.assigned_policy,
            "policy_bundle_id": self.policy_bundle_id,
            "unavailable_reason": (
                self.unavailable_reason.value if self.unavailable_reason else None
            ),
            "attributed_to": self.attributed_to(),
        }

    @classmethod
    def from_dict(cls, payload: Any) -> DecisionRecord:
        """Read a decision record off the wire.

        ``actual_config`` is required to be *present*, though it may be ``null``.
        A null one is a strong claim — nothing executed, this episode is a
        refusal — and reading an absent key as that claim lets a serializer that
        dropped the field turn an executed episode into a refusal. The record
        would then be internally consistent, count against its assigned policy as
        a refusal, and train nothing, which is the shape of a study quietly
        missing its executions.
        """
        obj = require_mapping(payload, "decision record")
        require_schema(obj, DECISION_RECORD_SCHEMA_VERSION)
        if "actual_config" not in obj:
            raise ValueError(
                "actual_config is required, explicitly null when nothing executed — an "
                "absent key would read as a refusal that never happened"
            )
        raw_config = obj["actual_config"]
        actual_config = (
            None if raw_config is None else Configuration.from_dict(raw_config)
        )

        # `executed` is derived on the way out, so on the way in it is a claim to
        # check rather than a field to read. A payload asserting both `executed`
        # and a null configuration disagrees with itself, and silently believing
        # the configuration would discard the half that says a run happened.
        if "executed" in obj:
            executed = obj["executed"]
            if not isinstance(executed, bool):
                raise ValueError(
                    f"executed must be a bool, got {type(executed).__name__}"
                )
            if executed != (actual_config is not None):
                raise ValueError(
                    f"executed is {executed} but actual_config is "
                    f"{'absent' if actual_config is None else 'present'}; the payload "
                    "contradicts itself about whether anything ran"
                )

        return cls(
            decision_id=require_str(obj, "decision_id"),
            episode_id=require_str(obj, "episode_id"),
            origin=require_enum(obj, "origin", DecisionOrigin),
            actual_config=actual_config,
            assigned_policy=optional_str(obj, "assigned_policy"),
            policy_bundle_id=optional_str(obj, "policy_bundle_id"),
            unavailable_reason=optional_enum(
                obj, "unavailable_reason", UnavailableReason
            ),
        )
