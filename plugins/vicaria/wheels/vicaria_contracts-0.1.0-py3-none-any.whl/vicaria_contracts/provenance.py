"""Selection provenance — why a run was chosen for judging (RFC 0008).

WHY THIS EXISTS

RFC 0003 §8 — Draft, so provisional — proposes stratified judging: every
failed, truncated and
escalated run, and a sampled fraction of the clean ones. That is the right
policy and it makes every rate computed from the judged set wrong unless the
sample is reweighted. The inclusion probability needed to reweight it is
knowable only at dispatch, and nothing recorded it — a stored ``RubricScore``
gives no hint whether its run was judged because every run in its stratum is
judged, or because it won a 1-in-20 draw.

So this module records. It does not aggregate: estimators belong to whoever
knows the estimand, the frame and the finite-population context, and
``ScoreCollection`` already draws that line for scores.

WHAT IT DOES NOT PROVE

Every identifier here is a string a caller supplies. The constructors refuse
malformed records, the factory refuses misattributed scores, and the ledger
refuses contradictory ones — and all of that is *self-consistency*, never
authenticity. A well-formed ``content_task_id`` belonging to a different task
reads back clean. RFC 0007 specifies the authority-issued receipt that would
close the gap, along with the attempt-scoped capture storage and per-tier
issuer it depends on. Until those exist, treat these records the way
``run_analysis`` already labels its own fields: unverified.

WHAT IS ENFORCED HERE

Records are frozen and validated at construction. :func:`record_outcome` is the
supported construction path for ``JudgmentOutcome`` — a guard against accident,
not enforced authority, since the sentinel it checks is importable — and it
binds a score to the rubric, the
judge and the *content* task it claims. Not to the run: ``RubricScore`` has no
run or attempt field, so a score produced while judging a different run of the
same ``EvalTask`` satisfies every comparison. Closing that is RFC 0007 §2, and
it is why the check below is a consistency check and not an attribution one.

``ProvenanceLedger`` is the reference admission semantics an ingest layer must
implement: append-only, replay-idempotent, and refusing — rather than
resolving — any contradiction about what ran.
"""

from __future__ import annotations

import math
from collections.abc import Mapping
from dataclasses import InitVar, dataclass, field
from enum import Enum
from types import MappingProxyType
from typing import Any

from vicaria_contracts.rubrics import Judge, JudgeKind, RubricScore
from vicaria_contracts.timestamps import timestamp_to_unix_nanos

SELECTION_CENSUS = "census"
RUN_SELECTION_SCHEMA_VERSION = "vicaria.run-selection.v2"


class SelectionMode(str, Enum):
    PROBABILITY = "probability"  # randomized; every eligible unit had p > 0
    PURPOSIVE = "purposive"  # deliberately chosen; NOT a probability sample


class RunIdKind(str, Enum):
    """What ``run_id`` identifies. Never inferred — two meanings behind one
    field is the ambiguity §3 argues against, so it is recorded."""

    ATTEMPT = "attempt"  # one execution; the primary contract
    DISPATCH_TERMINAL = (
        "dispatch_terminal"  # the accepted terminal attempt of a dispatch
    )


def _require_str(payload: Mapping[str, Any], key: str) -> str:
    """A wire identifier is a nonempty string or it is not an identifier.

    ``str(payload[key])`` was worse than no check: JSON ``null`` became the
    join key ``"None"``, ``true`` became ``"True"``, and an object became its
    ``repr`` — all nonempty, all passing the ``if not getattr(...)`` guards in
    ``__post_init__``, and all joining to nothing. A malformed identifier must
    fail at the boundary, where the payload is still available to name.
    """
    if key not in payload:
        raise ValueError(f"{key} is required")
    value = payload[key]
    if not isinstance(value, str) or not value:
        raise ValueError(f"{key} must be a nonempty string, got {type(value).__name__}")
    return value


def _require_mapping(payload: Any, what: str) -> Mapping[str, Any]:
    """A wire record is a JSON object, and every reader must say so first.

    ``payload.get(...)`` on a JSON array or ``null`` raises ``AttributeError``,
    which is an implementation detail leaking out where a deliberate
    malformed-wire ``ValueError`` belongs.
    """
    if not isinstance(payload, Mapping):
        raise ValueError(
            f"{what} payload must be a JSON object, got {type(payload).__name__}"
        )
    return payload


def _require_enum(payload: Mapping[str, Any], key: str, enum_type: type) -> Any:
    """An enum-typed wire field, refused deliberately rather than by accident.

    ``EnumType(payload["k"])`` raises ``KeyError`` when the field is absent —
    an implementation detail leaking where the malformed-wire ``ValueError``
    belongs, and the same failure ``_require_str`` exists to prevent for
    strings.
    """
    raw = _require_str(payload, key)
    try:
        return enum_type(raw)
    except ValueError:
        valid = sorted(m.value for m in enum_type)
        raise ValueError(f"{key} must be one of {valid}, got {raw!r}") from None


def _require_id(value: Any, name: str) -> None:
    """An identifier is a nonempty ``str``. Truthiness is not that check.

    ``if not self.x`` admits ``True``, ``1``, and any non-empty object, and
    ``accepted_lease_id=True`` then serializes as JSON ``true`` — acceptance
    evidence that is not even a string. The constructor is the boundary here,
    because ``_require_str`` only guards the *reader*.
    """
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} must be a nonempty string, got {value!r}")


def _optional_str(payload: Mapping[str, Any], key: str) -> str | None:
    """Absent or JSON null means absent; anything else must be a real id."""
    if payload.get(key) is None:
        return None
    return _require_str(payload, key)


def _check_probability(value: Any, field_name: str) -> None:
    """Reject bools, non-reals, and anything outside (0, 1].

    ``bool`` is an ``int`` subclass, so ``0.0 < True <= 1.0`` passes a naive
    range check and then serializes as JSON ``true``.
    """
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError(
            f"{field_name} must be a real number, got {type(value).__name__}"
        )
    if not math.isfinite(value):
        raise ValueError(f"{field_name} must be finite")
    if not 0.0 < value <= 1.0:
        raise ValueError(
            f"{field_name} {value} outside (0, 1] — 0 means it could not be drawn"
        )


def _check_mode(mode: Any, probability: Any, what: str) -> None:
    if not isinstance(mode, SelectionMode):
        raise ValueError(f"mode must be a SelectionMode, got {type(mode).__name__}")
    if mode is SelectionMode.PROBABILITY:
        if probability is None:
            raise ValueError(
                f"a probability {what} must state its probability — "
                "absent must never be read as census"
            )
        _check_probability(probability, "probability")
    elif probability is not None:
        raise ValueError(f"a purposive {what} has no inclusion probability")


@dataclass(frozen=True, slots=True)
class RunSelection:
    """Why one run entered the judged set, recorded at selection time.

    ``probability`` is the probability this run is selected from
    ``frame_instance_id``'s eligible population under ``policy_id``. A policy
    that stratifies at 5% and then RANDOMLY drops 40% to a budget records 0.03.
    A DETERMINISTIC budget gives later eligible units probability zero, which
    violates positivity and makes projection invalid rather than imprecise;
    such a policy must randomize or record PURPOSIVE. A hand-picked calibration
    set is PURPOSIVE, never a census.
    """

    selection_id: str
    run_id: str
    run_id_kind: RunIdKind  # what run_id means; no default, absence is refused
    execution_dispatch_id: str  # server EXECUTION dispatch — retries share it.
    # Distinct namespace from JudgmentDispatch.dispatch_id,
    # which identifies a judge call. Both were `dispatchId`
    # on the wire until v1 froze; they are not the same key.
    logical_task_id: str  # the work, across every redispatch of it — see RFC 0007 §1.
    # NOT the content hash: two unrelated logical tasks can
    # have byte-identical content, and one logical task can
    # be redispatched, so neither implies the other.
    content_task_id: (
        str  # CLAIMED EvalTask hash, unverified — not EvalRecord.task_id (RFC 0007 §1)
    )
    stratum: str
    policy_id: str  # the sampling rule and its version
    frame_instance_id: str  # the concrete eligible population
    accepted_lease_id: str | None = (
        None  # required iff run_id_kind is DISPATCH_TERMINAL
    )
    mode: SelectionMode = (
        SelectionMode.PROBABILITY
    )  # default PROBABILITY *requires* a probability
    probability: float | None = (
        None  # required under PROBABILITY, refused under PURPOSIVE
    )
    # init=False: a caller-set version is emitted by ``to_dict()`` and then
    # rejected by this record's own reader. The version describes the shape,
    # so it is not the caller's to choose.
    schema_version: str = field(default=RUN_SELECTION_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        for name in (
            "selection_id",
            "run_id",
            "execution_dispatch_id",
            "logical_task_id",
            "content_task_id",
            "stratum",
            "policy_id",
            "frame_instance_id",
        ):
            _require_id(getattr(self, name), name)
        if not isinstance(self.run_id_kind, RunIdKind):
            raise ValueError(
                "run_id_kind must be a RunIdKind — absence must not be inferred"
            )
        if self.accepted_lease_id is not None:
            _require_id(self.accepted_lease_id, "accepted_lease_id")
        if self.run_id_kind is RunIdKind.DISPATCH_TERMINAL:
            if self.run_id != self.execution_dispatch_id:
                raise ValueError(
                    "a dispatch_terminal selection's run_id IS its execution_dispatch_id; "
                    "two different values mean the unit is undefined"
                )
            if not self.accepted_lease_id:
                raise ValueError(
                    "a dispatch_terminal selection must name the accepted lease — "
                    "'the terminal attempt' without it is an assertion, not evidence"
                )
        elif self.accepted_lease_id is not None:
            raise ValueError(
                "an attempt selection already identifies the attempt; "
                "accepted_lease_id would be a second, unchecked answer"
            )
        _check_mode(self.mode, self.probability, "selection")

    @classmethod
    def census(
        cls,
        *,
        selection_id: str,
        run_id: str,
        run_id_kind: RunIdKind,
        execution_dispatch_id: str,
        logical_task_id: str,
        content_task_id: str,
        policy_id: str,
        frame_instance_id: str,
        accepted_lease_id: str | None = None,
        stratum: str = SELECTION_CENSUS,
    ) -> RunSelection:
        """``run_id_kind`` is keyword-required here too. A convenience default
        would infer the very discriminator ``RunIdKind`` says is never inferred,
        and a census helper is exactly where that would go unnoticed."""
        return cls(
            selection_id=selection_id,
            run_id=run_id,
            run_id_kind=run_id_kind,
            execution_dispatch_id=execution_dispatch_id,
            logical_task_id=logical_task_id,
            content_task_id=content_task_id,
            accepted_lease_id=accepted_lease_id,
            stratum=stratum,
            policy_id=policy_id,
            frame_instance_id=frame_instance_id,
            probability=1.0,
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schemaVersion": self.schema_version,
            "selectionId": self.selection_id,
            "runId": self.run_id,
            "runIdKind": self.run_id_kind.value,
            "executionDispatchId": self.execution_dispatch_id,
            "logicalTaskId": self.logical_task_id,
            "contentTaskId": self.content_task_id,
            "acceptedLeaseId": self.accepted_lease_id,
            "stratum": self.stratum,
            "policyId": self.policy_id,
            "frameInstanceId": self.frame_instance_id,
            "mode": self.mode.value,
            "probability": self.probability,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> RunSelection:
        payload = _require_mapping(payload, "run-selection")
        version = payload.get("schemaVersion")
        if version != RUN_SELECTION_SCHEMA_VERSION:
            raise ValueError(f"unsupported run-selection schema {version!r}")
        return cls(
            selection_id=_require_str(payload, "selectionId"),
            run_id=_require_str(payload, "runId"),
            run_id_kind=_require_enum(payload, "runIdKind", RunIdKind),
            execution_dispatch_id=_require_str(payload, "executionDispatchId"),
            logical_task_id=_require_str(payload, "logicalTaskId"),
            content_task_id=_require_str(payload, "contentTaskId"),
            accepted_lease_id=_optional_str(payload, "acceptedLeaseId"),
            stratum=_require_str(payload, "stratum"),
            policy_id=_require_str(payload, "policyId"),
            frame_instance_id=_require_str(payload, "frameInstanceId"),
            mode=_require_enum(payload, "mode", SelectionMode),
            probability=payload.get("probability"),
        )


JUDGMENT_DISPATCH_SCHEMA_VERSION = "vicaria.judgment-dispatch.v2"


@dataclass(frozen=True, slots=True)
class JudgmentDispatch:
    """One attempt to obtain one judgment, recorded BEFORE the judge is invoked.

    Written first because a judge that crashes before writeback would otherwise
    take its provenance with it — §1's gap, one level down. A dispatch with no
    outcome is a visible loose end; a judgment never recorded as dispatched is
    invisible.

    Causal keys, not inference: ``selection_id`` names the selection this serves
    (matching on ``run_id`` alone cannot separate overlapping frame instances,
    nor a production judgment from a calibration one), and
    ``parent_dispatch_id`` names the judgment whose outcome triggered a
    conditional adjudication.

    ``probability`` is the LOCAL conditional probability of this dispatch given
    its parent — for a root dispatch, given the selection — with respect to
    THIS dispatch's own ``policy_id`` and ``frame_instance_id``. A conditional
    draw is its own sample from its own population (§4.1); the parent names a
    unit, not a frame.

    The marginal inclusion probability is NOT the product along a chain when a
    unit is reachable by several paths; it is a union over them (§4.1).
    Composing either is estimation and is deferred (§8), so no field here
    pretends to hold it.

    ``dispatch_id`` is the idempotency key and what makes a retry a new attempt
    rather than a rejected duplicate.
    """

    dispatch_id: str
    selection_id: str
    run_id: str
    rubric_ref: str
    judge: Judge  # full Judge, not identity alone
    dispatched_at: str  # RFC3339; validated and ordered as an instant
    policy_id: str  # THIS draw's rule, not the selection's
    frame_instance_id: str  # THIS draw's concrete population
    stratum: str  # THIS draw's stratum within that population.
    # §4.1 calls a conditional dispatch its own
    # sample under its own rule; a sample without
    # its stratum has unrecoverable membership,
    # and stratum is dispatch-time-only knowledge
    parent_dispatch_id: str | None = None
    # A reattempt keeps its parent, so this is what says WHICH attempt it repeats.
    reattempt_of_dispatch_id: str | None = (
        None  # the failed attempt this repeats; same unit (§4.5)
    )
    mode: SelectionMode = (
        SelectionMode.PROBABILITY
    )  # default PROBABILITY *requires* a probability
    probability: float | None = (
        None  # required under PROBABILITY, refused under PURPOSIVE
    )
    # init=False: a caller-set version is emitted by ``to_dict()`` and then
    # rejected by this record's own reader. The version describes the shape,
    # so it is not the caller's to choose.
    schema_version: str = field(default=JUDGMENT_DISPATCH_SCHEMA_VERSION, init=False)

    def __post_init__(self) -> None:
        for name in (
            "dispatch_id",
            "selection_id",
            "run_id",
            "rubric_ref",
            "dispatched_at",
            "policy_id",
            "frame_instance_id",
            "stratum",
        ):
            _require_id(getattr(self, name), name)
        if self.parent_dispatch_id is not None:
            _require_id(self.parent_dispatch_id, "parent_dispatch_id")
        if self.parent_dispatch_id == self.dispatch_id:
            # The only chain defect visible without a store. The rest —
            # existence, matching selection/run/rubric, temporal order,
            # acyclicity beyond length one — need the other records, so they
            # live in `ProvenanceLedger.add_dispatch` (§4.5).
            raise ValueError("a dispatch cannot be its own parent")
        if self.reattempt_of_dispatch_id is not None:
            _require_id(self.reattempt_of_dispatch_id, "reattempt_of_dispatch_id")
            if self.reattempt_of_dispatch_id == self.dispatch_id:
                raise ValueError("a dispatch cannot be its own reattempt")
        if not isinstance(self.judge, Judge):
            raise ValueError(
                "judge must be a Judge — identity alone cannot distinguish kinds"
            )
        _require_id(self.judge.identity, "judge.identity")
        if not isinstance(self.judge.kind, JudgeKind):
            raise ValueError("judge.kind must be a JudgeKind")
        _check_mode(self.mode, self.probability, "dispatch")
        timestamp_to_unix_nanos(
            self.dispatched_at, "dispatched_at"
        )  # raises on unparseable

    @property
    def dispatched_ns(self) -> int:
        """Parsed instant. Ordering by the STRING is wrong: '10:00+08:00'
        sorts after '03:00Z' while being an hour earlier."""
        return timestamp_to_unix_nanos(self.dispatched_at, "dispatched_at")

    @property
    def order_key(self) -> tuple[int, str]:
        """Total order for resolution: instant, then dispatch_id as the tie rule."""
        return (self.dispatched_ns, self.dispatch_id)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schemaVersion": self.schema_version,
            "dispatchId": self.dispatch_id,
            "selectionId": self.selection_id,
            "runId": self.run_id,
            "rubricRef": self.rubric_ref,
            "judge": self.judge.to_dict(),
            "dispatchedAt": self.dispatched_at,
            "policyId": self.policy_id,
            "frameInstanceId": self.frame_instance_id,
            "stratum": self.stratum,
            "parentDispatchId": self.parent_dispatch_id,
            "reattemptOfDispatchId": self.reattempt_of_dispatch_id,
            "mode": self.mode.value,
            "probability": self.probability,
        }

    @classmethod
    def from_dict(cls, payload: Mapping[str, Any]) -> JudgmentDispatch:
        payload = _require_mapping(payload, "judgment-dispatch")
        version = payload.get("schemaVersion")
        if version != JUDGMENT_DISPATCH_SCHEMA_VERSION:
            raise ValueError(f"unsupported judgment-dispatch schema {version!r}")
        judge = _require_mapping(payload.get("judge"), "judge")
        return cls(
            dispatch_id=_require_str(payload, "dispatchId"),
            selection_id=_require_str(payload, "selectionId"),
            run_id=_require_str(payload, "runId"),
            rubric_ref=_require_str(payload, "rubricRef"),
            judge=Judge(
                kind=_require_enum(judge, "kind", JudgeKind),
                identity=_require_str(judge, "identity"),
            ),
            dispatched_at=_require_str(payload, "dispatchedAt"),
            policy_id=_require_str(payload, "policyId"),
            frame_instance_id=_require_str(payload, "frameInstanceId"),
            stratum=_require_str(payload, "stratum"),
            # Optional, but when present it is a join key like any other. The
            # previous reader passed it through untouched, so a number or an
            # object became a parent pointer.
            parent_dispatch_id=_optional_str(payload, "parentDispatchId"),
            reattempt_of_dispatch_id=_optional_str(payload, "reattemptOfDispatchId"),
            mode=_require_enum(payload, "mode", SelectionMode),
            probability=payload.get("probability"),
        )


JUDGMENT_OUTCOME_SCHEMA_VERSION = "vicaria.judgment-outcome.v2"


class OutcomeStatus(str, Enum):
    SCORED = "scored"
    REFUSED = "refused"  # judge or pack declined — undecidable evidence
    ERROR = "error"  # dispatch, transport, or parse failure


#: §4.5's decisive set: the statuses that constitute a verdict. `ERROR` is a
#: failure to obtain one, so it is excluded — and a reattempt repeats exactly
#: that failure, which is why it may not name a decisive predecessor.
DECISIVE_STATUSES = frozenset({OutcomeStatus.SCORED, OutcomeStatus.REFUSED})


_FACTORY_ONLY = object()


@dataclass(frozen=True, slots=True)
class JudgmentOutcome:
    """The terminal state of one dispatch.

    A tagged union: each status permits exactly its own payload. SCORED with an
    ``error_detail``, or ERROR with an ``undecided`` map, is not a record with a
    stray field — it is two claims about what happened.

    :func:`record_outcome` is the only SUPPORTED way to build one, and the
    sentinel below turns a bare ``JudgmentOutcome(...)`` into an error rather
    than a silently unbound record. An earlier draft asked for that in prose
    only, while leaving a constructor whose checks covered tagged-union shape
    alone — so a SCORED outcome for the wrong task, rubric and judge
    constructed and serialized cleanly.

    It is a guard against accident, not enforced authority. Python has no
    module-private binding, so a caller who imports the sentinel can construct
    any outcome, and a coherent fabricated one is admitted by the ledger and
    resolves normally. Only the relational checks in
    :meth:`ProvenanceLedger.add_outcome` bite, and only on records that
    contradict what the ledger already holds. See the module docstring.
    """

    dispatch_id: str
    status: OutcomeStatus
    score: RubricScore | None = None  # required by SCORED, refused by the other two
    undecided: Mapping[str, str] | None = (
        None  # required by REFUSED, refused by the other two
    )
    error_detail: str | None = None  # required by ERROR, refused by the other two
    # When the judge FINISHED. Outcome presence proves ingestion order only, so
    # without this a conditional child stamped 00:05 is admissible after a
    # parent whose result actually landed at 00:10 — the check would be
    # comparing the child to the parent's *dispatch* time. RFC3339, validated
    # and compared as an instant. RFC 0007 §4 requires the result attestation to cover
    # it; until then it is producer-asserted like everything else here.
    completed_at: str | None = (
        None  # required by SCORED/REFUSED; absent bars any child (§4.5)
    )
    # init=False: the version describes the shape, so it is not the caller's
    # to choose. (This record has no reader — RFC 0007 §5 — so unlike the other two
    # there is nothing here that would reject a forged version downstream,
    # which is a reason to pin it at construction, not a reason to skip it.)
    schema_version: str = field(default=JUDGMENT_OUTCOME_SCHEMA_VERSION, init=False)
    # Not data, and NOT a proof of anything. This is an accidental-misuse guard:
    # it makes `record_outcome()` the obvious way in and turns a bare
    # `JudgmentOutcome(...)` into an immediate TypeError. It is not a capability.
    # Python has no module-private binding, so `_FACTORY_ONLY` is importable and
    # a caller who imports it constructs any outcome it likes, including one
    # carrying a score for a different task. Verified, not assumed.
    #
    # What survives that is relational, not structural: `ProvenanceLedger`
    # re-derives the binding at admission against the dispatch it already holds,
    # so the forged outcome above is refused there. That is the check to rely
    # on. A type that could *prove* factory provenance needs a distinct
    # untrusted wire form promoted only during authenticated admission — RFC
    # 0007 §5, which owns the reader, not something a sentinel can do.
    #
    # InitVar, NOT a stored field. A stored one is copied by
    # ``dataclasses.replace()``, so replacing a legitimately built outcome with
    # a score from another task inherited the token, passed ``__post_init__``
    # and serialized forged provenance. As an InitVar it is consumed at
    # construction and never held, so ``replace()`` cannot carry it — which is
    # what this guard is genuinely good for.
    _factory: InitVar[Any] = None

    def __post_init__(self, _factory: Any) -> None:
        if _factory is not _FACTORY_ONLY:
            raise TypeError(
                "build a JudgmentOutcome through record_outcome() — direct "
                "construction skips the binding checks it exists to enforce"
            )
        # An outcome with no dispatch has no provenance. `_require_id`, not
        # truthiness — this was the last `if not self.x` id guard in the RFC.
        _require_id(self.dispatch_id, "dispatch_id")
        # The token proves the factory was *called*, not that its checks ran on
        # this payload — and it is an importable module attribute, so a caller
        # can supply it. Type the payload here too: an underscore name is a
        # convention, never a capability boundary.
        if self.score is not None and not isinstance(self.score, RubricScore):
            raise ValueError(
                f"score must be a RubricScore, got {type(self.score).__name__}"
            )
        if not isinstance(self.status, OutcomeStatus):
            raise ValueError(
                f"status must be an OutcomeStatus, got {type(self.status).__name__}"
            )
        if self.completed_at is not None:
            timestamp_to_unix_nanos(self.completed_at, "completed_at")
        if self.error_detail is not None:
            _require_id(self.error_detail, "error_detail")
        if self.undecided is not None:
            if not isinstance(self.undecided, Mapping):
                raise ValueError("undecided must be a mapping of criterion -> reason")
            for key, reason in self.undecided.items():
                _require_id(key, "undecided key")
                _require_id(reason, f"undecided[{key!r}]")
        allowed = {
            OutcomeStatus.SCORED: ("score",),
            OutcomeStatus.REFUSED: ("undecided",),
            OutcomeStatus.ERROR: ("error_detail",),
        }[self.status]
        for field_name in ("score", "undecided", "error_detail"):
            value = getattr(self, field_name)
            if field_name in allowed:
                if not value:
                    raise ValueError(f"{self.status.value} requires {field_name}")
            elif value is not None:
                raise ValueError(f"{self.status.value} cannot carry {field_name}")
        if self.undecided is not None:
            # The caller keeps a reference to the mapping it passed; without a
            # copy a "frozen" refusal can be emptied after construction and
            # serialize as null.
            object.__setattr__(
                self, "undecided", MappingProxyType(dict(self.undecided))
            )

        if self.status in DECISIVE_STATUSES and self.completed_at is None:
            # A verdict is a fact about a judgment that ran to completion, so it
            # knows when it finished. Allowing an undated one let a SCORED
            # settle a unit while §4.5's chronology check — which compares the
            # completion against every attempt at that unit — had nothing to
            # compare, so a sibling dispatched after the verdict could not be
            # rejected. An ERROR may still be undated: a judge that died before
            # writeback leaves a recorder that genuinely does not know when.
            raise ValueError(
                f"{self.status.value} requires completed_at — a verdict without a completion "
                "instant cannot be ordered against the other attempts at its unit (§4.5)"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schemaVersion": self.schema_version,
            "dispatchId": self.dispatch_id,
            "status": self.status.value,
            "score": self.score.to_dict() if self.score else None,
            "undecided": dict(self.undecided) if self.undecided else None,
            "errorDetail": self.error_detail,
            "completedAt": self.completed_at,
        }


def record_outcome(
    *,
    selection: RunSelection,
    dispatch: JudgmentDispatch,
    status: OutcomeStatus,
    score: RubricScore | None = None,
    undecided: Mapping[str, str] | None = None,
    error_detail: str | None = None,
    completed_at: str | None = None,
) -> JudgmentOutcome:
    """The only supported way to build a JudgmentOutcome.

    Binding is structural, not advisory: an earlier draft offered a
    ``validate_against`` helper that ``to_dict`` never called, so a score for
    the wrong task, rubric, or judge serialized cleanly.
    """
    if not isinstance(status, OutcomeStatus):
        # `OutcomeStatus` subclasses `str`, so the bare string "scored" hashes
        # and compares equal to the member and sails through the tagged-union
        # lookup below. The record then carries a `str` where an enum belongs
        # and dies in `to_dict` on `.value` — an AttributeError at
        # serialization instead of a ValueError at the door. Same check
        # `_check_mode` already makes for `SelectionMode`.
        raise ValueError(
            f"status must be an OutcomeStatus, got {type(status).__name__}"
        )
    # The three values whose fields the binding checks READ must be the real
    # types, or duck-typing walks straight through: an object with
    # `rubric_ref`, `judge` and `task_id` satisfies every comparison below and
    # then serializes whatever its own `to_dict` returns. `status`, `mode`,
    # `judge` and `run_id_kind` are all type-gated elsewhere; the payload that
    # actually carries a judgement was the one exception.
    if not isinstance(selection, RunSelection):
        raise ValueError(
            f"selection must be a RunSelection, got {type(selection).__name__}"
        )
    if not isinstance(dispatch, JudgmentDispatch):
        raise ValueError(
            f"dispatch must be a JudgmentDispatch, got {type(dispatch).__name__}"
        )
    if score is not None and not isinstance(score, RubricScore):
        raise ValueError(f"score must be a RubricScore, got {type(score).__name__}")
    if dispatch.selection_id != selection.selection_id:
        raise ValueError("dispatch does not belong to this selection")
    if dispatch.run_id != selection.run_id:
        raise ValueError("dispatch and selection disagree about the run")
    if score is not None:
        if score.rubric_ref != dispatch.rubric_ref:
            raise ValueError(
                f"score is against {score.rubric_ref}, dispatch against {dispatch.rubric_ref}"
            )
        if score.judge != dispatch.judge:
            raise ValueError(
                f"score is from {score.judge}, dispatch to {dispatch.judge}"
            )
        if score.task_id != selection.content_task_id:
            raise ValueError(
                f"score is for task {score.task_id}, run selected for {selection.content_task_id}"
            )
    if (
        completed_at is not None
        and timestamp_to_unix_nanos(completed_at, "completed_at")
        < dispatch.dispatched_ns
    ):
        raise ValueError(
            f"outcome completed at {completed_at} but its dispatch was sent at "
            f"{dispatch.dispatched_at} — a judgment cannot finish before it starts"
        )
    return JudgmentOutcome(
        dispatch_id=dispatch.dispatch_id,
        status=status,
        score=score,
        undecided=undecided,
        error_detail=error_detail,
        completed_at=completed_at,
        _factory=_FACTORY_ONLY,
    )


def judgment_unit_key(
    dispatch: JudgmentDispatch,
) -> tuple[tuple[str, str], str, str, Judge, str, str]:
    """The judgment unit a dispatch draws — what §4.5 refuses to draw twice.

    Root dispatches are units too. Exempting them let two roots for one
    selection/rubric/judge claim conflicting strata and probabilities.

    The key carries policy and frame because §4.1 makes a conditional draw its
    own sample under its own rule and population: two adjudication paths drawing
    the same parent under *different* policies are different units, and the RFC
    permits that. It carries the full Judge, not its identity — an autorater and
    a human can share an identity string and are not the same judge.

    The root/parent discriminator is a structural tag, not a string prefix.
    ``f"root:{selection_id}"`` shares a namespace with caller-supplied dispatch
    ids: a dispatch genuinely named ``root:sel-1`` produced the same key as
    sel-1's own root unit, so one could be refused as a conflicting draw of the
    other. Nothing rejects that id — it is a well-formed string.
    """
    return (
        ("parent", dispatch.parent_dispatch_id)
        if dispatch.parent_dispatch_id
        else ("root", dispatch.selection_id),
        dispatch.selection_id,
        dispatch.rubric_ref,
        dispatch.judge,
        dispatch.policy_id,
        dispatch.frame_instance_id,
    )


@dataclass
class ProvenanceLedger:
    """Admission and replay for provenance records — across frame instances.

    **Not one frame's.** Resolution is keyed on `selection_id`, so it is
    frame-local by construction. Execution identity is not: one lease or one
    execution dispatch claiming contradictory origins across two *overlapping*
    frame instances is exactly what the mappings below exist to catch, and a
    frame-local ledger could never see it. §8 item 3 defers pooling frames for
    *estimation*; holding them together for *identity* is the opposite
    requirement, and is why `test_resolution_is_per_selection_not_per_run`
    needs a production and a calibration
    selection in one ledger.

    In-memory and single-writer, matching §4's scope: this is the reference
    semantics an ingest layer must implement, not a storage engine. §8 keeps
    persistence placement open.
    """

    _selections: dict[str, RunSelection] = field(default_factory=dict, init=False)
    _dispatches: dict[str, JudgmentDispatch] = field(default_factory=dict, init=False)
    _outcomes: dict[str, JudgmentOutcome] = field(default_factory=dict, init=False)
    # Immutable execution-identity mappings (§4.5). Not caches: a contradiction
    # here is a false account of what ran, and is refused rather than resolved.
    # Both are keyed across BOTH RunIdKind branches — an attempt's ``run_id`` IS
    # a lease, and a terminal record's ``accepted_lease_id`` names one, so a
    # single lease namespace catches the cross-branch contradictions that two
    # per-branch maps let through.
    _dispatch_origin: dict[str, tuple[str, str]] = field(
        default_factory=dict, init=False
    )
    _lease_dispatch: dict[str, str] = field(default_factory=dict, init=False)
    # lease->dispatch does NOT imply dispatch->lease: two terminal records for
    # one dispatch naming different leases map to distinct keys and never
    # collide. A dispatch has one accepted attempt, so that direction is its
    # own mapping.
    _terminal_lease: dict[str, str] = field(default_factory=dict, init=False)
    # One rule applied to one concrete population assigns a unit exactly one
    # stratum and one inclusion probability — that pairing is §4.1's whole
    # argument. Two answers for one (run, policy, frame) is the same class of
    # contradiction as two origins for one dispatch, landing on the number the
    # RFC exists to protect.
    # Keyed on the CANONICAL execution — the lease — not on run_id plus
    # run_id_kind. Adding the kind to the key was worse than leaving it out: the
    # same physical execution enters once as ATTEMPT (keyed by lease L) and
    # again as DISPATCH_TERMINAL (keyed by dispatch D whose accepted lease is
    # that same L), landing in two buckets and passing the shared lease map,
    # which is exactly what this mapping exists to stop. The lease is already
    # computed during admission, so the two kinds collapse onto one key.
    # The value keeps the selection_id that first claimed the unit: a second
    # selection with an identical draw is not a harmless duplicate, it is a
    # second judgment for one sampled unit.
    _unit_draw: dict[
        tuple[str, str, str], tuple[str, tuple[str, SelectionMode, float | None]]
    ] = field(default_factory=dict, init=False)
    # A frame instance samples ONE kind of unit. Attempt-level and
    # accepted-dispatch-level populations have different denominators, so a
    # frame holding both has no single population to reweight against.
    # A frame instance samples one kind of unit — and "kind" spans more than
    # RunIdKind. A selection population (runs) and a judgment population
    # (dispatches) are different denominators, as are root and conditional
    # judgment draws, so storing only RunIdKind let one concrete frame hold
    # incompatible ones. The value is a tagged domain: ("selection", RunIdKind)
    # or ("judgment", "root"|"conditional").
    _frame_kind: dict[str, tuple[str, object]] = field(default_factory=dict, init=False)
    # The JudgmentDispatch equivalent of _unit_draw: a dispatch is its own
    # sample (§4.1), so one judgment unit cannot be drawn twice under different
    # strata or probabilities. Keyed by `judgment_unit_key` — see its docstring
    # for why each component is load-bearing. Root dispatches are keyed too;
    # they are units, not an exempt case.
    # unit -> every dispatch that drew it, in admission order. A decisive
    # outcome must be checked against ALL of them, not just the attempts that
    # name it: siblings of one predecessor never name each other.
    _unit_attempts: dict[
        tuple[tuple[str, str], str, str, Judge, str, str], list[str]
    ] = field(default_factory=dict, init=False)
    # unit -> the dispatch whose decisive outcome settled it. A judgment unit
    # is one draw; it may be executed many times but decided only once, or a
    # second verdict for the same draw could replace the first.
    _unit_decided: dict[tuple[tuple[str, str], str, str, Judge, str, str], str] = field(
        default_factory=dict, init=False
    )
    _judgment_draw: dict[
        tuple[tuple[str, str], str, str, Judge, str, str],
        tuple[str, tuple[str, SelectionMode, float | None]],
    ] = field(default_factory=dict, init=False)

    @staticmethod
    def _replay(existing: Any, incoming: Any, kind: str, key: str) -> bool:
        """True if this is an accepted identical replay; raises on a conflict.

        Idempotent ingest is the whole point of an append-only log: the same
        record delivered twice must be a no-op, and two DIFFERENT records
        claiming one identity must be loud, because silently keeping either
        one makes every join downstream a coin flip.
        """
        if existing is None:
            return False
        if existing != incoming:
            raise ValueError(
                f"conflicting {kind} for {key!r}: {existing!r} != {incoming!r}"
            )
        return True

    def add_selection(self, selection: RunSelection) -> None:
        """Reject a selection that contradicts an execution identity already seen.

        Deduping on ``selection_id`` alone is not enough: it lets one attempt be
        filed under two execution dispatches, and one terminal dispatch claim two
        different accepted leases. Both serialize cleanly and both are false —
        the reweighter would then hold two irreconcilable accounts of what ran.
        These mappings are immutable once observed.
        """
        if not isinstance(selection, RunSelection):
            raise ValueError(
                f"add_selection needs a RunSelection, got {type(selection).__name__} — "
                "a duck-typed record skips every invariant its constructor enforces"
            )
        if self._replay(
            self._selections.get(selection.selection_id),
            selection,
            "selection",
            selection.selection_id,
        ):
            return

        # PREFLIGHT — every check before any mutation. An earlier draft used
        # setdefault() and checked the lease afterwards, so a rejected selection
        # left its dispatch origin behind and the ledger then refused a later,
        # valid selection for that dispatch. Admission is all-or-nothing.
        origin = (selection.logical_task_id, selection.content_task_id)
        lease = (
            selection.run_id
            if selection.run_id_kind is RunIdKind.ATTEMPT
            else selection.accepted_lease_id
        )

        # A dispatch has ONE origin, whichever kind observed it. Keying this on
        # the attempt let two retries of one dispatch claim different logical
        # tasks or different content.
        prior_origin = self._dispatch_origin.get(selection.execution_dispatch_id)
        if prior_origin is not None and prior_origin != origin:
            raise ValueError(
                f"dispatch {selection.execution_dispatch_id!r} was already recorded as "
                f"{prior_origin}, now {origin} — one dispatch has one origin"
            )

        # ONE lease namespace across both branches: an attempt's run_id IS a
        # lease, and a terminal record's accepted_lease_id names one.
        prior_dispatch = self._lease_dispatch.get(lease)
        if (
            prior_dispatch is not None
            and prior_dispatch != selection.execution_dispatch_id
        ):
            raise ValueError(
                f"lease {lease!r} already belonged to dispatch {prior_dispatch!r}, "
                f"now {selection.execution_dispatch_id!r} — one execution has one dispatch"
            )

        # And the other direction, which the map above does not give.
        if selection.run_id_kind is RunIdKind.DISPATCH_TERMINAL:
            prior_lease = self._terminal_lease.get(selection.execution_dispatch_id)
            if prior_lease is not None and prior_lease != selection.accepted_lease_id:
                raise ValueError(
                    f"dispatch {selection.execution_dispatch_id!r} already accepted lease "
                    f"{prior_lease!r}, now {selection.accepted_lease_id!r} — "
                    "a dispatch has one accepted attempt"
                )

        # `lease` is the canonical execution identity, computed above.
        draw_key = (lease, selection.policy_id, selection.frame_instance_id)
        draw = (selection.stratum, selection.mode, selection.probability)
        prior = self._unit_draw.get(draw_key)
        if prior is not None:
            prior_owner, prior_draw = prior
            if prior_draw != draw:
                raise ValueError(
                    f"run {selection.run_id!r} was already drawn from "
                    f"{selection.frame_instance_id!r} under {selection.policy_id!r} as "
                    f"{prior_draw}, now {draw} — one rule on one population draws a unit once"
                )
            if prior_owner != selection.selection_id:
                raise ValueError(
                    f"unit {draw_key!r} is already claimed by selection {prior_owner!r}; "
                    f"{selection.selection_id!r} would be a second judgment for one draw"
                )

        # Keyed on the frame INSTANCE alone. frame_instance_id denotes the
        # concrete eligible population, so its unit kind is a property of that
        # population, not of whichever policy happened to draw from it — keying
        # on the pair let one frame be ATTEMPT under one policy and
        # DISPATCH_TERMINAL under another.
        frame_key = selection.frame_instance_id
        frame_domain: tuple[str, object] = ("selection", selection.run_id_kind)
        prior_kind = self._frame_kind.get(frame_key)
        if prior_kind is not None and prior_kind != frame_domain:
            raise ValueError(
                f"frame {selection.frame_instance_id!r} already samples "
                f"{prior_kind!r} units, now {frame_domain!r} — "
                "attempt-level and accepted-dispatch-level populations have different "
                "denominators and cannot share a frame"
            )

        # COMMIT
        self._frame_kind[frame_key] = frame_domain
        self._unit_draw[draw_key] = (selection.selection_id, draw)
        self._dispatch_origin[selection.execution_dispatch_id] = origin
        self._lease_dispatch[lease] = selection.execution_dispatch_id
        if selection.run_id_kind is RunIdKind.DISPATCH_TERMINAL:
            self._terminal_lease[selection.execution_dispatch_id] = (
                selection.accepted_lease_id
            )

        self._selections[selection.selection_id] = selection

    def add_dispatch(self, dispatch: JudgmentDispatch) -> None:
        """Admit a dispatch, validating the causal chain it claims.

        `JudgmentDispatch.__post_init__` can only catch self-parenthood. Every
        other way the chain breaks is relational.
        """
        if not isinstance(dispatch, JudgmentDispatch):
            raise ValueError(
                f"add_dispatch needs a JudgmentDispatch, got {type(dispatch).__name__}"
            )
        if self._replay(
            self._dispatches.get(dispatch.dispatch_id),
            dispatch,
            "dispatch",
            dispatch.dispatch_id,
        ):
            return
        selection = self._selections.get(dispatch.selection_id)
        if selection is None:
            raise ValueError(
                f"dispatch {dispatch.dispatch_id!r} names unknown selection"
            )
        if selection.run_id != dispatch.run_id:
            raise ValueError("dispatch and selection disagree about the run")
        parent_id = dispatch.parent_dispatch_id
        if parent_id is not None:
            parent = self._dispatches.get(parent_id)
            if parent is None:
                # Order matters: a parent must already be admitted. A forward
                # reference cannot be validated now and would have to be
                # re-checked forever.
                raise ValueError(f"parent dispatch {parent_id!r} is not recorded")
            # selection_id, not (run_id, rubric_ref): §4.3 introduced
            # selection_id precisely because that tuple cannot separate
            # overlapping frame instances or a production judgment from a
            # calibration one, and a chain that crosses selections would let a
            # calibration dispatch parent a production one.
            if parent.selection_id != dispatch.selection_id:
                raise ValueError(
                    f"parent {parent.dispatch_id!r} belongs to selection "
                    f"{parent.selection_id!r}, child to {dispatch.selection_id!r}"
                )
            if (parent.run_id, parent.rubric_ref) != (
                dispatch.run_id,
                dispatch.rubric_ref,
            ):
                raise ValueError(
                    "a conditional dispatch must adjudicate the same run and rubric"
                )
            # Instants, not order_key. order_key's second element is
            # dispatch_id, a resolution tiebreak; using it for causality lets
            # two dispatches at the SAME instant be parent and child according
            # to how their ids happen to sort.
            # parent_dispatch_id is defined (§4.3) as the judgment whose
            # OUTCOME triggered this draw, so a parent that has not finished
            # cannot have triggered anything. The dispatch timestamp alone
            # proves only that the parent was sent.
            if parent.dispatch_id not in self._outcomes:
                raise ValueError(
                    f"parent {parent.dispatch_id!r} has no admitted outcome; a conditional "
                    "dispatch is triggered by a parent's result, not by its existence"
                )
            parent_outcome = self._outcomes[parent.dispatch_id]
            if parent_outcome.completed_at is None:
                raise ValueError(
                    f"parent {parent.dispatch_id!r} records no completion instant; "
                    "admission order is not completion order, so a child cannot be "
                    "shown to follow its parent's result"
                )
            if (
                timestamp_to_unix_nanos(parent_outcome.completed_at, "completed_at")
                >= dispatch.dispatched_ns
            ):
                raise ValueError(
                    f"parent {parent.dispatch_id!r} completed at "
                    f"{parent_outcome.completed_at} — not before child dispatch "
                    f"{dispatch.dispatched_at}"
                )
            if parent.dispatched_ns >= dispatch.dispatched_ns:
                # A judgment cannot be triggered by its own future.
                raise ValueError(
                    "parent dispatch is not strictly earlier than its child"
                )
            # Parents are admitted before children and each has at most one
            # parent, so the chain is already a tree; walking it is a cheap
            # assertion of that, not a search.
            seen, cursor = {dispatch.dispatch_id}, parent
            while cursor is not None:
                if cursor.dispatch_id in seen:
                    raise ValueError("parent chain is cyclic")
                seen.add(cursor.dispatch_id)
                cursor = (
                    self._dispatches.get(cursor.parent_dispatch_id)
                    if cursor.parent_dispatch_id
                    else None
                )
        unit = judgment_unit_key(dispatch)

        # A reattempt repeats one failed attempt at the SAME unit. Keying it on
        # the unit is what stops it drifting into a new draw: same parent, same
        # rubric, judge, policy and frame, so the weight is untouched and only
        # the attempt chain grows.
        prior_id = dispatch.reattempt_of_dispatch_id
        # Lineage is REQUIRED once a unit has been dispatched, or every rule
        # below would be opt-in: an identical redispatch that simply omitted
        # the field skipped all of them, so a refusal could replace a score
        # with nothing refusing it.
        if prior_id is None and unit in self._judgment_draw:
            owner = self._judgment_draw[unit][0]
            raise ValueError(
                f"dispatch {dispatch.dispatch_id!r} redraws a unit already dispatched as "
                f"{owner!r} — a second dispatch of one judgment unit must name the attempt "
                "it repeats in reattempt_of_dispatch_id, or be a new draw with its own parent"
            )
        if prior_id is not None:
            prior_dispatch = self._dispatches.get(prior_id)
            if prior_dispatch is None:
                raise ValueError(f"reattempted dispatch {prior_id!r} is not recorded")
            if judgment_unit_key(prior_dispatch) != unit:
                raise ValueError(
                    f"dispatch {dispatch.dispatch_id!r} reattempts {prior_id!r} but draws a "
                    "different unit — a reattempt repeats a draw, it does not make a new one"
                )
            # Instants, not order_key — the same rule as the parent check above,
            # and for the same reason: order_key's tiebreak is dispatch_id, so
            # using it here made two dispatches at ONE instant a reattempt pair
            # or not according to how their ids happened to sort, and rendered
            # the refusal as "sent at X, not before X".
            if prior_dispatch.dispatched_ns >= dispatch.dispatched_ns:
                raise ValueError(
                    f"reattempted dispatch {prior_id!r} was sent at "
                    f"{prior_dispatch.dispatched_at}, which is not before "
                    f"{dispatch.dispatched_at} — a reattempt follows the attempt it repeats"
                )
            # The UNIT's decisive state, not the named predecessor's. Checking
            # only the predecessor let d1(ERROR) <- d2(SCORED) <- d3 naming d1
            # through: d3 reattempted a unit that was already decided, and its
            # refusal replaced a valid score.
            settled_by = self._unit_decided.get(unit)
            if settled_by is not None:
                raise ValueError(
                    f"judgment unit already decided by dispatch {settled_by!r}; a reattempt "
                    "repeats a failed execution, so a further pass at a decided judgment is a "
                    "new draw (§4.1), not a reattempt"
                )
            prior_outcome = self._outcomes.get(prior_id)
            if prior_outcome is None:
                # A reattempt follows a failure that was RECORDED, not one the
                # recorder merely believes happened. Allowing a reattempt of an
                # attempt still in flight let a timeout race discard a real
                # verdict: redispatch at 10:03, the original returns SCORED at
                # 10:04, and that score is refused as arriving after its own
                # reattempt. §4.3 writes the dispatch first precisely so a crash
                # is visible — the recorder writes the ERROR for it and then
                # redispatches, and the record says what actually happened.
                raise ValueError(
                    f"dispatch {prior_id!r} has no recorded outcome; a reattempt follows a "
                    "recorded failure, so write that attempt's ERROR before redispatching"
                )
            if prior_outcome.completed_at is not None:
                # Chronology, not just dispatch order: an attempt that finished
                # at 10:05 cannot have been repeated by something sent at 10:02.
                finished = timestamp_to_unix_nanos(
                    prior_outcome.completed_at, "completed_at"
                )
                if finished >= dispatch.dispatched_ns:
                    raise ValueError(
                        f"reattempted dispatch {prior_id!r} completed at "
                        f"{prior_outcome.completed_at}, which is not before "
                        f"{dispatch.dispatched_at} — a reattempt follows a failure"
                    )
            if prior_outcome is not None and prior_outcome.status in DECISIVE_STATUSES:
                # A reattempt repeats an execution that FAILED to yield a
                # verdict. A decisive outcome is a verdict, so re-running the
                # same draw against the same evidence is not what happened —
                # a further pass is a new draw, with its own frame and
                # probability (§4.1).
                raise ValueError(
                    f"dispatch {prior_id!r} is {prior_outcome.status.value}, which is decisive; "
                    "a reattempt repeats a failed execution, so a further pass at a decided "
                    "judgment is a new draw (§4.1), not a reattempt"
                )
        # Same frame rule as selections, on the judgment side — a frame that
        # samples runs cannot also sample dispatches, and root and conditional
        # judgment draws are different populations too.
        judgment_domain: tuple[str, object] = (
            "judgment",
            "conditional" if dispatch.parent_dispatch_id else "root",
        )
        prior_domain = self._frame_kind.get(dispatch.frame_instance_id)
        if prior_domain is not None and prior_domain != judgment_domain:
            raise ValueError(
                f"frame {dispatch.frame_instance_id!r} already samples "
                f"{prior_domain!r} units, now {judgment_domain!r} — one concrete "
                "population cannot carry two denominators"
            )

        draw = (dispatch.stratum, dispatch.mode, dispatch.probability)
        # Only the DRAW is pinned, not ownership — unlike `_unit_draw`. A
        # second dispatch of one judgment unit is a retry, which §4.5 requires
        # to be admissible; a second dispatch claiming a *different* stratum or
        # probability is two accounts of one sample. The first check catches the
        # second case without forbidding the first.
        prior = self._judgment_draw.get(unit)
        if prior is not None:
            prior_owner, prior_draw = prior
            if prior_draw != draw:
                raise ValueError(
                    f"judgment unit {unit!r} was already drawn as {prior_draw} by "
                    f"{prior_owner!r}, now {draw} — one rule draws a unit once"
                )
        else:
            self._judgment_draw[unit] = (dispatch.dispatch_id, draw)
        self._frame_kind[dispatch.frame_instance_id] = judgment_domain
        self._unit_attempts.setdefault(unit, []).append(dispatch.dispatch_id)

        self._dispatches[dispatch.dispatch_id] = dispatch

    def add_outcome(self, outcome: JudgmentOutcome) -> None:
        """Admit an outcome, re-checking the binding its factory checked.

        `record_outcome` validates at write time, but a record that arrives
        over the wire was built by a reader, not the factory, so the binding is
        re-derived here against the dispatch this ledger already holds.

        That is consistency with the ledger's own record, not producer trust:
        a caller who supplies a coherent dispatch and a coherent outcome for it
        passes every check here while naming a run it never judged. See the
        module docstring — nothing in this file establishes authenticity.
        """
        if not isinstance(outcome, JudgmentOutcome):
            raise ValueError(
                f"add_outcome needs a JudgmentOutcome, got {type(outcome).__name__}"
            )
        if outcome.score is not None and not isinstance(outcome.score, RubricScore):
            raise ValueError("admitted outcome carries a non-RubricScore score")
        dispatch = self._dispatches.get(outcome.dispatch_id)
        if dispatch is None:
            raise ValueError(f"outcome names unknown dispatch {outcome.dispatch_id!r}")
        if (
            outcome.completed_at is not None
            and timestamp_to_unix_nanos(outcome.completed_at, "completed_at")
            < dispatch.dispatched_ns
        ):
            raise ValueError(
                f"outcome completed at {outcome.completed_at} precedes its dispatch at "
                f"{dispatch.dispatched_at}"
            )
        if outcome.score is not None:
            selection = self._selections[dispatch.selection_id]
            if outcome.score.rubric_ref != dispatch.rubric_ref:
                raise ValueError(
                    "outcome score is against a different rubric than its dispatch"
                )
            if outcome.score.judge != dispatch.judge:
                raise ValueError(
                    "outcome score is from a different judge than its dispatch"
                )
            if outcome.score.task_id != selection.content_task_id:
                raise ValueError(
                    "outcome score is for a different task than its selection"
                )
        if self._replay(
            self._outcomes.get(outcome.dispatch_id),
            outcome,
            "outcome",
            outcome.dispatch_id,
        ):
            return
        if outcome.status in DECISIVE_STATUSES and outcome.completed_at is not None:
            # Against EVERY attempt at this unit, not just the ones naming this
            # dispatch. Two siblings reattempting one predecessor never name
            # each other, so a reverse index keyed on the predecessor missed
            # the case where a verdict lands while a later sibling is already
            # admitted — leaving an attempt dispatched after its unit was
            # decided.
            settled_ns = timestamp_to_unix_nanos(outcome.completed_at, "completed_at")
            for attempt_id in self._unit_attempts.get(judgment_unit_key(dispatch), ()):
                if attempt_id == outcome.dispatch_id:
                    continue
                attempt = self._dispatches[attempt_id]
                if attempt.dispatched_ns > settled_ns:
                    raise ValueError(
                        f"dispatch {outcome.dispatch_id!r} settles its unit at "
                        f"{outcome.completed_at}, but attempt {attempt_id!r} was sent later at "
                        f"{attempt.dispatched_at} — a decided unit is not attempted again"
                    )

        if outcome.status in DECISIVE_STATUSES:
            unit = judgment_unit_key(dispatch)
            # Load-bearing, and the case that reaches it is SIBLING reattempts:
            # two reattempts of one predecessor are both admitted while that
            # predecessor has no outcome, and neither is the other's reattempt,
            # so the reverse-edge rules above say nothing about the pair. Only
            # the unit's decisive state stops the second verdict. A previous
            # comment here called this unreachable on the strength of a mutation
            # that failed no test — the suite simply had no sibling case.
            settled_by = self._unit_decided.get(unit)
            if settled_by is not None and settled_by != outcome.dispatch_id:
                raise ValueError(
                    f"judgment unit was already decided by dispatch {settled_by!r}; one draw is "
                    f"judged once, so {outcome.dispatch_id!r} cannot deliver a second verdict — "
                    "a further pass is a new draw (§4.1)"
                )
            self._unit_decided[unit] = outcome.dispatch_id

        self._outcomes[outcome.dispatch_id] = outcome

    def resolve(
        self, *, selection_id: str, rubric_ref: str, judge: Judge
    ) -> JudgmentOutcome | None:
        """The decisive outcome for one selection's (rubric, judge) pair.

        Keyed by `selection_id`, NOT by `run_id`. `selection_id` exists to
        separate overlapping frame instances and a production judgment from a
        calibration one (§4.3); resolving on the run would let a later
        calibration dispatch replace the production judgment for the same run,
        rubric and judge — silently, and in exactly the case the field was
        introduced for.
        """
        decisive = [
            (self._dispatches[did].order_key, outcome)
            for did, outcome in self._outcomes.items()
            if outcome.status in DECISIVE_STATUSES
            and self._dispatches[did].selection_id == selection_id
            and self._dispatches[did].rubric_ref == rubric_ref
            and self._dispatches[did].judge == judge
        ]
        return max(decisive, key=lambda pair: pair[0])[1] if decisive else None
