"""Staging and the commit point (RFC 0009 §4.2, §4.2.1).

WHY STAGING AND NOT APPLYING

An earlier draft of the contract had the in-harness component *apply* its share
and the commit point forward the request "unmodified" when confirmation failed.
That does not produce the reference. By the time the commit point sees the
request the prompt and tool set have already changed, so "unmodified" means
unmodified *by the commit point*, and what runs is the staged instructions and
tools against the reference model — the partial configuration the rule forbids,
reached by the mechanism meant to prevent it.

Staging removes the problem rather than handling it. A contribution travels as
request data, the commit point materializes everything or nothing, and there is
no state to unwind because nothing was committed before the commit point.

NOT EVERYTHING CAN BE STAGED

A contract that assumes otherwise fails silently on the contributions that
cannot. :class:`ContributionClass` makes the three cases explicit, and a
contribution that is neither stageable nor restorable cannot take part in a
multi-component plan at all: it is single-component or it is refused. There is no
third option that preserves atomicity.

THE FALLBACK IS NOT EXEMPT

Falling back is a dispatch decision, so it passes admission like any other
(§4.2.1). The sequence this closes is not covered by ``cannot_execute``, because
nothing goes wrong at the service:

1. The reference's provider is prohibited by the organization.
2. The service correctly recommends a permitted, cheaper candidate — ``apply``.
3. Staging that candidate fails.
4. The commit point reconstructs the reference and dispatches the prohibited
   provider, reached precisely because the permitted one failed.

So :func:`commit` re-admits the reference before dispatching it, against the
state now rather than whatever made it the reference. Retention and restoration
never relax a constraint.

THERE IS NOT ALWAYS A REFERENCE TO FALL BACK TO

Admission answers "may this configuration run". It does not answer "is this
session still the configuration I am about to name", and the second question is
the one a fallback depends on. A ``NEITHER`` contribution has applied in-session
with no way back and a denied ``RESTORABLE`` restore left the session in a state
nobody established; in both cases "dispatch the reference" dispatches something
else under the reference's name, and every record of the run is consistent.

So the check lives in :func:`_reference_or_stop` rather than in an ordered
branch of :func:`commit`. It was written as a branch once, and only the case
that prompted it was covered — a refused restore stopped, while an irreversible
contribution reached an *earlier* branch and dispatched, and a lone irreversible
contribution whose confirmation never arrived reached a later one and dispatched
too. Putting it in the one function every fallback goes through is what makes
"every reference dispatch establishes the session is at the reference" a
property of the code rather than of a list of branches someone has to keep
complete.

WHAT IT DOES NOT DO

No transport, no provider call, no harness. :func:`commit` decides; a caller
dispatches. Admission is supplied as a callable because what is permitted is the
organization's answer, not this module's.
"""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from enum import Enum
from typing import Any

from vicaria_contracts._wire import (
    require_enum,
    require_mapping,
    require_schema,
    require_str,
)
from vicaria_contracts.capability import Dimension
from vicaria_contracts.plan import Configuration, Disposition, Plan

STAGING_CONFIRMATION_SCHEMA_VERSION = "vicaria.staging-confirmation.v1"
STAGED_CONTRIBUTION_SCHEMA_VERSION = "vicaria.staged-contribution.v1"
COMMIT_OUTCOME_SCHEMA_VERSION = "vicaria.commit-outcome.v1"


class ContributionClass(str, Enum):
    """Whether a component's share can be held back until the commit point."""

    STAGEABLE = "stageable"  # request data the commit point materializes
    RESTORABLE = "restorable"  # applied in-session, with a *verified* restore path
    NEITHER = "neither"  # applied in-session, no way back


class CommitAction(str, Enum):
    """What the commit point should do. Three, and no partial."""

    MATERIALIZE = "materialize"  # apply every staged contribution and its own
    SURFACE = "surface"  # show the proposal; set nothing, dispatch the reference
    REFERENCE = "reference"  # dispatch the reference; nothing was applied
    CANNOT_EXECUTE = "cannot_execute"  # dispatch nothing at all


class CommitRefusal(str, Enum):
    """Why a commit did not materialize. Closed, because these are counted.

    ``NO_DECISION`` and ``PLAN_REFUSED`` are never produced by :func:`commit` —
    it is only reached with a validated plan. They belong to the client core's
    own reference dispatches (``traces/client.py``), which pass the same gate,
    and they live in this vocabulary so that one count covers every path a
    client can take rather than two counts nobody joins.
    """

    NO_CONFIRMATION = "no_confirmation"
    MISSING_CONTRIBUTION = "missing_contribution"
    UNEXPECTED_CONTRIBUTION = "unexpected_contribution"
    CONFIRMATION_MISMATCH = "confirmation_mismatch"
    NOT_APPLICABLE = "not_applicable"
    NO_DECISION = "no_decision"
    PLAN_REFUSED = "plan_refused"
    STALE_BASELINE = "stale_baseline"
    UNSTAGEABLE_CONTRIBUTION = "unstageable_contribution"
    RESTORE_UNCONFIRMED = "restore_unconfirmed"
    REFERENCE_INADMISSIBLE = "reference_inadmissible"


def _require_id(value: Any, name: str) -> None:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} must be a nonempty string, got {value!r}")


def contribution_digest(dimensions: Iterable[Dimension], payload: Any) -> str:
    """A digest over what a component contributes, stable across processes."""
    canonical = json.dumps(
        {"dimensions": sorted(d.value for d in dimensions), "payload": payload},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        default=str,
    )
    return "sha256:" + hashlib.sha256(canonical.encode("utf-8")).hexdigest()


@dataclass(frozen=True, slots=True)
class StagedContribution:
    """One component's share, computed but not applied."""

    component: str
    dimensions: frozenset[Dimension]
    contribution_class: ContributionClass
    digest: str
    restore_confirmed: bool | None = None

    def __post_init__(self) -> None:
        _require_id(self.component, "component")
        _require_id(self.digest, "digest")
        if not isinstance(self.contribution_class, ContributionClass):
            raise ValueError("contribution_class must be a ContributionClass")
        if not self.dimensions:
            raise ValueError(
                f"{self.component} staged no dimensions — a contribution that changes "
                "nothing is not a contribution"
            )
        object.__setattr__(self, "dimensions", frozenset(self.dimensions))

        if self.contribution_class is ContributionClass.RESTORABLE:
            if self.restore_confirmed is None:
                raise ValueError(
                    f"{self.component} is restorable, so its restore must be confirmed or "
                    "denied — an assumed restore is the unknown configuration this refuses"
                )
        elif self.restore_confirmed is not None:
            raise ValueError(
                f"{self.component} is {self.contribution_class.value}, which needs no restore, "
                "so restore_confirmed would describe a step that never happens"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": STAGED_CONTRIBUTION_SCHEMA_VERSION,
            "component": self.component,
            "dimensions": sorted(d.value for d in self.dimensions),
            "contribution_class": self.contribution_class.value,
            "digest": self.digest,
            "restore_confirmed": self.restore_confirmed,
        }

    @classmethod
    def from_dict(cls, payload: Any) -> StagedContribution:
        """Read a contribution off the wire.

        ``restore_confirmed`` is three-valued — confirmed, denied, or not
        applicable — so it is required to be *present*, `null` where it does not
        apply. An absent key would be read as "not applicable", which for a
        restorable contribution is the assumed restore ``__post_init__``
        refuses; requiring the key keeps that refusal from depending on the
        reader.
        """
        obj = require_mapping(payload, "staged contribution")
        require_schema(obj, STAGED_CONTRIBUTION_SCHEMA_VERSION)
        raw_dimensions = obj.get("dimensions")
        if not isinstance(raw_dimensions, list | tuple):
            raise ValueError("dimensions must be a list of dimension names")
        dimensions = set()
        for name in raw_dimensions:
            if not isinstance(name, str):
                raise ValueError(f"dimensions entries must be strings, got {name!r}")
            try:
                dimensions.add(Dimension(name))
            except ValueError:
                valid = sorted(d.value for d in Dimension)
                raise ValueError(
                    f"dimensions must be one of {valid}, got {name!r}"
                ) from None
        if "restore_confirmed" not in obj:
            raise ValueError(
                "restore_confirmed is required, explicitly null where no restore applies — "
                "an absent key reads as 'not applicable' and would assume a restore"
            )
        restore_confirmed = obj["restore_confirmed"]
        if restore_confirmed is not None and not isinstance(restore_confirmed, bool):
            raise ValueError(
                f"restore_confirmed must be a bool or null, got {type(restore_confirmed).__name__}"
            )
        return cls(
            component=require_str(obj, "component"),
            dimensions=frozenset(dimensions),
            contribution_class=require_enum(
                obj, "contribution_class", ContributionClass
            ),
            digest=require_str(obj, "digest"),
            restore_confirmed=restore_confirmed,
        )


@dataclass(frozen=True, slots=True)
class StagingConfirmation:
    """What a staging component binds to the request (§4.2, bind).

    Carried *on the request*. A confirmation posted out of band and looked up by
    session or episode id reintroduces the same race one layer down: the lookup
    can win against a stage that has not finished, or lose against one that
    already failed.

    ``component`` is which component bound it, and it is not decoration. Matching
    confirmations to contributions by digest alone means two components that
    stage identical shares — the same dimensions and the same payload produce the
    same digest by construction — share one confirmation, so either one's success
    authorizes the other's contribution. That is the failure
    ``UNEXPECTED_CONTRIBUTION`` refuses when two contributions claim one
    component, arriving from the other side.
    """

    component: str
    decision_id: str
    base_config_digest: str
    contribution_digest: str

    def __post_init__(self) -> None:
        for name in (
            "component",
            "decision_id",
            "base_config_digest",
            "contribution_digest",
        ):
            _require_id(getattr(self, name), name)

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": STAGING_CONFIRMATION_SCHEMA_VERSION,
            "component": self.component,
            "decision_id": self.decision_id,
            "base_config_digest": self.base_config_digest,
            "contribution_digest": self.contribution_digest,
        }

    @classmethod
    def from_dict(cls, payload: Any) -> StagingConfirmation:
        """Read a confirmation off the wire.

        This is the one type the protocol *guarantees* crosses a process
        boundary: §4.2 requires the confirmation to travel on the request, and
        in the reference deployment the component that writes it and the commit
        point that reads it are different processes. A write-only serializer
        with a schema version nobody checks is half a contract — and the half
        that is missing is the one at the trust boundary.
        """
        obj = require_mapping(payload, "staging confirmation")
        require_schema(obj, STAGING_CONFIRMATION_SCHEMA_VERSION)
        return cls(
            component=require_str(obj, "component"),
            decision_id=require_str(obj, "decision_id"),
            base_config_digest=require_str(obj, "base_config_digest"),
            contribution_digest=require_str(obj, "contribution_digest"),
        )


@dataclass(frozen=True, slots=True)
class Admission:
    """Whether a configuration may run, now."""

    admitted: bool
    reason: str | None = None

    def __post_init__(self) -> None:
        if not self.admitted and not self.reason:
            raise ValueError("a refused admission must say why")


@dataclass(frozen=True, slots=True)
class CommitOutcome:
    """What the commit point decided, and everything needed to record it."""

    action: CommitAction
    refusal: CommitRefusal | None = None
    detail: str | None = None
    admission_reason: str | None = None

    def __post_init__(self) -> None:
        if self.action is CommitAction.MATERIALIZE and self.refusal is not None:
            raise ValueError("a materializing commit carries no refusal")
        if self.action is not CommitAction.MATERIALIZE and self.refusal is None:
            raise ValueError("a commit that did not materialize must name its refusal")

    @property
    def dispatches(self) -> bool:
        """False only for ``cannot_execute``: nothing reaches a provider."""
        return self.action is not CommitAction.CANNOT_EXECUTE

    @property
    def applies(self) -> bool:
        """True only when the plan's changes actually take effect."""
        return self.action is CommitAction.MATERIALIZE

    def to_dict(self) -> dict[str, Any]:
        """A recordable form. :class:`CommitRefusal` is closed because these are
        counted, and nothing can count them without this.

        Deliberately write-only: there is no ``from_dict``. Re-reading a commit
        decision and acting on it is the out-of-band lookup §4.2 forbids — the
        decision is made once, at the commit point, on the request that carried
        the contributions. This is for the record, not for a second caller.
        """
        return {
            "schema": COMMIT_OUTCOME_SCHEMA_VERSION,
            "action": self.action.value,
            "refusal": self.refusal.value if self.refusal else None,
            "detail": self.detail,
            "admission_reason": self.admission_reason,
            "dispatches": self.dispatches,
            "applies": self.applies,
        }


def _as_confirmations(
    confirmation: StagingConfirmation | Sequence[StagingConfirmation] | None,
) -> tuple[StagingConfirmation, ...]:
    if confirmation is None:
        return ()
    if isinstance(confirmation, StagingConfirmation):
        return (confirmation,)
    return tuple(confirmation)


def _unrestored_session(
    staged: Sequence[StagedContribution],
) -> tuple[CommitRefusal, str] | None:
    """Why this session is not known to be at the reference, or ``None``.

    Two classes of contribution have already touched the session by the time the
    commit point runs, and neither leaves the reference reconstructible:

    ``NEITHER`` applied in-session with no way back, so the session *is* the
    changed configuration and there is no operation that returns it. ``RESTORABLE``
    with a denied restore left the session in a state nobody established — and
    "may this configuration run" is a different question from "was the session
    put back", so admission cannot answer it.

    Only ``STAGEABLE`` (nothing applied) and a ``RESTORABLE`` whose restore was
    confirmed leave a reference to fall back to.
    """
    irreversible = sorted(
        c.component for c in staged if c.contribution_class is ContributionClass.NEITHER
    )
    if irreversible:
        return (
            CommitRefusal.UNSTAGEABLE_CONTRIBUTION,
            f"{', '.join(irreversible)} applied in-session with no way back, so the "
            "reference is not what this session would dispatch",
        )
    denied = sorted(
        c.component
        for c in staged
        if c.contribution_class is ContributionClass.RESTORABLE
        and not c.restore_confirmed
    )
    if denied:
        return (
            CommitRefusal.RESTORE_UNCONFIRMED,
            f"{', '.join(denied)} could not confirm its restore, so the session's "
            "configuration is unknown",
        )
    return None


def reference_or_stop(
    staged: Sequence[StagedContribution],
    reference: Configuration,
    admit: Callable[[Configuration], Admission],
    refusal: CommitRefusal,
    detail: str,
    action: CommitAction = CommitAction.REFERENCE,
) -> CommitOutcome:
    """Fall back to the reference, but only if there is one and it may still run.

    **The** fallback gate. Public because it is not only the commit point's: a
    client core has reference-dispatch paths of its own — an unreachable server,
    a plan refused by validation — and those are dispatch decisions under the
    same two rules. A second implementation of this is a second place to get it
    wrong, which is the defect this function's own history is about.

    Two preconditions, in this order, and ``staged`` is the first parameter so
    that no fallback path can be written without answering the first.

    *The session must still be at the reference.* A caller reaching here is about
    to dispatch a configuration it did not apply, which is only the reference if
    nothing was applied — see :func:`_unrestored_session`. This check lives here
    rather than in :func:`commit`'s ordered branches because it was written there
    once already and only the branch that prompted it was covered: a refused
    restore stopped, while an irreversible contribution reached the *earlier*
    unstageable branch and dispatched, and a lone irreversible contribution with
    no confirmation reached the later one and dispatched too.

    *The reference must be admissible.* This is §4.2.1. Admission is evaluated
    against the state *now*, not against whatever made this configuration the
    reference, and a failure carries both reasons: whoever debugs it needs to
    know the candidate failed *and* that the thing it would have fallen back to
    was not allowed either.
    """
    unrestored = _unrestored_session(staged)
    if unrestored is not None:
        session_refusal, why = unrestored
        return CommitOutcome(
            action=CommitAction.CANNOT_EXECUTE,
            refusal=session_refusal,
            detail=f"{detail}; and {why}",
        )
    admission = admit(reference)
    if admission.admitted:
        return CommitOutcome(action=action, refusal=refusal, detail=detail)
    return CommitOutcome(
        action=CommitAction.CANNOT_EXECUTE,
        refusal=CommitRefusal.REFERENCE_INADMISSIBLE,
        detail=detail,
        admission_reason=admission.reason,
    )


def commit(
    plan: Plan,
    staged: Sequence[StagedContribution],
    confirmation: StagingConfirmation | Sequence[StagingConfirmation] | None,
    *,
    reference: Configuration,
    admit: Callable[[Configuration], Admission],
    expected_components: Sequence[str] | None = None,
) -> CommitOutcome:
    """Decide whether to materialize a plan, fall back, or dispatch nothing.

    ``reference`` is what runs if the plan does not. Because staging applies
    nothing, it is simply the configuration that was already active — which is
    the property that makes "reconstruct the reference" trivial rather than an
    unwind.

    ``expected_components`` is the manifest: every component this plan requires
    a contribution from. It defaults to the components that staged, which is
    correct only for a single-component deployment and is why a multi-component
    caller must pass it — otherwise an upstream component that failed to stage
    looks exactly like a plan that never expected one.
    """
    if expected_components is None:
        expected_components = [c.component for c in staged]
    if plan.disposition is Disposition.CANNOT_EXECUTE:
        return CommitOutcome(
            action=CommitAction.CANNOT_EXECUTE,
            refusal=CommitRefusal.REFERENCE_INADMISSIBLE,
            detail="plan disposition is cannot_execute",
            admission_reason=plan.reason,
        )

    # Only APPLY applies. A SUGGEST plan cleared validation on the weaker claim
    # that the adapter could *show* its changes, so materializing it would apply
    # a configuration on authority nobody granted — and a RETAIN plan changes
    # nothing by definition, so materializing it can only mean applying
    # something the plan did not ask for.
    if plan.disposition is not Disposition.APPLY:
        action = (
            CommitAction.SURFACE
            if plan.disposition is Disposition.SUGGEST
            else CommitAction.REFERENCE
        )
        return reference_or_stop(
            staged,
            reference,
            admit,
            CommitRefusal.NOT_APPLICABLE,
            f"disposition is {plan.disposition.value}, which applies nothing",
            action=action,
        )

    unstageable = [
        c for c in staged if c.contribution_class is ContributionClass.NEITHER
    ]
    if unstageable and len(staged) > 1:
        names = ", ".join(sorted(c.component for c in unstageable))
        return reference_or_stop(
            staged,
            reference,
            admit,
            CommitRefusal.UNSTAGEABLE_CONTRIBUTION,
            f"{names} can be neither staged nor restored, so this plan cannot be split "
            "across components",
        )

    # An unconfirmed restore STOPS. Admission answers "may this configuration
    # run", which is a different question from "was the session put back", and
    # using one to answer the other dispatches into a session whose tools and
    # state nobody established. There is no safe target to fall back to, because
    # the thing in doubt is what the session currently *is*.
    denied = [
        c
        for c in staged
        if c.contribution_class is ContributionClass.RESTORABLE
        and not c.restore_confirmed
    ]
    if denied:
        names = ", ".join(sorted(c.component for c in denied))
        return CommitOutcome(
            action=CommitAction.CANNOT_EXECUTE,
            refusal=CommitRefusal.RESTORE_UNCONFIRMED,
            detail=(
                f"{names} could not confirm its restore; the session's configuration is "
                "unknown, and admission cannot establish that it was put back"
            ),
        )

    # Every expected component must have staged, and each must be confirmed.
    # Without a manifest, an upstream component that failed to stage is
    # indistinguishable from a legitimately single-component plan, and one
    # matching confirmation would authorize every contribution beside it.
    staged_by_component = {c.component: c for c in staged}
    if len(staged_by_component) != len(staged):
        return reference_or_stop(
            staged,
            reference,
            admit,
            CommitRefusal.UNEXPECTED_CONTRIBUTION,
            "two contributions claim the same component; one would authorize the other",
        )

    expected = frozenset(expected_components or ())
    missing = expected - set(staged_by_component)
    if missing:
        return reference_or_stop(
            staged,
            reference,
            admit,
            CommitRefusal.MISSING_CONTRIBUTION,
            f"expected contributions from {sorted(missing)} and none arrived; a component "
            "that failed to stage must not look like a plan that never had one",
        )
    surplus = set(staged_by_component) - expected
    if surplus:
        return reference_or_stop(
            staged,
            reference,
            admit,
            CommitRefusal.UNEXPECTED_CONTRIBUTION,
            f"contributions from {sorted(surplus)} were not expected for this plan",
        )

    # Confirmations are matched by component, not by digest. Two components
    # staging identical shares produce identical digests by construction, and a
    # digest-keyed lookup would let either one's confirmation authorize the
    # other's contribution — the same unauthorized ride-along the manifest
    # refuses, reached from the confirmation side.
    confirmations = _as_confirmations(confirmation)
    by_component: dict[str, StagingConfirmation] = {}
    for posted in confirmations:
        seen = by_component.get(posted.component)
        if seen is not None and seen != posted:
            return reference_or_stop(
                staged,
                reference,
                admit,
                CommitRefusal.CONFIRMATION_MISMATCH,
                f"{posted.component} posted two confirmations that disagree; a keyed lookup "
                "would silently keep whichever arrived last",
            )
        by_component[posted.component] = posted

    stray = sorted(set(by_component) - set(staged_by_component))
    if stray:
        return reference_or_stop(
            staged,
            reference,
            admit,
            CommitRefusal.UNEXPECTED_CONTRIBUTION,
            f"confirmations arrived from {stray}, which staged nothing for this plan",
        )

    for component, contribution in sorted(staged_by_component.items()):
        match = by_component.get(component)
        if match is None:
            return reference_or_stop(
                staged,
                reference,
                admit,
                CommitRefusal.NO_CONFIRMATION,
                f"{component} staged a contribution that no confirmation covers",
            )
        if match.contribution_digest != contribution.digest:
            return reference_or_stop(
                staged,
                reference,
                admit,
                CommitRefusal.CONFIRMATION_MISMATCH,
                f"{component}'s confirmation covers a different contribution than the one "
                "it staged",
            )
        if match.decision_id != plan.decision_id:
            return reference_or_stop(
                staged,
                reference,
                admit,
                CommitRefusal.CONFIRMATION_MISMATCH,
                f"{component}'s confirmation names plan {match.decision_id!r}, commit point "
                f"holds {plan.decision_id!r}",
            )
        if match.base_config_digest != plan.base_config_digest:
            return reference_or_stop(
                staged,
                reference,
                admit,
                CommitRefusal.STALE_BASELINE,
                f"{component}'s confirmation was computed against a different baseline "
                "than the plan",
            )

    return CommitOutcome(action=CommitAction.MATERIALIZE)
