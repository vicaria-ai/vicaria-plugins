"""Upload selection: which episodes left the machine, and with what probability.

RFC 0009 §2.3 names three sampling decisions and insists they stay apart.

| Decision | Made by | Population |
| --- | --- | --- |
| **Upload** | the adapter, per episode | all activity on the machine |
| **Grading** | the server, per uploaded episode | the uploaded episodes |
| **Assignment** | whatever applies the plan | tasks in the experiment |

Grading is RFC 0008's :class:`~vicaria_contracts.provenance.RunSelection`. Assignment is
the execution-assignment record. Upload was the one nothing wrote, which is the
worst of the three to be missing: it is the *first* filter, so every downstream
population inherits it, and an organization-wide claim built without it is a
claim about whatever the adapter happened to send.

WHY A FILTER IS NOT ENOUGH

§2.2: the adapter chooses what leaves the machine, and a plausible policy —
upload every failure, sample successes — makes the uploaded population
systematically unlike the organization's. Grading weights applied downstream
cannot repair it, because the distortion happened before grading had anything to
weight. So the choice is recorded as a probability rather than performed as a
filter, and the probability travels with the episode.

POSITIVITY IS A PROPERTY OF THE POLICY, NOT OF AN EPISODE

A stratum with rate zero produces no episodes, so there is nowhere to attach the
fact that it was excluded — the evidence of the exclusion is exactly the thing
the exclusion removed. §2.2 states the consequence: *where it is zero for a
stratum, no episode from that stratum exists and no amount of weighting invents
one.* :class:`UploadPolicy` therefore refuses a zero rate when the policy is
written, which is the last moment anything can be done about it.

The same reasoning forbids a deterministic budget — "upload the first hundred,
then stop" gives every later episode probability zero while the policy still
reads as a 100% sample. RFC 0008 §2 makes the identical argument for judgment
sampling, and the fix is the same: randomize, or declare the selection
``PURPOSIVE`` and give up projecting from it.

THE CONFLATION THIS IS SHAPED TO PREVENT

Presenting a grading rate as a propensity asserts a randomized comparison that
never happened: grading is decided *after* execution and says nothing about
alternatives that never ran. The same is true of an upload rate. So
:func:`organization_inclusion` composes exactly the two selections that do
compose — upload and grading — and there is no function here that will accept an
assignment propensity, because there is no arithmetic in which it belongs.

WHAT IT DOES NOT PROVE

That the two records describe the same episode. :class:`RunSelection` carries no
episode id — it identifies a run — so the join is the caller's and this module
checks the arithmetic, not the linkage. The composed result names both policies
so an auditor can see which two rules were multiplied.
"""

from __future__ import annotations

import hashlib
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from types import MappingProxyType
from typing import Any

from vicaria_contracts._wire import (
    require_enum,
    require_mapping,
    require_schema,
    require_str,
)
from vicaria_contracts.provenance import SELECTION_CENSUS, RunSelection, SelectionMode

UPLOAD_SELECTION_SCHEMA_VERSION = "vicaria.upload-selection.v1"

#: Versioned: changing it re-randomizes every episode not yet selected, which is
#: a change to the sample and not a refactor.
_DRAW_SALT = "vicaria.upload.draw.v1"
_SCALE = float(1 << 64)


def _require_id(value: Any, name: str) -> None:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} must be a nonempty string, got {value!r}")


def _check_rate(value: Any, name: str) -> float:
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise ValueError(f"{name} must be a number, got {value!r}")
    rate = float(value)
    if rate != rate or rate in (float("inf"), float("-inf")):
        raise ValueError(f"{name} must be finite, got {value!r}")
    if not 0.0 < rate <= 1.0:
        raise ValueError(
            f"{name} must be in (0, 1], got {value!r} — a zero rate produces no episodes "
            "from that stratum, so there is nothing to weight and nothing to attach the "
            "exclusion to; the stratum must be removed from the frame rather than sampled "
            "at zero"
        )
    return rate


@dataclass(frozen=True, slots=True)
class UploadSelection:
    """Why one episode left the machine, recorded at selection time.

    ``stratum`` is the population ``probability`` is over, and it is required
    even for a census: "1.0 of what" is the question a later weighting has to
    answer, and an unnamed frame makes every rate incomparable with every other.
    """

    selection_id: str
    episode_id: str
    policy_id: str
    stratum: str
    mode: SelectionMode = SelectionMode.PROBABILITY
    probability: float | None = None

    def __post_init__(self) -> None:
        for name in ("selection_id", "episode_id", "policy_id", "stratum"):
            _require_id(getattr(self, name), name)
        if not isinstance(self.mode, SelectionMode):
            raise ValueError(
                f"mode must be a SelectionMode, got {type(self.mode).__name__}"
            )
        if self.mode is SelectionMode.PROBABILITY:
            if self.probability is None:
                raise ValueError(
                    "a probability selection must state its probability — absent must "
                    "never be read as census, which is the reading that turns a 5% sample "
                    "into an organization-wide claim"
                )
            object.__setattr__(
                self, "probability", _check_rate(self.probability, "probability")
            )
        elif self.probability is not None:
            raise ValueError(
                "a purposive selection has no inclusion probability: it was chosen, not "
                "drawn, and a number here would let it be projected from"
            )

    @property
    def projectable(self) -> bool:
        """True when this episode can be weighted up to its population.

        A purposive selection is not a defect — a hand-picked calibration set is
        a legitimate thing to upload — but it supports no claim about the
        organization's workload, and saying so is what the field is for.
        """
        return self.mode is SelectionMode.PROBABILITY

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": UPLOAD_SELECTION_SCHEMA_VERSION,
            "selection_id": self.selection_id,
            "episode_id": self.episode_id,
            "policy_id": self.policy_id,
            "stratum": self.stratum,
            "mode": self.mode.value,
            "probability": self.probability,
        }

    @classmethod
    def from_dict(cls, payload: Any) -> UploadSelection:
        """Read a selection off the wire.

        ``mode`` is required rather than defaulted. On the wire an absent mode
        beside an absent probability would read as a purposive selection, and an
        absent mode beside a present one as a probability sample — so the reader
        would be inferring the discriminator from the field it discriminates.
        """
        obj = require_mapping(payload, "upload selection")
        require_schema(obj, UPLOAD_SELECTION_SCHEMA_VERSION)
        probability = obj.get("probability")
        if probability is not None and (
            isinstance(probability, bool) or not isinstance(probability, int | float)
        ):
            raise ValueError(
                f"probability must be a number or null, got {probability!r}"
            )
        return cls(
            selection_id=require_str(obj, "selection_id"),
            episode_id=require_str(obj, "episode_id"),
            policy_id=require_str(obj, "policy_id"),
            stratum=require_str(obj, "stratum"),
            mode=require_enum(obj, "mode", SelectionMode),
            probability=probability,
        )


@dataclass(frozen=True, slots=True)
class UploadPolicy:
    """A named upload rule: which strata are sampled, and at what rate.

    The policy draws as well as declares, so the recorded probability is the one
    the draw used. A caller that selected by one rule and recorded another would
    be maintaining the number in two places, and the copy that drifts is the one
    the analysis trusts.

    The draw is a pure function of ``sha256(salt, policy_id, episode_id)``. An
    episode reconsidered for upload — a retry, a resumed buffer after a network
    loss, a second pass over the same day — must not get a second chance to be
    selected. Drawing again gives an episode with rate *p* a real inclusion
    probability of ``1 - (1 - p)**k`` for *k* looks, while its record still says
    *p*, and the k that produced it is exactly what the buffer's failure history
    determines. Nothing downstream can see it.
    """

    policy_id: str
    rates: Mapping[str, float]

    def __post_init__(self) -> None:
        _require_id(self.policy_id, "policy_id")
        if not isinstance(self.rates, Mapping):
            raise ValueError(
                f"rates must be a mapping, got {type(self.rates).__name__}"
            )
        if not self.rates:
            raise ValueError(
                "an upload policy with no strata samples nothing, and a policy that "
                "uploads nothing should be absent rather than configured"
            )
        checked: dict[str, float] = {}
        for stratum, rate in self.rates.items():
            _require_id(stratum, "stratum")
            checked[stratum] = _check_rate(rate, f"rate for {stratum!r}")
        object.__setattr__(self, "rates", MappingProxyType(checked))

    def covers(self, stratum: str) -> bool:
        return stratum in self.rates

    def select(
        self, *, selection_id: str, episode_id: str, stratum: str
    ) -> UploadSelection | None:
        """The selection for one episode, or ``None`` when it is not uploaded.

        A stratum the policy does not name raises rather than defaulting to any
        rate. Silently sampling an unnamed stratum at 1.0 would upload it and
        claim a census; at 0.0 it would drop it and leave no record that anything
        was dropped — and the second is the failure §2.2 says cannot be repaired
        downstream.
        """
        _require_id(episode_id, "episode_id")
        if stratum not in self.rates:
            raise ValueError(
                f"policy {self.policy_id!r} names no rate for stratum {stratum!r}; add one "
                "or remove the stratum from the frame, because a default here is either an "
                "unclaimed census or a silent exclusion"
            )
        rate = self.rates[stratum]
        if _uniform(self.policy_id, episode_id) >= rate:
            return None
        return UploadSelection(
            selection_id=selection_id,
            episode_id=episode_id,
            policy_id=self.policy_id,
            stratum=stratum,
            mode=SelectionMode.PROBABILITY,
            probability=rate,
        )

    def census(self, *, selection_id: str, episode_id: str) -> UploadSelection:
        """Every episode, recorded as a probability sample at 1.0.

        A census is a sample whose rate is one, not a different kind of thing.
        Giving it its own mode would create a value that means "no probability
        applies" and a value that means "the probability is 1.0", and downstream
        weighting has to tell them apart.
        """
        return UploadSelection(
            selection_id=selection_id,
            episode_id=episode_id,
            policy_id=self.policy_id,
            stratum=SELECTION_CENSUS,
            mode=SelectionMode.PROBABILITY,
            probability=1.0,
        )


def _uniform(policy_id: str, episode_id: str) -> float:
    """A uniform in [0, 1), stable across processes, hosts and releases.

    Joined on NUL rather than concatenated: ``("ab", "c")`` and ``("a", "bc")``
    otherwise hash identically, so two episodes under two policies draw the same
    number — a real correlation between samples that are supposed to be
    independent, with nothing in the records to show for it.
    """
    material = "\x00".join((_DRAW_SALT, policy_id, episode_id)).encode("utf-8")
    return int.from_bytes(hashlib.sha256(material).digest()[:8], "big") / _SCALE


@dataclass(frozen=True, slots=True)
class OrganizationInclusion:
    """The probability an episode reached the graded set, out of everything that
    ran on the machine — over **every** path by which it could have got there.

    ``probability`` is ``None`` when the composition does not exist, and
    ``unknown_reason`` says which side made it so. That is not the same as a
    small probability, and a consumer that treated it as one would weight a
    hand-picked episode as though it stood for a population.

    ``grading_policies`` names every grading selection composed, in the order
    given. A single-path inclusion is the special case of one; there is no
    field for "the" grading policy because a run can enter the graded set by
    more than one, and a number computed from one of them is a
    :class:`PathInclusion`, not this.
    """

    probability: float | None
    upload_policy: str
    grading_policies: tuple[str, ...]
    unknown_reason: str | None = None

    def __post_init__(self) -> None:
        if (self.probability is None) == (self.unknown_reason is None):
            raise ValueError(
                "an inclusion is a probability or a reason there is none, never both and "
                "never neither"
            )
        if self.probability is not None:
            _check_rate(self.probability, "probability")
        if not self.grading_policies or not all(
            isinstance(g, str) and g for g in self.grading_policies
        ):
            raise ValueError("grading_policies must name at least one policy")

    @property
    def projectable(self) -> bool:
        return self.probability is not None


@dataclass(frozen=True, slots=True)
class PathInclusion:
    """The probability of reaching the graded set **through one grading path**.

    Deliberately a different type from :class:`OrganizationInclusion`, with no
    ``projectable`` property: a run can enter the graded set by several paths —
    a production probability sample and a purposive calibration pick, say — and
    the number for one of them is not the marginal for the graded set. RFC 0008
    §4.1/§8 defers that marginal; this is the honest partial, labelled as such.
    """

    probability: float | None
    upload_policy: str
    grading_policy: str
    unknown_reason: str | None = None

    def __post_init__(self) -> None:
        if (self.probability is None) == (self.unknown_reason is None):
            raise ValueError(
                "an inclusion is a probability or a reason there is none, never both and "
                "never neither"
            )
        if self.probability is not None:
            _check_rate(self.probability, "probability")


def _require_upload(upload: object) -> UploadSelection:
    if not isinstance(upload, UploadSelection):
        raise ValueError(
            f"upload must be an UploadSelection, got {type(upload).__name__} — an "
            "assignment propensity is not an inclusion probability and does not compose "
            "with one (RFC 0009 §2.3)"
        )
    return upload


def _require_grading(grading: object) -> RunSelection:
    if not isinstance(grading, RunSelection):
        raise ValueError(
            f"grading must be a RunSelection, got {type(grading).__name__} — an assignment "
            "propensity is not an inclusion probability and does not compose with one "
            "(RFC 0009 §2.3)"
        )
    return grading


def path_inclusion(upload: UploadSelection, grading: RunSelection) -> PathInclusion:
    """The product of upload and **one** grading selection: inclusion through that path.

    An episode reached the graded set *by this path* by surviving upload and then
    this selection, so the probability is the product. What this is not is the
    organization inclusion, because it says nothing about the other paths by
    which the same run could have been graded — see :func:`organization_inclusion`.
    Assignment is not a factor on any path: it allocates *within* the experiment
    and is the only selection an execution-arm comparison reads (§2.3). There is
    deliberately no overload that takes a propensity.
    """
    upload = _require_upload(upload)
    grading = _require_grading(grading)
    names = {"upload_policy": upload.policy_id, "grading_policy": grading.policy_id}
    if upload.mode is SelectionMode.PURPOSIVE:
        return PathInclusion(
            probability=None,
            unknown_reason=(
                "the upload selection was purposive, so this episode was chosen rather than "
                "drawn and supports no claim about the organization's workload"
            ),
            **names,
        )
    if grading.mode is SelectionMode.PURPOSIVE:
        return PathInclusion(
            probability=None,
            unknown_reason=(
                "the grading selection was purposive, so the graded set is not a probability "
                "sample of the uploaded one"
            ),
            **names,
        )
    assert upload.probability is not None and grading.probability is not None
    return PathInclusion(probability=upload.probability * grading.probability, **names)


def organization_inclusion(
    upload: UploadSelection,
    grading: RunSelection | Sequence[RunSelection] | Sequence[Sequence[RunSelection]],
    *,
    exhaustive: bool,
) -> OrganizationInclusion:
    """The marginal probability an episode reached the graded set, over every path.

    ``grading`` is **every** path by which this run could have entered the graded
    set, and ``exhaustive=True`` is the caller's assertion of exactly that. A
    total computed over a partial list is not a total, so ``exhaustive=False``
    is refused rather than quietly returning a number for one path — that number
    is :func:`path_inclusion`, and it has its own type so it cannot be mistaken
    for this one.

    Shape of ``grading``: one :class:`RunSelection` is one path; a flat sequence
    is one path per element, alternatives; a sequence of sequences is one
    *chain* per inner sequence (conditional selections along a path, which
    multiply), the chains being alternatives. Alternatives are composed as
    independent: ``P = p_upload · (1 - ∏(1 - p_path))``, which for one path is
    the plain product. A caller whose paths are dependent must not pass more
    than one. Any purposive selection anywhere makes the marginal unknowable and
    the result says so (RFC 0008 §4.1/§8 defers exactly this case).

    The join is the caller's. :class:`RunSelection` identifies a run, not an
    episode, so nothing here can confirm the records describe the same work;
    every policy id is carried through so an auditor can see what was composed.
    """
    upload = _require_upload(upload)
    if not exhaustive:
        raise ValueError(
            "organization_inclusion requires exhaustive=True: the caller must assert that "
            "these are every path by which the run could have entered the graded set. "
            "For one path of possibly several, use path_inclusion(), which is typed as "
            "the partial it is"
        )
    chains: list[list[RunSelection]]
    if isinstance(grading, RunSelection):
        chains = [[grading]]
    elif not isinstance(grading, list | tuple):
        _require_grading(grading)  # raises: neither a selection nor a list of them
        raise AssertionError("unreachable")
    else:
        items = list(grading)
        if not items:
            raise ValueError("grading must name at least one path")
        if all(isinstance(item, RunSelection) for item in items):
            chains = [[item] for item in items]  # type: ignore[list-item]
        else:
            chains = [list(chain) for chain in items]  # type: ignore[arg-type]
            if any(not chain for chain in chains):
                raise ValueError(
                    "every grading path must contain at least one selection"
                )
    for chain in chains:
        for selection_ in chain:
            _require_grading(selection_)

    policies = tuple(sel.policy_id for chain in chains for sel in chain)
    if upload.mode is SelectionMode.PURPOSIVE:
        return OrganizationInclusion(
            probability=None,
            unknown_reason=(
                "the upload selection was purposive, so this episode was chosen rather than "
                "drawn and supports no claim about the organization's workload"
            ),
            upload_policy=upload.policy_id,
            grading_policies=policies,
        )
    purposive = [
        sel.policy_id
        for chain in chains
        for sel in chain
        if sel.mode is SelectionMode.PURPOSIVE
    ]
    if purposive:
        return OrganizationInclusion(
            probability=None,
            unknown_reason=(
                f"grading path(s) {purposive} were purposive, so the marginal probability of "
                "reaching the graded set is unknowable: a chosen path is not a drawn one, and "
                "no number for the other paths repairs that"
            ),
            upload_policy=upload.policy_id,
            grading_policies=policies,
        )
    assert upload.probability is not None
    miss = 1.0
    for chain in chains:
        p_chain = 1.0
        for sel in chain:
            assert sel.probability is not None
            p_chain *= sel.probability
        miss *= 1.0 - p_chain
    return OrganizationInclusion(
        probability=upload.probability * (1.0 - miss),
        upload_policy=upload.policy_id,
        grading_policies=policies,
    )


def summarize(selection: UploadSelection | None, episode_id: str) -> Mapping[str, Any]:
    """A recordable form for an episode, uploaded or not.

    An episode the policy did not select still has a fact about it — that it was
    considered and not drawn — and a caller with only the uploaded selections
    cannot tell "not selected" from "never considered". This is the shape that
    difference travels in, for a local buffer that never leaves the machine.
    """
    _require_id(episode_id, "episode_id")
    if selection is None:
        return {"episode_id": episode_id, "uploaded": False, "selection": None}
    if selection.episode_id != episode_id:
        raise ValueError(
            f"selection names episode {selection.episode_id!r}, summary names {episode_id!r}"
        )
    return {
        "episode_id": episode_id,
        "uploaded": True,
        "selection": selection.to_dict(),
    }


__all__ = [
    "UPLOAD_SELECTION_SCHEMA_VERSION",
    "OrganizationInclusion",
    "PathInclusion",
    "UploadPolicy",
    "UploadSelection",
    "organization_inclusion",
    "path_inclusion",
    "summarize",
]
