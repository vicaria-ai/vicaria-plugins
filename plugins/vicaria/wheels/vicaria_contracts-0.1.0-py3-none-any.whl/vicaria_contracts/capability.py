"""The capability descriptor — what an adapter can actually do (RFC 0009 §3).

WHY THIS EXISTS

RFC 0005 established the rule for trace fields: an adapter states what it holds,
and the shared layer never discovers a capability by probing for a plausible
key. RFC 0009 §3 applies that rule to *control*, where the cost of breaking it
is higher. A wrong guess about a trace field produces a wrong number; a wrong
guess about a control produces a run whose configuration nobody knows, and every
record of it looks consistent.

WHAT A LEVEL IS FOR

A boolean cannot serve both dispositions. If "present" means *the adapter can
set this*, a constrained adapter must omit the control — and then a `suggest`
plan naming it is refused too, destroying the fallback `suggest` exists to
provide. If "present" means *the adapter knows about this*, validation stops
proving anything about application. So each control carries a level, and
:func:`satisfies` is the only place the ordering between levels lives.

``OBSERVE`` is not a filler value. A control the adapter can read but not set is
how the original-versus-effective record gets its "original" for a field nobody
can change, and it is how an unchanged dimension is verified against the
baseline rather than assumed (RFC 0009 §4.1).

WHAT IT DOES NOT PROVE

A descriptor is a claim by the adapter about a harness version. Nothing here
executes anything, so nothing here can tell you the claim is true: that is what
the control conformance suite is for (RFC 0009 §6), and until a suite has run
against a named version an entry in ``docs/harness-support.md`` stays a claim.
``UNKNOWN`` is therefore a real and useful answer — an adapter that cannot
determine a capability says so, rather than guessing in either direction.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from types import MappingProxyType
from typing import Any

from vicaria_contracts._wire import (
    optional_enum,
    require_enum,
    require_mapping,
    require_schema,
    require_str,
)

CAPABILITY_DESCRIPTOR_SCHEMA_VERSION = "vicaria.capability-descriptor.v1"


class Dimension(str, Enum):
    """The dimensions of a complete configuration.

    Closed by design. A configuration that resolves every dimension is the
    invariant RFC 0009 §4.0 depends on, and an open set would make "every
    dimension" unprovable.
    """

    MODEL = "model"
    EFFORT = "effort"
    PROMPT = "prompt"
    TOOLS = "tools"
    WORKFLOW = "workflow"


class ControlLevel(str, Enum):
    """What an adapter can do with one dimension. Ordered by :func:`satisfies`."""

    APPLY = "apply"  # sets it, and confirms the change from receipts
    SUGGEST = "suggest"  # displays the proposed change; sets nothing
    OBSERVE = "observe"  # reads the current value; changes nothing
    UNKNOWN = "unknown"  # cannot determine — never read as "no" or as "yes"


#: Ascending capability. Kept private: callers ask :func:`satisfies`, so the
#: ordering exists in exactly one place and a new level cannot be compared
#: incidentally by some other rule.
_RANK: Mapping[ControlLevel, int] = MappingProxyType(
    {
        ControlLevel.UNKNOWN: 0,
        ControlLevel.OBSERVE: 1,
        ControlLevel.SUGGEST: 2,
        ControlLevel.APPLY: 3,
    }
)


def satisfies(held: ControlLevel, required: ControlLevel) -> bool:
    """True when ``held`` is at least ``required``.

    ``UNKNOWN`` satisfies nothing, including itself: a dimension the adapter can
    neither set nor read cannot be applied *or* verified, so it fails a plan
    either way (RFC 0009 §4.1). Returning True for ``UNKNOWN >= UNKNOWN`` would
    make an unverifiable dimension pass whenever nothing was required of it.
    """
    if held is ControlLevel.UNKNOWN or required is ControlLevel.UNKNOWN:
        return False
    return _RANK[held] >= _RANK[required]


class PromptShape(str, Enum):
    """Additive and substitutive are different capabilities (RFC 0009 §3.1).

    A harness that can only add instructions alongside the user's prompt and one
    that can replace it are offering different controls, and ``prompt: true``
    collapses them. Claude Code is ``ADDITIVE``: its hooks reference names three
    content-rewriting events and says of the fourth that ``UserPromptSubmit``
    "can't replace the prompt; it only injects ``additionalContext`` alongside
    it."

    The consequence reaches the evaluator, not only the runtime. A patch
    evaluated as a replacement and applied as an addition is a different
    configuration, and every execution record of it is consistent — so the
    mismatch has to be caught here, before anything runs.
    """

    ADDITIVE = "additive"  # injects alongside; cannot replace
    SUBSTITUTIVE = "substitutive"  # replaces the prompt


class ValueSupport(str, Enum):
    """What an adapter has established about the values a dimension can take.

    Two different claims that a single ``None`` used to share. ``UNRESTRICTED``
    is a positive statement — any value reaches the harness, which is honest for
    a prompt recipe id nobody can enumerate. ``UNKNOWN`` is the *absence* of a
    statement, and it admits nothing, for the same reason
    :data:`ControlLevel.UNKNOWN` satisfies nothing: silence is not permission.

    Collapsing them is not cosmetic. An adapter that never enumerated its models
    would accept ``gpt-9``, pass validation, and discover at dispatch that it
    cannot reach it — after the user's turn has already started, which is the one
    place RFC 0009 §4.1 exists to keep the discovery out of.
    """

    UNRESTRICTED = "unrestricted"  # any value; a claim, made deliberately
    UNKNOWN = "unknown"  # nothing established; admits nothing


def _require_id(value: Any, name: str) -> None:
    """An identifier is a nonempty ``str``. Truthiness is not that check."""
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} must be a nonempty string, got {value!r}")


def _require_authorized(entry: Mapping[str, Any], where: str) -> bool:
    """``authorized`` is required on the wire, and absence is not permission.

    In-process the field defaults to ``True``: an adapter constructing a
    :class:`Control` is asserting a capability it holds, and says
    ``authorized=False`` when it finds it may not use one. On the wire the
    author of the payload is not the author of this reader, so a serializer that
    dropped the key would grant a permission nobody wrote down — the same
    failure ``controls`` refuses when a dimension is missing.
    """
    if "authorized" not in entry:
        raise ValueError(
            f"{where}.authorized is required — an absent grant read as permission is how "
            "a serializer bug authorizes a control no administrator granted"
        )
    authorized = entry["authorized"]
    if not isinstance(authorized, bool):
        raise ValueError(
            f"{where}.authorized must be a bool, got {type(authorized).__name__}"
        )
    return authorized


def _require_values(
    entry: Mapping[str, Any], where: str
) -> frozenset[str] | ValueSupport:
    """``values`` is required too, and there is no spelling for "nothing".

    ``null`` is refused rather than mapped to ``UNKNOWN``. The whole point of
    :class:`ValueSupport` is that "any value" and "we never said" are separate
    claims; leaving a third spelling that means one of them by convention puts
    the distinction back at the mercy of whoever writes the next serializer.
    """
    if "values" not in entry:
        raise ValueError(
            f"{where}.values is required — say {[m.value for m in ValueSupport]} or list the "
            "values, because an omission is as likely to be a serializer bug as a claim"
        )
    raw = entry["values"]
    if isinstance(raw, str):
        try:
            return ValueSupport(raw)
        except ValueError:
            valid = sorted(m.value for m in ValueSupport)
            raise ValueError(
                f"{where}.values must be a list of values or one of {valid}, got {raw!r}"
            ) from None
    if isinstance(raw, list | tuple):
        for item in raw:
            if not isinstance(item, str) or not item:
                raise ValueError(
                    f"{where}.values entries must be nonempty strings, got {item!r}"
                )
        return frozenset(raw)
    raise ValueError(
        f"{where}.values must be a list of values or one of "
        f"{sorted(m.value for m in ValueSupport)}, got {type(raw).__name__}"
    )


def _dump_values(values: frozenset[str] | ValueSupport) -> list[str] | str:
    return values.value if isinstance(values, ValueSupport) else sorted(values)


@dataclass(frozen=True, slots=True)
class Control:
    """What an adapter can do with one dimension, and to what.

    Three facts, kept apart because collapsing any two loses a refusal:

    ``level`` is the mechanism — can this package set the dimension, only show
    a recommendation about it, or only read it.

    ``authorized`` is whether this package may *use* that mechanism. RFC 0009
    §3.2: a harness exposing per-turn model selection has reported a capability
    of the harness, not a grant to every installed plugin. Folding an
    unauthorized control into ``UNKNOWN`` would make "we are not allowed" and
    "we could not tell" the same answer, and only one of them is fixable by
    asking an administrator.

    ``values`` is what the dimension may be set *to*, and it is three-valued for
    the same reason ``level`` is. A level says the adapter can select a model; it
    says nothing about whether ``gpt-9`` is one of them. An enumerated set admits
    exactly its members; :data:`ValueSupport.UNRESTRICTED` admits anything and is
    a claim the adapter makes deliberately; :data:`ValueSupport.UNKNOWN` — the
    default — admits **nothing**, because an adapter that has not said which
    values it can reach has not said it can reach this one.

    That default is deliberately inconvenient. A bare ``Control(APPLY)`` can be
    validated against no specific value until its author says which values exist
    or that any will do, and the inconvenience lands on the party that knows the
    answer rather than on a user whose turn fails at dispatch.
    """

    level: ControlLevel
    authorized: bool = True
    values: frozenset[str] | ValueSupport = ValueSupport.UNKNOWN

    def __post_init__(self) -> None:
        if not isinstance(self.level, ControlLevel):
            raise ValueError(
                f"level must be a ControlLevel, got {type(self.level).__name__}"
            )
        if not isinstance(self.authorized, bool):
            raise ValueError(
                f"authorized must be a bool, got {type(self.authorized).__name__}"
            )

        if isinstance(self.values, ValueSupport):
            return
        if not isinstance(self.values, frozenset | set | list | tuple):
            raise ValueError(
                "values must be a set of values, ValueSupport.UNRESTRICTED or "
                f"ValueSupport.UNKNOWN, got {type(self.values).__name__}"
            )
        values = frozenset(self.values)
        if not values:
            raise ValueError(
                "values must be nonempty, UNRESTRICTED or UNKNOWN — an empty set says "
                "every value is refused, which is what UNKNOWN already says"
            )
        for value in values:
            _require_id(value, "value")
        object.__setattr__(self, "values", values)

    @property
    def value_support(self) -> ValueSupport | None:
        """``None`` when the values are enumerated, otherwise which claim holds.

        Callers producing a refusal need this: "that value is not in the set"
        and "no set was ever declared" are different findings, and only the
        second is the adapter's to fix.
        """
        return self.values if isinstance(self.values, ValueSupport) else None

    def admits(self, value: str) -> bool:
        """True when this dimension may be set to ``value``.

        ``UNKNOWN`` admits nothing, including values that would obviously work.
        Reading silence as permission is precisely how a plan naming an
        unreachable model passes validation.
        """
        if self.values is ValueSupport.UNRESTRICTED:
            return True
        if self.values is ValueSupport.UNKNOWN:
            return False
        return value in self.values


#: The OpenCode adapter version the demo and the plan-validation fixtures
#: depict.  It is one constant rather than a literal in each script because it
#: had already drifted once: the plugin moved to 0.1.1 when it corrected a
#: published claim, and two scripts went on describing 0.1.0's capability
#: surface.  intelligent-tools' ``tests/test_cb_contracts.py``
#: (``test_the_demo_depicts_the_adapter_version_the_plugin_actually_is``) checks
#: this against the plugin's own ``runtime.ts`` and against
#: smart-gateway-bench's ``scripts/demo_loop_e2e.py`` literal when those
#: checkouts are present, and the plugin's ``test/contract.test.ts`` checks that
#: its vendored copy of the fixture depicts its ``runtime.ts`` version, so the
#: next move is a named failure rather than a fixture that quietly describes an
#: adapter nobody is running.  0.1.7 (2026-09-27): the plugin's capture notice
#: names TypeSafe AI, the decision-model provider, and the stand-in a policy
#: may put in its place (RFC 0034 §2.1); the notice version is quoted inside
#: the coverage document, so the adapter's identity moved.  0.1.8 (2026-09-27):
#: the plugin captures every file attached to a message, bytes included
#: (vicaria-docs RFC 0036), and its notice (v7) and coverage document say so.
#: 0.1.9: the plugin's recording-indicator claim says only what is true
#: (smart-gateway #40, which first took 0.1.6 for it; 0.1.6 and 0.1.7 reached
#: the plugin's main with other bytes first, and 0.1.8 is the attachments
#: release, smart-gateway #42, which landed before it).
DEMO_ADAPTER_VERSION = "0.1.9"

#: The harness version those same fixtures depict.
DEMO_HARNESS_VERSION = "1.18.30"


@dataclass(frozen=True, slots=True)
class CapabilityDescriptor:
    """What one adapter can do, on one harness version.

    ``controls`` is total over :class:`Dimension`: a dimension the adapter did
    not mention is stored as ``UNKNOWN`` rather than left absent, so that
    "unavailable" and "nobody said" cannot be told apart by a caller who forgot
    to check for the key. There is no default-on control.
    """

    harness: str
    harness_version: str
    adapter_version: str
    controls: Mapping[Dimension, Control]
    prompt_shape: PromptShape | None = None

    def __post_init__(self) -> None:
        for name in ("harness", "harness_version", "adapter_version"):
            _require_id(getattr(self, name), name)

        if not isinstance(self.controls, Mapping):
            raise ValueError(
                f"controls must be a mapping, got {type(self.controls).__name__}"
            )

        filled: dict[Dimension, Control] = {}
        for dimension in Dimension:
            control = self.controls.get(dimension, Control(ControlLevel.UNKNOWN))
            if isinstance(control, ControlLevel):  # convenience: a bare level
                control = Control(control)
            if not isinstance(control, Control):
                raise ValueError(
                    f"control for {dimension.value} must be a Control or ControlLevel, "
                    f"got {type(control).__name__}"
                )
            filled[dimension] = control

        unknown_keys = set(self.controls) - set(Dimension)
        if unknown_keys:
            names = sorted(str(k) for k in unknown_keys)
            raise ValueError(f"controls names dimensions that do not exist: {names}")

        object.__setattr__(self, "controls", MappingProxyType(filled))

        prompt = filled[Dimension.PROMPT].level
        declares_prompt_change = satisfies(prompt, ControlLevel.SUGGEST)
        if declares_prompt_change and self.prompt_shape is None:
            raise ValueError(
                f"prompt control is {prompt.value}, so prompt_shape must be declared — "
                "additive and substitutive are different capabilities (RFC 0009 §3.1)"
            )
        if not declares_prompt_change and self.prompt_shape is not None:
            raise ValueError(
                f"prompt control is {prompt.value}, which changes no prompt, so "
                f"prompt_shape={self.prompt_shape.value!r} would describe a capability "
                "this adapter does not claim"
            )
        if self.prompt_shape is not None and not isinstance(
            self.prompt_shape, PromptShape
        ):
            raise ValueError(
                f"prompt_shape must be a PromptShape, got {type(self.prompt_shape).__name__}"
            )

    def control(self, dimension: Dimension) -> Control:
        """The control held for one dimension. Total, so this never raises."""
        return self.controls[dimension]

    def level(self, dimension: Dimension) -> ControlLevel:
        """The mechanism held for one dimension, ignoring authorization.

        Callers deciding whether a plan may proceed want
        :meth:`control` — level alone cannot tell an unauthorized control from
        a permitted one, and the two need different refusals.
        """
        return self.controls[dimension].level

    @classmethod
    def from_dict(cls, payload: Any) -> CapabilityDescriptor:
        """Read a descriptor off the wire.

        The descriptor is the server's only account of what a client can do, so
        this is a trust boundary: a malformed level read as a permissive default
        would authorize an application the adapter cannot perform. Every field
        is required to be well-formed, and ``controls`` must name a level for
        every dimension — a payload that omits one is refused rather than
        silently filled with ``UNKNOWN``, because on the wire an omission is as
        likely to be a serializer bug as a deliberate claim.
        """
        obj = require_mapping(payload, "capability descriptor")
        require_schema(obj, CAPABILITY_DESCRIPTOR_SCHEMA_VERSION)
        raw = require_mapping(obj.get("controls"), "controls")
        controls: dict[Dimension, Control] = {}
        for dimension in Dimension:
            where = f"controls.{dimension.value}"
            entry = require_mapping(raw.get(dimension.value), where)
            controls[dimension] = Control(
                level=require_enum(entry, "level", ControlLevel),
                authorized=_require_authorized(entry, where),
                values=_require_values(entry, where),
            )
        return cls(
            harness=require_str(obj, "harness"),
            harness_version=require_str(obj, "harness_version"),
            adapter_version=require_str(obj, "adapter_version"),
            controls=controls,
            prompt_shape=optional_enum(obj, "prompt_shape", PromptShape),
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": CAPABILITY_DESCRIPTOR_SCHEMA_VERSION,
            "harness": self.harness,
            "harness_version": self.harness_version,
            "adapter_version": self.adapter_version,
            "controls": {
                d.value: {
                    "level": self.controls[d].level.value,
                    "authorized": self.controls[d].authorized,
                    "values": _dump_values(self.controls[d].values),
                }
                for d in Dimension
            },
            "prompt_shape": self.prompt_shape.value if self.prompt_shape else None,
        }
