"""Versioned, standard-library-only contracts shared by Vicaria components."""

__version__ = "0.1.0"
