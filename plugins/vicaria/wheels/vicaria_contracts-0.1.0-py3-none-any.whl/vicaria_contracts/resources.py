"""Installed contract resources, independent of repository layout."""

import importlib.util
import sys
import threading
from pathlib import Path
from types import ModuleType

ROOT = Path(__file__).resolve().parent
CB = ROOT / "cb"
REGISTRIES = ROOT / "data" / "registries"
FIXTURES = ROOT / "data" / "fixtures"
_LOCK = threading.RLock()


def load_cb(name: str, directory: Path | None = None) -> ModuleType:
    """Use the CB validators' existing module keys so exception identity is shared.

    A process may use one corpus. Refuse mixing an override and installed bytes
    after loading, instead of silently returning a module from a different corpus.
    """
    if not name.isidentifier():
        raise ValueError("a CB module name must be an identifier")
    path = ((CB if directory is None else directory) / f"{name}.py").resolve()
    key = f"cb_contract_{name}"
    with _LOCK:
        if key in sys.modules:
            module = sys.modules[key]
            if Path(module.__file__).resolve() != path:
                raise RuntimeError(
                    f"CB corpus already loaded from {module.__file__}; refused {path}"
                )
            return module
        spec = importlib.util.spec_from_file_location(key, path)
        if spec is None or spec.loader is None:
            raise ImportError(f"cannot load CB contract {path}")
        module = importlib.util.module_from_spec(spec)
        sys.modules[key] = module
        try:
            spec.loader.exec_module(module)
        except BaseException:
            del sys.modules[key]
            raise
        return module
