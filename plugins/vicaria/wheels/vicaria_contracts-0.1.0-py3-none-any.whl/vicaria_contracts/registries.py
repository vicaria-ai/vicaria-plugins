"""The registry reader (RFC 0024 §4, RFC 0025 §8).

A registry is a versioned JSON file under ``contracts/registries/<name>.json``
holding ``{"registry": <name>, "version": <int>, "rows": [...]}`` (ruling R4).
RFC 0024 §4 printed a ``schema``-keyed envelope this reader never accepted and
has since moved to the envelope all ten shipped files carry, so the note that
this overrides the RFC is gone: the two agree. It is not a table, and the ten
names are a contract between three components that would
otherwise each invent them: the snapshot builder, which records
``registry_versions`` for every registry of §4; the kinds, which translate a
card's effort and model into the request's vocabulary at serving time; and the
version loader, which verifies a published directory's copies against the
versions its ``version.json`` names.

Neither half of the advisor may import the other, so the reader lives here,
beside the configuration-artifact function (RFC 0025 §8). Stdlib only.

``contracts/registries/`` is where RFC 0024 §4 puts the files, and the
distribution carries that same path so ``directory=None`` resolves in a
deployment and not only in a checkout: this package is installed non-editable
from git by the clients that pin it, and every default-argument caller --
including the kinds that translate on the request path -- reads whatever copy
pip produced. A caller that has a published version directory passes it
explicitly instead. Nothing imports ``contracts``; the reader opens the files by
path (``pyproject.toml``'s ``package-data``, and
``tests/offline/test_edges.py``).
"""

from __future__ import annotations

import json
import re
from collections.abc import Collection, Iterable, Mapping
from dataclasses import dataclass
from pathlib import Path
from types import MappingProxyType
from typing import Any

from vicaria_contracts.capability import ValueSupport
from vicaria_contracts.ids import unknown
from vicaria_contracts.timestamps import timestamp_to_unix_nanos

#: The ten registries of RFC 0024 §4, one file each, in the order of its table.
REGISTRY_NAMES: tuple[str, ...] = (
    "harness_profiles",  # 4.1
    "configuration_dimensions",  # 4.2
    "effort_scales_and_model_aliases",  # 4.3, one file: the §4 table has ten rows (ruling R4)
    "evaluators",  # 4.4
    "taxonomies",  # 4.5
    "annotators",  # 4.6
    "retrieval_key_views",  # 4.7
    "small_sets",  # 4.8 -- link kinds, step kinds, trigger kinds, roles, statuses
    "extra_namespaces",  # 4.9
    "advisor_kinds",  # 4.10
)

#: The source of record, beside the contracts the store reuses (RFC 0024 §4).
#: Relative to the ``traces`` package's own parent, so it is this repository in
#: a checkout and ``<site-packages>/contracts/registries`` in an install --
#: which is why the packaging has to ship it.
CONTRACTS = Path(__file__).resolve().parent / "data" / "registries"

#: A name is joined onto ``<name>.json``, so it is a plain word and never a path
#: of its own -- the same shape the loader already enforces
#: (``vicaria_server/advisors/version.py:40``), which admits no digits, so no
#: registry name may carry a version number.
_NAME_RE = re.compile(r"^[a-z_]+$")

#: Ruling R5: a candidate whose effort or model has no image in the request's
#: vocabulary is dropped inside the kind, never refused by the policy gate.
#: Both strings are members of ``vicaria_server.advisors.protocol.DROP_REASONS``,
#: which this module may not import and ``tests/test_registries.py`` compares to.
EFFORT_UNTRANSLATABLE = "effort_untranslatable"
MODEL_UNTRANSLATABLE = "model_untranslatable"

#: The one registry :func:`translate_effort` and :func:`translate_model` read.
#: RFC 0024 §4.3 puts both vocabularies in this single file (ruling R4).
EFFORT_AND_MODEL_REGISTRY = "effort_scales_and_model_aliases"


class RegistryError(RuntimeError):
    """A registry file this reader refuses, and why -- or a registry handed to a
    function that does not read it, which is a caller's mistake and not a file's.
    """


@dataclass(frozen=True, slots=True)
class Registry:
    """One registry file, read.

    The rows are read-only views. The serving path holds one ``Registry`` across
    requests (RFC 0025 §8), so a caller that edited a row :meth:`find` handed it
    rewrote the vocabulary every later translation reads -- with ``frozen=True``
    on this class saying that could not happen. The freeze is over each row's own
    keys; a list *inside* a row is still the caller's to misuse, which is a
    mistake about a value rather than about the registry.
    """

    name: str
    version: int
    rows: tuple[Mapping[str, Any], ...]

    def find(self, **match: Any) -> Mapping[str, Any] | None:
        """The first row whose every named field equals the given value."""
        for row in self.rows:
            if all(row.get(key) == value for key, value in match.items()):
                return row
        return None

    def select(self, **match: Any) -> tuple[Mapping[str, Any], ...]:
        """Every row whose every named field equals the given value, in file order."""
        return tuple(
            row for row in self.rows if all(row.get(k) == v for k, v in match.items())
        )


@dataclass(frozen=True, slots=True)
class Translation:
    """A value's image in the target vocabulary, or the reason it has none.

    Ruling R5 makes the second case a candidate drop inside the kind, counted in
    ``trace``; it never becomes a ``Change``, so it can never reach the policy
    gate and be answered as ``advisor_out_of_policy``.
    """

    value: str | None
    drop_reason: str | None

    @property
    def ok(self) -> bool:
        return self.drop_reason is None


def _path(name: str, directory: Path | str | None) -> Path:
    if not isinstance(name, str) or not _NAME_RE.fullmatch(name):
        raise RegistryError(f"registry name {name!r} has an invalid shape")
    base = CONTRACTS if directory is None else Path(directory)
    return base / f"{name}.json"


def read(name: str, *, directory: Path | str | None = None) -> Registry:
    """One registry, by name, from ``directory`` (default: this checkout's own).

    Every way the file can be wrong is a refusal that names the path: it is
    written by another process -- ``publish`` copies it into a version directory
    -- and a reader that guessed past a malformed envelope would serve a
    vocabulary nobody wrote.
    """
    path = _path(name, directory)
    try:
        doc = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, RecursionError) as exc:
        raise RegistryError(f"{path}: {exc}") from None
    if not isinstance(doc, Mapping):
        raise RegistryError(f"{path}: a registry is a JSON object")
    if doc.get("registry") != name:
        raise RegistryError(f"{path}: the file names registry {doc.get('registry')!r}")
    version = doc.get("version")
    if not isinstance(version, int) or isinstance(version, bool) or version < 1:
        raise RegistryError(f"{path}: version must be an integer of at least 1")
    rows = doc.get("rows")
    if not isinstance(rows, list) or any(not isinstance(row, Mapping) for row in rows):
        raise RegistryError(f"{path}: rows must be a list of objects")
    return Registry(
        name=name,
        version=version,
        rows=tuple(MappingProxyType(dict(row)) for row in rows),
    )


def registry_versions(
    names: Iterable[str] = REGISTRY_NAMES, *, directory: Path | str | None = None
) -> dict[str, int]:
    """``{name: version}`` for a snapshot's params (RFC 0024 §3.8).

    Every requested name is in the result, or a :class:`RegistryError` names the
    path of the first one that could not be read: it is all-or-raise, the same
    discipline :func:`verify_directory` documents for its own refusals, and for
    the same reason -- a snapshot records what it was built against, and a
    partial record is a claim about registries nobody read.

    So a short map is not one of the answers. A caller comparing the result's
    keys against the names it asked for, and raising its own error on the
    difference, has written a guard that can never fire, and the error it means
    to raise for a missing registry is instead an unwrapped ``RegistryError``
    leaving the job. A caller that wants its own exception type wraps the call
    (``except RegistryError as exc: raise JobError(...) from exc``) rather than
    inspecting the keys.

    ``names`` is read in sorted order, so a refusal names the alphabetically
    first unreadable registry rather than whichever the caller listed first.
    """
    return {name: read(name, directory=directory).version for name in sorted(names)}


def verify_directory(directory: Path | str, versions: Mapping[str, int]) -> None:
    """Refuse a published version directory whose copies are not the ones it names.

    ``directory`` is ``$VICARIA_ADVISOR_DIR/<org_id>/<version_id>/``; the copies
    are under its ``registries/`` (RFC 0025 §4, ruling R4).

    The check runs both ways, and every refusal is a :class:`RegistryError`
    naming the path: a version naming a registry the directory does not hold, a
    copy whose version is not the one named, a version whose number is not a
    number, and a copy the version never named at all -- a file nobody vouched
    for, in a directory another process wrote.

    "An integer" is :func:`read`'s own rule, applied to the named version too.
    ``int(versions[name])`` used to coerce, so ``"3"``, ``" 3 "``, ``3.0`` and
    ``3.9`` all verified clean against a file at version 3 -- the last by
    truncation -- while ``read`` refused the same laxness inside the file. The
    two halves of one integrity check may not disagree about what an integer is.

    An empty ``versions`` vouches for nothing rather than checking nothing: a
    directory with no ``registries/`` verifies clean, and one holding copies its
    version never named is refused by the surplus half.

    The caller is the version loader, whose own refusals are ``LoadError``, and
    ``RegistryError`` is not one of those: an operator-written registry file
    must be wrapped -- ``except RegistryError as exc: raise LoadError(...)`` --
    or it reaches the serving path as an uncaught ``RuntimeError``.
    """
    root = Path(directory)
    for name in sorted(versions):
        registry = read(name, directory=root / "registries")
        named = versions[name]
        if not isinstance(named, int) or isinstance(named, bool):
            raise RegistryError(
                f"{root}: registry {name!r} names a non-integer version {named!r}"
            )
        if registry.version != named:
            raise RegistryError(
                f"{root}: registry {name!r} is version {registry.version}, "
                f"not the {named} the version names"
            )
    surplus = sorted(
        path.stem
        for path in (root / "registries").glob("*.json")
        if path.stem not in versions
    )
    if surplus:
        raise RegistryError(
            f"{root}: registries/ holds {', '.join(surplus)}, which the version never names"
        )


def _accepted(accepted: Collection[str] | ValueSupport | None) -> frozenset[str] | None:
    """``accepted`` as a membership test, with the one-value call refused loudly.

    A ``str`` *is* a ``Collection[str]``, so ``accepted="xhigh"`` type-checks and
    then tests substrings: ``"high" in "xhigh"`` is an accept where ruling R5
    demands a drop, and the kind would propose a configuration the request
    cannot serve. Normalising alone would not catch it either --
    ``frozenset("xhigh")`` degrades to a set of characters rather than raising
    -- so the mistake is refused at the call site.

    :class:`vicaria_contracts.capability.ValueSupport` is the descriptor's other legal
    answer and is checked first, because it subclasses ``str``: the guard above
    refused both of its members, and an adapter that never enumerated its
    efforts or its models -- the case the enum exists for -- turned the first
    kind that translated a card into an outage where a drop was intended.
    ``UNRESTRICTED`` asks no question, which is ``None``'s answer;
    ``UNKNOWN`` is the absence of a claim, and silence is not permission
    (``traces/capability.py:126``), so it admits nothing and every candidate
    drops.
    """
    if accepted is None:
        return None
    if isinstance(accepted, ValueSupport):
        return None if accepted is ValueSupport.UNRESTRICTED else frozenset()
    if isinstance(accepted, str | bytes):
        raise TypeError(
            f"accepted is a collection of values, not one value: {accepted!r}"
        )
    return frozenset(accepted)


def _effort_and_model(registry: Any) -> None:
    """Refuse a registry that is not the one the translators read.

    Both translators take a bare :class:`Registry` and then ask it for a row.
    The ten registries are one type with one shape, so handing over the wrong
    one is the likeliest caller mistake there is -- and without this it is the
    one mistake the module answers with data rather than with an error:
    ``find`` matches no row, and the caller gets a clean ruling-R5 drop,
    counted in ``trace``, never raised, never at the policy gate. That is
    indistinguishable from a card whose effort the harness genuinely cannot
    take, and it is the same total, silent translation failure the effort rows
    were fixed for in an earlier round -- reachable now by a wiring mistake
    instead of a data one.

    So it raises, for the reason :func:`_accepted` raises and
    :func:`translate_effort` checks ``value`` before the row: the answer to a
    caller's mistake may not depend on data another process writes.
    """
    name = registry.name if isinstance(registry, Registry) else None
    if name != EFFORT_AND_MODEL_REGISTRY:
        shown = name if name is not None else type(registry).__name__
        raise RegistryError(
            f"{shown!r} is not the {EFFORT_AND_MODEL_REGISTRY} registry"
        )


def translate_effort(
    registry: Registry,
    *,
    family: str,
    value: str,
    accepted: Collection[str] | ValueSupport | None = None,
) -> Translation:
    """A native effort's image in ``accepted``, or the drop reason (RFC 0024 §4.3).

    ``accepted`` is the values the request's descriptor takes (ruling R5);
    ``None`` asks only for the family's own canonical spelling, which is the
    store's derived ``canonical_effort``. A value outside ``accepted`` is
    **dropped, never clamped**: a card measured at ``xhigh`` proposed as ``high``
    would be evidence about a configuration nobody ran.

    The row is untrusted input -- ``read`` validates the envelope, not the
    fields -- so a row whose ``aliases`` is not an object or whose ``values`` is
    not a list of strings is a drop too. This runs on the request path, and a
    kind that raises is an outage where a drop was intended. An unreadable alias
    table drops the whole family rather than falling back to no aliases: an
    ``aliases`` written as a list may well be a mapping written badly, and
    answering ``high`` where the row meant to alias it is the clamp R5 forbids,
    dressed up as a translation.

    The call is checked before the row for the same reason: ``aliases.get(value)``
    hashes whatever the caller passed, so a non-string ``value`` used to raise
    ``TypeError`` out of the serving path for a family whose row carries an alias
    table while dropping cleanly for one whose row does not. The answer to a
    caller's mistake may not depend on data another process writes. The
    registry itself is checked the same way and first (:func:`_effort_and_model`).
    """
    _effort_and_model(registry)
    allowed = _accepted(accepted)
    if not isinstance(value, str) or not value:
        return Translation(None, EFFORT_UNTRANSLATABLE)
    row = registry.find(row_kind="effort_scale", family=family)
    if row is None:
        return Translation(None, EFFORT_UNTRANSLATABLE)
    aliases = row.get("aliases")
    if aliases is not None and not isinstance(aliases, Mapping):
        return Translation(None, EFFORT_UNTRANSLATABLE)
    canonical = aliases.get(value, value) if aliases else value
    values = row.get("values")
    if not isinstance(values, list) or canonical not in values:
        return Translation(None, EFFORT_UNTRANSLATABLE)
    if not isinstance(canonical, str) or not canonical:
        return Translation(None, EFFORT_UNTRANSLATABLE)
    if allowed is not None and canonical not in allowed:
        return Translation(None, EFFORT_UNTRANSLATABLE)
    return Translation(canonical, None)


#: An instant this reader cannot compare -- a window bound, or the ``at`` it is
#: asked about. It is not ``None``, which is an absent bound and an open end of
#: the window, and never an "asks no question about time".
_UNREADABLE = object()


def _instant(value: Any) -> Any:
    """One instant as an exact Unix-nanosecond integer, or ``_UNREADABLE``.

    :func:`vicaria_contracts.timestamps.timestamp_to_unix_nanos` is this repository's one
    parser for the instants it writes, and it is reused rather than restated: a
    second definition of "the same moment" is exactly the disagreement the store
    cannot survive. It takes both UTC spellings this codebase treats as UTC
    (``Z`` and ``+00:00``, ``traces/timestamps.py:25``) and every offset RFC 3339
    allows, and refuses a naive stamp, ``-00:00`` and anything that is not a
    string -- each of which becomes a skip here rather than an answer.
    """
    try:
        return timestamp_to_unix_nanos(value, "registry instant")
    except ValueError:
        return _UNREADABLE


def _bound(row: Mapping[str, Any], key: str) -> Any:
    """One end of an alias row's window: the instant, ``None``, or ``_UNREADABLE``.

    The row is untrusted input, and ``str()``-coercing whatever the file holds
    compares ``at`` against a ``repr``: a ``valid_to`` written as the JSON number
    ``20270601`` sorts above every ``…-…Z`` instant, so a row the registry had
    withdrawn stayed alive and :func:`translate_model` vouched for its mapping.
    That is the fabrication ruling R5 forbids, not merely the clamp -- a
    canonical id attributed to a card whose window says nothing of the sort.
    """
    value = row.get(key)
    if value is None:
        return None
    return _instant(value)


def _in_window(row: Mapping[str, Any], at: int | None) -> bool:
    """Whether an alias row is valid at ``at``, an instant in exact Unix nanos.

    Instants are compared, never their spellings. Lexicographic order is not an
    ordering on the timestamps this codebase writes: ``…T00:00:01Z`` sorts
    *below* ``…T00:00:01.000Z``, which is the same instant, and below
    ``…T00:00:01.500Z``, which is later. So a row withdrawn at 00:00:01 stayed
    alive for every caller that spelled the instant with a fraction -- and the
    fixtures that supply ``at``, the row's ``started_at``, write three
    fractional digits -- while the row that replaced it was refused as not yet
    open. The ``+00:00`` spelling of UTC, which this repository's own parser
    accepts (``traces/timestamps.py:25``), had the same two defects.

    A bound that cannot be read makes the row skip, so :func:`translate_model`
    falls through to ``MODEL_UNTRANSLATABLE`` instead of answering from a
    comparison that means nothing. The upper bound is exclusive: a row is
    withdrawn *from* its ``valid_to``, which is what lets the next row's
    ``valid_from`` carry the same instant.

    ``at=None`` asks no question about time, so no bound is consulted.
    """
    if at is None:
        return True
    start, end = _bound(row, "valid_from"), _bound(row, "valid_to")
    if start is _UNREADABLE or end is _UNREADABLE:
        return False
    if start is not None and at < start:
        return False
    return not (end is not None and at >= end)


def translate_model(
    registry: Registry,
    *,
    raw_id: str,
    at: str | None = None,
    accepted: Collection[str] | ValueSupport | None = None,
) -> Translation:
    """A raw model id's canonical id at ``at``, or the drop reason (RFC 0024 §4.3).

    ``accepted`` is the ids the request's provider serves (ruling R5). A raw id
    the registry has never seen has no image -- the ingest's answer to an
    unregistered value is :func:`unregistered`, but a *candidate* the kind cannot
    name to the provider is a drop. A row with no usable ``canonical_id`` is a
    drop as well: ``str(None)`` would hand a provider a model named ``"None"``.

    ``at`` is read once, before any row, for the reason ``value`` is checked
    before the row in :func:`translate_effort`: compared row by row, an ``at``
    the caller got wrong -- an ``int``, a ``datetime``, a date with no time --
    raised ``TypeError`` out of the serving path against a row carrying a window
    and resolved cleanly against one that did not. One caller bug, an outage on
    one alias and an answer on the next, decided by data another process writes.
    An ``at`` that is not an instant is the drop ruling R5 asks for, on every
    row alike. The registry is checked before either (:func:`_effort_and_model`).
    """
    _effort_and_model(registry)
    allowed = _accepted(accepted)
    instant = None if at is None else _instant(at)
    if instant is _UNREADABLE:
        return Translation(None, MODEL_UNTRANSLATABLE)
    for row in registry.select(row_kind="model_alias", raw_id=raw_id):
        if not _in_window(row, instant):
            continue
        canonical = row.get("canonical_id")
        if not isinstance(canonical, str) or not canonical:
            continue
        if allowed is not None and canonical not in allowed:
            return Translation(None, MODEL_UNTRANSLATABLE)
        return Translation(canonical, None)
    return Translation(None, MODEL_UNTRANSLATABLE)


def unregistered(value: str) -> dict[str, str]:
    """RFC 0024 §4: an unregistered vocabulary value is ``unknown(unregistered:<value>)``.

    The ingest never refuses a row for a vocabulary it has not seen; it records
    this Measure and counts the miss in its own job report.
    """
    return unknown(f"unregistered:{value}")


__all__ = [
    "CONTRACTS",
    "EFFORT_AND_MODEL_REGISTRY",
    "EFFORT_UNTRANSLATABLE",
    "MODEL_UNTRANSLATABLE",
    "REGISTRY_NAMES",
    "Registry",
    "RegistryError",
    "Translation",
    "read",
    "registry_versions",
    "translate_effort",
    "translate_model",
    "unregistered",
    "verify_directory",
]
