"""Reading untrusted wire payloads, refusing rather than coercing.

Every reader in this package faces the same three failures, and each one is a
defect that reads back clean:

``str(payload[key])`` turns JSON ``null`` into the join key ``"None"``, ``true``
into ``"True"``, and an object into its ``repr`` — all nonempty, all passing a
``if not value`` guard, and all joining to nothing.

``payload.get(...)`` on a JSON array or ``null`` raises ``AttributeError``,
which is an implementation detail leaking out where a deliberate malformed-wire
``ValueError`` belongs.

``EnumType(payload["k"])`` raises ``KeyError`` when the field is absent, which
is the same leak for enum-typed fields.

``traces/provenance.py`` carries its own copies of these, written before this
module existed and pinned by its own tests. They are not re-pointed here: that
would be a refactor of a merged contract inside an unrelated change.
"""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any


def require_mapping(payload: Any, what: str) -> Mapping[str, Any]:
    """A wire record is a JSON object, and every reader must say so first."""
    if not isinstance(payload, Mapping):
        raise ValueError(
            f"{what} payload must be a JSON object, got {type(payload).__name__}"
        )
    return payload


def require_str(payload: Mapping[str, Any], key: str) -> str:
    """A wire identifier is a nonempty string or it is not an identifier."""
    if key not in payload:
        raise ValueError(f"{key} is required")
    value = payload[key]
    if not isinstance(value, str) or not value:
        raise ValueError(f"{key} must be a nonempty string, got {type(value).__name__}")
    return value


def optional_str(payload: Mapping[str, Any], key: str) -> str | None:
    """Absent or JSON null means absent; anything else must be a real value."""
    if payload.get(key) is None:
        return None
    return require_str(payload, key)


def require_enum(payload: Mapping[str, Any], key: str, enum_type: type) -> Any:
    """An enum-typed wire field, refused deliberately rather than by accident."""
    raw = require_str(payload, key)
    try:
        return enum_type(raw)
    except ValueError:
        valid = sorted(m.value for m in enum_type)
        raise ValueError(f"{key} must be one of {valid}, got {raw!r}") from None


def optional_enum(payload: Mapping[str, Any], key: str, enum_type: type) -> Any:
    if payload.get(key) is None:
        return None
    return require_enum(payload, key, enum_type)


def require_schema(payload: Mapping[str, Any], expected: str) -> None:
    """A payload states which contract it was written against.

    Reading a ``vicaria.plan.v1`` payload as a ``v2`` would silently reinterpret
    whatever the version changed — which is the whole reason the field exists,
    so an absent one is refused rather than assumed current.
    """
    schema = require_str(payload, "schema")
    if schema != expected:
        raise ValueError(f"schema must be {expected!r}, got {schema!r}")
