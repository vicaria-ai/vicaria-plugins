"""Exact timestamp parsing shared by schema, policy, and run intelligence.

Python ``datetime`` stores microseconds and silently truncates longer accepted
fractions. This module separates the fractional component before constructing a
datetime so comparisons and durations retain every supported nanosecond.
"""

from __future__ import annotations

import re
import time
from datetime import datetime, timezone

_TIMESTAMP = re.compile(
    r"^(?P<date>[0-9]{4}-[0-9]{2}-[0-9]{2})[Tt]"
    r"(?P<time>[0-9]{2}:[0-9]{2}:[0-9]{2})"
    r"(?:\.(?P<fraction>[0-9]+))?"
    r"(?P<offset>[Zz]|[+-][0-9]{2}:[0-9]{2})?$"
)


# `-00:00` is excluded deliberately: RFC 3339 reads it as "offset unknown",
# which cannot back an exact instant — the parser above rejects it for the
# same reason.
_UTC_SUFFIXES = frozenset({"Z", "z", "+00:00"})


def timestamp_to_unix_nanos(
    value: str,
    field_name: str,
    *,
    allow_naive: bool = False,
    format_name: str = "RFC 3339",
) -> int:
    """Parse one timestamp to an exact, unbounded Unix-nanosecond integer.

    ``allow_naive`` exists only for legacy fleet ordering, where the historical
    behavior explicitly interpreted a missing offset as UTC. Normative runner,
    sidecar, and OTLP inputs require an offset. Range constraints such as OTLP's
    uint64 boundary remain the caller's responsibility.
    """
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a valid {format_name} timestamp")
    match = _TIMESTAMP.fullmatch(value)
    if match is None:
        raise ValueError(f"{field_name} must be a valid {format_name} timestamp")
    fraction = match.group("fraction") or ""
    if len(fraction) > 9:
        raise ValueError(f"{field_name} must not exceed nanosecond precision")
    offset = match.group("offset")
    if offset is None and not allow_naive:
        if format_name == "RFC 3339":
            raise ValueError(f"{field_name} must be a valid RFC 3339 timestamp")
        raise ValueError(f"{field_name} must include a timezone")
    if offset not in {None, "Z", "z"}:
        offset_hour = int(offset[1:3])
        offset_minute = int(offset[4:6])
        # datetime.fromisoformat normalizes offsets such as +14:60 instead of
        # rejecting their invalid components. RFC 3339 permits two-digit
        # hours only through 23 and minutes only through 59. Its -00:00 token
        # means that the local offset is unknown, not a known UTC instant, so
        # it cannot back an exact Unix timestamp either.
        if offset_hour > 23 or offset_minute > 59 or offset == "-00:00":
            raise ValueError(f"{field_name} must be a valid {format_name} timestamp")
    normalized_offset = "+00:00" if offset in {None, "Z", "z"} else offset
    try:
        parsed = datetime.fromisoformat(
            f"{match.group('date')}T{match.group('time')}{normalized_offset}"
        )
    except ValueError as exc:
        raise ValueError(
            f"{field_name} must be a valid {format_name} timestamp"
        ) from exc
    epoch = datetime(1970, 1, 1, tzinfo=timezone.utc)
    delta = parsed - epoch
    whole_seconds = delta.days * 86_400 + delta.seconds
    fractional_nanos = int(fraction.ljust(9, "0")) if fraction else 0
    return whole_seconds * 1_000_000_000 + fractional_nanos


# CLOCK_BOOTTIME is monotonic AND counts time the host spent suspended;
# time.monotonic() does not, on either Linux or Darwin. A capture or probe that
# spans a laptop lid-close or a VM pause would otherwise record a completion
# instant short by the whole sleep, and that number is published as a MEASURED
# duration. Darwin exposes no equivalent through Python, so it keeps the plain
# monotonic clock — still never backwards, still ordered, just blind to
# suspend.
_ELAPSED_CLOCK = getattr(time, "CLOCK_BOOTTIME", None)


def monotonic_elapsed_ns() -> int:
    """A reading of the best monotonic clock this platform offers."""
    if _ELAPSED_CLOCK is not None:
        return time.clock_gettime_ns(_ELAPSED_CLOCK)
    return time.monotonic_ns()


def advance_timestamp(
    stamp: str,
    nanos: int,
    field_name: str,
    *,
    format_name: str = "RFC 3339",
    utc_suffix: str = "Z",
) -> str:
    """``stamp`` advanced by a monotonic elapsed time, at nanosecond resolution.

    Deriving an end instant from the duration rather than reading the wall
    clock a second time means the pair can never invert, whatever the system
    clock does mid-run. ``max(nanos, 0)`` is belt-and-braces: monotonic cannot
    go backwards, and a zero-length run is still ordered.

    The two recorders that need this — black-box observation and local capture
    — spell the same instant with different UTC suffixes, so that is a
    parameter rather than a second copy of the arithmetic. It is restricted to
    UTC spellings because the civil time is rendered in UTC: appending any
    other offset would keep the digits and name a different instant, which is
    a silent, plausible-looking way for a future caller to lose hours.
    """
    if utc_suffix not in _UTC_SUFFIXES:
        raise ValueError(
            f"advance_timestamp renders UTC; {utc_suffix!r} is not a UTC suffix"
        )
    total = timestamp_to_unix_nanos(stamp, field_name, format_name=format_name) + max(
        nanos, 0
    )
    seconds, remainder = divmod(total, 1_000_000_000)
    moment = datetime.fromtimestamp(seconds, tz=timezone.utc)
    # Formatted field by field rather than through strftime: glibc does not
    # zero-pad %Y below year 1000, so year 1 came back as "1-01-01T…" — a
    # string this module's own parser rejects. Latent for a wall-clock caller
    # and not for a shared helper, since Go's zero time is a value this
    # codebase already treats as reachable.
    date = f"{moment.year:04d}-{moment.month:02d}-{moment.day:02d}"
    clock = f"{moment.hour:02d}:{moment.minute:02d}:{moment.second:02d}"
    return f"{date}T{clock}.{remainder:09d}{utc_suffix}"
