"""The declared policy, ``vicaria.policy.v1``: what an organization wrote down.

The v1 service is not clever on purpose (RFC 0011 §5, design §5.3). An
organization declares its strata, its arms and which arm each stratum runs,
with escalation triggers for the cheap arms; the service pins the stratum at
the episode's first request and runs the arm's state machine after that. An
experiment is the same policy with the arm drawn per episode under declared
weights instead of named per stratum.

Everything that can be wrong with a policy is wrong when it is *saved*, not
when a developer's turn is waiting on it: a model outside ``allowed_models``,
an effort outside the bounds, a protected tool an arm removes, an escalation
to an arm that does not exist, a trigger nobody implements. ``Policy.from_dict``
refuses all of them with a message naming the field.

The vocabulary of escalation triggers is closed for the same reason the
contract's refusal vocabulary is: a misspelt trigger that silently never
fires is a policy that looks like it escalates and does not.
"""

from __future__ import annotations

import hashlib
import math
from collections.abc import Iterable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from vicaria_contracts.capability import Dimension
from vicaria_contracts.plan import Disposition

POLICY_SCHEMA = "vicaria.policy.v1"
MODES = ("declared", "experiment", "advisor")
#: The plan budget the client is told to wait for a rules mode; an advisor mode
#: declares its own timeout plus a margin (RFC 0016 §3).
RULES_PLAN_BUDGET_MS = 500
#: How long an in-process kind (one that computes rather than calls out) may
#: take before the seam answers without it. The plan budget for such a kind
#: stays ``RULES_PLAN_BUDGET_MS``: the bound is what the kind gets, and the
#: budget is that bound plus the service's own work around the call.
RULES_BOUND_MS = 100
ADVISOR_BUDGET_MARGIN_MS = 1500
#: The plugin waits at most this long for a plan, whatever the service declares
#: (smart-gateway's PLAN_BUDGET_CAP_MS); an advisor's bound must fit under it
#: with the margin, so the fallback the service promises can still arrive.
CLIENT_PLAN_BUDGET_CAP_MS = 10_000
MAX_ADVISOR_TIMEOUT_MS = CLIENT_PLAN_BUDGET_CAP_MS - ADVISOR_BUDGET_MARGIN_MS
#: Request fields the advisor call owns; a policy's ``extra`` may not name them.
ADVISOR_RESERVED_EXTRA = frozenset(
    {
        "model",
        "messages",
        "max_tokens",
        "temperature",
        "stream",
        "tools",
        "tool_choice",
        "functions",
        "function_call",
        "n",
        "response_format",
    }
)
EFFORTS = ("low", "medium", "high")
_EFFORT_RANK = {name: i for i, name in enumerate(EFFORTS)}
_DISPOSITIONS = {
    "apply": Disposition.APPLY,
    "suggest": Disposition.SUGGEST,
    "retain": Disposition.RETAIN,
}
_WHEN_KEYS = ("turn", "prompt_length_lt", "prompt_length_gte", "harness", "signal")
_ARM_KEYS = ("disposition", "model", "effort", "prompt", "tools")
UNAVAILABLE_THEN = ("block", "reference")
DEFAULT_GRACE_S = 7 * 24 * 3600

#: Escalation triggers the service implements. ``tool_failure_streak`` takes a
#: count: ``tool_failure_streak:2``. Every other name stands alone.
TRIGGERS = (
    "likely_correction",
    "explicit_feedback_down",
    "stop_failure",
    "tool_failure_streak",
    "tool_denied",
    "permission_denied",
    "compaction",
)
_COUNTED_TRIGGERS = ("tool_failure_streak",)
_TOOL_SIGNALS = frozenset({"tool_failure", "tool_ok", "tool_result", "tool_denied"})
_DOWN_SCORES = frozenset({"down", "-1", "👎"})


class PolicyError(ValueError):
    pass


@dataclass(frozen=True, slots=True)
class Arm:
    label: str
    disposition: Disposition
    changes: Mapping[Dimension, str] = field(default_factory=dict)
    recipe_text: str | None = None
    tools_keep: frozenset[str] | None = None
    tools_remove: frozenset[str] | None = None

    @property
    def changes_tools(self) -> bool:
        return self.tools_keep is not None or self.tools_remove is not None


@dataclass(frozen=True, slots=True)
class Trigger:
    name: str
    count: int = 1

    def __str__(self) -> str:
        return (
            f"{self.name}:{self.count}" if self.name in _COUNTED_TRIGGERS else self.name
        )

    def fires(self, signals: Sequence[Mapping[str, Any]]) -> bool:
        """Whether the signals carried on a plan request satisfy this trigger."""
        if self.name == "tool_failure_streak":
            streak = 0
            for signal in (s for s in signals if s.get("signal") in _TOOL_SIGNALS):
                streak = streak + 1 if signal.get("signal") == "tool_failure" else 0
            return streak >= self.count
        if self.name == "explicit_feedback_down":
            for signal in signals:
                if signal.get("signal") != "explicit_feedback":
                    continue
                score = signal.get("score")
                if isinstance(score, int | float) and not isinstance(score, bool):
                    if score < 0:
                        return True
                elif isinstance(score, str) and score.strip().lower() in _DOWN_SCORES:
                    return True
            return False
        return any(_signal_present(signal, self.name) for signal in signals)

    def matches(self, signal: Mapping[str, Any]) -> bool:
        """Whether one signal is an event of this trigger's kind."""
        if self.name == "tool_failure_streak":
            return signal.get("signal") == "tool_failure"
        if self.name == "explicit_feedback_down":
            if signal.get("signal") != "explicit_feedback":
                return False
            score = signal.get("score")
            if isinstance(score, int | float) and not isinstance(score, bool):
                return score < 0
            return isinstance(score, str) and score.strip().lower() in _DOWN_SCORES
        return _signal_present(signal, self.name)

    def newest(self, signals: Sequence[Mapping[str, Any]]) -> Mapping[str, Any] | None:
        """The most recent event of this trigger's kind: the one an escalation consumes."""
        for signal in reversed(signals):
            if self.matches(signal):
                return signal
        return None


@dataclass(frozen=True, slots=True)
class Escalation:
    triggers: tuple[Trigger, ...]
    to: str
    once: bool = True

    def fired(self, signals: Sequence[Mapping[str, Any]]) -> Trigger | None:
        for trigger in self.triggers:
            if trigger.fires(signals):
                return trigger
        return None


@dataclass(frozen=True, slots=True)
class Stratum:
    id: str
    when: Mapping[str, Any]

    def matches(self, features: Mapping[str, Any]) -> bool:
        when = self.when
        turn = when.get("turn")
        turn_index = _int(features.get("turn_index"), default=0)
        if turn == "first" and turn_index != 0:
            return False
        if turn == "later" and turn_index == 0:
            return False
        length = _int(features.get("prompt_length"), default=0)
        if "prompt_length_lt" in when and not length < when["prompt_length_lt"]:
            return False
        if "prompt_length_gte" in when and not length >= when["prompt_length_gte"]:
            return False
        if "harness" in when and features.get("harness") != when["harness"]:
            return False
        if "signal" in when:
            signals = features.get("signals") or ()
            if not any(
                _signal_present(s, when["signal"])
                for s in signals
                if isinstance(s, Mapping)
            ):
                return False
        return True


@dataclass(frozen=True, slots=True)
class DeclaredCell:
    arm: str
    escalation: Escalation | None = None


@dataclass(frozen=True, slots=True)
class ExperimentLabel:
    label: str
    arm: str
    weight: float
    escalation: Escalation | None = None


@dataclass(frozen=True, slots=True)
class Experiment:
    id: str
    labels: Mapping[str, ExperimentLabel]

    def propensity(self, label: str) -> float:
        total = sum(entry.weight for entry in self.labels.values())
        return self.labels[label].weight / total

    def draw(self, episode_id: str) -> tuple[str, float]:
        """A deterministic draw for the episode: the same episode always lands the same.

        Hashing the episode id under the experiment id makes the draw
        reproducible from the record alone (RFC 0010 §6.3 "re-derivable"), and
        independent of anything the request carries beyond the id.
        """
        digest = hashlib.sha256(f"{self.id}:{episode_id}".encode()).digest()
        point = int.from_bytes(digest[:8], "big") / float(1 << 64)
        total = sum(entry.weight for entry in self.labels.values())
        cumulative = 0.0
        # Labels in sorted order: the draw must not depend on how a policy
        # document happened to order its keys, or on how it was stored.
        chosen = min(self.labels)
        for label in sorted(self.labels):
            cumulative += self.labels[label].weight / total
            chosen = label
            if point < cumulative:
                break
        return chosen, self.propensity(chosen)


@dataclass(frozen=True, slots=True)
class AdvisorSpec:
    """Who answers an advisor policy: a stand-in model, or an advisor version.

    Two shapes share this block. RFC 0016 §2.1's stand-in names a ``model``
    (with its ``base_url`` and ``api_key_env``) and no ``version``: a language
    model chooses among the declared arms. RFC 0025's advisor names a
    ``version`` — or names neither, and takes whichever version the resolver
    promotes — and the arms play no part in what it proposes.

    ``api_key_env`` names the server's environment variable; the key itself is
    never in the policy. ``extra`` is merged into the chat-completion request
    for a provider's own parameters (a thinking switch, say), and both belong
    to the stand-in alone.

    There is no consent flag here: what the organization decides about its
    task text is ``capture.prompt_text``, the one grant, and what the advice
    does with the text it may read (a version's judge included) is the
    service's processing under the notice that names every sub-processor
    (RFC 0034 §2.1).
    """

    model: str | None
    base_url: str | None
    api_key_env: str | None
    timeout_ms: int = 2500
    max_prompt_chars: int = 2000
    fallback: str = "reference"
    extra: Mapping[str, Any] = field(default_factory=dict)
    version: str | None = None

    @property
    def is_stand_in(self) -> bool:
        """RFC 0016's stand-in: a model named in the policy and no version pinned."""
        return self.model is not None and self.version is None

    def to_dict(self) -> dict[str, Any]:
        return {
            "model": self.model,
            "base_url": self.base_url,
            "api_key_env": self.api_key_env,
            "timeout_ms": self.timeout_ms,
            "max_prompt_chars": self.max_prompt_chars,
            "fallback": self.fallback,
            "extra": dict(self.extra),
            **({"version": self.version} if self.version is not None else {}),
        }


@dataclass(frozen=True, slots=True)
class Capture:
    prompt_text: bool = False
    recent_turns: int = 0
    store_text: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "prompt_text": self.prompt_text,
            "recent_turns": self.recent_turns,
            "store_text": self.store_text,
        }


@dataclass(frozen=True, slots=True)
class Unavailable:
    """What the plugin does when the service cannot be reached (RFC 0011 §3).

    The cached client configuration carries the admission inputs, and within
    ``grace_s`` of its last refresh the reference is admitted against them.
    Past the grace, ``then`` decides: ``block`` stops the turn until a refresh
    succeeds (the default: an unreachable service must not become a bypass of
    the organization's own policy), ``reference`` lets the developer's own
    configuration run unadmitted, which an organization chooses knowingly.
    Text capture is never part of the grace: it stops at ``ttl_s``.
    """

    grace_s: int = DEFAULT_GRACE_S
    then: str = "block"

    def to_dict(self) -> dict[str, Any]:
        return {"grace_s": self.grace_s, "then": self.then}


@dataclass(frozen=True, slots=True)
class Policy:
    allowed_models: frozenset[str]
    protected_tools: frozenset[str]
    effort_min: str
    effort_max: str
    capture: Capture
    mode: str
    strata: tuple[Stratum, ...]
    arms: Mapping[str, Arm]
    declared: Mapping[str, DeclaredCell]
    experiment: Experiment | None
    unavailable: Unavailable = field(default_factory=Unavailable)
    advisor: AdvisorSpec | None = None

    # --- construction ------------------------------------------------------------

    @classmethod
    def from_dict(cls, obj: Any) -> Policy:
        if not isinstance(obj, Mapping):
            raise PolicyError("policy must be a JSON object")
        if obj.get("schema") != POLICY_SCHEMA:
            raise PolicyError(f"policy schema must be {POLICY_SCHEMA!r}")
        unknown = set(obj) - {
            "schema",
            "allowed_models",
            "protected_tools",
            "effort",
            "capture",
            "mode",
            "strata",
            "arms",
            "declared",
            "experiment",
            "unavailable",
            "advisor",
        }
        if unknown:
            raise PolicyError(f"policy: unknown keys {sorted(unknown)}")
        unavailable = _unavailable(obj.get("unavailable"))

        allowed = _string_list(
            obj.get("allowed_models"), "allowed_models", nonempty=True
        )
        protected = _string_list(obj.get("protected_tools", []), "protected_tools")
        effort_min, effort_max = _effort_bounds(obj.get("effort"))
        capture = _capture(obj.get("capture"))
        mode = obj.get("mode")
        if mode not in MODES:
            raise PolicyError(f"mode must be one of {list(MODES)}, got {mode!r}")

        arms = _arms(obj.get("arms"), allowed, protected, effort_min, effort_max)

        declared: dict[str, DeclaredCell] = {}
        experiment: Experiment | None = None
        advisor: AdvisorSpec | None = None
        strata: tuple[Stratum, ...] = ()
        if mode == "advisor":
            # The advisor reads the context itself: no strata, no cells, no draw.
            for key in ("strata", "declared", "experiment"):
                if key in obj:
                    raise PolicyError(f"an advisor policy carries no {key}")
            advisor = _advisor(obj.get("advisor"), arms)
        else:
            if "advisor" in obj:
                raise PolicyError(f"a {mode} policy carries no advisor block")
            strata = _strata(obj.get("strata"))
            if mode == "declared":
                if "experiment" in obj:
                    raise PolicyError("a declared policy carries no experiment")
                declared = _declared(obj.get("declared"), strata, arms)
            else:
                if "declared" in obj:
                    raise PolicyError("an experiment policy carries no declared map")
                experiment = _experiment(obj.get("experiment"), arms)

        return cls(
            allowed_models=frozenset(allowed),
            protected_tools=frozenset(protected),
            effort_min=effort_min,
            effort_max=effort_max,
            capture=capture,
            mode=mode,
            strata=strata,
            arms=arms,
            declared=declared,
            experiment=experiment,
            unavailable=unavailable,
            advisor=advisor,
        )

    # --- serving ---------------------------------------------------------------------

    @property
    def plan_budget_ms(self) -> int:
        """How long the client is told a plan may take (RFC 0016 §3)."""
        if self.advisor is not None and self.advisor.is_stand_in:
            return self.advisor.timeout_ms + ADVISOR_BUDGET_MARGIN_MS
        return RULES_PLAN_BUDGET_MS

    @property
    def restricts_effort(self) -> bool:
        return self.effort_min != EFFORTS[0] or self.effort_max != EFFORTS[-1]

    def admits_effort(self, effort: str | None) -> bool:
        """Whether a configuration at this effort may run under the policy's bounds.

        Bounds that span every effort restrict nothing, so an unresolved value
        (the plugin's ``default``, when the developer chose no variant) runs.
        Narrower bounds are a claim about what runs, and an effort that cannot
        be shown to be inside them is treated as outside them.
        """
        if not self.restricts_effort:
            return True
        rank = _EFFORT_RANK.get(effort or "")
        return (
            rank is not None
            and _EFFORT_RANK[self.effort_min] <= rank <= _EFFORT_RANK[self.effort_max]
        )

    def match_stratum(self, features: Mapping[str, Any]) -> Stratum | None:
        """The first stratum whose predicate holds, in the policy's own order."""
        for stratum in self.strata:
            if stratum.matches(features):
                return stratum
        return None

    def effective_tools(
        self, arm: Arm, loaded: Iterable[str]
    ) -> tuple[list[str], list[str]]:
        """``(kept, removed)`` over the tools the harness loaded, protected tools always kept."""
        universe = sorted({name for name in loaded if isinstance(name, str) and name})
        if arm.tools_keep is not None:
            kept = [
                n for n in universe if n in arm.tools_keep or n in self.protected_tools
            ]
        elif arm.tools_remove is not None:
            kept = [
                n
                for n in universe
                if n not in arm.tools_remove or n in self.protected_tools
            ]
        else:
            kept = list(universe)
        removed = [n for n in universe if n not in kept]
        return kept, removed

    def client_config(
        self, *, gateway_url: str, refresh_s: int, ttl_s: int = 24 * 3600
    ) -> dict[str, Any]:
        """What the plugin caches: routing, capture, mode, and the admission inputs.

        ``admission`` is what lets the plugin admit the *reference* while the
        service is unreachable (RFC 0009 §4.3, RFC 0011 §3): the models the
        organization allows, the tools it protects, the provider it routes.
        ``ttl_s`` bounds the capture policy — a cached configuration older than
        that captures shape only until a refresh succeeds — and
        ``unavailable`` says what happens to the reference past the grace.
        """
        config: dict[str, Any] = {
            "gateway_url": gateway_url,
            "provider": "openrouter",
            "capture": {
                "prompt_text": self.capture.prompt_text,
                "recent_turns": self.capture.recent_turns,
            },
            "mode": self.mode,
            "plan_budget_ms": self.plan_budget_ms,
            "refresh_s": refresh_s,
            "ttl_s": ttl_s,
            "admission": {
                "allowed_models": sorted(self.allowed_models),
                "protected_tools": sorted(self.protected_tools),
                "effort": {"min": self.effort_min, "max": self.effort_max},
            },
            "unavailable": self.unavailable.to_dict(),
        }
        if self.experiment is not None:
            config["experiment"] = {
                "id": self.experiment.id,
                "labels": sorted(self.experiment.labels),
            }
        return config


# --- parsing helpers -----------------------------------------------------------------


def _advisor(value: Any, arms: Mapping[str, Arm]) -> AdvisorSpec:
    if not isinstance(value, Mapping):
        raise PolicyError("an advisor policy needs an advisor block")
    known = {
        "model",
        "base_url",
        "api_key_env",
        "timeout_ms",
        "max_prompt_chars",
        "fallback",
        "extra",
        "version",
    }
    if set(value) - known:
        raise PolicyError(f"advisor: unknown keys {sorted(set(value) - known)}")
    model = value.get("model")
    base_url = value.get("base_url")
    key_env = value.get("api_key_env")
    for name, item in (
        ("model", model),
        ("base_url", base_url),
        ("api_key_env", key_env),
    ):
        if item is not None and (not isinstance(item, str) or not item):
            raise PolicyError(f"advisor.{name} must be a nonempty string when present")
    triplet = (("model", model), ("base_url", base_url), ("api_key_env", key_env))
    present = [name for name, item in triplet if item is not None]
    if present and len(present) != 3:
        raise PolicyError(
            "advisor.model, base_url and api_key_env come together or not at all"
        )
    if base_url is not None and not str(base_url).startswith(("http://", "https://")):
        raise PolicyError("advisor.base_url must be an http(s) URL")
    version = value.get("version")
    if version is not None and (not isinstance(version, str) or not version):
        raise PolicyError("advisor.version must be a nonempty string when present")
    if version == "rules@0":
        raise PolicyError("advisor.version: rules@0 is never pinned (RFC 0025 §3.1)")
    timeout_ms = value.get("timeout_ms", 2500)
    if (
        not isinstance(timeout_ms, int)
        or isinstance(timeout_ms, bool)
        or not 100 <= timeout_ms <= MAX_ADVISOR_TIMEOUT_MS
    ):
        raise PolicyError(
            f"advisor.timeout_ms must be an integer between 100 and {MAX_ADVISOR_TIMEOUT_MS}: "
            "the client waits at most 10 s for a plan, margin included"
        )
    max_chars = value.get("max_prompt_chars", 2000)
    if not isinstance(max_chars, int) or isinstance(max_chars, bool) or max_chars < 0:
        raise PolicyError("advisor.max_prompt_chars must be a non-negative integer")
    fallback = value.get("fallback", "reference")
    if not isinstance(fallback, str) or (
        fallback != "reference" and fallback not in arms
    ):
        raise PolicyError("advisor.fallback must be an arm label or 'reference'")
    if fallback != "reference" and not (model is not None and version is None):
        # An advisor version proposes changes of its own and never picks among
        # the arms, so an arm named here would be applied for a reason the
        # version never gave (RFC 0025 §5.0).
        raise PolicyError(
            "advisor.fallback must be 'reference' unless the advisor is the stand-in model"
        )
    extra = value.get("extra", {})
    if not isinstance(extra, Mapping):
        raise PolicyError("advisor.extra must be an object")
    reserved = sorted(set(extra) & ADVISOR_RESERVED_EXTRA)
    if reserved:
        raise PolicyError(
            f"advisor.extra may not set the call's own fields: {reserved}"
        )
    reference = arms.get("reference")
    if reference is not None and (reference.changes or reference.changes_tools):
        raise PolicyError(
            "advisor: an arm named 'reference' is the developer's own settings and must be empty"
        )
    return AdvisorSpec(
        model=str(model) if model is not None else None,
        base_url=str(base_url).rstrip("/") if base_url is not None else None,
        api_key_env=str(key_env) if key_env is not None else None,
        timeout_ms=timeout_ms,
        max_prompt_chars=max_chars,
        fallback=fallback,
        extra=dict(extra),
        version=version,
    )


def _string_list(value: Any, name: str, *, nonempty: bool = False) -> list[str]:
    if not isinstance(value, list) or not all(isinstance(v, str) and v for v in value):
        raise PolicyError(f"{name} must be a list of nonempty strings")
    if nonempty and not value:
        raise PolicyError(f"{name} must name at least one entry")
    return list(dict.fromkeys(value))


def _effort_bounds(value: Any) -> tuple[str, str]:
    if value is None:
        return EFFORTS[0], EFFORTS[-1]
    if not isinstance(value, Mapping) or set(value) - {"min", "max"}:
        raise PolicyError("effort must be {'min': ..., 'max': ...}")
    lo = value.get("min", EFFORTS[0])
    hi = value.get("max", EFFORTS[-1])
    for bound in (lo, hi):
        if bound not in _EFFORT_RANK:
            raise PolicyError(
                f"effort bounds must be one of {list(EFFORTS)}, got {bound!r}"
            )
    if _EFFORT_RANK[lo] > _EFFORT_RANK[hi]:
        raise PolicyError(f"effort.min {lo!r} is above effort.max {hi!r}")
    return lo, hi


def _unavailable(value: Any) -> Unavailable:
    if value is None:
        return Unavailable()
    if not isinstance(value, Mapping) or set(value) - {"grace_s", "then"}:
        raise PolicyError(
            "unavailable must be {'grace_s': seconds, 'then': 'block' | 'reference'}"
        )
    grace = value.get("grace_s", DEFAULT_GRACE_S)
    if not isinstance(grace, int) or isinstance(grace, bool) or grace < 0:
        raise PolicyError("unavailable.grace_s must be a non-negative integer")
    then = value.get("then", "block")
    if then not in UNAVAILABLE_THEN:
        raise PolicyError(f"unavailable.then must be one of {list(UNAVAILABLE_THEN)}")
    return Unavailable(grace_s=grace, then=then)


def _capture(value: Any) -> Capture:
    if value is None:
        return Capture()
    if not isinstance(value, Mapping) or set(value) - {
        "prompt_text",
        "recent_turns",
        "store_text",
    }:
        raise PolicyError("capture must be {prompt_text, recent_turns, store_text}")
    prompt_text = value.get("prompt_text", False)
    recent_turns = value.get("recent_turns", 0)
    store_text = value.get("store_text", False)
    if not isinstance(prompt_text, bool) or not isinstance(store_text, bool):
        raise PolicyError("capture.prompt_text and capture.store_text must be booleans")
    if (
        not isinstance(recent_turns, int)
        or isinstance(recent_turns, bool)
        or recent_turns < 0
    ):
        raise PolicyError("capture.recent_turns must be a non-negative integer")
    if store_text and not prompt_text:
        raise PolicyError("capture.store_text requires capture.prompt_text")
    return Capture(
        prompt_text=prompt_text, recent_turns=recent_turns, store_text=store_text
    )


def _strata(value: Any) -> tuple[Stratum, ...]:
    if not isinstance(value, list) or not value:
        raise PolicyError("strata must be a nonempty list")
    seen: set[str] = set()
    out: list[Stratum] = []
    for entry in value:
        if not isinstance(entry, Mapping) or set(entry) - {"id", "when"}:
            raise PolicyError("each stratum is {'id': ..., 'when': {...}}")
        sid = entry.get("id")
        if not isinstance(sid, str) or not sid:
            raise PolicyError("stratum ids must be nonempty strings")
        if sid in seen:
            raise PolicyError(f"stratum {sid!r} is declared twice")
        seen.add(sid)
        when = entry.get("when", {})
        if not isinstance(when, Mapping):
            raise PolicyError(f"stratum {sid!r}: when must be an object")
        unknown = set(when) - set(_WHEN_KEYS)
        if unknown:
            raise PolicyError(
                f"stratum {sid!r}: unknown predicate(s) {sorted(unknown)}"
            )
        if "turn" in when and when["turn"] not in ("first", "later"):
            raise PolicyError(f"stratum {sid!r}: turn must be 'first' or 'later'")
        for key in ("prompt_length_lt", "prompt_length_gte"):
            if key in when and (
                not isinstance(when[key], int)
                or isinstance(when[key], bool)
                or when[key] < 0
            ):
                raise PolicyError(
                    f"stratum {sid!r}: {key} must be a non-negative integer"
                )
        for key in ("harness", "signal"):
            if key in when and (not isinstance(when[key], str) or not when[key]):
                raise PolicyError(f"stratum {sid!r}: {key} must be a nonempty string")
        out.append(Stratum(id=sid, when=dict(when)))
    return tuple(out)


def _arms(
    value: Any,
    allowed: Sequence[str],
    protected: Sequence[str],
    effort_min: str,
    effort_max: str,
) -> Mapping[str, Arm]:
    if not isinstance(value, Mapping) or not value:
        raise PolicyError("arms must be a nonempty object")
    arms: dict[str, Arm] = {}
    for label, spec in value.items():
        if not isinstance(label, str) or not label:
            raise PolicyError("arm labels must be nonempty strings")
        if not isinstance(spec, Mapping):
            raise PolicyError(f"arm {label!r} must be an object")
        unknown = set(spec) - set(_ARM_KEYS)
        if unknown:
            raise PolicyError(f"arm {label!r}: unknown keys {sorted(unknown)}")
        changes: dict[Dimension, str] = {}
        if "model" in spec:
            model = spec["model"]
            if not isinstance(model, str) or not model:
                raise PolicyError(f"arm {label!r}: model must be a nonempty string")
            if model not in allowed:
                raise PolicyError(
                    f"arm {label!r}: model {model!r} is not in allowed_models"
                )
            changes[Dimension.MODEL] = model
        if "effort" in spec:
            effort = spec["effort"]
            if effort not in _EFFORT_RANK:
                raise PolicyError(
                    f"arm {label!r}: effort must be one of {list(EFFORTS)}"
                )
            if (
                not _EFFORT_RANK[effort_min]
                <= _EFFORT_RANK[effort]
                <= _EFFORT_RANK[effort_max]
            ):
                raise PolicyError(
                    f"arm {label!r}: effort {effort!r} is outside the policy's bounds "
                    f"[{effort_min}, {effort_max}]"
                )
            changes[Dimension.EFFORT] = effort
        recipe_text: str | None = None
        if "prompt" in spec:
            prompt = spec["prompt"]
            if (
                not isinstance(prompt, Mapping)
                or set(prompt) != {"recipe", "text"}
                or not isinstance(prompt.get("recipe"), str)
                or not prompt["recipe"]
                or not isinstance(prompt.get("text"), str)
                or not prompt["text"]
            ):
                raise PolicyError(
                    f"arm {label!r}: prompt must be {{'recipe': id, 'text': text}}"
                )
            changes[Dimension.PROMPT] = prompt["recipe"]
            recipe_text = prompt["text"]
        tools_keep: frozenset[str] | None = None
        tools_remove: frozenset[str] | None = None
        if "tools" in spec:
            tools = spec["tools"]
            if not isinstance(tools, Mapping) or set(tools) not in (
                {"keep"},
                {"remove"},
            ):
                raise PolicyError(
                    f"arm {label!r}: tools must be {{'keep': [...]}} or {{'remove': [...]}}"
                )
            if "keep" in tools:
                tools_keep = frozenset(
                    _string_list(tools["keep"], f"arm {label!r}: tools.keep")
                )
            else:
                removed = _string_list(
                    tools["remove"], f"arm {label!r}: tools.remove", nonempty=True
                )
                clash = sorted(set(removed) & set(protected))
                if clash:
                    raise PolicyError(
                        f"arm {label!r}: removes protected tool(s) {clash}"
                    )
                tools_remove = frozenset(removed)
            for name in (tools_keep or ()) or (tools_remove or ()):
                if "," in name:
                    raise PolicyError(
                        f"arm {label!r}: tool name {name!r} contains a comma"
                    )
        changes_tools = tools_keep is not None or tools_remove is not None
        default = "retain" if not changes and not changes_tools else "apply"
        disposition_name = spec.get("disposition", default)
        disposition = _DISPOSITIONS.get(disposition_name)
        if disposition is None:
            raise PolicyError(
                f"arm {label!r}: disposition must be one of {sorted(_DISPOSITIONS)}"
            )
        if disposition is Disposition.RETAIN and (changes or changes_tools):
            raise PolicyError(f"arm {label!r}: a retain arm changes nothing")
        if disposition is not Disposition.RETAIN and not changes and not changes_tools:
            raise PolicyError(
                f"arm {label!r}: {disposition_name} needs at least one change"
            )
        arms[label] = Arm(
            label=label,
            disposition=disposition,
            changes=changes,
            recipe_text=recipe_text,
            tools_keep=tools_keep,
            tools_remove=tools_remove,
        )
    return arms


def _escalation(value: Any, where: str, arms: Mapping[str, Arm]) -> Escalation | None:
    if value is None:
        return None
    if not isinstance(value, Mapping) or set(value) - {"triggers", "to", "once"}:
        raise PolicyError(f"{where}: escalation must be {{triggers, to, once}}")
    triggers_raw = value.get("triggers")
    if not isinstance(triggers_raw, list) or not triggers_raw:
        raise PolicyError(f"{where}: escalation.triggers must be a nonempty list")
    triggers: list[Trigger] = []
    for raw in triggers_raw:
        if not isinstance(raw, str) or not raw:
            raise PolicyError(f"{where}: triggers must be strings")
        name, _, count = raw.partition(":")
        if name not in TRIGGERS:
            raise PolicyError(
                f"{where}: unknown trigger {name!r}; known: {list(TRIGGERS)}"
            )
        if name in _COUNTED_TRIGGERS:
            if not count.isdigit() or int(count) < 1:
                raise PolicyError(
                    f"{where}: trigger {name!r} needs a count, as {name}:2"
                )
            triggers.append(Trigger(name, int(count)))
        else:
            if count:
                raise PolicyError(f"{where}: trigger {name!r} takes no count")
            triggers.append(Trigger(name))
    to = value.get("to")
    if to not in arms:
        raise PolicyError(f"{where}: escalation.to names no arm ({to!r})")
    once = value.get("once", True)
    if not isinstance(once, bool):
        raise PolicyError(f"{where}: escalation.once must be a boolean")
    return Escalation(triggers=tuple(triggers), to=to, once=once)


def _declared(
    value: Any, strata: Sequence[Stratum], arms: Mapping[str, Arm]
) -> dict[str, DeclaredCell]:
    if not isinstance(value, Mapping):
        raise PolicyError(
            "declared must map every stratum id to {'arm': ..., 'escalation'?: ...}"
        )
    ids = {s.id for s in strata}
    missing = sorted(ids - set(value))
    extra = sorted(set(value) - ids)
    if missing:
        raise PolicyError(f"declared: no entry for strata {missing}")
    if extra:
        raise PolicyError(f"declared: entries for unknown strata {extra}")
    out: dict[str, DeclaredCell] = {}
    for sid, entry in value.items():
        where = f"declared[{sid!r}]"
        if not isinstance(entry, Mapping) or set(entry) - {"arm", "escalation"}:
            raise PolicyError(f"{where} must be {{'arm': ..., 'escalation'?: ...}}")
        arm = entry.get("arm")
        if arm not in arms:
            raise PolicyError(f"{where}: arm {arm!r} is not declared under arms")
        escalation = _escalation(entry.get("escalation"), where, arms)
        if escalation is not None and escalation.to == arm:
            raise PolicyError(f"{where}: escalation.to is the arm already running")
        out[sid] = DeclaredCell(arm=arm, escalation=escalation)
    return out


def _experiment(value: Any, arms: Mapping[str, Arm]) -> Experiment:
    if not isinstance(value, Mapping) or set(value) - {"id", "labels"}:
        raise PolicyError("experiment must be {'id': ..., 'labels': {...}}")
    exp_id = value.get("id")
    if not isinstance(exp_id, str) or not exp_id:
        raise PolicyError("experiment.id must be a nonempty string")
    labels_raw = value.get("labels")
    if not isinstance(labels_raw, Mapping) or len(labels_raw) < 2:
        raise PolicyError("experiment.labels must map at least two labels")
    labels: dict[str, ExperimentLabel] = {}
    for label, entry in labels_raw.items():
        where = f"experiment.labels[{label!r}]"
        if not isinstance(label, str) or not label:
            raise PolicyError("experiment labels must be nonempty strings")
        if not isinstance(entry, Mapping) or set(entry) - {
            "arm",
            "weight",
            "escalation",
        }:
            raise PolicyError(
                f"{where} must be {{'arm': ..., 'weight': ..., 'escalation'?: ...}}"
            )
        arm = entry.get("arm")
        if arm not in arms:
            raise PolicyError(f"{where}: arm {arm!r} is not declared under arms")
        weight = _weight(entry.get("weight", 1), where)
        escalation = _escalation(entry.get("escalation"), where, arms)
        if escalation is not None and escalation.to == arm:
            raise PolicyError(f"{where}: escalation.to is the arm already running")
        labels[label] = ExperimentLabel(
            label=label, arm=arm, weight=weight, escalation=escalation
        )
    # Each weight finite is not enough: the draw and the propensity divide by
    # the sum, and two weights near the float limit overflow it to infinity,
    # which records every propensity as 0.
    total = sum(entry.weight for entry in labels.values())
    if not math.isfinite(total):
        raise PolicyError(
            f"experiment.labels: the weights sum to {total!r}, which is not finite; scale them down"
        )
    return Experiment(id=exp_id, labels=labels)


def _weight(value: Any, where: str) -> float:
    """A label's weight: a number, not a boolean, finite and above zero.

    ``json.loads`` reads ``NaN`` and ``Infinity`` out of a policy file, and a
    NaN passes ``<= 0``; either would reach the propensity the record carries.
    """
    if isinstance(value, bool) or not isinstance(value, int | float):
        raise PolicyError(f"{where}: weight must be a positive number, got {value!r}")
    try:
        weight = float(value)
    except OverflowError:
        raise PolicyError(
            f"{where}: weight must be finite; the integer is too large"
        ) from None
    if not math.isfinite(weight):
        raise PolicyError(f"{where}: weight must be finite, got {weight!r}")
    if weight <= 0:
        raise PolicyError(f"{where}: weight must be a positive number, got {weight!r}")
    return weight


def _signal_present(signal: Any, name: str) -> bool:
    if not isinstance(signal, Mapping):
        return False
    if signal.get("signal") == name:
        return True
    return signal.get(name) is True


def _int(value: Any, *, default: int) -> int:
    return value if isinstance(value, int) and not isinstance(value, bool) else default


__all__ = [
    "EFFORTS",
    "MODES",
    "POLICY_SCHEMA",
    "TRIGGERS",
    "AdvisorSpec",
    "Arm",
    "Capture",
    "DeclaredCell",
    "Escalation",
    "Experiment",
    "ExperimentLabel",
    "Policy",
    "PolicyError",
    "Stratum",
    "Trigger",
    "Unavailable",
]
