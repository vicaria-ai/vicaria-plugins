"""vicaria.codes.v1: the one list of refusal codes, queue words and SDK warning
keys, each with its one-sentence meaning (vicaria-docs RFC 0044 §5.1, R-E43).

Both services raise the codes, the console prints the words, the SDK warns
under the keys; this file is where a reader looks a code up, and the test in
smart-gateway-server (``tests/capture/test_codes_are_the_one_list.py``) fails
when a service raises a code this list does not hold or the list holds one
nothing raises.  ``codes.json`` is the data; this module reads it.
"""

from __future__ import annotations

import json
from functools import lru_cache
from typing import Any

from .resources import ROOT

#: The list itself, shipped with the package.
CODES = ROOT / "codes.json"
SCHEMA = "vicaria.codes.v1"


@lru_cache(maxsize=1)
def load() -> dict[str, Any]:
    """The whole document, read once."""
    document = json.loads(CODES.read_text(encoding="utf-8"))
    if document.get("schema") != SCHEMA:
        raise ValueError(f"{CODES} is not {SCHEMA}")
    return document


def refusals() -> dict[str, dict[str, Any]]:
    """Every refusal code either service answers with: ``{"status": [..], "sentence": ..}``."""
    return load()["refusals"]


def queue_states() -> dict[str, str]:
    """The review queue's state words (``needs_review``, ``blocked``, ...)."""
    return load()["queue"]["states"]


def queue_reasons() -> dict[str, str]:
    """The word beside a ``blocked``, ``no_attempts`` or ``erased`` state."""
    return load()["queue"]["reasons"]


def sdk_warnings() -> dict[str, str]:
    """The keys @vicaria/sdk warns once under."""
    return load()["sdk_warnings"]


def sentence(code: str) -> str | None:
    """The one sentence for a code or word, wherever it is listed; ``None`` for none."""
    document = load()
    held = document["refusals"].get(code)
    if held is not None:
        return held["sentence"]
    for section in (document["queue"]["states"], document["queue"]["reasons"],
                    document["sdk_warnings"]):
        if code in section:
            return section[code]
    return None


__all__ = ["CODES", "SCHEMA", "load", "queue_reasons", "queue_states", "refusals",
           "sdk_warnings", "sentence"]
