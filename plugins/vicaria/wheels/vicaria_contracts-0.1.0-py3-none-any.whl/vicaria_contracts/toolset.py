"""The ``tools`` dimension as an explicit set of tool names.

RFC 0009 leaves the *value* of the ``tools`` dimension to the adapter: a
profile id such as ``profile:read-only@v1`` where the harness offers named
profiles, or — RFC 0011 §4, for a harness whose tool inventory is only known
once it has loaded — the explicit list of tools kept. This module is that
second encoding, shared by the server that builds plans and the client that
applies them, so neither side re-invents it:

    set:edit,grep,read

``set:`` followed by the kept tool names, sorted, comma-separated; ``set:``
alone is the empty set. Names are identifiers and may not contain a comma.
Any other value is opaque here — a profile id — and :func:`decode_tool_set`
returns ``None`` for it rather than guessing.

The order is fixed so that the value is canonical: two plans keeping the same
tools have the same ``tools`` value and the same configuration digest, which
is what lets the journal's ``base_config_digest`` check (RFC 0010 §6.2) hold
across a client and a server that built the value independently.
"""

from __future__ import annotations

from collections.abc import Iterable

TOOL_SET_PREFIX = "set:"


def encode_tool_set(names: Iterable[str]) -> str:
    """The canonical ``set:`` value for ``names``. Duplicates collapse."""
    cleaned: set[str] = set()
    for name in names:
        if not isinstance(name, str) or not name:
            raise ValueError(f"tool names must be nonempty strings, got {name!r}")
        if "," in name:
            raise ValueError(
                f"tool name {name!r} contains a comma, which the encoding reserves"
            )
        cleaned.add(name)
    return TOOL_SET_PREFIX + ",".join(sorted(cleaned))


def decode_tool_set(value: str) -> frozenset[str] | None:
    """The names a ``set:`` value keeps, or ``None`` for any other encoding."""
    if not isinstance(value, str) or not value.startswith(TOOL_SET_PREFIX):
        return None
    body = value[len(TOOL_SET_PREFIX) :]
    return frozenset(part for part in body.split(",") if part)


__all__ = ["TOOL_SET_PREFIX", "decode_tool_set", "encode_tool_set"]
