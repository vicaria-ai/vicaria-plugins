"""The keys and Measures every trajectory-store table shares (RFC 0024 §3, §5.8).

RFC 0024 gives a key formula for four of its eight tables and leaves two as
"key"; ruling R3 mints those two, and ruling R2 fixes one typing rule for the
roughly 150 columns §3 names without a type. All of it reduces to three
functions: one digest over canonical JSON, one canonical serializer for a JSON
column, and one Measure encoder.

They live here rather than in ``vicaria_offline`` because RFC 0025 §8's edge
runs one way. The offline half may import ``traces``, so it loses nothing; the
online half may not import the offline package and still has to mint the
``native_ref`` behind its own ``observation_id`` (ruling R13) and to write the
Measures the ingest projects back out. Two implementations of one hash is the
disagreement the store cannot survive. Stdlib only, plus ``traces`` itself.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections.abc import Mapping
from typing import Any

from vicaria_contracts.config_artifact import canonical_json
from vicaria_contracts.config_artifact import unknown as _unknown_json


def digest(*parts: Any) -> str:
    """RFC 0024 §3's one key recipe: sha256 over the canonical JSON of the parts.

    The parts are hashed as a JSON list and never joined into a string: a
    ``session_id`` holding the separator would otherwise mint another row's
    key. Bare hex, as :func:`vicaria_contracts.config_artifact.artifact_id` hashes --
    a row key is a column value, and the ``sha256:`` prefix belongs to an
    artifact id, which is a reference.
    """
    return hashlib.sha256(canonical_json(list(parts)).encode("utf-8")).hexdigest()


def trajectory_id(org_id: str, session_id: str, segment_index: int) -> str:
    """RFC 0024 §3.1."""
    return digest(org_id, session_id, segment_index)


def observation_id(org_id: str, observer: str, native_ref: str) -> str:
    """RFC 0024 §3.4. The service mints and journals the ``native_ref`` (ruling R13)."""
    return digest(org_id, observer, native_ref)


def outcome_id(
    org_id: str,
    subject_kind: str,
    subject_id: str,
    evaluator_id: str,
    evaluator_version: str,
    run_index: int,
) -> str:
    """Ruling R3, amended by ruling R40. §3.6 says only "key", and §5.9
    re-derives the row on every re-ingest of the session, so a non-deterministic
    id would duplicate the outcome silently -- the table is append-only and no
    constraint would fire.

    ``evaluator_version`` is in the id (R40) because the registry keys an
    evaluator on the pair ``(evaluator_id, version)`` -- "because the readers
    key on both" -- and a snapshot's ``primary_rule`` names
    ``evaluator_id@version``. Without it, version 2 scoring a trajectory that
    version 1 already scored minted version 1's id at the same ``run_index`` and
    was refused; the obvious workaround, run 1, made a reader that counts runs
    per evaluator see a new version as flakiness. ``run_index`` counts runs
    within one evaluator version. ``evaluator_version`` is the ``TEXT`` column
    and is hashed as the string it stores.
    """
    return digest(
        org_id, subject_kind, subject_id, evaluator_id, evaluator_version, run_index
    )


def annotation_id(
    org_id: str,
    subject_kind: str,
    subject_id: str,
    annotator_id: str,
    input_digest: str,
    taxonomy: str,
    taxonomy_version: int,
    label: str,
) -> str:
    """Ruling R3, amended by ruling R41. §3.7 says only "key"; the input digest
    keeps one annotator's two views of a subject apart, which is what §5.4's
    admissibility check recomputes.

    ``taxonomy``, ``taxonomy_version`` and ``label`` are in the id (R41).
    Without them one annotator reading one input view held ONE row per subject
    across every taxonomy: a task's eight suite labels -- a difficulty, a
    category and six tags, all under ``suite@1``'s one view -- stored the first
    and refused the other seven, and the only way in was to forge a different
    ``input_digest`` per label, which breaks §5.4's meaning of the digest.

    Each is hashed in its column's type: ``taxonomy`` and ``label`` are
    ``TEXT``, ``taxonomy_version`` is ``INTEGER``. The id has to be recomputable
    from the stored row, and ``1`` and ``"1"`` are two digests.
    """
    return digest(
        org_id,
        subject_kind,
        subject_id,
        annotator_id,
        input_digest,
        taxonomy,
        taxonomy_version,
        label,
    )


def row_json(value: Any) -> str:
    """A JSON column's text (ruling R2): canonical, with NaN and infinity refused.

    :func:`vicaria_contracts.config_artifact.canonical_json` is the identity serializer and
    stays exactly as it is -- every artifact id in the journal was hashed with
    it. This is the storage one. The two agree on every valid document; this one
    refuses the two float values JSON cannot represent instead of writing a bare
    ``NaN`` into a column no reader can parse.
    """
    return json.dumps(
        value,
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
    )


def measure(value: Any, source: str) -> dict[str, Any]:
    """An observed quantity: ``{value, source}`` (RFC 0024 §3.9, ``smart_gateway.measure``)."""
    if not isinstance(value, bool | int | float | str):
        raise ValueError(
            "a known Measure needs a value of type bool, int, float or str"
        )
    if isinstance(value, float) and not math.isfinite(value):
        raise ValueError("a known Measure cannot hold NaN or infinity")
    if not isinstance(source, str) or not source:
        raise ValueError("a known Measure needs a nonempty source")
    return {"value": value, "source": source}


def unknown(reason: str) -> dict[str, str]:
    """A quantity that could not be observed: ``{"unknown": <reason>}``.

    The shape is :func:`vicaria_contracts.config_artifact.unknown`'s, which the
    configuration artifact already hashes, so there is one producer of it. This
    adds the refusal a column needs: an empty reason is the one thing "unknown"
    may never be, because RFC 0024 §5.8 imputes nothing and every unknown states
    why.
    """
    if not isinstance(reason, str) or not reason:
        raise ValueError("an unknown Measure needs a nonempty reason")
    return _unknown_json(reason)


def is_known(value: Any) -> bool:
    """Whether ``value`` is an observed Measure. Anything malformed is not one.

    The same gate as :func:`measure`, not a test of the key set: this admits a
    block exactly when the constructor would have built it, which is what lets
    :func:`measure_json` and a store read one definition of a well-formed
    Measure. This predicate is what a store reads to decide whether a column
    holds a number: :func:`measure_value` answers ``None`` -- "unknown" --
    for everything it turns down, and :func:`measure_reason` answers ``None``
    too, so a block admitted here with no usable value reads back as an unknown
    with no stated reason. RFC 0024 §5.8 imputes nothing and every unknown
    states why, which makes that block indistinguishable from an honest absence
    -- and the ingest, which assembles Measures out of harness payloads rather
    than through :func:`measure`, is the producer most likely to write one.

    Finiteness is part of the gate. A NaN or an infinity is a ``float`` a
    producer really observed, but it is not a value any column can hold:
    :func:`row_json` writes with ``allow_nan=False``, so admitting one here
    only moves the refusal to encode time and raises out of the write path
    instead of dropping. A producer holding one has an observation it cannot
    store, and §5.8's answer to that is :func:`unknown` with the reason
    written out, not a value that fails on the way to the column.
    """
    if not isinstance(value, Mapping) or set(value) != {"value", "source"}:
        return False
    if not isinstance(value["value"], bool | int | float | str):
        return False
    if isinstance(value["value"], float) and not math.isfinite(value["value"]):
        return False
    return bool(isinstance(value["source"], str) and value["source"])


def measure_value(value: Any) -> Any | None:
    """The value a known Measure holds, or ``None`` for anything else.

    The other half of :func:`measure_reason`, and here for the same reason the
    rest of this module is: both halves of the store must read a Measure the
    way :func:`is_known` admits one, and a reader that lived in the persistence
    package would make every consumer of a stored Measure -- the snapshot
    builder above all, which touches no database -- import SQLite to read a
    number. ``None`` is "unknown" here, exactly as in :func:`measure_reason`:
    a block this turns down carries no value, and the reason it carries, if
    any, is that function's answer.
    """
    return value["value"] if is_known(value) else None


def measure_reason(value: Any) -> str | None:
    """The reason an unknown Measure gives, or ``None`` for anything else."""
    if isinstance(value, Mapping) and set(value) == {"unknown"}:
        reason = value["unknown"]
        if isinstance(reason, str) and reason:
            return reason
    return None


def measure_json(value: Any) -> str:
    """One Measure as a column's text; anything that is not a Measure is refused.

    The encoder, the constructor and :func:`is_known` are one gate, so there is
    a single definition of a well-formed Measure across the predicate a store
    reads, the constructor the online half writes with, and this serializer.
    Everything :func:`is_known` admits encodes here, and every block it refuses
    is refused here -- by the constructor itself where the shape is right and
    the value is not, so the ``ValueError`` names which rule it broke.

    It has no caller yet, and this docstring used to name one. The store's
    ``encode_row`` canonicalizes every JSON column -- Measure-valued or not --
    through :func:`row_json`, which serializes whatever shape it is given;
    routing the Measure columns through here needs a Measure-column list its
    schema does not have. So the gate that is on the write path today is
    :func:`is_known`. This stays the encoder for a caller that holds one
    Measure and wants its bytes.
    """
    if is_known(value):
        return row_json(measure(value["value"], value["source"]))
    reason = measure_reason(value)
    if reason is not None:
        return row_json(unknown(reason))
    if isinstance(value, Mapping) and set(value) == {"value", "source"}:
        # The shape of a known Measure with a value the constructor refuses:
        # let it raise, so the caller is told which rule the block broke.
        measure(value["value"], value["source"])
    raise ValueError(f"not a Measure: {value!r}")


__all__ = [
    "annotation_id",
    "digest",
    "is_known",
    "measure",
    "measure_json",
    "measure_reason",
    "measure_value",
    "observation_id",
    "outcome_id",
    "row_json",
    "trajectory_id",
    "unknown",
]
