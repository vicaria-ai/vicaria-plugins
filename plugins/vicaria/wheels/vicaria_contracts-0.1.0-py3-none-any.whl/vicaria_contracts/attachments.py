"""Attachments on a captured user message (vicaria-docs RFC 0036).

Every file a developer attaches to a message -- image, PDF, document,
spreadsheet, audio, video or anything else -- is captured: the event carries
its kind, media type, name, size and sha256, and the bytes are uploaded beside
the event under that digest. One consent covers them, as it covers the words,
and nothing is redacted.

``kind`` is a coarse reading of the media type, so a reader can filter without
parsing MIME strings. The media type stays on the event as the harness
reported it; ``kind`` never replaces it.
"""

from __future__ import annotations

import hashlib
import os

KINDS: tuple[str, ...] = (
    "image",
    "pdf",
    "document",
    "spreadsheet",
    "presentation",
    "audio",
    "video",
    "text",
    "archive",
    "other",
)

_EXACT: dict[str, str] = {
    "application/pdf": "pdf",
    "application/msword": "document",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "document",
    "application/vnd.oasis.opendocument.text": "document",
    "application/rtf": "document",
    "text/rtf": "document",
    "application/vnd.ms-excel": "spreadsheet",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "spreadsheet",
    "application/vnd.oasis.opendocument.spreadsheet": "spreadsheet",
    "text/csv": "spreadsheet",
    "text/tab-separated-values": "spreadsheet",
    "application/vnd.ms-powerpoint": "presentation",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "presentation",
    "application/vnd.oasis.opendocument.presentation": "presentation",
    "application/zip": "archive",
    "application/gzip": "archive",
    "application/x-gzip": "archive",
    "application/x-tar": "archive",
    "application/x-7z-compressed": "archive",
    "application/x-rar-compressed": "archive",
    "application/vnd.rar": "archive",
    "application/json": "text",
    "application/xml": "text",
    "application/yaml": "text",
    "application/x-yaml": "text",
    "application/toml": "text",
    "application/javascript": "text",
    "application/typescript": "text",
    "application/x-sh": "text",
}

_PREFIX: tuple[tuple[str, str], ...] = (
    ("image/", "image"),
    ("audio/", "audio"),
    ("video/", "video"),
    ("text/", "text"),
)

_EXTENSION: dict[str, str] = {
    ".png": "image", ".jpg": "image", ".jpeg": "image", ".gif": "image", ".webp": "image",
    ".bmp": "image", ".svg": "image", ".heic": "image", ".tif": "image", ".tiff": "image",
    ".pdf": "pdf",
    ".doc": "document", ".docx": "document", ".odt": "document", ".rtf": "document",
    ".xls": "spreadsheet", ".xlsx": "spreadsheet", ".ods": "spreadsheet", ".csv": "spreadsheet",
    ".tsv": "spreadsheet",
    ".ppt": "presentation", ".pptx": "presentation", ".odp": "presentation", ".key": "presentation",
    ".mp3": "audio", ".wav": "audio", ".m4a": "audio", ".ogg": "audio", ".flac": "audio",
    ".aac": "audio", ".opus": "audio",
    ".mp4": "video", ".mov": "video", ".webm": "video", ".mkv": "video", ".avi": "video",
    ".zip": "archive", ".tar": "archive", ".gz": "archive", ".tgz": "archive", ".7z": "archive",
    ".rar": "archive",
    ".txt": "text", ".md": "text", ".json": "text", ".yaml": "text", ".yml": "text",
    ".toml": "text", ".xml": "text", ".html": "text", ".log": "text",
}


def attachment_kind(media_type: str | None, filename: str | None = None) -> str:
    """The coarse kind of an attachment, from its media type, else its name.

    A media type the harness did not know (absent, or the generic
    ``application/octet-stream``) falls back to the file extension; anything
    still unrecognised is ``other``.
    """
    base = (media_type or "").split(";", 1)[0].strip().lower()
    if base and base != "application/octet-stream":
        if base in _EXACT:
            return _EXACT[base]
        for prefix, kind in _PREFIX:
            if base.startswith(prefix):
                return kind
    if filename:
        extension = os.path.splitext(filename)[1].lower()
        if extension in _EXTENSION:
            return _EXTENSION[extension]
    return "other"


def attachment_digest(body: bytes) -> str:
    """The digest an attachment's bytes are stored and erased under."""
    return "sha256:" + hashlib.sha256(body).hexdigest()


__all__ = ["KINDS", "attachment_digest", "attachment_kind"]
