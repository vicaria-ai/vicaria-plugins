"""The client core: the contract as a sequence that cannot be run out of order.

WHY THIS EXISTS

Five modules implement RFC 0009 and, until this one, nothing imported any of
them except their own tests. ``docs/STATUS.md`` said so three times, and "no
caller" understates the problem: the modules compose *only if a caller composes
them correctly*, and the ways to compose them incorrectly are the failures the
RFC is about.

``traces/plan.py`` says as much in its own docstring:

    a caller that gets ``PlanValidation.ok`` still owes the staging protocol
    (RFC 0009 §4.2) and, on any fallback to a reference, a fresh admission check
    for that reference (§4.2.1). Neither is implemented here, and a passing
    validation is not a licence to skip them.

That is a warning in a comment. This module is the enforcement: the only way to
reach a dispatchable configuration is through :func:`decide` and
:func:`resolve`, and neither can be skipped or reordered because each takes the
previous stage's value as its input rather than a bag of fields a caller
assembles.

THE PATHS THE COMMIT POINT NEVER SEES

:func:`vicaria_contracts.staging.commit` is reached only when a plan exists and validated.
A client has two reference dispatches that never get there:

1. **No plan arrived.** The server was unreachable, the response expired, or it
   timed out. The reference runs.
2. **A plan arrived and validation refused it.** A stale revision, a moved
   baseline, an undeclared value. The reference runs.

Both are dispatch decisions, and §4.2.1's rule is general: *retention and
restoration never relax a constraint.* A configuration does not become
permissible by being the one already in use — including when the reason it is
still in use is that nobody could tell us otherwise. So both go through
:func:`vicaria_contracts.staging.reference_or_stop`, the same gate the commit point's own
fallbacks use, rather than a second implementation of it here.

ORDER IS THE CHECK, NOT AN IMPLEMENTATION DETAIL

``stop`` is tested before ``ok`` in :func:`resolve`. ``stop`` implies ``not
ok``, so a reader who reversed them would send a ``cannot_execute`` plan down
the fallback path — the client converting a refusal into the thing it refused,
which §4.5 calls worse than no refusal at all because it looks handled. The
ordering is pinned by a test for exactly that reason.

WHAT IT DOES NOT DO

No transport, no provider call, no harness, no clock. This module decides and
records; a caller dispatches and reports back whether the dispatch reached a
provider. That last part is the caller's observation and not this module's
assumption: the client knows what it *decided* to send, and only the caller
knows whether it arrived.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from typing import Any

from vicaria_contracts.capability import CapabilityDescriptor
from vicaria_contracts.decision import (
    ApplicationRecord,
    DecisionOrigin,
    DecisionRecord,
    UnavailableReason,
)
from vicaria_contracts.plan import Configuration, Plan, PlanValidation, validate_plan
from vicaria_contracts.staging import (
    Admission,
    CommitAction,
    CommitOutcome,
    CommitRefusal,
    StagedContribution,
    StagingConfirmation,
    commit,
    reference_or_stop,
)

EPISODE_RECORDS_SCHEMA_VERSION = "vicaria.episode-records.v1"


def _require_id(value: Any, name: str) -> None:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} must be a nonempty string, got {value!r}")


@dataclass(frozen=True, slots=True)
class Episode:
    """What the client knows before any plan arrives.

    ``active_config`` is both the baseline validation compares a plan against
    and the reference a fallback dispatches. They are the same value because
    staging applies nothing (§4.2): the reference is simply the configuration
    that was already running, which is what makes "reconstruct the reference" a
    lookup rather than an unwind. Keeping them as one field means they cannot
    drift apart, which a caller holding two variables eventually lets happen.
    """

    episode_id: str
    descriptor: CapabilityDescriptor
    active_config: Configuration
    request_revision: str
    assigned_policy: str | None = None

    def __post_init__(self) -> None:
        _require_id(self.episode_id, "episode_id")
        _require_id(self.request_revision, "request_revision")
        if not isinstance(self.descriptor, CapabilityDescriptor):
            raise ValueError(
                f"descriptor must be a CapabilityDescriptor, got {type(self.descriptor).__name__}"
            )
        if not isinstance(self.active_config, Configuration):
            raise ValueError(
                f"active_config must be a Configuration, got {type(self.active_config).__name__}"
            )
        if self.assigned_policy is not None:
            _require_id(self.assigned_policy, "assigned_policy")


@dataclass(frozen=True, slots=True)
class Decided:
    """A decision point resolved, one way or another.

    The invariants here mirror :class:`~vicaria_contracts.decision.DecisionRecord`'s on
    purpose. They are the same distinctions — a usable bundle would have made
    this a local decision, an unavailable one must say why — enforced where the
    decision is *made* rather than only where it is written down, so an
    inconsistent pair cannot survive long enough to become a record.
    """

    episode: Episode
    decision_id: str
    origin: DecisionOrigin
    plan: Plan | None = None
    validation: PlanValidation | None = None
    unavailable_reason: UnavailableReason | None = None
    policy_bundle_id: str | None = None

    def __post_init__(self) -> None:
        _require_id(self.decision_id, "decision_id")
        if not isinstance(self.episode, Episode):
            raise ValueError(
                f"episode must be an Episode, got {type(self.episode).__name__}"
            )
        if not isinstance(self.origin, DecisionOrigin):
            raise ValueError(
                f"origin must be a DecisionOrigin, got {type(self.origin).__name__}"
            )

        if self.origin is DecisionOrigin.UNAVAILABLE:
            if self.unavailable_reason is None:
                raise ValueError("an unavailable decision must say why")
            if self.plan is not None or self.validation is not None:
                raise ValueError(
                    "an unavailable decision carries no plan — a plan that arrived and was "
                    "refused is a decision, and the two must not be counted together"
                )
            if self.policy_bundle_id is not None:
                raise ValueError(
                    "an unavailable decision names no bundle: a usable bundle would have "
                    "made this a local decision"
                )
        else:
            if self.unavailable_reason is not None:
                raise ValueError(
                    f"a {self.origin.value} decision carries no unavailable reason"
                )
            if self.plan is None or self.validation is None:
                raise ValueError(
                    f"a {self.origin.value} decision must carry its plan and result"
                )
            if self.origin is DecisionOrigin.LOCAL and not self.policy_bundle_id:
                raise ValueError(
                    "a local decision must name the bundle that produced it"
                )

    @property
    def proceeds(self) -> bool:
        """True when a validated plan is ready to stage. Not the same as "no
        error": a ``cannot_execute`` plan is a correct response and proceeds
        nowhere."""
        return self.validation is not None and self.validation.ok


def decide(
    episode: Episode, plan: Plan, *, policy_bundle_id: str | None = None
) -> Decided:
    """Validate ``plan`` against what this client can do (§4.1).

    ``policy_bundle_id`` marks the decision as ``local`` — a cached bundle
    decided with no round trip. It is required there because a local decision
    that cannot be replayed is not auditable as a decision, which is the only
    thing separating it from ``unavailable``.
    """
    if not isinstance(plan, Plan):
        raise ValueError(f"plan must be a Plan, got {type(plan).__name__}")
    validation = validate_plan(
        plan,
        episode.descriptor,
        active_config=episode.active_config,
        current_request_revision=episode.request_revision,
    )
    return Decided(
        episode=episode,
        decision_id=plan.decision_id,
        origin=DecisionOrigin.LOCAL if policy_bundle_id else DecisionOrigin.SERVED,
        plan=plan,
        validation=validation,
        policy_bundle_id=policy_bundle_id,
    )


def no_decision(
    episode: Episode, reason: UnavailableReason, *, decision_id: str
) -> Decided:
    """No plan and no usable bundle (§4.3).

    ``decision_id`` is supplied by the caller because there is no plan to take
    one from, and §2.1 requires every record to carry one: without it the
    episode cannot be linked to the request that failed, and "the server
    declined to recommend" and "the server could not be reached" become the same
    hole in the evidence.
    """
    if not isinstance(reason, UnavailableReason):
        raise ValueError(
            f"reason must be an UnavailableReason, got {type(reason).__name__}"
        )
    return Decided(
        episode=episode,
        decision_id=decision_id,
        origin=DecisionOrigin.UNAVAILABLE,
        unavailable_reason=reason,
    )


@dataclass(frozen=True, slots=True)
class Dispatch:
    """What to send, and what to show. Every path produces a
    :class:`~vicaria_contracts.staging.CommitOutcome`, including the two that never reach
    the commit point, so one refusal vocabulary covers the whole client and a
    count of refusals is a count of everything that happened."""

    decided: Decided
    outcome: CommitOutcome
    surfaced: Configuration | None = None

    def __post_init__(self) -> None:
        if not isinstance(self.decided, Decided):
            raise ValueError("decided must be a Decided")
        if not isinstance(self.outcome, CommitOutcome):
            raise ValueError("outcome must be a CommitOutcome")
        if (
            self.surfaced is not None
            and self.outcome.action is not CommitAction.SURFACE
        ):
            raise ValueError(
                f"a {self.outcome.action.value} dispatch surfaces nothing, so carrying a "
                "proposal would show the user a recommendation this episode did not make"
            )
        if self.surfaced is None and self.outcome.action is CommitAction.SURFACE:
            raise ValueError("a surface dispatch must carry the proposal it surfaces")

    @property
    def dispatches(self) -> bool:
        return self.outcome.dispatches

    @property
    def applies(self) -> bool:
        return self.outcome.applies

    @property
    def config(self) -> Configuration | None:
        """The configuration to send to the provider, or ``None`` when nothing
        is sent.

        A ``surface`` dispatch sends the **reference**: the adapter cleared
        validation on the weaker claim that it could display the change, so what
        runs is what was already running. :attr:`surfaced` is the proposal, and
        keeping them in separate fields is what stops a caller from dispatching
        the thing it was only supposed to show.
        """
        action = self.outcome.action
        if action is CommitAction.CANNOT_EXECUTE:
            return None
        if action is CommitAction.MATERIALIZE:
            assert (
                self.decided.plan is not None
            )  # MATERIALIZE requires a validated plan
            return self.decided.plan.effective_config
        return self.decided.episode.active_config


def resolve(
    decided: Decided,
    staged: Sequence[StagedContribution] = (),
    confirmation: StagingConfirmation | Sequence[StagingConfirmation] | None = None,
    *,
    admit: Callable[[Configuration], Admission],
    expected_components: Sequence[str] | None = None,
) -> Dispatch:
    """Turn a resolved decision into a dispatch, through the commit point where
    there is one and through the same fallback gate where there is not.

    ``staged`` is passed on every path, including the ones with no plan. A
    caller that staged nothing passes nothing and the gate is a no-op; a caller
    that somehow applied something in-session before the decision resolved gets
    stopped rather than dispatched into an unknown session, which is the safer
    direction for a case that should not arise.
    """
    episode = decided.episode
    reference = episode.active_config

    if decided.origin is DecisionOrigin.UNAVAILABLE:
        # §4.3: a missing server is not a plan, and the reference runs. It is
        # still a dispatch decision, so it passes admission (§4.2.1) — a
        # configuration does not become permissible by being the one nobody
        # could tell us to change.
        assert (
            decided.unavailable_reason is not None
        )  # Decided.__post_init__ requires it
        return Dispatch(
            decided,
            reference_or_stop(
                staged,
                reference,
                admit,
                CommitRefusal.NO_DECISION,
                f"no decision was available ({decided.unavailable_reason.value}), so the "
                "configuration already running is what runs",
            ),
        )

    validation = decided.validation
    plan = decided.plan
    assert validation is not None and plan is not None  # guaranteed by Decided

    if validation.stop:
        # §4.5, and the ORDER is the check. `stop` implies `not ok`, so testing
        # `ok` first would send a cannot_execute plan down the fallback branch
        # below — the client converting a refusal into the exact configuration
        # it refused, which is worse than no refusal because it looks handled.
        # validate_plan keeps the same order one level down: a stale
        # cannot_execute still arrives here as `stop`, not as a stale refusal.
        # commit() short-circuits the disposition rather than a second copy of
        # the rule living here.
        return Dispatch(
            decided, commit(plan, staged, None, reference=reference, admit=admit)
        )

    if not validation.ok:
        assert (
            validation.refusal is not None
        )  # a failing, non-stopping validation names one
        return Dispatch(
            decided,
            reference_or_stop(
                staged,
                reference,
                admit,
                CommitRefusal.PLAN_REFUSED,
                f"plan refused at validation ({validation.refusal.value}): {validation.detail}",
            ),
        )

    outcome = commit(
        plan,
        staged,
        confirmation,
        reference=reference,
        admit=admit,
        expected_components=expected_components,
    )
    surfaced = plan.effective_config if outcome.action is CommitAction.SURFACE else None
    return Dispatch(decided, outcome, surfaced=surfaced)


@dataclass(frozen=True, slots=True)
class EpisodeRecords:
    """Everything one episode owes: the decision, the application when there was
    one, and the commit outcome that produced both."""

    decision: DecisionRecord
    outcome: CommitOutcome
    application: ApplicationRecord | None = None
    not_executed_reason: str | None = None

    def __post_init__(self) -> None:
        if self.decision.executed() != (self.application is not None):
            raise ValueError(
                "an executed episode owes an application record and an unexecuted one has "
                "nothing to describe; these two must not disagree"
            )
        if self.decision.executed() and self.not_executed_reason is not None:
            raise ValueError("an executed episode carries no reason for not executing")

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": EPISODE_RECORDS_SCHEMA_VERSION,
            "decision": self.decision.to_dict(),
            "application": self.application.to_dict() if self.application else None,
            "commit": self.outcome.to_dict(),
            "not_executed_reason": self.not_executed_reason,
        }


def _decision_record(
    dispatch: Dispatch, actual: Configuration | None
) -> DecisionRecord:
    decided = dispatch.decided
    return DecisionRecord(
        decision_id=decided.decision_id,
        episode_id=decided.episode.episode_id,
        origin=decided.origin,
        actual_config=actual,
        assigned_policy=decided.episode.assigned_policy,
        policy_bundle_id=decided.policy_bundle_id,
        unavailable_reason=decided.unavailable_reason,
    )


def executed(dispatch: Dispatch) -> EpisodeRecords:
    """The caller dispatched, and it reached a provider.

    Refuses a dispatch that decided to send nothing. "Nothing was dispatched"
    and "something ran" cannot both be true, and a record asserting both trains
    a configuration that never executed while counting a refusal that did.
    """
    if not dispatch.dispatches:
        raise ValueError(
            f"this dispatch is {dispatch.outcome.action.value} and reaches no provider, so "
            "nothing executed — record it with not_executed()"
        )
    actual = dispatch.config
    assert actual is not None  # dispatches is False only for cannot_execute
    return EpisodeRecords(
        decision=_decision_record(dispatch, actual),
        outcome=dispatch.outcome,
        # Recorded even when the effective request equals the original: §2.1's
        # four records are what separate "the recommendation did not help" from
        # "the recommendation was never applied", and a fallback is precisely
        # the second. `applied_nothing()` says which this was.
        application=ApplicationRecord(
            decision_id=dispatch.decided.decision_id,
            original=dispatch.decided.episode.active_config,
            effective=actual,
        ),
    )


def not_executed(dispatch: Dispatch, reason: str | None = None) -> EpisodeRecords:
    """Nothing reached a provider.

    Two different things end here and the distinction is preserved in the commit
    outcome rather than flattened: the client decided to dispatch nothing, or it
    decided to dispatch and the dispatch itself failed. Only the caller can tell
    us the second, which is why this is a function it calls rather than
    something :func:`resolve` concludes.
    """
    detail = reason or dispatch.outcome.detail
    return EpisodeRecords(
        decision=_decision_record(dispatch, None),
        outcome=dispatch.outcome,
        not_executed_reason=detail,
    )
