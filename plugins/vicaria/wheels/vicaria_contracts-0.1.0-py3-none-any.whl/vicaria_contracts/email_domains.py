"""vicaria.consumer-email-domains.v1: the mail providers' domains, and the rule
that reads an address's domain (vicaria-docs RFC 0047 §2.2, §2.4, D2, D3).

A work email's domain names the organization its owner belongs to; a mail
provider's address names none, so the person names one.  Which is which is
this list's to say and nothing else's: no operator mark, no per-tenant list,
no notion of a public domain of our own.  ``consumer_email_domains.json`` is
the data, copied from a maintained open list and refreshed from it; this
module reads it.

The domain is the part of the verified address after its last ``@``,
lower-cased, its Unicode labels in A-label (punycode) form, with no trailing
dot.  Plus-addressing is the local part's business and is not read.
"""

from __future__ import annotations

import json
import re
from functools import lru_cache
from typing import Any

import idna

from .resources import ROOT

#: The list itself, shipped with the package.
CONSUMER_EMAIL_DOMAINS = ROOT / "consumer_email_domains.json"
SCHEMA = "vicaria.consumer-email-domains.v1"

#: One DNS label in A-label form: letters, digits and hyphens, neither first
#: nor last a hyphen, at most 63 octets.
LABEL = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")


@lru_cache(maxsize=1)
def load() -> dict[str, Any]:
    """The whole document, read once."""
    document = json.loads(CONSUMER_EMAIL_DOMAINS.read_text(encoding="utf-8"))
    if document.get("schema") != SCHEMA:
        raise ValueError(f"{CONSUMER_EMAIL_DOMAINS} is not {SCHEMA}")
    return document


@lru_cache(maxsize=1)
def mail_providers() -> frozenset[str]:
    """Every mail provider's domain the list holds, normalized as :func:`normalize_domain`:
    the copied list and the ``additions``, less the ``exclusions`` (domains the
    source lists that are not a mail provider's, found in review)."""
    document = load()
    return frozenset(document["domains"]) - frozenset(document.get("exclusions", []))


def normalize_domain(domain: str) -> str | None:
    """RFC 0047 §2.2's spelling of a domain, or ``None`` for a string that is
    not a domain of two or more labels.  Lower-cased, each Unicode label in
    A-label form, no trailing dot."""
    if not isinstance(domain, str):
        return None
    text = domain.strip().lower().rstrip(".")
    if not text or len(text) > 253:
        return None
    # IDNA 2008 with UTS #46 mapping and no transitional processing (found in
    # review: Python's codec is IDNA 2003, under which ``straße.de`` became
    # ``strasse.de`` --- another domain --- while its A-label stayed itself,
    # so one domain had two keys and two domains one).  An A-label given as
    # such must round-trip, or it is not a domain.
    try:
        text = idna.encode(text, uts46=True, transitional=False, std3_rules=True).decode("ascii")
        if idna.encode(idna.decode(text), uts46=True, transitional=False).decode("ascii") != text:
            return None
    except (idna.IDNAError, UnicodeError, ValueError):
        return None
    labels = text.split(".")
    if len(labels) < 2 or not all(LABEL.match(label) for label in labels):
        return None
    if labels[-1].isdigit():
        return None  # an address at an IP literal names no domain
    return text


def domain_of(email: str) -> str | None:
    """The domain of an address: what follows its last ``@``, normalized; ``None``
    when there is no address to read."""
    if not isinstance(email, str) or "@" not in email:
        return None
    _, _, domain = email.strip().rpartition("@")
    return normalize_domain(domain)


def is_mail_provider(domain: str | None) -> bool:
    """Whether a normalized domain is a mail provider's (D3).  A domain the list
    does not hold is a company's, a university's or a shared host's; a string
    that is not a domain is nobody's and answers ``False``."""
    normalized = normalize_domain(domain) if domain is not None else None
    return normalized is not None and normalized in mail_providers()


__all__ = ["CONSUMER_EMAIL_DOMAINS", "LABEL", "SCHEMA", "domain_of", "is_mail_provider",
           "load", "mail_providers", "normalize_domain"]
