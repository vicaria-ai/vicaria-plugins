"""The control conformance suite (RFC 0009 §6).

WHY THIS EXISTS

``docs/harness-support.md`` records what each harness is *claimed* to expose. A
claim becomes support when a conformance run passes against a named harness
version, and reverts when that run fails. This module is what produces that
result.

WHAT IT REFUSES TO DO

Call something supported that it did not verify. :meth:`ConformanceReport.supported`
is true only when **all ten** checks passed; a check that did not run is not a
check that passed, and the distinction is the entire point. A suite that graded
eight passes and two skips as "supported" would produce exactly the claim the
register exists to avoid.

It also refuses to generalize. A report names the harness version it ran
against, because passing on 2.1.261 says nothing about 2.2.0 — the drift that
``scripts/conformance_check.py`` was written to catch is vendor drift, and it is
the reason fixtures cannot stand in for a live run.

ALL TEN CHECKS NEED THE ADAPTER

An earlier version answered checks 6, 9 and 10 from shared-library calls and
called them "contract logic". That was a certification hole, and it was
reproducible: a driver exercising only [1, 2, 5, 7, 8] received **"SUPPORTED —
10 passed"** while nothing had induced a cross-component failure or watched a
single provider request.

The RFC is specific about why those three cannot be answered here. Check 6
requires the in-harness component *induced to fail*. Checks 9 and 10 both
require **zero provider requests, counted at the wire rather than inferred from
the adapter's own logs** — which is exactly the observation a library call
cannot make, since the library is the thing the adapter is supposed to be using
correctly. Asking it whether the adapter used it correctly is asking the wrong
party.

So every check is delegated. With no driver the whole report is ``NOT_RUN`` and
unsupported, which is the accurate state of a system with no adapter.

:func:`run_contract_regression` remains, renamed for what it is: a regression
net over the shipped modules. It produces no ``ConformanceReport`` and cannot
contribute to a support claim, because "the library still behaves" and "this
adapter conforms" are different assertions and only one of them is what
``docs/harness-support.md`` records.

No mock driver ships with this module. A fake harness that passes proves the
fake agrees with us.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass, field
from enum import Enum, IntEnum
from typing import Any, Protocol, runtime_checkable

from vicaria_contracts.capability import (
    CapabilityDescriptor,
    Control,
    ControlLevel,
    Dimension,
    PromptShape,
    ValueSupport,
)
from vicaria_contracts.client import Episode, decide, no_decision, resolve
from vicaria_contracts.decision import UnavailableReason
from vicaria_contracts.plan import (
    Configuration,
    Disposition,
    Plan,
    Refusal,
    validate_plan,
)
from vicaria_contracts.staging import (
    Admission,
    CommitAction,
    CommitRefusal,
    ContributionClass,
    StagedContribution,
    commit,
    contribution_digest,
)

CONFORMANCE_REPORT_SCHEMA_VERSION = "vicaria.conformance-report.v1"


class CheckId(IntEnum):
    """The ten checks of RFC 0009 §6, numbered as the RFC numbers them."""

    INTERCEPTION = 1
    DECLARED_MUTATIONS = 2
    LEVEL_HONORED = 3
    STALE_BASELINE_REFUSED = 4
    TOOL_EXECUTION = 5
    CROSS_COMPONENT_ATOMICITY = 6
    EVENT_COMPLETENESS = 7
    SERVER_UNAVAILABLE_RECOVERY = 8
    CANNOT_EXECUTE_STOPS = 9
    INADMISSIBLE_FALLBACK_STOPS = 10


#: **Every** check is harness-dependent. An earlier split kept 6, 9 and 10 as
#: "contract logic" the suite could answer itself, and that was a certification
#: hole: a driver exercising only [1, 2, 5, 7, 8] received "SUPPORTED — 10
#: passed" while nothing had induced a cross-component failure, dispatched a
#: `cannot_execute`, or observed the wire.
#:
#: Re-read against the RFC, those three are adapter behavior and say so: check 6
#: requires the in-harness component *induced to fail*, and 9 and 10 both require
#: **zero provider requests counted at the wire, not inferred from the adapter's
#: own logs**. A shared-library call cannot satisfy any of that — the library is
#: what the adapter is supposed to be using correctly, so asking it is asking the
#: wrong party.
HARNESS_DEPENDENT = frozenset(CheckId)
CONTRACT_LOGIC: frozenset[CheckId] = frozenset()


class CheckStatus(str, Enum):
    PASSED = "passed"
    FAILED = "failed"
    NOT_RUN = "not_run"  # never counted as a pass


@dataclass(frozen=True, slots=True)
class CheckResult:
    check: CheckId
    status: CheckStatus
    detail: str

    def __post_init__(self) -> None:
        if not isinstance(self.check, CheckId):
            raise ValueError("check must be a CheckId")
        if not isinstance(self.status, CheckStatus):
            raise ValueError("status must be a CheckStatus")
        if not self.detail:
            raise ValueError(
                f"check {int(self.check)} must say what happened — a bare status is not a "
                "result anyone can act on"
            )

    def to_dict(self) -> dict[str, Any]:
        return {
            "check": int(self.check),
            "name": self.check.name.lower(),
            "status": self.status.value,
            "detail": self.detail,
        }


@runtime_checkable
class ConformanceDriver(Protocol):
    """What an adapter supplies so its harness-dependent checks can run.

    Each method drives a *real* harness and returns what it observed. Returning
    a passing result without having driven anything is the one thing that
    defeats the suite, and no amount of typing prevents it — which is why a row
    in the support register names the adapter version that produced it.
    """

    def harness_identity(self) -> tuple[str, str, str]:
        """``(harness, harness_version, adapter_version)`` for the report."""
        ...

    def check_interception(self) -> CheckResult: ...
    def check_declared_mutations(self) -> CheckResult: ...
    def check_level_honored(self) -> CheckResult: ...
    def check_stale_baseline_refused(self) -> CheckResult: ...
    def check_tool_execution(self) -> CheckResult: ...

    def check_cross_component_atomicity(self) -> CheckResult:
        """Induce the in-harness component to fail *after* staging succeeds, and
        observe that the reference runs — not the staged contribution against
        the reference model."""
        ...

    def check_event_completeness(self) -> CheckResult: ...
    def check_server_unavailable_recovery(self) -> CheckResult: ...

    def check_cannot_execute_stops(self) -> CheckResult:
        """Observe **zero provider requests at the wire**. Counting from the
        adapter's own logs would let an adapter that fell through to the
        reference report a clean stop."""
        ...

    def check_inadmissible_fallback_stops(self) -> CheckResult:
        """The same wire observation, for a *valid* plan whose staging fails
        against an inadmissible reference. Unreachable through the check above:
        the service returned a correct recommendation."""
        ...


@dataclass(frozen=True, slots=True)
class ConformanceReport:
    """The result of one run, against one named harness version."""

    harness: str
    harness_version: str
    adapter_version: str
    results: Sequence[CheckResult] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        for name in ("harness", "harness_version", "adapter_version"):
            value = getattr(self, name)
            if not isinstance(value, str) or not value:
                raise ValueError(f"{name} must be a nonempty string, got {value!r}")
        seen = [r.check for r in self.results]
        if len(seen) != len(set(seen)):
            raise ValueError("a report carries at most one result per check")
        missing = set(CheckId) - set(seen)
        if missing:
            names = sorted(int(c) for c in missing)
            raise ValueError(
                f"a report must account for every check; {names} are absent. An absent "
                "check is indistinguishable from one nobody thought to run"
            )
        object.__setattr__(
            self, "results", tuple(sorted(self.results, key=lambda r: r.check))
        )

    def by_status(self, status: CheckStatus) -> tuple[CheckResult, ...]:
        return tuple(r for r in self.results if r.status is status)

    def supported(self) -> bool:
        """True only when every check passed on this harness version.

        Not "nothing failed". A check that did not run did not pass, and
        treating the two alike is how a register of claims turns into a
        register of claims that look like results.
        """
        return all(r.status is CheckStatus.PASSED for r in self.results)

    def summary(self) -> str:
        passed = len(self.by_status(CheckStatus.PASSED))
        failed = len(self.by_status(CheckStatus.FAILED))
        skipped = len(self.by_status(CheckStatus.NOT_RUN))
        verdict = "SUPPORTED" if self.supported() else "NOT SUPPORTED"
        return (
            f"{verdict}: {self.harness} {self.harness_version} "
            f"(adapter {self.adapter_version}) — "
            f"{passed} passed, {failed} failed, {skipped} not run"
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "schema": CONFORMANCE_REPORT_SCHEMA_VERSION,
            "harness": self.harness,
            "harness_version": self.harness_version,
            "adapter_version": self.adapter_version,
            "supported": self.supported(),
            "results": [r.to_dict() for r in self.results],
        }


# --- the five contract-logic checks ---------------------------------------
#
# These exercise the shipped modules rather than restating their rules, so a
# regression in the contract fails the suite rather than being described by it.

_BASE = Configuration(
    model="reference-model",
    effort="high",
    prompt="recipe:base@v1",
    tools="profile:readonly@v1",
    workflow="workflow:probe@v1",
)
_CHEAPER = Configuration(
    model="cheaper-model",
    effort="low",
    prompt="recipe:base@v1",
    tools="profile:readonly@v1",
    workflow="workflow:probe@v1",
)


#: Declared rather than left silent: an undeclared value set admits nothing, so
#: a descriptor that named only levels would refuse every plan these scenarios
#: are about, and the regression net would stop testing what it claims to.
_MODELS = frozenset({"reference-model", "cheaper-model", "something-else"})
_EFFORTS = frozenset({"high", "low"})


def _descriptor(model: ControlLevel, effort: ControlLevel) -> CapabilityDescriptor:
    return CapabilityDescriptor(
        harness="contract",
        harness_version="n/a",
        adapter_version="n/a",
        controls={
            Dimension.MODEL: Control(model, values=_MODELS),
            Dimension.EFFORT: Control(effort, values=_EFFORTS),
            Dimension.PROMPT: Control(
                ControlLevel.APPLY, values=ValueSupport.UNRESTRICTED
            ),
            Dimension.TOOLS: Control(ControlLevel.OBSERVE),
            Dimension.WORKFLOW: Control(ControlLevel.OBSERVE),
        },
        prompt_shape=PromptShape.ADDITIVE,
    )


def _plan(disposition: Disposition, **kw: Any) -> Plan:
    fields: dict[str, Any] = {
        "decision_id": "conformance",
        "request_revision": "req-1",
        "base_config_digest": _BASE.digest(),
        "disposition": disposition,
        "effective_config": _CHEAPER,
    }
    fields.update(kw)
    return Plan(**fields)


def _result(check: CheckId, ok: bool, detail: str) -> CheckResult:
    return CheckResult(
        check=check,
        status=CheckStatus.PASSED if ok else CheckStatus.FAILED,
        detail=detail,
    )


def _check_level_honored() -> CheckResult:
    constrained = _descriptor(ControlLevel.SUGGEST, ControlLevel.SUGGEST)
    refused = validate_plan(
        _plan(Disposition.APPLY),
        constrained,
        active_config=_BASE,
        current_request_revision="req-1",
    )
    served = validate_plan(
        _plan(Disposition.SUGGEST),
        constrained,
        active_config=_BASE,
        current_request_revision="req-1",
    )
    undeclared = validate_plan(
        _plan(Disposition.SUGGEST),
        _descriptor(ControlLevel.UNKNOWN, ControlLevel.SUGGEST),
        active_config=_BASE,
        current_request_revision="req-1",
    )
    ok = (
        refused.refusal is Refusal.INSUFFICIENT_LEVEL
        and served.ok
        and undeclared.refusal is Refusal.INSUFFICIENT_LEVEL
    )
    return _result(
        CheckId.LEVEL_HONORED,
        ok,
        "apply refused and suggest served on a suggest-level control; an undeclared "
        "control refused at both",
    )


def _check_stale_baseline_refused() -> CheckResult:
    moved = Configuration(
        model="something-else",
        effort=_BASE.effort,
        prompt=_BASE.prompt,
        tools=_BASE.tools,
        workflow=_BASE.workflow,
    )
    descriptor = _descriptor(ControlLevel.APPLY, ControlLevel.APPLY)
    baseline = validate_plan(
        _plan(Disposition.APPLY),
        descriptor,
        active_config=moved,
        current_request_revision="req-1",
    )
    stale = validate_plan(
        _plan(Disposition.APPLY),
        descriptor,
        active_config=_BASE,
        current_request_revision="req-2",
    )
    ok = (
        baseline.refusal is Refusal.BASELINE_MISMATCH
        and stale.refusal is Refusal.STALE_REQUEST_REVISION
    )
    return _result(
        CheckId.STALE_BASELINE_REFUSED,
        ok,
        "a moved baseline and a superseded request revision are both refused before execution",
    )


def _check_cross_component_atomicity() -> CheckResult:
    """Three scenarios, and the second and third are the ones that catch a
    design which only *looks* atomic: staging succeeded and the reference still
    runs, and — where the session can no longer *be* the reference — nothing
    runs at all."""
    plan = _plan(Disposition.APPLY)
    digest = contribution_digest([Dimension.MODEL], {"model": "cheaper-model"})

    def contribution(cls: ContributionClass) -> StagedContribution:
        return StagedContribution(
            component="in-harness",
            dimensions=frozenset({Dimension.MODEL}),
            contribution_class=cls,
            digest=digest,
        )

    def permitted(_config: Configuration) -> Admission:
        return Admission(admitted=True)

    before_staging = commit(plan, [], None, reference=_BASE, admit=permitted)
    after_staging = commit(
        plan,
        [contribution(ContributionClass.STAGEABLE)],
        None,
        reference=_BASE,
        admit=permitted,
    )
    # The reference is only a fallback while the session is still at it. An
    # irreversible contribution has already changed the session, so "dispatch
    # the reference" would dispatch something else under the reference's name.
    unrestored = commit(
        plan,
        [contribution(ContributionClass.NEITHER)],
        None,
        reference=_BASE,
        admit=permitted,
    )
    ok = (
        before_staging.action is CommitAction.MATERIALIZE
        and after_staging.action is CommitAction.REFERENCE
        and not unrestored.dispatches
        and unrestored.refusal is CommitRefusal.UNSTAGEABLE_CONTRIBUTION
    )
    return _result(
        CheckId.CROSS_COMPONENT_ATOMICITY,
        ok,
        "with staging successful and confirmation absent the reference runs rather than "
        "the staged contribution against the reference model; and where a contribution "
        "cannot be taken back, nothing runs at all",
    )


def _episode(**kw: Any) -> Episode:
    fields: dict[str, Any] = {
        "episode_id": "conformance",
        "descriptor": _descriptor(ControlLevel.APPLY, ControlLevel.APPLY),
        "active_config": _BASE,
        "request_revision": "req-1",
    }
    fields.update(kw)
    return Episode(**fields)


def _check_cannot_execute_stops() -> CheckResult:
    """Driven through the client core, not through ``commit`` directly.

    The regression this check describes is a *client* one — "an adapter that
    treats the response as unsupported and falls through to the reference fails
    this check". Calling ``commit`` with the plan short-circuits on the
    disposition and never exercises any client, so the earlier version of this
    scenario could not have caught the regression it names. ``resolve`` is where
    the ordering lives, so ``resolve`` is what is driven.
    """
    plan = _plan(
        Disposition.CANNOT_EXECUTE,
        effective_config=None,
        reason="no admissible configuration",
    )
    decided = decide(_episode(), plan)
    dispatch = resolve(decided, admit=lambda _c: Admission(admitted=True))
    ok = (
        decided.validation is not None
        and decided.validation.stop
        and not decided.proceeds
        and not dispatch.dispatches
        and dispatch.config is None
    )
    return _result(
        CheckId.CANNOT_EXECUTE_STOPS,
        ok,
        "a cannot_execute plan stops the client and reaches no provider, even with an "
        "admission oracle that would have permitted the reference",
    )


def _check_inadmissible_fallback_stops() -> CheckResult:
    """All three reference dispatches, not just the one the commit point sees.

    Deliberately unreachable through check 9 — no plan here is refused by the
    service. A client that guards only the commit point's fallback passes 9 and
    fails on the two dispatches that never reach a commit point at all.
    """

    def prohibited(_config: Configuration) -> Admission:
        return Admission(admitted=False, reason="reference provider prohibited")

    digest = contribution_digest([Dimension.MODEL], {"model": "cheaper-model"})
    staged = [
        StagedContribution(
            component="in-harness",
            dimensions=frozenset({Dimension.MODEL}),
            contribution_class=ContributionClass.STAGEABLE,
            digest=digest,
        )
    ]

    # 1. A valid plan whose staging failed: the commit point's own fallback.
    valid = decide(_episode(), _plan(Disposition.APPLY))
    after_staging = resolve(valid, staged, None, admit=prohibited)

    # 2. No plan at all. No commit point runs, and the reference still runs.
    unreachable = no_decision(
        _episode(), UnavailableReason.UNREACHABLE, decision_id="conformance-local"
    )
    no_plan = resolve(unreachable, admit=prohibited)

    # 3. A plan validation refused. Same: the refusal is recorded and the
    #    reference would run, so the reference is admitted first.
    stale = decide(_episode(request_revision="req-2"), _plan(Disposition.APPLY))
    refused = resolve(stale, admit=prohibited)

    dispatches = [after_staging, no_plan, refused]
    ok = (
        valid.proceeds
        and not stale.proceeds
        and all(not d.dispatches for d in dispatches)
        and all(d.outcome.admission_reason is not None for d in dispatches)
    )
    return _result(
        CheckId.INADMISSIBLE_FALLBACK_STOPS,
        ok,
        "all three reference dispatches reach no provider when the reference is itself "
        "inadmissible — a failed stage, an unavailable decision, and a refused plan — "
        "and each records both reasons",
    )


_CONTRACT_CHECKS = {
    CheckId.LEVEL_HONORED: _check_level_honored,
    CheckId.STALE_BASELINE_REFUSED: _check_stale_baseline_refused,
    CheckId.CROSS_COMPONENT_ATOMICITY: _check_cross_component_atomicity,
    CheckId.CANNOT_EXECUTE_STOPS: _check_cannot_execute_stops,
    CheckId.INADMISSIBLE_FALLBACK_STOPS: _check_inadmissible_fallback_stops,
}

_NO_DRIVER = (
    "no conformance driver supplied; this check drives a real harness and is not "
    "simulated, because a fake harness that passes proves the fake agrees with us"
)


def run_conformance(driver: ConformanceDriver | None = None) -> ConformanceReport:
    """Run every check against ``driver``. All ten are the adapter's to answer.

    With no driver every check reports ``NOT_RUN`` and the report is not
    supported — the accurate state of a system in which no adapter exists.
    """
    if driver is None:
        return ConformanceReport(
            harness="none",
            harness_version="not-run",
            adapter_version="not-run",
            results=[CheckResult(c, CheckStatus.NOT_RUN, _NO_DRIVER) for c in CheckId],
        )

    harness, harness_version, adapter_version = driver.harness_identity()
    delegated = {
        CheckId.INTERCEPTION: driver.check_interception,
        CheckId.DECLARED_MUTATIONS: driver.check_declared_mutations,
        CheckId.LEVEL_HONORED: driver.check_level_honored,
        CheckId.STALE_BASELINE_REFUSED: driver.check_stale_baseline_refused,
        CheckId.TOOL_EXECUTION: driver.check_tool_execution,
        CheckId.CROSS_COMPONENT_ATOMICITY: driver.check_cross_component_atomicity,
        CheckId.EVENT_COMPLETENESS: driver.check_event_completeness,
        CheckId.SERVER_UNAVAILABLE_RECOVERY: driver.check_server_unavailable_recovery,
        CheckId.CANNOT_EXECUTE_STOPS: driver.check_cannot_execute_stops,
        CheckId.INADMISSIBLE_FALLBACK_STOPS: driver.check_inadmissible_fallback_stops,
    }
    results = []
    for check_id, run in delegated.items():
        result = run()
        if result.check is not check_id:
            raise ValueError(
                f"driver returned a result for check {int(result.check)} when asked for "
                f"{int(check_id)}; a misfiled result would credit a check nobody ran"
            )
        results.append(result)

    return ConformanceReport(
        harness=harness,
        harness_version=harness_version,
        adapter_version=adapter_version,
        results=results,
    )


def run_contract_regression() -> tuple[CheckResult, ...]:
    """Exercise the shipped modules. **Not** a conformance result.

    These are the same scenarios checks 3, 4, 6, 9 and 10 describe, run against
    the library rather than against an adapter — so they catch a regression in
    `capability`/`plan`/`staging`, and they establish nothing about any harness.
    They return bare results rather than a :class:`ConformanceReport` precisely
    so they cannot be mistaken for one or merged into one.
    """
    return tuple(check() for check in _CONTRACT_CHECKS.values())
